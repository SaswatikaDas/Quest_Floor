globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js",
    "static/development/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
    "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
    "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
    "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
    "static/chunks/node_modules_next_dist_1e8vcs8._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
    "static/chunks/_1anvha4._.js",
    "static/chunks/turbopack-_08bm286._.js"
  ],
  "rootMainFilesTree": {
    "/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
      "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
      "static/chunks/node_modules_next_dist_1e8vcs8._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
      "static/chunks/_1anvha4._.js",
      "static/chunks/turbopack-_08bm286._.js",
      "static/chunks/_219uq1s._.js"
    ]
  },
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
