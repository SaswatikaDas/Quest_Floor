@echo off
echo =========================================================================
echo 🏪 RetailRise / QuestFloor: Enterprise Retail Platform Launch
echo Python FastAPI Backend (Port 8000) + React Next.js Frontend (Port 3000)
echo =========================================================================

start "QuestFloor Backend (FastAPI)" cmd /k "python backend/run.py"
start "QuestFloor Frontend (React Next.js)" cmd /k "npm run dev"

echo Servers started!
echo Frontend: http://localhost:3000
echo Backend API & Docs: http://localhost:8000/docs
