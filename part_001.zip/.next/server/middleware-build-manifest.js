globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/nBQGHhScUVpyUdp5aIdfH/_buildManifest.js",
    "static/nBQGHhScUVpyUdp5aIdfH/_ssgManifest.js",
    "static/nBQGHhScUVpyUdp5aIdfH/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1inwntv0b4r-7.js",
    "static/chunks/3l55y_b874rx7.js",
    "static/chunks/3byuobrkyz9bj.js",
    "static/chunks/turbopack-3l7p4iryw728u.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
