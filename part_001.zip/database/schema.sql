-- ============================================================================
-- QuestFloor – AI Workforce Engagement & Customer Experience Platform
-- Production PostgreSQL & Supabase Database Schema
-- Multi-Tenant, Role-Based Security (RLS), Indexed for Scale (1,200+ Stores)
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- 1. STORES & REGIONAL HUBS
-- ============================================================================
CREATE TABLE IF NOT EXISTS stores (
    id VARCHAR(50) PRIMARY KEY,
    code VARCHAR(30) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    city VARCHAR(80) NOT NULL,
    state VARCHAR(80) NOT NULL,
    tier VARCHAR(20) DEFAULT 'Tier-3' CHECK (tier IN ('Tier-1', 'Tier-2', 'Tier-3')),
    address TEXT,
    pincode VARCHAR(10),
    active_associates INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_stores_city ON stores(city);
CREATE INDEX idx_stores_tier ON stores(tier);

-- ============================================================================
-- 2. USERS & AUTH ROLES (Supabase Auth Integration)
-- ============================================================================
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('EMPLOYEE', 'MANAGER', 'ADMIN')),
    full_name VARCHAR(120) NOT NULL,
    phone VARCHAR(20),
    avatar_url TEXT,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_email ON users(email);

-- ============================================================================
-- 3. MANAGERS & STORE ALLOCATIONS
-- ============================================================================
CREATE TABLE IF NOT EXISTS managers (
    id VARCHAR(50) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(100) DEFAULT 'Store Manager',
    region VARCHAR(100) DEFAULT 'Central India'
);

CREATE TABLE IF NOT EXISTS manager_stores (
    manager_id VARCHAR(50) REFERENCES managers(id) ON DELETE CASCADE,
    store_id VARCHAR(50) REFERENCES stores(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (manager_id, store_id)
);

-- ============================================================================
-- 4. EMPLOYEES / STORE ASSOCIATES
-- ============================================================================
CREATE TABLE IF NOT EXISTS employees (
    id VARCHAR(50) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    store_id VARCHAR(50) NOT NULL REFERENCES stores(id) ON DELETE RESTRICT,
    points INT DEFAULT 0 CHECK (points >= 0),
    weekly_points INT DEFAULT 0 CHECK (weekly_points >= 0),
    monthly_points INT DEFAULT 0 CHECK (monthly_points >= 0),
    current_level INT DEFAULT 1 CHECK (current_level BETWEEN 1 AND 5),
    pos_adoption_rate INT DEFAULT 50 CHECK (pos_adoption_rate BETWEEN 0 AND 100),
    customer_feedback_score INT DEFAULT 70 CHECK (customer_feedback_score BETWEEN 0 AND 100),
    sales_conversion_rate INT DEFAULT 50 CHECK (sales_conversion_rate BETWEEN 0 AND 100),
    engagement_score INT DEFAULT 70 CHECK (engagement_score BETWEEN 0 AND 100),
    avatar_color VARCHAR(20) DEFAULT '#F3A712',
    join_date DATE DEFAULT CURRENT_DATE
);

CREATE INDEX idx_employees_store ON employees(store_id);
CREATE INDEX idx_employees_points ON employees(points DESC);

-- ============================================================================
-- 5. TRAINING MODULES, LESSONS & QUIZZES
-- ============================================================================
CREATE TABLE IF NOT EXISTS training_modules (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN (
        'Product Knowledge', 'Customer Service', 'POS Training', 'Sales Skills', 'Company Policies'
    )),
    duration VARCHAR(20) DEFAULT '5 min',
    points_reward INT DEFAULT 100,
    emoji VARCHAR(10) DEFAULT '📚',
    description TEXT,
    key_points JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS quiz_questions (
    id VARCHAR(50) PRIMARY KEY,
    module_id VARCHAR(50) NOT NULL REFERENCES training_modules(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    options JSONB NOT NULL, -- Array of strings e.g. ["A", "B", "C", "D"]
    correct_option_index INT NOT NULL,
    explanation TEXT
);

CREATE INDEX idx_quiz_module ON quiz_questions(module_id);

-- ============================================================================
-- 6. EMPLOYEE PROGRESS & QUIZ ATTEMPTS
-- ============================================================================
CREATE TABLE IF NOT EXISTS employee_progress (
    id VARCHAR(50) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    employee_id VARCHAR(50) NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    module_id VARCHAR(50) NOT NULL REFERENCES training_modules(id) ON DELETE CASCADE,
    score_pct INT NOT NULL CHECK (score_pct BETWEEN 0 AND 100),
    passed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(employee_id, module_id)
);

CREATE INDEX idx_emp_progress ON employee_progress(employee_id, passed);

-- ============================================================================
-- 7. BADGES & RECOGNITION
-- ============================================================================
CREATE TABLE IF NOT EXISTS badges (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    icon VARCHAR(10) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) DEFAULT 'General'
);

CREATE TABLE IF NOT EXISTS employee_badges (
    employee_id VARCHAR(50) REFERENCES employees(id) ON DELETE CASCADE,
    badge_id VARCHAR(50) REFERENCES badges(id) ON DELETE CASCADE,
    unlocked_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (employee_id, badge_id)
);

-- ============================================================================
-- 8. GAMIFIED CHALLENGES
-- ============================================================================
CREATE TABLE IF NOT EXISTS challenges (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('daily', 'weekly')),
    reward_points INT DEFAULT 100 CHECK (reward_points > 0),
    icon VARCHAR(50) DEFAULT 'Target',
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS challenge_completions (
    challenge_id VARCHAR(50) REFERENCES challenges(id) ON DELETE CASCADE,
    employee_id VARCHAR(50) REFERENCES employees(id) ON DELETE CASCADE,
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (challenge_id, employee_id)
);

-- ============================================================================
-- 9. PEER RECOGNITION & CLAPS
-- ============================================================================
CREATE TABLE IF NOT EXISTS recognitions (
    id VARCHAR(50) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    from_user_id VARCHAR(50) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    to_user_id VARCHAR(50) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    category VARCHAR(50) NOT NULL CHECK (category IN (
        'Customer Service', 'Teamwork', 'Problem Solving', 'Knowledge Sharing', 'Sales Excellence'
    )),
    message TEXT NOT NULL,
    likes_count INT DEFAULT 0 CHECK (likes_count >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS recognition_likes (
    recognition_id VARCHAR(50) REFERENCES recognitions(id) ON DELETE CASCADE,
    user_id VARCHAR(50) REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (recognition_id, user_id)
);

CREATE INDEX idx_recognitions_to ON recognitions(to_user_id);

-- ============================================================================
-- 10. REAL-TIME NOTIFICATIONS & ALERTS
-- ============================================================================
CREATE TABLE IF NOT EXISTS notifications (
    id VARCHAR(50) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    recipient_id VARCHAR(50) NOT NULL, -- User ID or 'all'
    icon VARCHAR(50) DEFAULT 'Bell',
    text TEXT NOT NULL,
    read BOOLEAN DEFAULT FALSE,
    action_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifs_recipient ON notifications(recipient_id, read);

-- ============================================================================
-- 11. DAILY PERFORMANCE & CUSTOMER SATISFACTION TELEMETRY
-- ============================================================================
CREATE TABLE IF NOT EXISTS performance_metrics (
    id VARCHAR(50) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    employee_id VARCHAR(50) NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    record_date DATE DEFAULT CURRENT_DATE,
    pos_transactions_count INT DEFAULT 0,
    pos_error_count INT DEFAULT 0,
    upsell_attempts INT DEFAULT 0,
    upsell_successes INT DEFAULT 0,
    customer_feedback_avg NUMERIC(3,1) DEFAULT 4.5,
    UNIQUE(employee_id, record_date)
);

CREATE INDEX idx_metrics_emp_date ON performance_metrics(employee_id, record_date);

-- ============================================================================
-- 12. AI GENERATED QUIZZES & ADAPTIVE STUDIO
-- ============================================================================
CREATE TABLE IF NOT EXISTS ai_quiz_drafts (
    id VARCHAR(50) PRIMARY KEY,
    product_name VARCHAR(150) NOT NULL,
    skill_domain VARCHAR(50) NOT NULL,
    difficulty VARCHAR(20) NOT NULL,
    language VARCHAR(30) DEFAULT 'English',
    time_limit_minutes INT DEFAULT 4,
    questions_json JSONB NOT NULL,
    challenge_title VARCHAR(200),
    reward_points INT DEFAULT 120,
    published BOOLEAN DEFAULT FALSE,
    created_by VARCHAR(50) REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- 13. SEED DATA FOR TIER-3 EXPANSION (10 Associates, 3 Managers, 5 Stores)
-- ============================================================================

INSERT INTO stores (id, code, name, city, state, tier, active_associates) VALUES
('s1', 'QF-NGP-01', 'QuestFloor Nagpur Central', 'Nagpur', 'Maharashtra', 'Tier-3', 4),
('s2', 'QF-IND-02', 'QuestFloor Indore Palasia', 'Indore', 'Madhya Pradesh', 'Tier-3', 5),
('s3', 'QF-JPR-03', 'QuestFloor Jaipur Malviya Nagar', 'Jaipur', 'Rajasthan', 'Tier-3', 4),
('s4', 'QF-CBE-04', 'QuestFloor Coimbatore RS Puram', 'Coimbatore', 'Tamil Nadu', 'Tier-3', 4),
('s5', 'QF-PAT-05', 'QuestFloor Patna Boring Road', 'Patna', 'Bihar', 'Tier-3', 3)
ON CONFLICT (id) DO NOTHING;

INSERT INTO users (id, email, role, full_name) VALUES
('admin1', 'neha.kapoor@questfloor.in', 'ADMIN', 'Neha Kapoor'),
('mgr1', 'anil.deshmukh@questfloor.in', 'MANAGER', 'Anil Deshmukh'),
('mgr2', 'rekha.menon@questfloor.in', 'MANAGER', 'Rekha Menon'),
('mgr3', 'sanjay.gupta@questfloor.in', 'MANAGER', 'Sanjay Gupta'),
('e1', 'sneha.patil@questfloor.in', 'EMPLOYEE', 'Sneha Patil'),
('e2', 'rahul.verma@questfloor.in', 'EMPLOYEE', 'Rahul Verma'),
('e3', 'ayesha.khan@questfloor.in', 'EMPLOYEE', 'Ayesha Khan'),
('e4', 'vikram.singh@questfloor.in', 'EMPLOYEE', 'Vikram Singh'),
('e5', 'priya.nair@questfloor.in', 'EMPLOYEE', 'Priya Nair'),
('e6', 'arjun.reddy@questfloor.in', 'EMPLOYEE', 'Arjun Reddy'),
('e7', 'meera.iyer@questfloor.in', 'EMPLOYEE', 'Meera Iyer'),
('e8', 'karan.malhotra@questfloor.in', 'EMPLOYEE', 'Karan Malhotra'),
('e9', 'divya.sharma@questfloor.in', 'EMPLOYEE', 'Divya Sharma'),
('e10', 'suresh.kumar@questfloor.in', 'EMPLOYEE', 'Suresh Kumar')
ON CONFLICT (id) DO NOTHING;

INSERT INTO managers (id, title, region) VALUES
('mgr1', 'Senior Store Manager', 'Nagpur & Indore'),
('mgr2', 'Cluster Manager', 'Jaipur & Coimbatore'),
('mgr3', 'Regional Operations Manager', 'Patna Hub')
ON CONFLICT (id) DO NOTHING;

INSERT INTO manager_stores (manager_id, store_id) VALUES
('mgr1', 's1'),
('mgr1', 's2'),
('mgr2', 's3'),
('mgr2', 's4'),
('mgr3', 's5')
ON CONFLICT DO NOTHING;

INSERT INTO employees (id, store_id, points, weekly_points, monthly_points, current_level, pos_adoption_rate, customer_feedback_score, sales_conversion_rate, engagement_score, avatar_color) VALUES
('e1', 's1', 1480, 320, 890, 4, 82, 91, 74, 88, '#F3A712'),
('e2', 's1', 980, 180, 560, 3, 58, 70, 60, 65, '#0E8C82'),
('e3', 's2', 640, 140, 400, 2, 45, 66, 50, 55, '#EF5A4C'),
('e4', 's2', 2150, 410, 1200, 5, 93, 95, 88, 92, '#6C3FA0'),
('e5', 's3', 1340, 260, 780, 4, 71, 84, 69, 80, '#232C63'),
('e6', 's3', 1620, 300, 900, 5, 85, 88, 79, 84, '#C9840C'),
('e7', 's4', 1890, 350, 1020, 5, 90, 93, 82, 89, '#0E8C82'),
('e8', 's4', 860, 150, 480, 3, 52, 62, 55, 58, '#EF5A4C'),
('e9', 's5', 1210, 230, 700, 4, 68, 80, 65, 76, '#6C3FA0'),
('e10', 's5', 420, 90, 250, 2, 38, 58, 42, 48, '#232C63')
ON CONFLICT (id) DO NOTHING;

INSERT INTO badges (id, name, icon, description, category) VALUES
('product-expert', 'Product Expert', '🏅', 'Completed all Product Knowledge modules', 'Product Knowledge'),
('pos-pro', 'POS Pro', '🎯', 'Mastered digital POS training & zero billing errors', 'POS Training'),
('customer-champion', 'Customer Champion', '⭐', 'Received 5+ positive customer feedbacks', 'Customer Service'),
('learning-streak', 'Learning Streak', '🔥', 'Completed daily lessons 7 days in a row', 'General'),
('team-player', 'Team Player', '🤝', 'Helped 3+ teammates and received peer recognition', 'Culture'),
('top-performer', 'Top Performer', '🏆', 'Ranked Top 3 on the monthly leaderboard', 'Sales Skills'),
('knowledge-seeker', 'Knowledge Seeker', '📚', 'Completed 5+ training modules and quizzes', 'General'),
('problem-solver', 'Problem Solver', '💡', 'Resolved an escalated customer issue smoothly', 'Customer Service')
ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- 14. ROW-LEVEL SECURITY (RLS) POLICIES
-- ============================================================================
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE recognitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Allow employees to read their own and peer public info
CREATE POLICY "Public employee read policy" ON employees FOR SELECT USING (true);
CREATE POLICY "Public recognition read policy" ON recognitions FOR SELECT USING (true);
