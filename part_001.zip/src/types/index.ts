export type Role = 'employee' | 'manager' | 'admin';

export interface LevelInfo {
  level: number;
  name: string;
  min: number;
}

export interface LevelStatus extends LevelInfo {
  next?: LevelInfo;
  pointsToNext: number;
  progressPct: number;
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  desc: string;
  category?: string;
}

export interface Store {
  id: string;
  code: string;
  name: string;
  city: string;
  state: string;
  tier: 'Tier-1' | 'Tier-2' | 'Tier-3';
  activeAssociates: number;
}

export interface Manager {
  id: string;
  name: string;
  title: string;
  email: string;
  stores: string[];
}

export interface Admin {
  id: string;
  name: string;
  title: string;
  email: string;
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  storeId: string;
  points: number;
  weeklyPoints: number;
  monthlyPoints: number;
  posAdoption: number; // 0 - 100%
  customerFeedbackScore: number; // 0 - 100%
  salesConversion: number; // 0 - 100%
  engagementScore: number; // 0 - 100%
  badges: string[]; // Badge IDs
  completedModules: string[]; // Module IDs
  active: boolean;
  approvalStatus?: 'approved' | 'pending' | 'rejected';
  color: string;
  avatarUrl?: string;
  joinDate?: string;
}

export interface PendingRegistration {
  id: string;
  name: string;
  email: string;
  role: Role;
  storeId: string;
  joinDate: string;
  avatarColor: string;
}

export interface QuizQuestion {
  id: string;
  q: string;
  options: string[];
  correct: number;
  explanation?: string;
}

export interface TrainingModule {
  id: string;
  title: string;
  category: 'Product Knowledge' | 'Customer Service' | 'POS Training' | 'Sales Skills' | 'Company Policies';
  duration: string;
  points: number;
  emoji: string;
  description: string;
  keyPoints: string[];
  quiz: QuizQuestion[];
}

export interface Challenge {
  id: string;
  title: string;
  type: 'daily' | 'weekly';
  reward: number;
  icon: string;
  desc: string;
  completedBy: string[];
  expiresIn?: string;
  quiz?: QuizQuestion[];
}

export interface Recognition {
  id: string;
  fromId: string;
  toId: string;
  category: 'Customer Service' | 'Teamwork' | 'Problem Solving' | 'Knowledge Sharing' | 'Sales Excellence';
  message: string;
  likes: number;
  time: string;
}

export interface NotificationItem {
  id: string;
  recipientId: string;
  icon: string;
  text: string;
  time: string;
  read: boolean;
  actionUrl?: string;
}

export interface SkillScore {
  skill: 'Product Knowledge' | 'Customer Service' | 'Sales' | 'POS';
  score: number;
}

export interface AIRecommendation {
  moduleId: string;
  title: string;
  category: string;
  skillGap: string;
  confidenceScore: number;
  rationale: string;
  factors: {
    label: string;
    value: number | string;
    status: 'High' | 'Medium' | 'Low';
    color: string;
  }[];
}

export interface CXBreakdown {
  score: number;
  label: 'Excellent' | 'Good' | 'Needs Attention';
  color: string;
  trainingAvg: number;
  posAvg: number;
  feedbackAvg: number;
  salesAvg: number;
  engagementAvg: number;
}

export interface GeneratedQuestion {
  id: string;
  type: 'MCQ' | 'Scenario-based' | 'Customer Interaction';
  difficulty: 'Easy' | 'Medium' | 'Hard';
  prompt: string;
  options: string[];
  correct: number;
}

export interface AIQuizDraft {
  id: string;
  product: string;
  skill: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  language: string;
  timeLimit: number;
  questions: GeneratedQuestion[];
  challengeTitle: string;
  rewardPoints: number;
  createdAt: string;
}

export interface ToastMessage {
  id: string;
  message: string;
  icon: string;
}

export interface CelebrationData {
  emoji: string;
  eyebrow: string;
  title: string;
  sub?: string;
}

/* ============================================================================
   LEARNATHON INNOVATION TYPES
============================================================================ */

// 1. GENAI ROLEPLAY ARENA
export interface CustomerPersona {
  id: string;
  name: string;
  role: string;
  temperament: 'Aggressive' | 'Hesitant' | 'Rushed' | 'Frustrated';
  avatar: string;
  scenario: string;
  initialPrompt: string;
  idealKeywords: string[];
  objectionType: 'Price Comparison' | 'Return Without Bill' | 'Time Crunch' | 'Product Confusion';
}

export interface RoleplayMessage {
  sender: 'customer' | 'associate';
  text: string;
  timestamp: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
}

export interface RoleplayEvaluation {
  empathyScore: number;
  policyScore: number;
  upsellScore: number;
  overallScore: number;
  feedback: string;
  suggestedResponse: string;
  xpEarned: number;
}

// 2. EXPLAINABLE AI & COUNTERFACTUAL
export interface XAIAttribution {
  feature: string;
  weightPct: number;
  currentValue: string | number;
  impactDirection: 'positive' | 'negative' | 'neutral';
  explanation: string;
}

export interface CounterfactualParams {
  posAdoption: number;
  completedModulesCount: number;
  csatScore: number;
  upsellConversion: number;
}

export interface CounterfactualResult {
  simulatedCX: number;
  cxDelta: number;
  projectedRank: number;
  daysToNextLevel: number;
  unlockedBadgesCount: number;
  storeRevenueLiftPct: number;
}

// 3. MULTIMODAL VISUAL MERCHANDISING AUDITOR
export interface VMDisplayPreset {
  id: string;
  name: string;
  category: string;
  imageEmoji: string;
  description: string;
  complianceScore: number;
  ruleOfThreeScore: number;
  priceTagVisibilityScore: number;
  shelfFullnessPct: number;
  findings: {
    area: string;
    status: 'pass' | 'warning' | 'fail';
    message: string;
  }[];
}

// 4. POS SANDBOX & SPEED ARENA
export interface POSProductItem {
  id: string;
  barcode: string;
  name: string;
  price: number;
  category: string;
  emoji: string;
  comboOffer?: string;
  hasDiscount?: boolean;
}

export interface POSCartItem {
  product: POSProductItem;
  quantity: number;
  discount: number;
}

// 5. PREDICTIVE CX & ROOT CAUSE
export interface RootCauseInsight {
  id: string;
  storeId: string;
  counterOrShift: string;
  bottleneck: string;
  impactScore: number;
  aiPrescription: string;
  playbookTitle: string;
}

// 6. TEAM BATTLE ARENA
export interface StoreBattle {
  id: string;
  storeAId: string;
  storeBId: string;
  storeAName: string;
  storeBName: string;
  storeAPoints: number;
  storeBPoints: number;
  endsIn: string;
  questTitle: string;
}

export interface MysteryBoxReward {
  id: string;
  title: string;
  type: 'xp' | 'badge' | 'multiplier' | 'streak_shield';
  value: string;
  emoji: string;
}

// 7. VERNACULAR "BHASHA" DIALECT COACH
export type VernacularLanguage = 'Hinglish' | 'Hindi' | 'Marathi' | 'Tamil' | 'Telugu';

export interface DialectScenario {
  id: string;
  language: VernacularLanguage;
  nativeTitle: string;
  customerQuery: string;
  phoneticAudioText: string;
  englishMeaning: string;
  keyPolitenessTokens: string[];
  idealPitch: string;
  context: string;
}

export interface DialectEvaluation {
  politenessScore: number;
  clarityScore: number;
  translationAccuracy: number;
  culturalEtiquetteFeedback: string;
  suggestedVernacularPitch: string;
  bonusXP: number;
}

// 8. AUTONOMOUS FLOOR TWIN & HEATMAP
export interface FloorZone {
  id: string;
  name: string;
  footfallDensity: 'Low' | 'Moderate' | 'High' | 'Critical Bottleneck';
  customerCount: number;
  assignedAssociates: string[];
  frictionType?: 'Long Billing Queue' | 'Unattended Gifting Shoppers' | 'Fitting Room Waiting' | 'Smooth';
  zoneColor: string;
}

export interface StaffAllocationSim {
  projectedQueueDropMin: number;
  projectedCXLift: number;
  estimatedBasketIncreasePct: number;
}

// 9. NEURO-ADAPTIVE SPACED REPETITION
export interface MemoryNode {
  id: string;
  topic: string;
  category: string;
  retentionPct: number;
  daysSinceReview: number;
  decayStatus: 'Optimal' | 'At Risk' | 'Decaying Critical';
  decayRiskReason: string;
}

export interface SpacedDrillQuestion {
  id: string;
  topicId: string;
  prompt: string;
  options: string[];
  correct: number;
  quickFact: string;
}

// 10. OFFLINE EDGE SYNC CONSOLE
export type NetworkMode = '5G_HIGH' | '2G_RURAL' | 'OFFLINE';

export interface EdgeSyncQueueItem {
  id: string;
  type: 'Quiz Score' | 'Roleplay Attempt' | 'POS Transaction' | 'Peer Shoutout';
  payloadSummary: string;
  queuedAt: string;
  sizeBytes: number;
  status: 'Queued Locally' | 'Syncing...' | 'Synced to Cloud';
}

// 11. VOICE PITCH & TONE ANALYZER
export interface VoicePitchAnalysis {
  wordsPerMinute: number;
  warmthIndexPct: number;
  clarityScorePct: number;
  pacingStatus: 'Optimal (120-140 WPM)' | 'Too Fast (>150 WPM)' | 'Too Slow (<100 WPM)';
  coachingObservation: string;
}

/* ============================================================================
   360-DEGREE BUSINESS LOOP TYPES
============================================================================ */

// A. REWARDS MARKETPLACE
export interface RewardItem {
  id: string;
  title: string;
  costXP: number;
  category: 'Vouchers' | 'Perks' | 'Prestige' | 'Merchandise';
  icon: string;
  description: string;
  partnerBrand?: string;
  availableStock: number;
}

export interface RedeemedVoucher {
  id: string;
  rewardId: string;
  rewardTitle: string;
  costXP: number;
  code: string;
  redeemedAt: string;
  expiresAt: string;
  status: 'Active' | 'Used';
}

// B. CUSTOMER FEEDBACK & CSAT LOOP
export interface CustomerFeedbackSubmission {
  id: string;
  rating: number; // 1 to 5
  associateId: string;
  storeId: string;
  helpful: boolean;
  selectedTags: string[]; // e.g. "Helpful Staff", "Fast Billing", "Clean Store"
  comment: string;
  createdAt: string;
}

// C. STORE MISSIONS
export interface StoreMission {
  id: string;
  title: string;
  category: 'Speed' | 'Sales' | 'CSAT' | 'Teamwork';
  currentValue: number;
  targetValue: number;
  unit: string;
  rewardXP: number;
  icon: string;
  expiresIn: string;
  isClaimed: boolean;
  description: string;
}

// D. EMPLOYEE MY IMPACT STATS
export interface EmployeeImpactStats {
  customersHelpedCount: number;
  avgCSATScore: number;
  posTransactionsCount: number;
  avgBillingTimeSeconds: number;
  trainingCompletionPct: number;
  storeCXContributionPct: number;
}
