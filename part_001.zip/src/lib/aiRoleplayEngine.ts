import { CustomerPersona, RoleplayMessage, RoleplayEvaluation } from '../types';

export const CUSTOMER_PERSONAS: CustomerPersona[] = [
  {
    id: 'p1',
    name: 'Ramesh Gupta',
    role: 'Festive Shopper (Aggressive Haggler)',
    temperament: 'Aggressive',
    avatar: '👨‍💼',
    scenario: 'Comparing Store Prices with Online E-Commerce Discounts',
    initialPrompt: 'Look, Amazon is offering this same Kurta Set for ₹1,299 with free delivery. Your shelf price tag says ₹1,799! Give me a flat 25% store manager discount or I am ordering it online right now.',
    idealKeywords: ['fabric quality', 'instant trial', 'festive combo', 'loyalty points', 'store warranty', 'in-store customization'],
    objectionType: 'Price Comparison',
  },
  {
    id: 'p2',
    name: 'Sunita Sharma',
    role: 'Disgruntled Customer (Lost Receipt)',
    temperament: 'Frustrated',
    avatar: '👩‍🦳',
    scenario: 'Demanding Return Without Physical Paper Receipt',
    initialPrompt: 'I bought this festive lamp yesterday and it doesn’t fit my living room table! I lost the paper bill in the cab, and your cashier said no returns without a receipt! This is unacceptable customer service!',
    idealKeywords: ['registered phone number', 'omnichannel lookup', 'instant exchange', 'store credit', 'apologize', 'digital invoice'],
    objectionType: 'Return Without Bill',
  },
  {
    id: 'p3',
    name: 'Vikram Mehta',
    role: 'Corporate Commuter (Time Crunch)',
    temperament: 'Rushed',
    avatar: '👨‍💻',
    scenario: 'Rush Hour Checkout with Split Tender UPI + Gift Card',
    initialPrompt: 'I have a train departing in 10 minutes! I want to pay ₹400 using my QuestFloor Gift Card and the remaining ₹850 via UPI QR code. Make sure you don’t double charge me!',
    idealKeywords: ['split payment', 'gift card balance verify', 'instant qr', 'fast scan', 'express checkout'],
    objectionType: 'Time Crunch',
  },
  {
    id: 'p4',
    name: 'Anjali Verma',
    role: 'First-time Festive Buyer (Indecisive)',
    temperament: 'Hesitant',
    avatar: '🥻',
    scenario: 'Unsure about Gifting Budget & Hamper Combinations',
    initialPrompt: 'I need to gift 4 family hampers under ₹2,000 total. I am completely confused between brass diyas, sweet boxes, and lighting. Everything looks overwhelming.',
    idealKeywords: ['customization', 'under ₹499 combo', 'complimentary gift packaging', 'rule of three', 'personalized recommendation'],
    objectionType: 'Product Confusion',
  },
];

export function simulateCustomerTurn(
  persona: CustomerPersona,
  conversationHistory: RoleplayMessage[],
  associateResponse: string
): { customerReply: string; sentiment: 'positive' | 'neutral' | 'negative' } {
  const text = associateResponse.toLowerCase();

  // Check matching keywords
  const matchedKeywords = persona.idealKeywords.filter((kw) => text.includes(kw.toLowerCase()));

  if (persona.id === 'p1') {
    if (matchedKeywords.length >= 2 || text.includes('trial') || text.includes('combo') || text.includes('loyalty')) {
      return {
        customerReply: 'Hmm, that is a fair point. If you can customize the packaging and apply the Gold Club 5% discount at the POS right now, I’ll take it.',
        sentiment: 'positive',
      };
    } else if (text.includes('policy') || text.includes('cannot') || text.includes('fixed price')) {
      return {
        customerReply: 'Just quoting store policy is unhelpful. Why should I pay more here if you won’t explain the value?',
        sentiment: 'negative',
      };
    } else {
      return {
        customerReply: 'I see. Can you show me the size chart and confirm if I can exchange it if my family doesn’t like the fit?',
        sentiment: 'neutral',
      };
    }
  }

  if (persona.id === 'p2') {
    if (matchedKeywords.length >= 1 || text.includes('phone') || text.includes('mobile') || text.includes('look up') || text.includes('help')) {
      return {
        customerReply: 'Oh, you can look it up with my phone number? Thank you, my registered mobile number is 98230-44912. Please see if we can exchange it for the brass diya set.',
        sentiment: 'positive',
      };
    } else {
      return {
        customerReply: 'Stop telling me about company rules! I want a manager right now!',
        sentiment: 'negative',
      };
    }
  }

  if (persona.id === 'p3') {
    if (text.includes('gift card') || text.includes('qr') || text.includes('split') || text.includes('done') || text.includes('seconds')) {
      return {
        customerReply: 'Awesome, scanned the QR! Received the e-receipt on SMS. That was super fast, thank you!',
        sentiment: 'positive',
      };
    } else {
      return {
        customerReply: 'Please hurry up, my cab is waiting outside!',
        sentiment: 'neutral',
      };
    }
  }

  // Persona 4
  if (matchedKeywords.length >= 1 || text.includes('499') || text.includes('pack') || text.includes('diya') || text.includes('recommend')) {
    return {
      customerReply: 'The ₹499 diya and lantern combo sounds wonderful and perfectly within my ₹2,000 budget for 4 gifts! Could you please pack them in festive gift boxes?',
      sentiment: 'positive',
    };
  }

  return {
    customerReply: 'Could you give me one concrete suggestion that fits my price range?',
    sentiment: 'neutral',
  };
}

export function evaluateRoleplaySession(
  persona: CustomerPersona,
  conversationHistory: RoleplayMessage[]
): RoleplayEvaluation {
  const associateMessages = conversationHistory.filter((m) => m.sender === 'associate').map((m) => m.text.toLowerCase());
  const combined = associateMessages.join(' ');

  let empathyScore = 75;
  let policyScore = 70;
  let upsellScore = 65;

  persona.idealKeywords.forEach((kw) => {
    if (combined.includes(kw.toLowerCase())) {
      empathyScore += 7;
      policyScore += 8;
      upsellScore += 6;
    }
  });

  if (combined.includes('sorry') || combined.includes('understand') || combined.includes('glad to help') || combined.includes('happy to assist')) {
    empathyScore += 10;
  }

  if (combined.includes('pos') || combined.includes('phone number') || combined.includes('bill') || combined.includes('discount')) {
    policyScore += 8;
  }

  if (combined.includes('combo') || combined.includes('recommend') || combined.includes('pairing') || combined.includes('gift')) {
    upsellScore += 12;
  }

  empathyScore = Math.min(98, Math.max(60, empathyScore));
  policyScore = Math.min(98, Math.max(60, policyScore));
  upsellScore = Math.min(98, Math.max(55, upsellScore));

  const overall = Math.round((empathyScore * 0.35) + (policyScore * 0.35) + (upsellScore * 0.30));
  const xpEarned = overall >= 85 ? 150 : overall >= 70 ? 100 : 60;

  let feedback = 'Good consultative listening and prompt responses.';
  let suggested = 'Remember to proactively offer phone number lookup or explain value-add customization.';

  if (persona.id === 'p1') {
    suggested = '“I completely understand! While online shipping takes 3-4 days, here you get instant fabric trial, free custom gift packing, and our 100% verified in-store exchange guarantee.”';
    feedback = 'Strong value framing against online discount pressure.';
  } else if (persona.id === 'p2') {
    suggested = '“I sincerely apologize for the inconvenience! Don’t worry at all — I can instantly retrieve your digital bill using your registered mobile number.”';
    feedback = 'De-escalated customer anger by removing friction.';
  }

  return {
    empathyScore,
    policyScore,
    upsellScore,
    overallScore: overall,
    feedback,
    suggestedResponse: suggested,
    xpEarned,
  };
}
