import { LevelInfo, Badge } from '../types';

export const COLORS = {
  navy: '#12183A',
  navy2: '#1B2354',
  navy3: '#232C63',
  paper: '#F5F5FB',
  card: '#FFFFFF',
  amber: '#F3A712',
  amberDeep: '#C9840C',
  teal: '#0E8C82',
  coral: '#EF5A4C',
  plum: '#6C3FA0',
  ink: '#1B1C29',
  muted: '#6E7191',
  line: '#E7E7F2',
  emerald: '#10B981',
  sky: '#0EA5E9',
};

export const LEVELS: LevelInfo[] = [
  { level: 1, name: 'Beginner', min: 0 },
  { level: 2, name: 'Learner', min: 400 },
  { level: 3, name: 'Skilled', min: 800 },
  { level: 4, name: 'Expert', min: 1200 },
  { level: 5, name: 'Champion', min: 1600 },
];

export const BADGES: Badge[] = [
  { id: 'product-expert', name: 'Product Expert', icon: '🏅', desc: 'Completed all Product Knowledge modules', category: 'Product Knowledge' },
  { id: 'pos-pro', name: 'POS Pro', icon: '🎯', desc: 'Mastered digital POS training & zero billing errors', category: 'POS Training' },
  { id: 'customer-champion', name: 'Customer Champion', icon: '⭐', desc: 'Received 5+ positive customer feedbacks', category: 'Customer Service' },
  { id: 'learning-streak', name: 'Learning Streak', icon: '🔥', desc: 'Completed daily lessons 7 days in a row', category: 'General' },
  { id: 'team-player', name: 'Team Player', icon: '🤝', desc: 'Helped 3+ teammates and received peer recognition', category: 'Culture' },
  { id: 'top-performer', name: 'Top Performer', icon: '🏆', desc: 'Ranked Top 3 on the monthly leaderboard', category: 'Sales Skills' },
  { id: 'knowledge-seeker', name: 'Knowledge Seeker', icon: '📚', desc: 'Completed 5+ training modules and quizzes', category: 'General' },
  { id: 'problem-solver', name: 'Problem Solver', icon: '💡', desc: 'Resolved an escalated customer issue smoothly', category: 'Customer Service' },
];

export const ROLE_LABEL: Record<string, string> = {
  employee: 'Store Associate',
  manager: 'Store Manager',
  admin: 'HR / Admin',
};

export const CATEGORY_ICONS: Record<string, string> = {
  'Product Knowledge': '🪔',
  'Customer Service': '🗣️',
  'POS Training': '🧾',
  'Sales Skills': '📈',
  'Company Policies': '🛡️',
};

export const RECOGNITION_CATEGORIES = [
  { name: 'Customer Service', icon: '🌟', color: COLORS.teal },
  { name: 'Teamwork', icon: '🤝', color: COLORS.plum },
  { name: 'Problem Solving', icon: '💡', color: COLORS.amberDeep },
  { name: 'Knowledge Sharing', icon: '📚', color: COLORS.navy3 },
  { name: 'Sales Excellence', icon: '🎯', color: COLORS.coral },
] as const;

export const WEEKLY_TREND = [
  { week: 'Wk 1', engagement: 68, training: 55, pos: 60, cx: 62 },
  { week: 'Wk 2', engagement: 72, training: 61, pos: 64, cx: 67 },
  { week: 'Wk 3', engagement: 76, training: 68, pos: 70, cx: 73 },
  { week: 'Wk 4', engagement: 84, training: 77, pos: 79, cx: 81 },
];
