import { MemoryNode, SpacedDrillQuestion } from '../types';

export const INITIAL_MEMORY_NODES: MemoryNode[] = [
  {
    id: 'mem-1',
    topic: 'Diya & Lantern Combo Price Point',
    category: 'Product Knowledge',
    retentionPct: 48,
    daysSinceReview: 5,
    decayStatus: 'Decaying Critical',
    decayRiskReason: 'Unreviewed for 5 days. Risk of misquoting impulse checkout price to shoppers.',
  },
  {
    id: 'mem-2',
    topic: 'Phone Number Bill Retrieval Policy',
    category: 'POS & Returns',
    retentionPct: 56,
    daysSinceReview: 4,
    decayStatus: 'At Risk',
    decayRiskReason: 'Associates tend to ask for paper bills when digital lookup is available.',
  },
  {
    id: 'mem-3',
    topic: 'Rule of Three Visual Display Grouping',
    category: 'Visual Merchandising',
    retentionPct: 82,
    daysSinceReview: 1,
    decayStatus: 'Optimal',
    decayRiskReason: 'Recent training completed. Retaining core display principles.',
  },
  {
    id: 'mem-4',
    topic: 'Gold Club 5% Instant Festive Discount',
    category: 'Promotions',
    retentionPct: 52,
    daysSinceReview: 6,
    decayStatus: 'At Risk',
    decayRiskReason: 'Risk of forgetting to trigger extra 5% voucher at checkout.',
  },
  {
    id: 'mem-5',
    topic: 'Terminal Lockout (Ctrl+L) Safety Protocol',
    category: 'Data Security',
    retentionPct: 91,
    daysSinceReview: 1,
    decayStatus: 'Optimal',
    decayRiskReason: 'Strong adherence to POS terminal screen locking standards.',
  },
];

export const NEURO_DRILL_QUESTIONS: SpacedDrillQuestion[] = [
  {
    id: 'nd-1',
    topicId: 'mem-1',
    prompt: '⚡ Quick 15s Recall: What is the exact price ceiling for the festive diya & lantern impulse combo?',
    options: ['₹299', '₹499', '₹799', '₹1,299'],
    correct: 1,
    quickFact: '₹499 is the optimal impulse threshold for festive shopper conversion.',
  },
  {
    id: 'nd-2',
    topicId: 'mem-2',
    prompt: '⚡ Quick 15s Recall: If a customer lost their paper receipt, what is the fastest way to look up their purchase history on POS?',
    options: ['Ask for bank statement', 'Search by registered mobile phone number', 'Call regional manager', 'Refuse return'],
    correct: 1,
    quickFact: 'All purchases across 1,200 stores are indexed by registered mobile number.',
  },
  {
    id: 'nd-3',
    topicId: 'mem-4',
    prompt: '⚡ Quick 15s Recall: What extra discount percentage do Gold Club loyalty members receive on festive items?',
    options: ['2%', '5% instant discount', '15%', '25%'],
    correct: 1,
    quickFact: 'Gold Club members receive 5% extra discount automatically applied at billing.',
  },
];
