'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import confetti from 'canvas-confetti';
import {
  Role,
  Employee,
  Store,
  Manager,
  Admin,
  TrainingModule,
  Challenge,
  Recognition,
  NotificationItem,
  ToastMessage,
  CelebrationData,
  AIQuizDraft,
  RewardItem,
  RedeemedVoucher,
  CustomerFeedbackSubmission,
  StoreMission,
  PendingRegistration,
} from '../../types';
import {
  EMPLOYEES_INIT,
  STORES_INIT,
  MANAGERS_INIT,
  ADMIN_INIT,
  TRAINING_MODULES_INIT,
  CHALLENGES_INIT,
  RECOGNITIONS_INIT,
  NOTIFICATIONS_INIT,
  CURRENT_EMPLOYEE_ID,
  CURRENT_MANAGER_ID,
} from '../data/initialData';
import { BADGES, COLORS } from '../constants';
import { getLevelInfo, getEmployeeName } from '../cxCalculator';
import { sounds } from '../audioEffect';
import { LanguageCode, getTranslation } from '../translations';

const INITIAL_MISSIONS: StoreMission[] = [
  {
    id: 'sm-1',
    title: '⚡ Floor Speed Sprint: Reduce Billing Time below 90s',
    category: 'Speed',
    currentValue: 82,
    targetValue: 90,
    unit: 'sec avg',
    rewardXP: 300,
    icon: 'Zap',
    expiresIn: '4h 20m',
    isClaimed: false,
    description: 'Keep average digital POS scan & tender authorization under 90 seconds during peak shift.',
  },
  {
    id: 'sm-2',
    title: '🎯 Festive Pairing: Recommend 5 Diya & Kurta Combos',
    category: 'Sales',
    currentValue: 4,
    targetValue: 5,
    unit: 'upsells',
    rewardXP: 200,
    icon: 'TrendingUp',
    expiresIn: '6h 15m',
    isClaimed: false,
    description: 'Help shoppers pair traditional ethnic wear with ₹499 diya and lantern impulse combos.',
  },
  {
    id: 'sm-3',
    title: '⭐ Customer Delight: Maintain 90%+ 5-Star CSAT Rating',
    category: 'CSAT',
    currentValue: 94,
    targetValue: 90,
    unit: '% CSAT',
    rewardXP: 500,
    icon: 'Star',
    expiresIn: 'End of Shift',
    isClaimed: false,
    description: 'Ensure friendly hospitality greetings and zero pricing friction across all floor counters.',
  },
];

const INITIAL_FEEDBACK: CustomerFeedbackSubmission[] = [
  {
    id: 'fb-1',
    rating: 5,
    associateId: 'e1',
    storeId: 's1',
    helpful: true,
    selectedTags: ['Helpful Staff', 'Polite Hospitality', 'Clean Store'],
    comment: 'Sneha explained the cotton-silk fabric quality and helped customize my Diwali gift hamper beautifully!',
    createdAt: '15 mins ago',
  },
  {
    id: 'fb-2',
    rating: 5,
    associateId: 'e4',
    storeId: 's2',
    helpful: true,
    selectedTags: ['Fast Billing', 'Product Knowledge'],
    comment: 'Super fast UPI QR checkout! Billed in under 45 seconds.',
    createdAt: '1h ago',
  },
  {
    id: 'fb-3',
    rating: 4,
    associateId: 'e6',
    storeId: 's3',
    helpful: true,
    selectedTags: ['Helpful Staff', 'Product Knowledge'],
    comment: 'Arjun recommended the perfect matching dupatta for my kurta set.',
    createdAt: '3h ago',
  },
  {
    id: 'fb-4',
    rating: 2,
    associateId: 'e2',
    storeId: 's1',
    helpful: false,
    selectedTags: ['Billing Queue Delay'],
    comment: 'Had to wait 7 minutes at billing counter 2 because split payment took time.',
    createdAt: '5h ago',
  },
];

const INITIAL_VOUCHERS: RedeemedVoucher[] = [
  {
    id: 'rv-0',
    rewardId: 'rw-ccd',
    rewardTitle: '☕ Café Coffee Day Free Beverage Voucher',
    costXP: 500,
    code: 'QF-CCD-8492',
    redeemedAt: 'Yesterday',
    expiresAt: 'In 29 Days',
    status: 'Active',
  },
];

interface AppContextType {
  role: Role | null;
  screen: string;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
  currentEmployeeId: string;
  setSelectedEmployeeId: (id: string) => void;
  currentManagerId: string;
  currentEmployee: Employee;
  currentManager: Manager;
  admin: Admin;
  employees: Employee[];
  stores: Store[];
  managers: Manager[];
  trainingModules: TrainingModule[];
  challenges: Challenge[];
  recognitions: Recognition[];
  notifications: NotificationItem[];
  toast: ToastMessage | null;
  celebration: CelebrationData | null;
  publishedQuizzes: AIQuizDraft[];
  redeemedVouchers: RedeemedVoucher[];
  feedbackSubmissions: CustomerFeedbackSubmission[];
  storeMissions: StoreMission[];
  pendingRegistrations: PendingRegistration[];
  managerProfile: {
    name: string;
    shiftHours: string;
    coachingFocus: string;
    phone: string;
    storeName: string;
    targetPosRate: number;
    targetTrainingRate: number;
  };
  registerPendingEmployee: (data: { name: string; email: string; role?: Role; storeId?: string; password?: string }) => Promise<{ status: string; message: string }>;
  approveRegistration: (id: string) => Promise<void>;
  rejectRegistration: (id: string) => Promise<void>;
  updateManagerProfileData: (data: any) => Promise<void>;
  isStoryModalOpen: boolean;
  setIsStoryModalOpen: (open: boolean) => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
  t: (key: string) => string;
  setRole: (role: Role | null) => void;
  setScreen: (screen: string) => void;
  showToast: (message: string, icon?: string) => void;
  fireCelebration: (data: CelebrationData) => void;
  handleLogin: (role: Role) => void;
  handleLogout: () => void;
  finishModule: (moduleId: string, scorePct: number) => { pointsEarned: number; unlockedBadge: typeof BADGES[0] | null };
  completeChallenge: (challengeId: string) => void;
  giveRecognition: (fromId: string, toId: string, category: Recognition['category'], message: string) => void;
  likeRecognition: (id: string) => void;
  markNotificationsRead: (recipientId: string) => void;
  nudgeEmployee: (employee: Employee) => void;
  createChallenge: (challenge: { title: string; type: 'daily' | 'weekly'; reward: number }) => void;
  publishAIQuiz: (draft: AIQuizDraft) => void;
  sendAnnouncement: (text: string) => void;
  toggleEmployeeActive: (id: string) => void;
  resetDemoData: () => void;
  redeemReward: (reward: RewardItem) => boolean;
  submitCustomerFeedback: (feedback: Omit<CustomerFeedbackSubmission, 'id' | 'createdAt'>) => void;
  claimMissionReward: (missionId: string) => void;
  sendManagerAction: (empId: string, actionTitle: string, rewardXP: number) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'questfloor_store_v1';

export function AppProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role | null>(null);
  const [screen, setScreen] = useState<string>('dashboard');
  const [mobileOpen, setMobileOpen] = useState<boolean>(false);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [celebration, setCelebration] = useState<CelebrationData | null>(null);
  const [isStoryModalOpen, setIsStoryModalOpen] = useState<boolean>(false);
  const [activeEmployeeId, setActiveEmployeeId] = useState<string>(CURRENT_EMPLOYEE_ID);
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const t = (key: string) => getTranslation(language, key);

  const [employees, setEmployees] = useState<Employee[]>(EMPLOYEES_INIT);
  const [stores] = useState<Store[]>(STORES_INIT);
  const [managers] = useState<Manager[]>(MANAGERS_INIT);
  const [admin] = useState<Admin>(ADMIN_INIT);
  const [trainingModules, setTrainingModules] = useState<TrainingModule[]>(TRAINING_MODULES_INIT);
  const [challenges, setChallenges] = useState<Challenge[]>(CHALLENGES_INIT);
  const [recognitions, setRecognitions] = useState<Recognition[]>(RECOGNITIONS_INIT);
  const [notifications, setNotifications] = useState<NotificationItem[]>(NOTIFICATIONS_INIT);
  const [publishedQuizzes, setPublishedQuizzes] = useState<AIQuizDraft[]>([]);
  const [redeemedVouchers, setRedeemedVouchers] = useState<RedeemedVoucher[]>(INITIAL_VOUCHERS);
  const [feedbackSubmissions, setFeedbackSubmissions] = useState<CustomerFeedbackSubmission[]>(INITIAL_FEEDBACK);
  const [storeMissions, setStoreMissions] = useState<StoreMission[]>(INITIAL_MISSIONS);
  const [pendingRegistrations, setPendingRegistrations] = useState<PendingRegistration[]>([
    {
      id: 'e-pending-1',
      name: 'Rohan Sharma',
      email: 'rohan.sharma@retailrise.com',
      role: 'employee',
      storeId: 's1',
      joinDate: 'Today (10 mins ago)',
      avatarColor: '#f59e0b',
    },
  ]);
  const [managerProfile, setManagerProfile] = useState({
    name: 'Priya Patel',
    shiftHours: '09:00 AM - 06:00 PM (Morning & Peak Rush)',
    coachingFocus: 'POS Split-Tender Speed & Upsell Attachment',
    phone: '+91 98765 43210',
    storeName: 'QuestFloor Store #104 (Nagpur Hub)',
    targetPosRate: 90.0,
    targetTrainingRate: 95.0,
  });

  // Load from local storage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.employees) setEmployees(parsed.employees);
        if (parsed.trainingModules) setTrainingModules(parsed.trainingModules);
        if (parsed.challenges) setChallenges(parsed.challenges);
        if (parsed.recognitions) setRecognitions(parsed.recognitions);
        if (parsed.notifications) setNotifications(parsed.notifications);
        if (parsed.publishedQuizzes) setPublishedQuizzes(parsed.publishedQuizzes);
        if (parsed.redeemedVouchers) setRedeemedVouchers(parsed.redeemedVouchers);
        if (parsed.feedbackSubmissions) setFeedbackSubmissions(parsed.feedbackSubmissions);
        if (parsed.storeMissions) setStoreMissions(parsed.storeMissions);
        if (parsed.language) setLanguage(parsed.language);
        if (parsed.theme) setTheme(parsed.theme);
      }
    } catch {
      // LocalStorage access failed or not supported
    }
  }, []);

  // Save to local storage
  useEffect(() => {
    try {
      const stateToSave = {
        employees,
        trainingModules,
        challenges,
        recognitions,
        notifications,
        publishedQuizzes,
        redeemedVouchers,
        feedbackSubmissions,
        storeMissions,
        language,
        theme,
      };
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(stateToSave));
    } catch {
      // LocalStorage save failed
    }
  }, [
    employees,
    trainingModules,
    challenges,
    recognitions,
    notifications,
    publishedQuizzes,
    redeemedVouchers,
    feedbackSubmissions,
    storeMissions,
    language,
    theme,
  ]);

  const showToast = (message: string, icon = '✨') => {
    const id = `toast-${Date.now()}`;
    setToast({ id, message, icon });
    sounds.playClick();
    setTimeout(() => {
      setToast((prev) => (prev?.id === id ? null : prev));
    }, 3500);
  };

  const fireCelebration = (data: CelebrationData) => {
    setCelebration(data);
    sounds.playLevelUp();

    if (typeof window !== 'undefined') {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#F3A712', '#0E8C82', '#6C3FA0', '#EF5A4C'],
        });
      } catch {
        // Confetti fallback
      }
    }

    setTimeout(() => {
      setCelebration(null);
    }, 2600);
  };

  const addNotification = (recipientId: string, icon: string, text: string) => {
    const newNotif: NotificationItem = {
      id: `n-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      recipientId,
      icon,
      text,
      time: 'Just now',
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const currentEmployee = employees.find((e) => e.id === activeEmployeeId) || employees[0];
  const currentManager = managers.find((m) => m.id === CURRENT_MANAGER_ID) || managers[0];

  const handleLogin = (selectedRole: Role) => {
    setRole(selectedRole);
    setScreen('dashboard');
    const name = selectedRole === 'employee' ? (currentEmployee?.name?.split(' ')[0] || 'Amit') : selectedRole === 'manager' ? 'Priya' : 'Neha';
    showToast(`Welcome back, ${name}!`, '👋');
  };

  const handleLogout = () => {
    setRole(null);
    setScreen('dashboard');
  };

  const finishModule = (moduleId: string, scorePct: number) => {
    const emp = employees.find((e) => e.id === CURRENT_EMPLOYEE_ID) || employees[0];
    const moduleDef = trainingModules.find((m) => m.id === moduleId);
    if (!moduleDef) return { pointsEarned: 0, unlockedBadge: null };

    const alreadyDone = emp.completedModules.includes(moduleId);
    const pointsEarned = alreadyDone || scorePct < 60 ? 0 : moduleDef.points;
    const newCompleted = alreadyDone ? emp.completedModules : [...emp.completedModules, moduleId];

    let newBadges = [...emp.badges];
    let unlockedBadge: typeof BADGES[0] | null = null;

    if (!alreadyDone && scorePct >= 60) {
      const nextBadge = BADGES.find((b) => !emp.badges.includes(b.id));
      if (nextBadge) {
        newBadges.push(nextBadge.id);
        unlockedBadge = nextBadge;
      }
    }

    const beforeLevel = getLevelInfo(emp.points);
    const afterLevel = getLevelInfo(emp.points + pointsEarned);

    setEmployees((prev) =>
      prev.map((e) =>
        e.id === CURRENT_EMPLOYEE_ID
          ? {
              ...e,
              points: e.points + pointsEarned,
              weeklyPoints: e.weeklyPoints + pointsEarned,
              monthlyPoints: e.monthlyPoints + pointsEarned,
              completedModules: newCompleted,
              badges: newBadges,
            }
          : e
      )
    );

    if (!alreadyDone && scorePct >= 60) {
      addNotification(CURRENT_EMPLOYEE_ID, 'BookOpen', `Completed "${moduleDef.title}" — +${moduleDef.points} XP earned!`);

      if (unlockedBadge) {
        addNotification(CURRENT_EMPLOYEE_ID, 'Award', `New Badge Unlocked: ${unlockedBadge.name}!`);
        fireCelebration({
          emoji: unlockedBadge.icon,
          eyebrow: 'Badge Unlocked!',
          title: unlockedBadge.name,
          sub: unlockedBadge.desc,
        });
      } else if (afterLevel.level > beforeLevel.level) {
        fireCelebration({
          emoji: '🚀',
          eyebrow: 'Level Up!',
          title: `Level ${afterLevel.level} · ${afterLevel.name}`,
          sub: 'Outstanding work! Keep building momentum.',
        });
      } else {
        sounds.playSuccess();
        showToast(`Quiz Passed! +${pointsEarned} XP`, '🎉');
      }
    }

    return { pointsEarned, unlockedBadge };
  };

  const completeChallenge = (challengeId: string) => {
    const ch = challenges.find((c) => c.id === challengeId);
    if (!ch || ch.completedBy.includes(CURRENT_EMPLOYEE_ID)) return;

    const emp = employees.find((e) => e.id === CURRENT_EMPLOYEE_ID) || employees[0];
    const beforeLevel = getLevelInfo(emp.points);
    const afterLevel = getLevelInfo(emp.points + ch.reward);

    setChallenges((prev) =>
      prev.map((c) => (c.id === challengeId ? { ...c, completedBy: [...c.completedBy, CURRENT_EMPLOYEE_ID] } : c))
    );

    setEmployees((prev) =>
      prev.map((e) =>
        e.id === CURRENT_EMPLOYEE_ID
          ? { ...e, points: e.points + ch.reward, weeklyPoints: e.weeklyPoints + ch.reward }
          : e
      )
    );

    addNotification(CURRENT_EMPLOYEE_ID, 'Target', `Challenge Completed: "${ch.title}" (+${ch.reward} XP)`);

    if (afterLevel.level > beforeLevel.level) {
      fireCelebration({
        emoji: '🚀',
        eyebrow: 'Level Up!',
        title: `Level ${afterLevel.level} · ${afterLevel.name}`,
        sub: 'You crushed today\'s challenge!',
      });
    } else {
      sounds.playSuccess();
      showToast(`Challenge Completed! +${ch.reward} XP`, '🎯');
    }
  };

  const giveRecognition = (fromId: string, toId: string, category: Recognition['category'], message: string) => {
    const newRec: Recognition = {
      id: `r-${Date.now()}`,
      fromId,
      toId,
      category,
      message,
      likes: 0,
      time: 'Just now',
    };
    setRecognitions((prev) => [newRec, ...prev]);

    const recipientName = getEmployeeName(employees, toId);
    const senderName = getEmployeeName(employees, fromId);

    addNotification(toId, 'Heart', `${senderName} recognized you for ${category}: "${message.slice(0, 45)}…"`);
    sounds.playSuccess();
    showToast(`Recognition shared with ${recipientName}!`, '👏');
  };

  const likeRecognition = (id: string) => {
    setRecognitions((prev) => prev.map((r) => (r.id === id ? { ...r, likes: r.likes + 1 } : r)));
    sounds.playClick();
  };

  const markNotificationsRead = (recipientId: string) => {
    setNotifications((prev) => {
      const hasUnread = prev.some(
        (n) => (n.recipientId === recipientId || n.recipientId === 'all') && !n.read
      );
      if (!hasUnread) return prev;
      return prev.map((n) =>
        n.recipientId === recipientId || n.recipientId === 'all' ? { ...n, read: true } : n
      );
    });
  };

  const nudgeEmployee = (emp: Employee) => {
    addNotification(emp.id, 'AlertTriangle', `Manager Anil Deshmukh sent a reminder to complete your POS Training module.`);
    sounds.playClick();
    showToast(`Training reminder sent to ${emp.name}.`, '📩');
  };

  const createChallenge = (ch: { title: string; type: 'daily' | 'weekly'; reward: number }) => {
    const newCh: Challenge = {
      id: `c-${Date.now()}`,
      title: ch.title,
      type: ch.type,
      reward: ch.reward,
      icon: 'Target',
      desc: 'Published organization-wide by HR & Admin.',
      completedBy: [],
    };
    setChallenges((prev) => [newCh, ...prev]);
    addNotification('all', 'Target', `New Challenge Published: "${ch.title}" (+${ch.reward} XP)`);
    sounds.playSuccess();
    showToast('New challenge published to all stores!', '🎯');
  };

  const publishAIQuiz = (draft: AIQuizDraft) => {
    const newModule: TrainingModule = {
      id: `m-ai-${Date.now()}`,
      title: `${draft.product} Masterclass`,
      category: draft.skill as TrainingModule['category'],
      duration: `${draft.timeLimit} min`,
      points: draft.rewardPoints,
      emoji: '✨',
      description: `AI-generated micro-learning module focusing on ${draft.skill.toLowerCase()} for ${draft.product}.`,
      keyPoints: [
        `Master key consultation techniques for ${draft.product}.`,
        `Apply store guidelines to resolve customer doubts with empathy.`,
        `Accurately register product sales and warranties in the POS terminal.`,
      ],
      quiz: draft.questions.map((q, idx) => ({
        id: `q-mod-${idx}`,
        q: q.prompt,
        options: q.options,
        correct: q.correct,
      })),
    };

    setTrainingModules((prev) => [newModule, ...prev]);
    setPublishedQuizzes((prev) => [draft, ...prev]);

    createChallenge({
      title: draft.challengeTitle,
      type: 'weekly',
      reward: draft.rewardPoints,
    });

    addNotification('all', 'Sparkles', `New AI Training live: "${newModule.title}" (+${draft.rewardPoints} XP)`);
    showToast(`AI Quiz & Challenge for "${draft.product}" published live!`, '🚀');
  };

  const sendAnnouncement = (text: string) => {
    addNotification('all', 'Megaphone', text);
    sounds.playSuccess();
    showToast('Announcement broadcasted to all 3,000 associates!', '📣');
  };

  const toggleEmployeeActive = (id: string) => {
    setEmployees((prev) => prev.map((e) => (e.id === id ? { ...e, active: !e.active } : e)));
    showToast('Employee status updated.', '⚙️');
  };

  // 360-DEGREE ACTIONS
  const redeemReward = (reward: RewardItem): boolean => {
    if (currentEmployee.points < reward.costXP) {
      showToast(`Need ${reward.costXP - currentEmployee.points} more XP to redeem this reward.`, '⚠️');
      return false;
    }

    const code = `QF-${reward.category.slice(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newVoucher: RedeemedVoucher = {
      id: `v-${Date.now()}`,
      rewardId: reward.id,
      rewardTitle: reward.title,
      costXP: reward.costXP,
      code,
      redeemedAt: 'Just now',
      expiresAt: 'In 30 Days',
      status: 'Active',
    };

    setEmployees((prev) =>
      prev.map((e) =>
        e.id === CURRENT_EMPLOYEE_ID
          ? { ...e, points: e.points - reward.costXP }
          : e
      )
    );

    setRedeemedVouchers((prev) => [newVoucher, ...prev]);
    addNotification(CURRENT_EMPLOYEE_ID, 'Award', `Redeemed "${reward.title}" (Code: ${code})`);

    fireCelebration({
      emoji: '🎁',
      eyebrow: 'Reward Unlocked & Claimed!',
      title: reward.title,
      sub: `Voucher Code: ${code}`,
    });

    return true;
  };

  const submitCustomerFeedback = (feedback: Omit<CustomerFeedbackSubmission, 'id' | 'createdAt'>) => {
    const newFb: CustomerFeedbackSubmission = {
      ...feedback,
      id: `fb-${Date.now()}`,
      createdAt: 'Just now',
    };

    setFeedbackSubmissions((prev) => [newFb, ...prev]);

    // Boost associate CSAT slightly if 5-star
    if (feedback.rating === 5) {
      setEmployees((prev) =>
        prev.map((e) =>
          e.id === feedback.associateId
            ? { ...e, customerFeedbackScore: Math.min(99, e.customerFeedbackScore + 1) }
            : e
        )
      );
    }

    sounds.playSuccess();
    showToast('Customer Voice & CSAT Feedback Recorded!', '⭐');
  };

  const claimMissionReward = (missionId: string) => {
    const mission = storeMissions.find((m) => m.id === missionId);
    if (!mission || mission.isClaimed) return;

    setStoreMissions((prev) =>
      prev.map((m) => (m.id === missionId ? { ...m, isClaimed: true } : m))
    );

    setEmployees((prev) =>
      prev.map((e) =>
        e.id === CURRENT_EMPLOYEE_ID
          ? { ...e, points: e.points + mission.rewardXP, weeklyPoints: e.weeklyPoints + mission.rewardXP }
          : e
      )
    );

    addNotification(CURRENT_EMPLOYEE_ID, 'Zap', `Store Mission Claimed: "${mission.title}" (+${mission.rewardXP} XP)`);

    fireCelebration({
      emoji: '🔥',
      eyebrow: 'Store Operational Mission Completed!',
      title: `+${mission.rewardXP} XP Claimed`,
      sub: mission.title,
    });
  };

  const sendManagerAction = (empId: string, actionTitle: string, rewardXP: number) => {
    const emp = employees.find((e) => e.id === empId);
    if (!emp) return;

    if (rewardXP > 0) {
      setEmployees((prev) =>
        prev.map((e) =>
          e.id === empId
            ? { ...e, points: e.points + rewardXP, weeklyPoints: e.weeklyPoints + rewardXP }
            : e
        )
      );
    }

    addNotification(empId, 'Award', `Manager Action: ${actionTitle} (+${rewardXP} XP)`);
    showToast(`Manager Action "${actionTitle}" dispatched to ${emp.name}!`, '🚀');
  };

  const registerPendingEmployee = async (data: { name: string; email: string; role?: Role; storeId?: string; password?: string }) => {
    const newPending: PendingRegistration = {
      id: `e-${Date.now()}`,
      name: data.name,
      email: data.email,
      role: data.role || 'employee',
      storeId: data.storeId || 's1',
      joinDate: 'Today',
      avatarColor: COLORS.amber,
    };
    setPendingRegistrations((prev) => [newPending, ...prev]);

    return {
      status: 'pending_approval',
      message: `Registration request for ${data.name} has been sent to Store Manager (Store #${data.storeId || '104'}) for verification.`,
    };
  };

  const approveRegistration = async (id: string) => {
    const target = pendingRegistrations.find((p) => p.id === id);
    if (!target) return;

    setPendingRegistrations((prev) => prev.filter((p) => p.id !== id));

    const newActiveEmployee: Employee = {
      id: target.id,
      name: target.name,
      email: target.email,
      storeId: target.storeId,
      points: 100, // Onboarding welcome bonus
      weeklyPoints: 100,
      monthlyPoints: 100,
      posAdoption: 75,
      customerFeedbackScore: 80,
      salesConversion: 70,
      engagementScore: 85,
      badges: ['knowledge-seeker'],
      completedModules: [],
      active: true,
      approvalStatus: 'approved',
      color: target.avatarColor || COLORS.teal,
      joinDate: target.joinDate,
    };

    setEmployees((prev) => [newActiveEmployee, ...prev]);

    const approvalNotif: NotificationItem = {
      id: `notif-appr-${Date.now()}`,
      recipientId: target.id,
      icon: 'Award',
      text: `🎉 Welcome to QuestFloor! Store Manager Priya Patel approved your account. +100 XP Welcome Bonus Credited.`,
      time: 'Just Now',
      read: false,
    };
    setNotifications((prev) => [approvalNotif, ...prev]);

    showToast(`Approved ${target.name}! Account activated with +100 XP.`, '✅');
    sounds.playLevelUp();
  };

  const rejectRegistration = async (id: string) => {
    const target = pendingRegistrations.find((p) => p.id === id);
    setPendingRegistrations((prev) => prev.filter((p) => p.id !== id));
    showToast(`Rejected registration request for ${target?.name || 'staff'}.`, 'ℹ️');
  };

  const updateManagerProfileData = async (data: any) => {
    setManagerProfile((prev) => ({ ...prev, ...data }));
    showToast('Manager profile and shift targets updated!', '💾');
  };

  const resetDemoData = () => {
    setEmployees(EMPLOYEES_INIT);
    setTrainingModules(TRAINING_MODULES_INIT);
    setChallenges(CHALLENGES_INIT);
    setRecognitions(RECOGNITIONS_INIT);
    setNotifications(NOTIFICATIONS_INIT);
    setPublishedQuizzes([]);
    setRedeemedVouchers(INITIAL_VOUCHERS);
    setFeedbackSubmissions(INITIAL_FEEDBACK);
    setStoreMissions(INITIAL_MISSIONS);
    setPendingRegistrations([
      {
        id: 'e-pending-1',
        name: 'Rohan Sharma',
        email: 'rohan.sharma@retailrise.com',
        role: 'employee',
        storeId: 's1',
        joinDate: 'Today (10 mins ago)',
        avatarColor: '#f59e0b',
      },
    ]);
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    showToast('Demo data reset to default seed.', '🔄');
  };

  return (
    <AppContext.Provider
      value={{
        role,
        screen,
        mobileOpen,
        setMobileOpen,
        currentEmployeeId: activeEmployeeId,
        setSelectedEmployeeId: setActiveEmployeeId,
        currentManagerId: CURRENT_MANAGER_ID,
        currentEmployee,
        currentManager,
        admin,
        employees,
        stores,
        managers,
        trainingModules,
        challenges,
        recognitions,
        notifications,
        toast,
        celebration,
        publishedQuizzes,
        redeemedVouchers,
        feedbackSubmissions,
        storeMissions,
        pendingRegistrations,
        managerProfile,
        registerPendingEmployee,
        approveRegistration,
        rejectRegistration,
        updateManagerProfileData,
        isStoryModalOpen,
        setIsStoryModalOpen,
        language,
        setLanguage,
        theme,
        setTheme,
        toggleTheme,
        t,
        setRole,
        setScreen,
        showToast,
        fireCelebration,
        handleLogin,
        handleLogout,
        finishModule,
        completeChallenge,
        giveRecognition,
        likeRecognition,
        markNotificationsRead,
        nudgeEmployee,
        createChallenge,
        publishAIQuiz,
        sendAnnouncement,
        toggleEmployeeActive,
        resetDemoData,
        redeemReward,
        submitCustomerFeedback,
        claimMissionReward,
        sendManagerAction,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppStore() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppStore must be used within an AppProvider');
  }
  return context;
}
