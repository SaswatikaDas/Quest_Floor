import { Employee, LevelStatus, CXBreakdown, Store } from '../types';
import { LEVELS, COLORS } from './constants';
import { TRAINING_MODULES_INIT } from './data/initialData';

export const avg = (arr: number[]): number =>
  arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : 0;

export const trainingPct = (emp: Employee, modules = TRAINING_MODULES_INIT): number =>
  modules.length ? Math.round((emp.completedModules.length / modules.length) * 100) : 0;

export function getLevelInfo(points: number): LevelStatus {
  let current = LEVELS[0];
  for (const l of LEVELS) {
    if (points >= l.min) {
      current = l;
    }
  }
  const idx = LEVELS.findIndex((l) => l.level === current.level);
  const next = LEVELS[idx + 1];
  const progressPct = next
    ? Math.min(100, Math.max(0, Math.round(((points - current.min) / (next.min - current.min)) * 100)))
    : 100;
  const pointsToNext = next ? Math.max(0, next.min - points) : 0;

  return {
    ...current,
    next,
    pointsToNext,
    progressPct,
  };
}

/**
 * Computes Customer Experience (CX) Score (0 - 100)
 * Weighted Formula:
 * - Product Training Completion: 20%
 * - Digital POS Adoption: 25%
 * - Customer Feedback / CSAT: 25%
 * - Sales / Upsell Conversion: 15%
 * - Associate Engagement: 15%
 */
export function calculateCX(employees: Employee[], modules = TRAINING_MODULES_INIT): CXBreakdown {
  if (!employees.length) {
    return {
      score: 0,
      label: 'Needs Attention',
      color: COLORS.coral,
      trainingAvg: 0,
      posAvg: 0,
      feedbackAvg: 0,
      salesAvg: 0,
      engagementAvg: 0,
    };
  }

  const trainingAvg = avg(employees.map((e) => trainingPct(e, modules)));
  const posAvg = avg(employees.map((e) => e.posAdoption));
  const feedbackAvg = avg(employees.map((e) => e.customerFeedbackScore));
  const salesAvg = avg(employees.map((e) => e.salesConversion));
  const engagementAvg = avg(employees.map((e) => e.engagementScore));

  const weightedScore = Math.round(
    trainingAvg * 0.20 +
    posAvg * 0.25 +
    feedbackAvg * 0.25 +
    salesAvg * 0.15 +
    engagementAvg * 0.15
  );

  let label: 'Excellent' | 'Good' | 'Needs Attention' = 'Needs Attention';
  let color = COLORS.coral;

  if (weightedScore >= 85) {
    label = 'Excellent';
    color = COLORS.teal;
  } else if (weightedScore >= 70) {
    label = 'Good';
    color = COLORS.amberDeep;
  }

  return {
    score: weightedScore,
    label,
    color,
    trainingAvg,
    posAvg,
    feedbackAvg,
    salesAvg,
    engagementAvg,
  };
}

export const getStoreCity = (stores: Store[], id: string): string =>
  stores.find((s) => s.id === id)?.city || '—';

export const getStoreName = (stores: Store[], id: string): string =>
  stores.find((s) => s.id === id)?.name || '—';

export const getEmployeeName = (employees: Employee[], id: string): string => {
  const found = employees.find((e) => e.id === id);
  if (found) return found.name;
  if (id === 'mgr1') return 'Anil Deshmukh';
  if (id === 'mgr2') return 'Rekha Menon';
  if (id === 'mgr3') return 'Sanjay Gupta';
  if (id === 'admin1') return 'Neha Kapoor';
  return 'Associate';
};

export const getInitials = (name: string): string =>
  name
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
