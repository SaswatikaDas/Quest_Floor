import { Employee, SkillScore, TrainingModule, GeneratedQuestion, AIQuizDraft } from '../types';
import { COLORS } from './constants';
import { trainingPct } from './cxCalculator';

export const SKILL_CATEGORY_MAP: Record<string, TrainingModule['category']> = {
  'Product Knowledge': 'Product Knowledge',
  'Customer Service': 'Customer Service',
  'Sales': 'Sales Skills',
  'POS': 'POS Training',
};

export function computeSkillScores(emp: Employee, modules: TrainingModule[]): SkillScore[] {
  const productModules = modules.filter((m) => m.category === 'Product Knowledge');
  const productDone = productModules.filter((m) => emp.completedModules.includes(m.id)).length;
  const productPct = productModules.length ? Math.round((productDone / productModules.length) * 100) : 0;

  return [
    { skill: 'Product Knowledge', score: Math.round(productPct * 0.55 + emp.engagementScore * 0.45) },
    { skill: 'Customer Service', score: emp.customerFeedbackScore },
    { skill: 'Sales', score: emp.salesConversion },
    { skill: 'POS', score: emp.posAdoption },
  ];
}

export function primarySkillGap(emp: Employee, modules: TrainingModule[]): SkillScore {
  const scores = computeSkillScores(emp, modules);
  return scores.reduce((worst, current) => (current.score < worst.score ? current : worst), scores[0]);
}

export function aiConfidence(emp: Employee, gapScore: number): number {
  const seed = emp.id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  return Math.min(97, Math.max(72, 96 - Math.round(gapScore / 6) + (seed % 5)));
}

export function getImpactLevel(value: number, { high = 60, medium = 75 } = {}): { label: 'High' | 'Medium' | 'Low'; dot: string; color: string } {
  if (value < high) return { label: 'High', dot: '🔴', color: COLORS.coral };
  if (value < medium) return { label: 'Medium', dot: '🟡', color: COLORS.amberDeep };
  return { label: 'Low', dot: '🟢', color: COLORS.teal };
}

export function getExplainabilityFactors(emp: Employee, storeAvgPos: number, modules: TrainingModule[]) {
  const gap = primarySkillGap(emp, modules);
  const posGapPct = Math.max(0, storeAvgPos - emp.posAdoption);

  return [
    {
      label: 'Digital POS usage',
      value: `${emp.posAdoption}%`,
      impact: getImpactLevel(gap.skill === 'POS' ? emp.posAdoption : 80),
    },
    {
      label: 'Micro-training completion',
      value: `${trainingPct(emp, modules)}%`,
      impact: getImpactLevel(trainingPct(emp, modules), { high: 55, medium: 75 }),
    },
    {
      label: 'Customer CSAT feedback',
      value: `${emp.customerFeedbackScore}%`,
      impact: getImpactLevel(emp.customerFeedbackScore, { high: 65, medium: 82 }),
    },
    {
      label: 'Store peer average comparison',
      value: `${storeAvgPos}%`,
      impact: getImpactLevel(100 - posGapPct, { high: 80, medium: 92 }),
    },
  ];
}

/* ============================== AI GENERATOR ENGINE ============================== */
export function generateAIQuiz(params: {
  product: string;
  skill: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  numQuestions: number;
  scenarioBased: boolean;
  language: string;
  timeLimit: number;
}): AIQuizDraft {
  const { product, skill, difficulty, numQuestions, scenarioBased, language, timeLimit } = params;
  const questions: GeneratedQuestion[] = [];

  const reward = difficulty === 'Hard' ? 200 : difficulty === 'Medium' ? 150 : 100;
  const baseCount = scenarioBased ? Math.max(1, numQuestions - 1) : numQuestions;

  for (let i = 1; i <= baseCount; i++) {
    questions.push({
      id: `q-gen-${Date.now()}-${i}`,
      type: 'MCQ',
      difficulty,
      prompt: `Which approach best reflects optimal ${skill.toLowerCase()} standards when handling "${product}"?`,
      options: [
        `Follow standard ${skill.toLowerCase()} retail guidelines tailored for ${product}`,
        `Skip customer consultation if the floor rush is heavy`,
        `Improvise pricing without verifying on the POS scanner`,
        `Direct the shopper to check the competitor website`,
      ],
      correct: 0,
    });
  }

  if (scenarioBased) {
    questions.push({
      id: `q-gen-${Date.now()}-scenario`,
      type: 'Scenario-based',
      difficulty,
      prompt: `Roleplay Scenario: A customer walks into the store looking for "${product}" for an upcoming family celebration. They express budget doubts. What is the recommended consultative response?`,
      options: [
        `Ask clarifying questions regarding their preference, highlight product value & mention available store combo offers`,
        `Insist on selling the highest-priced alternative immediately`,
        `Tell them you cannot assist until they decide their budget`,
        `Walk away to restock adjacent shelves`,
      ],
      correct: 0,
    });
  }

  return {
    id: `quiz-draft-${Date.now()}`,
    product,
    skill,
    difficulty,
    language,
    timeLimit,
    questions: questions.slice(0, numQuestions),
    challengeTitle: `Recommend the right ${product} to 3 simulated customers with 0 errors`,
    rewardPoints: reward,
    createdAt: new Date().toISOString(),
  };
}

export function evaluateScenarioRubric(difficulty: 'Easy' | 'Medium' | 'Hard') {
  const base = difficulty === 'Hard' ? 82 : difficulty === 'Medium' ? 88 : 94;
  const rubric = [
    { label: 'Empathy & Rapport', score: Math.min(100, base + 4) },
    { label: 'Policy Adherence', score: Math.min(100, base - 5) },
    { label: 'Clear Communication', score: Math.min(100, base + 2) },
    { label: 'Problem Resolution', score: Math.min(100, base - 1) },
  ];
  const overall = Math.round(rubric.reduce((a, r) => a + r.score, 0) / rubric.length);

  return {
    rubric,
    overall,
    feedback: 'High empathy and clear tone observed. Ensure store return policy terms are mentioned before initiating warranty replacement.',
  };
}
