import { Employee, TrainingModule, XAIAttribution, CounterfactualParams, CounterfactualResult } from '../types';
import { trainingPct } from './cxCalculator';

export function getGlassboxAttributions(emp: Employee, modules: TrainingModule[]): XAIAttribution[] {
  const trnPct = trainingPct(emp, modules);

  return [
    {
      feature: 'Digital POS Floor Adoption',
      weightPct: 25,
      currentValue: `${emp.posAdoption}%`,
      impactDirection: emp.posAdoption >= 75 ? 'positive' : emp.posAdoption >= 60 ? 'neutral' : 'negative',
      explanation:
        emp.posAdoption >= 75
          ? 'Fast barcode scan rate eliminates pricing mismatches and billing queues.'
          : 'Low digital terminal usage creates inventory sync delays and checkout friction.',
    },
    {
      feature: 'Micro-Curriculum Mastery',
      weightPct: 20,
      currentValue: `${trnPct}% (${emp.completedModules.length}/${modules.length})`,
      impactDirection: trnPct >= 70 ? 'positive' : 'negative',
      explanation: 'Quiz scores demonstrate consistent festive catalog and return policy knowledge.',
    },
    {
      feature: 'Shopper CSAT & Sentiment',
      weightPct: 25,
      currentValue: `${emp.customerFeedbackScore}% 5-Star`,
      impactDirection: emp.customerFeedbackScore >= 80 ? 'positive' : 'neutral',
      explanation: 'Direct post-checkout customer survey ratings logged on digital receipts.',
    },
    {
      feature: 'Consultative Sales Conversion',
      weightPct: 15,
      currentValue: `${emp.salesConversion}% Basket Lift`,
      impactDirection: emp.salesConversion >= 70 ? 'positive' : 'neutral',
      explanation: 'Frequency of recommending relevant add-ons (cufflinks, dupatta, diya combos).',
    },
    {
      feature: 'Associate Morale & Recognition',
      weightPct: 15,
      currentValue: `${emp.engagementScore}% Morale`,
      impactDirection: emp.engagementScore >= 80 ? 'positive' : 'neutral',
      explanation: 'Peer recognition volume, attendance consistency, and daily challenge streaks.',
    },
  ];
}

export function simulateCounterfactual(
  currentEmp: Employee,
  allEmployees: Employee[],
  totalModules: number,
  params: CounterfactualParams
): CounterfactualResult {
  const simulatedTrainingPct = Math.round((params.completedModulesCount / totalModules) * 100);

  // Compute simulated CX for this employee
  const currentEmpCX = Math.round(
    trainingPct(currentEmp) * 0.20 +
    currentEmp.posAdoption * 0.25 +
    currentEmp.customerFeedbackScore * 0.25 +
    currentEmp.salesConversion * 0.15 +
    currentEmp.engagementScore * 0.15
  );

  const simulatedEmpCX = Math.round(
    simulatedTrainingPct * 0.20 +
    params.posAdoption * 0.25 +
    params.csatScore * 0.25 +
    params.upsellConversion * 0.15 +
    currentEmp.engagementScore * 0.15
  );

  const cxDelta = simulatedEmpCX - currentEmpCX;

  // Projected Points from new modules and POS milestones
  const extraPoints = (params.completedModulesCount - currentEmp.completedModules.length) * 100 +
    (params.posAdoption > currentEmp.posAdoption ? Math.round((params.posAdoption - currentEmp.posAdoption) * 4) : 0);

  const simulatedPoints = currentEmp.points + Math.max(0, extraPoints);

  // Re-calculate Leaderboard Rank
  const simulatedList = allEmployees.map((e) =>
    e.id === currentEmp.id ? { ...e, points: simulatedPoints } : e
  );
  simulatedList.sort((a, b) => b.points - a.points);
  const projectedRank = simulatedList.findIndex((e) => e.id === currentEmp.id) + 1;

  // ETA to next level
  const pointsNeeded = Math.max(0, 1600 - simulatedPoints);
  const daysToNextLevel = pointsNeeded === 0 ? 0 : Math.max(1, Math.ceil(pointsNeeded / 45));

  // Store Revenue Lift
  const storeRevenueLiftPct = +(
    ((params.posAdoption - currentEmp.posAdoption) * 0.08) +
    ((params.upsellConversion - currentEmp.salesConversion) * 0.14)
  ).toFixed(1);

  const unlockedBadgesCount = Math.min(
    8,
    currentEmp.badges.length + (params.posAdoption >= 90 ? 1 : 0) + (params.completedModulesCount >= 8 ? 1 : 0)
  );

  return {
    simulatedCX: simulatedEmpCX,
    cxDelta,
    projectedRank,
    daysToNextLevel,
    unlockedBadgesCount,
    storeRevenueLiftPct: Math.max(0, storeRevenueLiftPct),
  };
}
