/**
 * QuestFloor / RetailRise API Client
 * Seamlessly interfaces React frontend with Python FastAPI Backend (http://localhost:8000/api)
 * with robust local fallback for ultra-smooth presentation.
 */

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';

async function fetchJSON<T>(endpoint: string, options?: RequestInit): Promise<T | null> {
  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    });
    if (!res.ok) {
      console.warn(`API call to ${endpoint} failed with status:`, res.status);
      return null;
    }
    return await res.json();
  } catch (err) {
    console.warn(`Backend connection to ${endpoint} unavailable, using intelligent local engine:`, err);
    return null;
  }
}

export const api = {
  // Authentication & Registration
  async login(credentials: { email_or_username: string; password?: string; role?: string }) {
    return fetchJSON<{ status: string; message: string; user: any; token?: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        email_or_username: credentials.email_or_username,
        password: credentials.password || 'pass123',
        role: credentials.role || 'employee',
      }),
    });
  },
  async register(data: { name: string; email: string; password?: string; role?: string; store_id?: string; staff_id?: string }) {
    return fetchJSON<{ status: string; message: string; user: any; token?: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        name: data.name,
        email: data.email,
        password: data.password || 'pass123',
        role: data.role || 'employee',
        store_id: data.store_id || 's104',
        staff_id: data.staff_id,
      }),
    });
  },

  // Health & Personas
  async getHealth() {
    return fetchJSON<{ status: string }>('/health');
  },
  async getPersonas() {
    return fetchJSON<{ personas: any[] }>('/auth/personas');
  },

  // Employees & Gamification
  async getEmployee(id: string) {
    return fetchJSON<any>(`/employees/${id}`);
  },
  async addXP(employeeId: string, xpAmount: number, reason: string, badgeToUnlock?: string) {
    return fetchJSON<any>(`/employees/${employeeId}/add-xp`, {
      method: 'POST',
      body: JSON.stringify({
        xp_amount: xpAmount,
        reason,
        badge_to_unlock: badgeToUnlock,
      }),
    });
  },
  async getLeaderboard(scope = 'store', storeId = 's104') {
    return fetchJSON<{ leaderboard: any[] }>(`/employees/leaderboard/top?scope=${scope}&store_id=${storeId}`);
  },
  async getNotifications(employeeId: string) {
    return fetchJSON<{ notifications: any[] }>(`/employees/${employeeId}/notifications`);
  },

  // Learning & Quizzes
  async getModules() {
    return fetchJSON<any[]>('/learning/modules');
  },
  async submitQuiz(employeeId: string, moduleId: string, selectedAnswers: Record<string, number>) {
    return fetchJSON<any>('/learning/quiz/submit', {
      method: 'POST',
      body: JSON.stringify({
        employee_id: employeeId,
        module_id: moduleId,
        selected_answers: selectedAnswers,
      }),
    });
  },
  async getChallenges() {
    return fetchJSON<{ challenges: any[] }>('/learning/challenges/active');
  },

  // POS Sandbox & Speed Billing
  async getPOSCatalog() {
    return fetchJSON<{ catalog: any[] }>('/pos/catalog');
  },
  async processPOSCheckout(payload: {
    employee_id: string;
    store_id?: string;
    customer_name?: string;
    items: any[];
    coupon_code?: string;
    discount_amount?: number;
    payment_method?: string;
  }) {
    return fetchJSON<any>('/pos/checkout', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Peer Recognition
  async getRecognitionFeed() {
    return fetchJSON<{ feed: any[] }>('/recognition/feed');
  },
  async sendRecognition(payload: {
    sender_id: string;
    receiver_id: string;
    message: string;
    badge_tagged?: string;
  }) {
    return fetchJSON<any>('/recognition/send', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async likeRecognition(recognitionId: string) {
    return fetchJSON<any>(`/recognition/${recognitionId}/like`, {
      method: 'POST',
    });
  },

  // Manager & Analytics
  async getStoreDashboard(storeId = 's104') {
    return fetchJSON<any>(`/manager/store/${storeId}`);
  },
  async getMultiStoreOverview() {
    return fetchJSON<any>('/manager/multi-store-overview');
  },
  async getPendingRegistrations(storeId = 's104') {
    return fetchJSON<{ pending_count: number; requests: any[] }>(`/manager/store/${storeId}/pending-registrations`);
  },
  async approveEmployee(employeeId: string) {
    return fetchJSON<any>(`/manager/employee/${employeeId}/approve`, {
      method: 'POST',
    });
  },
  async rejectEmployee(employeeId: string) {
    return fetchJSON<any>(`/manager/employee/${employeeId}/reject`, {
      method: 'POST',
    });
  },
  async updateManagerProfile(payload: any) {
    return fetchJSON<any>('/manager/profile/update', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async assignNudge(storeId: string, employeeId: string, challengeTitle: string) {
    return fetchJSON<any>(`/manager/store/${storeId}/assign-nudge`, {
      method: 'POST',
      body: JSON.stringify({ employee_id: employeeId, challenge_title: challengeTitle }),
    });
  },

  // LLM Features
  async roleplayTurn(payload: {
    persona_id: string;
    persona_name: string;
    conversation_history: any[];
    associate_message: string;
  }) {
    return fetchJSON<any>('/llm/roleplay/turn', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async evaluateRoleplay(payload: {
    persona_name: string;
    scenario_title: string;
    conversation_history: any[];
  }) {
    return fetchJSON<any>('/llm/roleplay/evaluate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async askCopilot(query: string, employeeId = 'e-amit', contextType = 'general') {
    return fetchJSON<any>('/llm/copilot', {
      method: 'POST',
      body: JSON.stringify({ query, employee_id: employeeId, context_type: contextType }),
    });
  },
  async polishKudos(rawNotes: string, receiverName: string, senderName: string, helpContext?: string) {
    return fetchJSON<any>('/llm/polish-kudos', {
      method: 'POST',
      body: JSON.stringify({
        raw_notes: rawNotes,
        receiver_name: receiverName,
        sender_name: senderName,
        help_context: helpContext,
      }),
    });
  },
  async generateLesson(topic: string, targetRole = 'Store Associate', storeTier = 'Tier-3 Retail Hub') {
    return fetchJSON<any>('/llm/generate-lesson', {
      method: 'POST',
      body: JSON.stringify({ topic, target_role: targetRole, store_tier: storeTier }),
    });
  },
  async generateManagerInsights(storeId = 's104', metrics?: any) {
    return fetchJSON<any>('/llm/manager-insights', {
      method: 'POST',
      body: JSON.stringify({ store_id: storeId, metrics }),
    });
  },
};
