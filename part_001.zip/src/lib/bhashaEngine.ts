import { DialectScenario, DialectEvaluation, VernacularLanguage } from '../types';

export const BHASHA_SCENARIOS: DialectScenario[] = [
  {
    id: 'bh-hinglish',
    language: 'Hinglish',
    nativeTitle: 'Hinglish Festive Rush & Sizing',
    customerQuery: '“Bhaiya, ye Kurta set bahut sundar hai but thoda loose lag raha hai. Kya iska Medium size trial room me mil sakta hai? Also online 10% sasta mil raha hai.”',
    phoneticAudioText: 'Bhaiya, ye Kurta set bahut sundar hai but thoda loose lag raha hai...',
    englishMeaning: '“Brother, this Kurta set looks beautiful but feels a bit loose. Can I get a Medium size in the trial room? Also it is 10% cheaper online.”',
    keyPolitenessTokens: ['ji', 'bilkul', 'aaiye sir', 'trial room', 'instant exchange', 'quality warranty'],
    idealPitch: '“Ji bilkul sir! Main abhi aapke liye Medium size trial room me arrange kar deta hoon. Store me aapko instant fit trial aur 100% genuine warranty milti hai jo online me possible nahi.”',
    context: 'Fast-paced metro / Tier-2 mixed language interaction with price comparison.',
  },
  {
    id: 'bh-hindi',
    language: 'Hindi',
    nativeTitle: 'शुद्ध हिंदी: पूजा दीया व उपहार कॉम्बो',
    customerQuery: '“नमस्ते जी! क्या यह पीतल का दीया और लालटेन सेट दिवाली पूजा के लिए उपयुक्त है? क्या आप इसमें विशेष उपहार पैकिंग कर देंगे?”',
    phoneticAudioText: 'Namaste ji! Kya yeh peetal ka diya set Diwali puja ke liye...',
    englishMeaning: '“Namaste! Is this brass diya and lantern set suitable for Diwali puja? Will you provide special gift packaging for it?”',
    keyPolitenessTokens: ['नमस्ते', 'जी', 'अवश्य', 'उपहार', 'पूजा', 'निःशुल्क'],
    idealPitch: '“नमस्ते जी! यह विशुद्ध पीतल का बना है और पूजा के लिए अत्यंत शुभ है। हमारे पास इसके साथ निःशुल्क उपहार पैकिंग की सुविधा भी उपलब्ध है।”',
    context: 'Traditional festive shopper looking for respectful cultural tone and free gift packing.',
  },
  {
    id: 'bh-marathi',
    language: 'Marathi',
    nativeTitle: 'मराठी: सणासुदीचे कॉम्बो व बजेट',
    customerQuery: '“नमस्कार, मला कुटुंबासाठी 4 भेटवस्तूंचे बॉक्सेस हवे आहेत. 2000 रुपयांच्या बजेटमध्ये तुमच्याकडे कोणता उत्तम कॉम्बो उपलब्ध आहे?”',
    phoneticAudioText: 'Namaskar, mala kutumbasathi 4 bhetvastunche boxes have aahet...',
    englishMeaning: '“Hello, I need 4 gift boxes for my family. What is the best combo available within a ₹2,000 budget?”',
    keyPolitenessTokens: ['नमस्कार', 'नक्कीच', 'उत्तम', 'कॉम्बो', 'पॅकिंग', 'धन्यवाद'],
    idealPitch: '“नमस्कार सर! आमच्याकडे 499 रुपयांचा खास पितळी दिवा आणि कंदील कॉम्बो आहे. 2000 रुपयांत चारही बॉक्सेस मोफत गिफ्ट पॅकिंगसह तयार होतील!”',
    context: 'Nagpur / Pune regional customer looking for polite Marathi greeting and exact budget fit.',
  },
  {
    id: 'bh-tamil',
    language: 'Tamil',
    nativeTitle: 'தமிழ்: பண்டிகை காம்போ & விரைவு பில்லிங்',
    customerQuery: '“வணக்கம் (Vanakkam)! Indha festive saree-kku matching stole irukka? Innum 10 mins-la train irukku, UPI QR-la fast-ah bill panna mudiyuma?”',
    phoneticAudioText: 'Vanakkam! Indha festive saree-kku matching stole irukka?...',
    englishMeaning: '“Greetings! Do you have a matching stole for this saree? I have a train in 10 mins, can you bill fast via UPI QR?”',
    keyPolitenessTokens: ['vanakkam', 'kandippa', 'matching', 'instant upi', 'nandri'],
    idealPitch: '“Vanakkam madam! Kandippa irukku, idho matching silk stole. Namma POS terminal-la 30 seconds-la UPI QR scan panni express checkout mudichidalaam!”',
    context: 'Coimbatore / Chennai express customer needing warm Vanakkam and fast digital checkout.',
  },
  {
    id: 'bh-telugu',
    language: 'Telugu',
    nativeTitle: 'తెలుగు: పండుగ బహుమతి & కాంబో ఆఫర్లు',
    customerQuery: '“నమస్కారం (Namaskaram)! Ee festive hamper lo customized sweet box add cheyyocha? Gift card payment accept chesthara?”',
    phoneticAudioText: 'Namaskaram! Ee festive hamper lo customized sweet box...',
    englishMeaning: '“Greetings! Can I add a customized sweet box to this festive hamper? Do you accept gift card payment?”',
    keyPolitenessTokens: ['namaskaram', 'tappakunda', 'customization', 'gift card', 'dhanyavadalu'],
    idealPitch: '“Namaskaram sir! Tappakunda, meeku istamaina sweets add chesi customized packing chestham. Mana POS lo Gift Card + UPI split payment easy ga avuthundi!”',
    context: 'Hyderabad / Tier-3 AP/Telangana festive shopper requiring polite Telugu consultation.',
  },
];

export function evaluateVernacularResponse(
  scenario: DialectScenario,
  associatePitch: string
): DialectEvaluation {
  const text = associatePitch.toLowerCase();

  let politenessScore = 70;
  let clarityScore = 75;
  let translationAccuracy = 80;

  // Check politeness tokens
  let matchedTokens = 0;
  scenario.keyPolitenessTokens.forEach((token) => {
    if (text.includes(token.toLowerCase())) {
      matchedTokens++;
      politenessScore += 7;
      clarityScore += 5;
    }
  });

  if (text.includes('ji') || text.includes('sir') || text.includes('madam') || text.includes('namaste') || text.includes('namaskar') || text.includes('vanakkam')) {
    politenessScore += 8;
  }

  if (text.includes('499') || text.includes('packing') || text.includes('upi') || text.includes('trial') || text.includes('warranty') || text.includes('pos')) {
    translationAccuracy += 10;
  }

  politenessScore = Math.min(99, Math.max(65, politenessScore));
  clarityScore = Math.min(98, Math.max(70, clarityScore));
  translationAccuracy = Math.min(100, Math.max(72, translationAccuracy));

  const bonusXP = politenessScore >= 85 ? 120 : 80;

  let etiquetteFeedback = 'Great conversational flow and respectful greeting.';
  if (matchedTokens < 2) {
    etiquetteFeedback = `Add traditional local greetings (e.g. "${scenario.keyPolitenessTokens[0]}") to establish immediate cultural warmth with the shopper.`;
  }

  return {
    politenessScore,
    clarityScore,
    translationAccuracy,
    culturalEtiquetteFeedback: etiquetteFeedback,
    suggestedVernacularPitch: scenario.idealPitch,
    bonusXP,
  };
}
