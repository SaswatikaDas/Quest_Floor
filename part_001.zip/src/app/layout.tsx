import type { Metadata } from 'next';
import { Space_Grotesk, Inter, JetBrains_Mono } from 'next/font/google';
import './globals.css';
import { AppProvider } from '../lib/store/useAppStore';

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  weight: ['500', '600', '700'],
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  weight: ['400', '500', '600', '700'],
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  weight: ['500', '600', '700'],
});

export const metadata: Metadata = {
  title: 'QuestFloor – AI Workforce Engagement & Customer Experience Platform',
  description:
    'Real-time workforce engagement, generative AI micro-learning, gamification, and Customer Experience (CX) platform for 1,200 retail stores and 3,000 associates.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrainsMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col font-sans bg-[#F5F5FB] text-[#1B1C29]">
        <AppProvider>{children}</AppProvider>
      </body>
    </html>
  );
}
