'use client';

import React from 'react';
import { useAppStore } from '../lib/store/useAppStore';
import { LoginScreen } from '../components/layout/LoginScreen';
import { Sidebar } from '../components/layout/Sidebar';
import { Topbar } from '../components/layout/Topbar';
import { Toast } from '../components/common/Toast';
import { CelebrationModal } from '../components/common/CelebrationModal';
import { NotificationsScreen } from '../components/common/NotificationsScreen';
import { SettingsScreen } from '../components/common/SettingsScreen';
import { OfflineEdgeSyncConsole } from '../components/common/OfflineEdgeSyncConsole';
import { CustomerFeedbackLoop } from '../components/common/CustomerFeedbackLoop';

// Employee Screens
import { EmployeeDashboard } from '../components/employee/EmployeeDashboard';
import { RewardsMarketplace } from '../components/employee/RewardsMarketplace';
import { StoreMissions } from '../components/employee/StoreMissions';
import { MyImpactScreen } from '../components/employee/MyImpactScreen';
import { CXChampionHub } from '../components/employee/CXChampionHub';
import { AICoachScreen } from '../components/employee/AICoachScreen';
import { VernacularDialectCoach } from '../components/employee/VernacularDialectCoach';
import { SpacedRepetitionDrill } from '../components/employee/SpacedRepetitionDrill';
import { VoiceToneAnalyzer } from '../components/employee/VoiceToneAnalyzer';
import { AIRoleplayArena } from '../components/employee/AIRoleplayArena';
import { XAICounterfactualScreen } from '../components/employee/XAICounterfactualScreen';
import { VisualMerchandisingAuditor } from '../components/employee/VisualMerchandisingAuditor';
import { POSSandboxArena } from '../components/employee/POSSandboxArena';
import { TeamBattleArena } from '../components/employee/TeamBattleArena';
import { LearningCenter } from '../components/employee/LearningCenter';
import { ChallengesScreen } from '../components/employee/ChallengesScreen';
import { LeaderboardScreen } from '../components/employee/LeaderboardScreen';
import { RecognitionScreen } from '../components/employee/RecognitionScreen';
import { AchievementsScreen } from '../components/employee/AchievementsScreen';
import { ProfileScreen } from '../components/employee/ProfileScreen';

// Manager Screens
import { ManagerDashboard } from '../components/manager/ManagerDashboard';
import { ManagerActionCenter } from '../components/manager/ManagerActionCenter';
import { FloorTwinHeatmap } from '../components/manager/FloorTwinHeatmap';
import { ManagerEmployees } from '../components/manager/ManagerEmployees';
import { ManagerPerformance } from '../components/manager/ManagerPerformance';
import { ManagerAIInsights } from '../components/manager/ManagerAIInsights';
import { PredictiveCXForecast } from '../components/manager/PredictiveCXForecast';
import { StoreAnalytics } from '../components/manager/StoreAnalytics';
import { TrainingOverview } from '../components/manager/TrainingOverview';

// Admin Screens
import { AdminDashboard } from '../components/admin/AdminDashboard';
import { TrainingCorrelationMatrix } from '../components/admin/TrainingCorrelationMatrix';
import { AdminEmployees } from '../components/admin/AdminEmployees';
import { AdminStores } from '../components/admin/AdminStores';
import { AdminChallenges } from '../components/admin/AdminChallenges';
import { AdminAIStudio } from '../components/admin/AdminAIStudio';
import { AdminAnalytics } from '../components/admin/AdminAnalytics';
import { AnnouncementComposer } from '../components/admin/AnnouncementComposer';
import { LearnathonStoryModal } from '../components/common/LearnathonStoryModal';
import { COLORS } from '../lib/constants';

export default function MainPage() {
  const { role, screen, toast, celebration, isStoryModalOpen, setIsStoryModalOpen, theme } = useAppStore();

  if (!role) {
    return (
      <>
        <LoginScreen />
        <LearnathonStoryModal isOpen={isStoryModalOpen} onClose={() => setIsStoryModalOpen(false)} />
      </>
    );
  }

  let content: React.ReactNode = null;

  /* ==================== ROLE 1: STORE ASSOCIATE ==================== */
  if (role === 'employee') {
    switch (screen) {
      case 'dashboard':
        content = <EmployeeDashboard />;
        break;
      case 'rewards':
        content = <RewardsMarketplace />;
        break;
      case 'storeMissions':
        content = <StoreMissions />;
        break;
      case 'myImpact':
        content = <MyImpactScreen />;
        break;
      case 'cxChampion':
        content = <CXChampionHub />;
        break;
      case 'csatLoop':
        content = <CustomerFeedbackLoop />;
        break;
      case 'vernacularCoach':
        content = <VernacularDialectCoach />;
        break;
      case 'spacedRepetition':
        content = <SpacedRepetitionDrill />;
        break;
      case 'voiceAnalyzer':
        content = <VoiceToneAnalyzer />;
        break;
      case 'offlineSync':
        content = <OfflineEdgeSyncConsole />;
        break;
      case 'roleplayArena':
        content = <AIRoleplayArena />;
        break;
      case 'xaiCounterfactual':
        content = <XAICounterfactualScreen />;
        break;
      case 'vmAuditor':
        content = <VisualMerchandisingAuditor />;
        break;
      case 'posSandbox':
        content = <POSSandboxArena />;
        break;
      case 'teamBattles':
        content = <TeamBattleArena />;
        break;
      case 'aiCoach':
        content = <AICoachScreen />;
        break;
      case 'learning':
        content = <LearningCenter />;
        break;
      case 'challenges':
        content = <ChallengesScreen />;
        break;
      case 'leaderboard':
        content = <LeaderboardScreen />;
        break;
      case 'recognition':
        content = <RecognitionScreen />;
        break;
      case 'achievements':
        content = <AchievementsScreen />;
        break;
      case 'notifications':
        content = <NotificationsScreen />;
        break;
      case 'profile':
        content = <ProfileScreen />;
        break;
      default:
        content = <EmployeeDashboard />;
    }
  }

  /* ==================== ROLE 2: STORE MANAGER ==================== */
  else if (role === 'manager') {
    switch (screen) {
      case 'dashboard':
        content = <ManagerDashboard />;
        break;
      case 'actionCenter':
        content = <ManagerActionCenter />;
        break;
      case 'storeMissions':
        content = <StoreMissions />;
        break;
      case 'csatLoop':
        content = <CustomerFeedbackLoop />;
        break;
      case 'floorTwin':
        content = <FloorTwinHeatmap />;
        break;
      case 'predictiveCX':
        content = <PredictiveCXForecast />;
        break;
      case 'aiInsights':
        content = <ManagerAIInsights />;
        break;
      case 'employees':
        content = <ManagerEmployees />;
        break;
      case 'performance':
        content = <ManagerPerformance />;
        break;
      case 'storeAnalytics':
        content = <StoreAnalytics />;
        break;
      case 'offlineSync':
        content = <OfflineEdgeSyncConsole />;
        break;
      case 'recognition':
        content = <RecognitionScreen />;
        break;
      case 'training':
        content = <TrainingOverview scopeFilter="manager" />;
        break;
      case 'notifications':
        content = <NotificationsScreen />;
        break;
      case 'settings':
        content = <SettingsScreen />;
        break;
      default:
        content = <ManagerDashboard />;
    }
  }

  /* ==================== ROLE 3: ADMIN / HR HQ ==================== */
  else if (role === 'admin') {
    switch (screen) {
      case 'dashboard':
        content = <AdminDashboard />;
        break;
      case 'correlationMatrix':
        content = <TrainingCorrelationMatrix />;
        break;
      case 'rewards':
        content = <RewardsMarketplace />;
        break;
      case 'csatLoop':
        content = <CustomerFeedbackLoop />;
        break;
      case 'floorTwin':
        content = <FloorTwinHeatmap />;
        break;
      case 'aiStudio':
        content = <AdminAIStudio />;
        break;
      case 'vernacularCoach':
        content = <VernacularDialectCoach />;
        break;
      case 'roleplayArena':
        content = <AIRoleplayArena />;
        break;
      case 'vmAuditor':
        content = <VisualMerchandisingAuditor />;
        break;
      case 'employees':
        content = <AdminEmployees />;
        break;
      case 'stores':
        content = <AdminStores />;
        break;
      case 'training':
        content = (
          <TrainingOverview
            title="Curriculum &amp; Module Completion"
            subtitle="Organization-wide completion rates across all 3,000 associates"
            scopeFilter="all"
          />
        );
        break;
      case 'challenges':
        content = <AdminChallenges />;
        break;
      case 'analytics':
        content = <AdminAnalytics />;
        break;
      case 'offlineSync':
        content = <OfflineEdgeSyncConsole />;
        break;
      case 'recognition':
        content = <RecognitionScreen />;
        break;
      case 'notifications':
        content = (
          <div className="space-y-6">
            <AnnouncementComposer />
            <NotificationsScreen />
          </div>
        );
        break;
      case 'settings':
        content = <SettingsScreen />;
        break;
      default:
        content = <AdminDashboard />;
    }
  }

  const isDark = theme === 'dark';

  return (
    <div
      className={`min-h-screen flex transition-colors duration-200 ${
        isDark ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      <Sidebar />
      <div className="flex-1 min-w-0 flex flex-col">
        <Topbar />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">{content}</main>
      </div>

      <Toast toast={toast} />
      <CelebrationModal celebration={celebration} />
      <LearnathonStoryModal isOpen={isStoryModalOpen} onClose={() => setIsStoryModalOpen(false)} />
    </div>
  );
}
