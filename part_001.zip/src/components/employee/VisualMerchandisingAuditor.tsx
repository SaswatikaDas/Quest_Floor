'use client';

import React, { useState } from 'react';
import {
  Camera,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Award,
  Star,
  Eye,
  Layers,
  Zap,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { ProgressBar } from '../common/ProgressBar';
import { VMDisplayPreset } from '../../types';
import { COLORS } from '../../lib/constants';

const VM_PRESETS: VMDisplayPreset[] = [
  {
    id: 'vm1',
    name: 'Festive Entrance Gifting Table',
    category: 'Entrance Feature',
    imageEmoji: '🪔✨🎁',
    description: 'Central entrance island display featuring brass diya combos, gourmet hampers, and fairy lights.',
    complianceScore: 88,
    ruleOfThreeScore: 92,
    priceTagVisibilityScore: 85,
    shelfFullnessPct: 90,
    findings: [
      { area: 'Grouping Aesthetics', status: 'pass', message: 'Rule of Three applied correctly: 3 tiered heights for diya sets.' },
      { area: 'Price Tag Placement', status: 'pass', message: 'Clear front-facing ₹499 price tags visible on all combos.' },
      { area: 'Left Corner Hamper Stack', status: 'warning', message: 'Leftmost hamper is angled 30° away from the main walkway.' },
    ],
  },
  {
    id: 'vm2',
    name: 'POS Impulse Checkout Rack',
    category: 'Billing Queue',
    imageEmoji: '🍬🏷️🕯️',
    description: 'High-traffic impulse rack located directly adjacent to digital billing terminal 1.',
    complianceScore: 68,
    ruleOfThreeScore: 60,
    priceTagVisibilityScore: 70,
    shelfFullnessPct: 65,
    findings: [
      { area: 'Shelf Stock Fullness', status: 'fail', message: 'Middle row is 35% empty — restock mini scented candles before peak rush.' },
      { area: 'Price Tag Alignment', status: 'warning', message: 'Bottom tag is folded backwards and unreadable.' },
      { area: 'Accessibility', status: 'pass', message: 'Within arm’s reach of customers waiting in the billing queue.' },
    ],
  },
  {
    id: 'vm3',
    name: 'Ethnic Wear Display Table',
    category: 'Apparel Department',
    imageEmoji: '🥻👔🎗️',
    description: 'Folded ethnic wear table showcasing festive cotton-silk kurtas and matching stoles.',
    complianceScore: 94,
    ruleOfThreeScore: 95,
    priceTagVisibilityScore: 92,
    shelfFullnessPct: 96,
    findings: [
      { area: 'Color Flow & Harmony', status: 'pass', message: 'Smooth gradient from gold to royal maroon.' },
      { area: 'Stack Neatness', status: 'pass', message: 'Apparel edges aligned within 1 cm margin.' },
      { area: 'Size Label Indicators', status: 'pass', message: 'Digital size cards placed on top of each stack.' },
    ],
  },
];

export function VisualMerchandisingAuditor() {
  const { fireCelebration } = useAppStore();

  const [selectedPreset, setSelectedPreset] = useState<VMDisplayPreset>(VM_PRESETS[0]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(true);

  const handleRunAudit = () => {
    setIsScanning(true);
    setScanComplete(false);
    setTimeout(() => {
      setIsScanning(false);
      setScanComplete(true);
      fireCelebration({
        emoji: '📸',
        eyebrow: 'Multimodal Vision AI Audit Completed!',
        title: `${selectedPreset.complianceScore}% Store Compliance`,
        sub: '+75 Visual Merchandising XP Awarded',
      });
    }, 1200);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.amberDeep} 0%, ${COLORS.navy} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Multimodal Vision AI
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Edge Inspection Model</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            AI Visual Merchandising (VM) Floor Auditor
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Simulate or inspect store visual displays in real time. AI verifies &ldquo;Rule of Three&rdquo; grouping, price tag visibility, and shelf fullness standards.
          </p>
        </div>

        <button
          onClick={handleRunAudit}
          disabled={isScanning}
          className="px-5 py-3 rounded-2xl font-extrabold text-xs text-slate-900 bg-amber-400 hover:bg-amber-300 shadow-md flex items-center gap-2 shrink-0 transition-all disabled:opacity-50"
        >
          <Camera size={16} />
          <span>{isScanning ? 'Scanning Display…' : 'Run Vision AI Audit'}</span>
        </button>
      </div>

      {/* Preset Selector */}
      <div className="space-y-2">
        <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Select Store Floor Area / Display Type:
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {VM_PRESETS.map((preset) => {
            const isSelected = selectedPreset.id === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => {
                  setSelectedPreset(preset);
                  setScanComplete(true);
                }}
                className={`text-left p-4 rounded-2xl border transition-all duration-200 ${
                  isSelected
                    ? 'bg-amber-50/70 border-amber-400 shadow-md ring-2 ring-amber-400/20'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="text-2xl mb-1">{preset.imageEmoji}</div>
                <div className="font-bold text-xs text-slate-900">{preset.name}</div>
                <div className="text-[11px] text-amber-700 font-semibold">{preset.category}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Audit Scanner View & Findings Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Visual Display Simulator with Bounding Overlays */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5" style={{ borderColor: COLORS.line }}>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-amber-600">
                Visual Inspection Viewport
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">{selectedPreset.name}</h3>
            </div>
            <Pill color={COLORS.navy3}>{selectedPreset.category}</Pill>
          </div>

          {/* Simulated Display Viewport */}
          <div className="relative rounded-3xl overflow-hidden border-2 border-slate-200 bg-slate-900 text-white p-8 min-h-[300px] flex flex-col items-center justify-center text-center">
            {isScanning ? (
              <div className="space-y-3">
                <div className="w-16 h-16 rounded-full border-4 border-amber-400 border-t-transparent animate-spin mx-auto" />
                <div className="text-sm font-bold text-amber-400">
                  Analyzing display symmetry, pricing visibility &amp; stock density…
                </div>
              </div>
            ) : (
              <div className="space-y-4 w-full">
                <div className="text-7xl mb-2">{selectedPreset.imageEmoji}</div>
                <div className="text-sm text-slate-300 max-w-md mx-auto">
                  {selectedPreset.description}
                </div>

                {/* Simulated Bounding Box Tags */}
                {scanComplete && (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-4 pt-4 border-t border-white/10 text-xs">
                    <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400 text-emerald-300 font-bold flex items-center justify-center gap-1.5">
                      <CheckCircle2 size={13} /> Rule of 3: {selectedPreset.ruleOfThreeScore}%
                    </div>
                    <div className="p-2.5 rounded-xl bg-teal-500/20 border border-teal-400 text-teal-300 font-bold flex items-center justify-center gap-1.5">
                      <Eye size={13} /> Price Visible: {selectedPreset.priceTagVisibilityScore}%
                    </div>
                    <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-400 text-amber-300 font-bold flex items-center justify-center gap-1.5">
                      <Layers size={13} /> Stock Full: {selectedPreset.shelfFullnessPct}%
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Overall Score & Actionable Findings */}
        <div className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between" style={{ borderColor: COLORS.line }}>
          <div className="space-y-5">
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-amber-600">
                Audit Score Summary
              </div>
              <div className="font-mono text-4xl font-extrabold text-slate-900 mt-1">
                {selectedPreset.complianceScore}%
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Floor Standard Compliance</div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Actionable Floor Findings:
              </div>
              {selectedPreset.findings.map((f, i) => (
                <div
                  key={i}
                  className={`p-3 rounded-2xl border text-xs space-y-1 ${
                    f.status === 'pass'
                      ? 'bg-emerald-50/50 border-emerald-200 text-emerald-950'
                      : f.status === 'warning'
                      ? 'bg-amber-50/50 border-amber-200 text-amber-950'
                      : 'bg-red-50/50 border-red-200 text-red-950'
                  }`}
                >
                  <div className="font-bold flex items-center justify-between">
                    <span>{f.area}</span>
                    <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded font-bold">
                      {f.status}
                    </span>
                  </div>
                  <div className="text-[11px] leading-snug">{f.message}</div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={handleRunAudit}
            className="mt-6 w-full py-3 rounded-xl font-bold text-xs text-white shadow-md flex items-center justify-center gap-1.5"
            style={{ backgroundColor: COLORS.navy }}
          >
            <Sparkles size={14} />
            <span>Mark Floor Fixed &amp; Re-Audit (+75 XP)</span>
          </button>
        </div>
      </div>
    </div>
  );
}
