'use client';

import React from 'react';
import {
  Trophy,
  Award,
  Star,
  Sparkles,
  Zap,
  CheckCircle2,
  TrendingUp,
  ShieldCheck,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { ProgressBar } from '../common/ProgressBar';
import { COLORS } from '../../lib/constants';

export function CXChampionHub() {
  const { currentEmployee, fireCelebration } = useAppStore();

  const isChampion = currentEmployee.points >= 1400;

  const triggerCelebration = () => {
    fireCelebration({
      emoji: '🏆',
      eyebrow: 'CX Champion Status Confirmed!',
      title: `${currentEmployee.name} · Nagpur Central`,
      sub: '94/100 CX Score · +500 Bonus XP Granted',
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.amberDeep} 0%, ${COLORS.navy} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Customer Experience Excellence
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Top 5% Tier</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            🏆 CX Champion Recognition &amp; Hall of Fame
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Celebrating associates who consistently deliver 90%+ customer satisfaction, zero-error digital billing, and empathetic hospitality.
          </p>
        </div>

        <button
          onClick={triggerCelebration}
          className="px-6 py-3.5 rounded-2xl font-extrabold text-xs text-slate-900 bg-amber-400 hover:bg-amber-300 shadow-md flex items-center gap-2 shrink-0 transition-all"
        >
          <Sparkles size={16} />
          <span>Claim CX Champion Spotlight (+500 XP)</span>
        </button>
      </div>

      {/* Main Champion Card & Metrics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: Official CX Champion Spotlight Certificate */}
        <div className="lg:col-span-1 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs flex flex-col justify-between text-center space-y-4" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="w-20 h-20 rounded-3xl bg-amber-100 border-2 border-amber-300 mx-auto flex items-center justify-center text-4xl shadow-sm">
              🏆
            </div>

            <h3 className="font-extrabold text-xl text-slate-900 mt-3">{currentEmployee.name}</h3>
            <div className="text-xs text-amber-700 font-bold uppercase tracking-wider mt-0.5">
              Verified CX Champion · Level 4 Expert
            </div>
            <div className="text-xs text-slate-400 font-mono mt-0.5">Nagpur Central Flagship Hub</div>
          </div>

          {/* CX Score Gauge */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="text-xs text-slate-500 font-semibold">Composite Floor CX Index</div>
            <div className="font-mono text-4xl font-extrabold text-teal-800 mt-1">
              94 <span className="text-base text-slate-400 font-sans">/ 100</span>
            </div>
            <div className="text-[11px] font-bold text-emerald-700 mt-0.5">Top 3% Chain-Wide</div>
          </div>

          <div className="p-3 rounded-2xl bg-amber-50 text-xs text-amber-950 font-medium italic leading-relaxed border border-amber-200">
            &ldquo;Sneha sets the gold standard for consultative gifting and fast barcode checkout across Maharashtra.&rdquo;
            <div className="text-[10px] font-bold font-sans text-amber-800 mt-1">— Anil Deshmukh (Store Manager)</div>
          </div>
        </div>

        {/* Right 2 Cols: 5 Pillar CX Performance Decomposition */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-amber-700">
              Operational Performance Breakdown
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-0.5">5 Pillars of Consistent CX</h3>
          </div>

          <div className="space-y-4 pt-1">
            {/* Pillar 1: CSAT */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Verified Shopper CSAT (Weight: 25%)</span>
                <span className="font-mono text-teal-700">{currentEmployee.customerFeedbackScore}% 5-Star</span>
              </div>
              <ProgressBar pct={currentEmployee.customerFeedbackScore} color={COLORS.teal} height={8} />
            </div>

            {/* Pillar 2: POS Adoption */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Digital POS Floor Adoption &amp; Speed (Weight: 25%)</span>
                <span className="font-mono text-purple-700">{currentEmployee.posAdoption}%</span>
              </div>
              <ProgressBar pct={currentEmployee.posAdoption} color={COLORS.plum} height={8} />
            </div>

            {/* Pillar 3: Micro-Learning */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Festive Micro-Curriculum Mastery (Weight: 20%)</span>
                <span className="font-mono text-amber-700">88% (7 Modules)</span>
              </div>
              <ProgressBar pct={88} color={COLORS.amber} height={8} />
            </div>

            {/* Pillar 4: Consultative Sales */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Consultative Basket Upsell Conversion (Weight: 15%)</span>
                <span className="font-mono text-rose-700">{currentEmployee.salesConversion}%</span>
              </div>
              <ProgressBar pct={currentEmployee.salesConversion} color={COLORS.coral} height={8} />
            </div>

            {/* Pillar 5: Team Engagement */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Peer Recognition &amp; Shift Morale (Weight: 15%)</span>
                <span className="font-mono text-slate-800">{currentEmployee.engagementScore}%</span>
              </div>
              <ProgressBar pct={currentEmployee.engagementScore} color={COLORS.navy3} height={8} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
