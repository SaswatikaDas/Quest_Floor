'use client';

import React from 'react';
import {
  HeartHandshake,
  Star,
  Zap,
  TrendingUp,
  Award,
  Users,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { StatCard } from '../common/StatCard';
import { COLORS } from '../../lib/constants';

export function MyImpactScreen() {
  const { currentEmployee } = useAppStore();

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.teal} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Frontline Sense of Purpose
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Associate Value Contribution</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            My Customer &amp; Store Impact
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            See exactly how your daily hospitality greetings, fast POS checkouts, and micro-learning mastery elevate your store&apos;s customer satisfaction.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">CX Contribution Lift</div>
          <div className="text-3xl font-extrabold text-emerald-400 mt-0.5">+6.4%</div>
        </div>
      </div>

      {/* Purpose Quote Banner */}
      <div className="p-6 rounded-3xl bg-emerald-50/70 border border-emerald-200 flex items-center gap-4 text-xs sm:text-sm text-emerald-950 font-medium leading-relaxed shadow-xs">
        <span className="text-4xl p-2 rounded-2xl bg-white border border-emerald-200 shrink-0 shadow-xs">
          🌟
        </span>
        <div>
          <strong>You make a tangible difference every shift, {currentEmployee.name}!</strong>
          <p className="text-xs text-emerald-800 mt-0.5">
            Your consultative gifting advice and 82-second average checkout pace helped <strong>Nagpur Central</strong> secure the <strong>#1 Store CX Rank</strong> across Maharashtra this month!
          </p>
        </div>
      </div>

      {/* 6 Key Impact Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard
          icon={Users}
          label="Shoppers Assisted"
          value={126}
          sub="This Month"
          accent={COLORS.teal}
        />
        <StatCard
          icon={Star}
          label="Average CSAT"
          value="94%"
          sub="5-Star Verified"
          accent={COLORS.amber}
        />
        <StatCard
          icon={Zap}
          label="POS Bills"
          value={342}
          sub="Zero Errors"
          accent={COLORS.plum}
        />
        <StatCard
          icon={TrendingUp}
          label="Avg Billing Pace"
          value="82s"
          sub="vs 96s Store Avg"
          accent={COLORS.coral}
        />
        <StatCard
          icon={Award}
          label="Modules Mastered"
          value="7 / 10"
          sub="88% Mastery"
          accent={COLORS.navy3}
        />
        <StatCard
          icon={HeartHandshake}
          label="Peer Shoutouts"
          value={14}
          sub="Received"
          accent={COLORS.teal}
        />
      </div>
    </div>
  );
}
