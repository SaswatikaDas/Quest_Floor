'use client';

import React, { useState } from 'react';
import {
  MessageSquare,
  Sparkles,
  Send,
  RotateCcw,
  CheckCircle2,
  Award,
  Star,
  Brain,
  Zap,
  ArrowRight,
  Smile,
  Meh,
  Frown,
  Mic,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { AnimatedNumber } from '../common/AnimatedNumber';
import { CUSTOMER_PERSONAS, simulateCustomerTurn, evaluateRoleplaySession } from '../../lib/aiRoleplayEngine';
import { CustomerPersona, RoleplayMessage, RoleplayEvaluation } from '../../types';
import { COLORS } from '../../lib/constants';
import { api } from '../../lib/api';

export function AIRoleplayArena() {
  const { fireCelebration, showToast } = useAppStore();

  const [selectedPersona, setSelectedPersona] = useState<CustomerPersona>(CUSTOMER_PERSONAS[0]);
  const [messages, setMessages] = useState<RoleplayMessage[]>([
    {
      sender: 'customer',
      text: CUSTOMER_PERSONAS[0].initialPrompt,
      timestamp: 'Just now',
      sentiment: 'negative',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evaluation, setEvaluation] = useState<RoleplayEvaluation | null>(null);

  const selectPersona = (p: CustomerPersona) => {
    setSelectedPersona(p);
    setMessages([
      {
        sender: 'customer',
        text: p.initialPrompt,
        timestamp: 'Just now',
        sentiment: p.temperament === 'Aggressive' || p.temperament === 'Frustrated' ? 'negative' : 'neutral',
      },
    ]);
    setInputText('');
    setEvaluation(null);
  };

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: RoleplayMessage = {
      sender: 'associate',
      text: inputText.trim(),
      timestamp: 'Just now',
      sentiment: 'positive',
    };

    const updated = [...messages, userMsg];
    setMessages(updated);
    setInputText('');

    // Call Python FastAPI Backend with resilient fallback
    api.roleplayTurn({
      persona_id: selectedPersona.id,
      persona_name: selectedPersona.name,
      conversation_history: updated.map((m) => ({ sender: m.sender, text: m.text })),
      associate_message: userMsg.text,
    }).then((res) => {
      if (res && res.customer_reply) {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'customer',
            text: res.customer_reply,
            timestamp: 'Just now',
            sentiment:
              res.customer_sentiment === 'positive' || res.customer_sentiment === 'satisfied'
                ? 'positive'
                : res.customer_sentiment === 'frustrated' || res.customer_sentiment === 'negative'
                ? 'negative'
                : 'neutral',
          },
        ]);
        if (res.coach_quick_tip) {
          showToast(`💡 Coach: ${res.coach_quick_tip}`);
        }
      } else {
        const response = simulateCustomerTurn(selectedPersona, updated, userMsg.text);
        setMessages((prev) => [
          ...prev,
          {
            sender: 'customer',
            text: response.customerReply,
            timestamp: 'Just now',
            sentiment: response.sentiment,
          },
        ]);
      }
    });
  };

  const handleFinishEvaluation = () => {
    setIsEvaluating(true);
    api.evaluateRoleplay({
      persona_name: selectedPersona.name,
      scenario_title: selectedPersona.scenario,
      conversation_history: messages.map((m) => ({ sender: m.sender, text: m.text })),
    }).then((res) => {
      setIsEvaluating(false);
      if (res && res.overall_score) {
        const mappedEval: RoleplayEvaluation = {
          overallScore: res.overall_score,
          empathyScore: res.empathy_score,
          policyScore: res.product_knowledge_score,
          upsellScore: res.upsell_technique_score,
          xpEarned: res.xp_earned,
          feedback: res.coaching_verdict,
          suggestedResponse: res.strengths?.[0] || 'Good consultative approach.',
        };
        setEvaluation(mappedEval);
        fireCelebration({
          emoji: '🎙️',
          eyebrow: 'Roleplay Simulation Complete!',
          title: `${res.overall_score}% Mastery Score`,
          sub: `+${res.xp_earned} Experience Points Granted`,
        });
      } else {
        const result = evaluateRoleplaySession(selectedPersona, messages);
        setEvaluation(result);
        fireCelebration({
          emoji: '🎙️',
          eyebrow: 'Roleplay Simulation Complete!',
          title: `${result.overallScore}% Mastery Score`,
          sub: `+${result.xpEarned} Experience Points Granted`,
        });
      }
    });
  };

  const restartSession = () => {
    selectPersona(selectedPersona);
  };

  const quickReplies = [
    '“Sir bilkul, 5000mAh battery aur 45W fast charger ke sath 1.5 din backup milega. Sath me ANC Earbuds combo offer me bhi mil jayenge!”',
    '“Online se better, store me aapko instant data transfer, genuine 1-year brand warranty, aur zero-cost EMI milti hai.”',
    '“Aap ₹500 Cash aur baki amount UPI QR se pay kar sakte hain Split Tender billing me.”',
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.plum} 0%, ${COLORS.navy} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Generative AI Feature
            </span>
            <span className="text-xs font-mono font-bold text-white/70">v3.2 Autonomous Engine</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            AI Customer Objection &amp; Roleplay Arena
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Simulate realistic floor interactions with challenging customer personas. Practice objection handling, de-escalation, and consultative selling in a zero-risk sandbox.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 shrink-0 text-center">
          <div className="text-xs text-white/70 font-semibold">Simulation Reward</div>
          <div className="font-mono text-2xl font-extrabold text-amber-400 mt-0.5">+150 XP</div>
        </div>
      </div>

      {/* Persona Selection Pills */}
      <div className="space-y-2">
        <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Select Customer Persona &amp; Floor Scenario:
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {CUSTOMER_PERSONAS.map((p) => {
            const isSelected = selectedPersona.id === p.id;
            return (
              <button
                key={p.id}
                onClick={() => selectPersona(p)}
                className={`text-left p-4 rounded-2xl border transition-all duration-200 flex items-start gap-3 ${
                  isSelected
                    ? 'bg-purple-50/80 border-purple-400 shadow-md ring-2 ring-purple-400/20'
                    : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <span className="text-3xl p-2 rounded-xl bg-white border border-slate-100 shadow-xs">
                  {p.avatar}
                </span>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 truncate">{p.name}</div>
                  <div className="text-[11px] text-purple-700 font-semibold truncate">{p.role}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{p.objectionType}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Roleplay Terminal & Scoring Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Live Turn-by-Turn Chat Terminal */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between min-h-[480px]" style={{ borderColor: COLORS.line }}>
          <div>
            {/* Persona Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{selectedPersona.avatar}</span>
                <div>
                  <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>{selectedPersona.name}</span>
                    <span className="text-[10px] px-2 py-0.2 rounded-full font-bold bg-amber-100 text-amber-800">
                      {selectedPersona.temperament}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500">{selectedPersona.scenario}</div>
                </div>
              </div>

              <button
                onClick={restartSession}
                className="text-xs font-bold text-slate-400 hover:text-slate-700 flex items-center gap-1"
              >
                <RotateCcw size={13} /> Reset
              </button>
            </div>

            {/* Chat Stream */}
            <div className="space-y-3.5 my-4 max-h-[320px] overflow-y-auto pr-1 custom-scrollbar">
              {messages.map((m, i) => {
                const isCustomer = m.sender === 'customer';
                return (
                  <div
                    key={i}
                    className={`flex items-start gap-2.5 ${isCustomer ? 'justify-start' : 'justify-end'}`}
                  >
                    {isCustomer && (
                      <span className="text-2xl shrink-0">{selectedPersona.avatar}</span>
                    )}

                    <div
                      className={`rounded-2xl p-4 max-w-md text-xs sm:text-sm font-medium shadow-xs leading-relaxed ${
                        isCustomer
                          ? 'bg-slate-100 text-slate-900 rounded-tl-xs'
                          : 'bg-purple-600 text-white rounded-tr-xs'
                      }`}
                    >
                      {m.text}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom Chat Input & Quick Chips */}
          <div className="pt-3 border-t border-slate-100 space-y-3">
            {/* Quick response suggestions */}
            <div className="flex gap-2 overflow-x-auto pb-1 text-xs custom-scrollbar">
              {quickReplies.map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => setInputText(chip.replace(/[“”]/g, ''))}
                  className="px-3 py-1.5 rounded-full text-[11px] font-semibold bg-slate-50 border border-slate-200 hover:border-purple-300 hover:bg-purple-50 text-slate-600 truncate max-w-xs shrink-0"
                >
                  💡 {chip}
                </button>
              ))}
            </div>

            <form onSubmit={handleSend} className="flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={`Respond to ${selectedPersona.name.split(' ')[0]} with consultative empathy...`}
                className="flex-1 border rounded-2xl px-4 py-3 text-xs sm:text-sm font-semibold bg-slate-50 text-slate-900 border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
              />

              <button
                type="submit"
                className="px-5 py-3 rounded-2xl font-bold text-xs text-white shadow-md flex items-center gap-1.5 transition-all hover:opacity-90 shrink-0"
                style={{ backgroundColor: COLORS.plum }}
              >
                <Send size={14} />
                <span>Reply</span>
              </button>
            </form>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                <Brain size={13} className="text-purple-600" />
                AI analyzes tone, store policy adherence, and consultative upselling in real time
              </span>

              <button
                onClick={handleFinishEvaluation}
                disabled={messages.length < 2 || isEvaluating}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white shadow-sm flex items-center gap-1.5 transition-all disabled:opacity-40"
                style={{ backgroundColor: COLORS.navy }}
              >
                {isEvaluating ? 'Evaluating…' : 'Finish & Score Session'}
                <ArrowRight size={13} />
              </button>
            </div>
          </div>
        </div>

        {/* Right Col: Real-Time AI Rubric & Coaching Feedback */}
        <div className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-purple-700 mb-2">
              <Award size={15} /> AI Performance Rubric
            </div>
            <div className="text-sm font-bold text-slate-900">
              Session Evaluation &amp; Gold Standard
            </div>

            {evaluation ? (
              <div className="space-y-4 mt-4 animate-in fade-in duration-300">
                {/* 3 Metric Gauges */}
                <div className="grid grid-cols-3 gap-2 text-center font-mono">
                  <div className="bg-teal-50 p-3 rounded-2xl border border-teal-100">
                    <div className="text-[10px] text-teal-600 font-sans font-bold">Empathy</div>
                    <div className="text-lg font-extrabold text-teal-800 mt-0.5">{evaluation.empathyScore}%</div>
                  </div>
                  <div className="bg-purple-50 p-3 rounded-2xl border border-purple-100">
                    <div className="text-[10px] text-purple-600 font-sans font-bold">Policy</div>
                    <div className="text-lg font-extrabold text-purple-800 mt-0.5">{evaluation.policyScore}%</div>
                  </div>
                  <div className="bg-amber-50 p-3 rounded-2xl border border-amber-100">
                    <div className="text-[10px] text-amber-600 font-sans font-bold">Upsell</div>
                    <div className="text-lg font-extrabold text-amber-800 mt-0.5">{evaluation.upsellScore}%</div>
                  </div>
                </div>

                {/* Overall Score Banner */}
                <div
                  className="rounded-2xl p-4 text-center border"
                  style={{
                    backgroundColor: evaluation.overallScore >= 80 ? 'rgba(14,140,130,0.08)' : 'rgba(243,167,18,0.1)',
                    borderColor: evaluation.overallScore >= 80 ? 'rgba(14,140,130,0.2)' : 'rgba(243,167,18,0.2)',
                  }}
                >
                  <div className="text-xs font-bold text-slate-600">Overall Mastery Rating</div>
                  <div className="font-mono text-3xl font-extrabold mt-0.5" style={{ color: COLORS.ink }}>
                    {evaluation.overallScore}%
                  </div>
                  <div className="text-xs font-bold text-amber-700 mt-1">+{evaluation.xpEarned} XP Awarded</div>
                </div>

                {/* AI Coaching Tips */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                  <div className="font-bold text-slate-900 flex items-center gap-1">
                    <Sparkles size={13} className="text-amber-600" /> AI Coach Observation:
                  </div>
                  <p className="text-slate-600 leading-relaxed font-medium">{evaluation.feedback}</p>
                </div>

                {/* Suggested Gold Standard Alternative */}
                <div className="p-3.5 rounded-2xl bg-purple-50/60 border border-purple-200 text-xs space-y-1">
                  <div className="font-bold text-purple-900">✨ Recommended Gold Standard Pitch:</div>
                  <p className="text-purple-950 font-medium italic leading-relaxed">{evaluation.suggestedResponse}</p>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-slate-400 space-y-3">
                <Brain size={36} className="mx-auto text-slate-300 animate-pulse" />
                <p>
                  Respond to the customer&apos;s objection on the left, then click <strong>Finish &amp; Score Session</strong> to evaluate your response against corporate retail standards.
                </p>
              </div>
            )}
          </div>

          <div className="text-[11px] text-slate-400 font-mono pt-4 border-t border-slate-100 text-center">
            Standardized retail simulation training
          </div>
        </div>
      </div>
    </div>
  );
}
