'use client';

import React, { useState } from 'react';
import { CheckCircle2, Clock, Star, Sparkles } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { LessonView } from './LessonView';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';

const CATEGORIES = [
  'All',
  'Product Knowledge',
  'Customer Service',
  'POS Training',
  'Sales Skills',
  'Company Policies',
] as const;

export function LearningCenter() {
  const { currentEmployee, trainingModules, finishModule } = useAppStore();
  const [activeModuleId, setActiveModuleId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const activeModule = trainingModules.find((m) => m.id === activeModuleId);

  if (activeModule) {
    return (
      <LessonView
        module={activeModule}
        alreadyDone={currentEmployee.completedModules.includes(activeModule.id)}
        onExit={() => setActiveModuleId(null)}
        onFinish={finishModule}
      />
    );
  }

  const filteredModules =
    selectedCategory === 'All'
      ? trainingModules
      : trainingModules.filter((m) => m.category === selectedCategory);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
            Micro-Learning Center
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Bite-sized 3–5 minute lessons designed for quick shift learning &amp; instant XP rewards
          </p>
        </div>

        <div className="text-xs font-mono font-bold px-3 py-1 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
          {currentEmployee.completedModules.length} of {trainingModules.length} Modules Completed
        </div>
      </div>

      {/* Category Pills Filter */}
      <div className="flex gap-2 overflow-x-auto pb-1 custom-scrollbar">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all border ${
                isSelected
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Grid of Micro-Modules */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredModules.map((m) => {
          const isDone = currentEmployee.completedModules.includes(m.id);
          return (
            <div
              key={m.id}
              onClick={() => setActiveModuleId(m.id)}
              className="cursor-pointer bg-white rounded-3xl p-6 border shadow-xs transition-all duration-200 hover:-translate-y-1 hover:shadow-md flex flex-col justify-between group"
              style={{ borderColor: COLORS.line }}
            >
              <div>
                {/* Top Emoji + Completed status */}
                <div className="flex items-start justify-between mb-3">
                  <div className="text-4xl p-2 rounded-2xl bg-slate-50 border border-slate-100 group-hover:scale-105 transition-transform">
                    {m.emoji}
                  </div>
                  {isDone ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-full border border-teal-200">
                      <CheckCircle2 size={13} /> Completed
                    </span>
                  ) : (
                    <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
                      Ready to Start
                    </span>
                  )}
                </div>

                <Pill color={COLORS.teal}>{m.category}</Pill>

                <h3 className="font-bold text-base mt-2.5 leading-snug group-hover:text-teal-700 transition-colors" style={{ color: COLORS.ink }}>
                  {m.title}
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 line-clamp-2">
                  {m.description}
                </p>
              </div>

              {/* Bottom Meta */}
              <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-100 text-xs font-semibold">
                <span className="text-slate-400 flex items-center gap-1">
                  <Clock size={13} /> {m.duration}
                </span>
                <span className="text-amber-600 font-bold flex items-center gap-1 font-mono">
                  <Star size={13} /> +{m.points} XP
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
