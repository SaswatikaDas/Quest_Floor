'use client';

import React, { useState } from 'react';
import {
  Swords,
  Gift,
  Trophy,
  Flame,
  Shield,
  Sparkles,
  Award,
  Users,
  CheckCircle2,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { ProgressBar } from '../common/ProgressBar';
import { MysteryBoxReward, StoreBattle } from '../../types';
import { COLORS } from '../../lib/constants';

const DEMO_BATTLE: StoreBattle = {
  id: 'battle-01',
  storeAId: 's1',
  storeBId: 's2',
  storeAName: 'Nagpur Central Tigers 🐅',
  storeBName: 'Indore Palasia Royals 👑',
  storeAPoints: 4820,
  storeBPoints: 4410,
  endsIn: '2 Days, 4 Hours',
  questTitle: 'Festive Micro-Learning & Zero-Error POS Sprint',
};

const MYSTERY_REWARDS: MysteryBoxReward[] = [
  { id: 'r1', title: '🔥 2X Points Multiplier Token', type: 'multiplier', value: 'Active for Next 3 Lessons', emoji: '⚡' },
  { id: 'r2', title: '💎 Rare Gold Crown Avatar Frame', type: 'badge', value: 'Cosmetic Prestige', emoji: '👑' },
  { id: 'r3', title: '🛡️ Learning Streak Shield', type: 'streak_shield', value: 'Protects 1 Missed Shift Day', emoji: '🛡️' },
  { id: 'r4', title: '⭐ +250 Bonus XP Chest', type: 'xp', value: 'Instant Points Drop', emoji: '💰' },
];

export function TeamBattleArena() {
  const { fireCelebration, showToast } = useAppStore();

  const [boxOpened, setBoxOpened] = useState(false);
  const [reward, setReward] = useState<MysteryBoxReward | null>(null);

  const openMysteryBox = () => {
    if (boxOpened) return;
    const randomReward = MYSTERY_REWARDS[Math.floor(Math.random() * MYSTERY_REWARDS.length)];
    setReward(randomReward);
    setBoxOpened(true);

    fireCelebration({
      emoji: randomReward.emoji,
      eyebrow: 'Mystery Lucky Box Unlocked!',
      title: randomReward.title,
      sub: randomReward.value,
    });
  };

  const aPct = Math.round((DEMO_BATTLE.storeAPoints / (DEMO_BATTLE.storeAPoints + DEMO_BATTLE.storeBPoints)) * 100);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.coral} 0%, ${COLORS.plum} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Cooperative Gamification
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Retail League Season 4</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Team Battle Arena &amp; Mystery Lucky Chests
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Compete collaboratively store vs store. Unlock communal rewards when your store achieves 80%+ training completion.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">Sprint Ends In</div>
          <div className="text-xl font-extrabold text-amber-300 mt-0.5">{DEMO_BATTLE.endsIn}</div>
        </div>
      </div>

      {/* Store vs Store Battle Live Quest */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5" style={{ borderColor: COLORS.line }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-extrabold text-xs uppercase tracking-wider text-rose-600">
            <Swords size={16} /> Weekly Store Clash: {DEMO_BATTLE.questTitle}
          </div>
          <span className="text-xs font-mono font-bold text-slate-400">Live Telemetry</span>
        </div>

        {/* Battle Progress Tug-of-War */}
        <div className="space-y-3 pt-2">
          <div className="flex justify-between items-center text-sm font-extrabold">
            <span className="text-rose-600">{DEMO_BATTLE.storeAName}</span>
            <span className="font-mono text-slate-900">{DEMO_BATTLE.storeAPoints} XP vs {DEMO_BATTLE.storeBPoints} XP</span>
            <span className="text-purple-600">{DEMO_BATTLE.storeBName}</span>
          </div>

          <div className="w-full h-4 rounded-full bg-purple-100 overflow-hidden flex">
            <div
              className="h-full bg-gradient-to-r from-rose-500 to-amber-500 transition-all duration-700"
              style={{ width: `${aPct}%` }}
            />
          </div>

          <div className="flex justify-between text-xs text-slate-500 font-semibold">
            <span>Nagpur Central is leading by +410 XP!</span>
            <span>Reward: +300 XP for all winning store associates</span>
          </div>
        </div>
      </div>

      {/* Grid: Mystery Lucky Box + Store Team Chest Tracker */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Mystery Box Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs flex flex-col justify-between" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-amber-600 flex items-center gap-1.5">
              <Gift size={15} /> Weekly Shift Lucky Box
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-1">Unlock Mystery Floor Perk</h3>
            <p className="text-xs text-slate-500 mt-1">
              Unlocked every 3 completed micro-learning lessons. Contains XP multipliers, cosmetic crowns, and streak protectors.
            </p>
          </div>

          <div className="my-6 text-center">
            {boxOpened && reward ? (
              <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 animate-in zoom-in-95 duration-300">
                <div className="text-5xl mb-2">{reward.emoji}</div>
                <div className="font-extrabold text-sm text-slate-900">{reward.title}</div>
                <div className="text-xs font-mono font-bold text-amber-700 mt-0.5">{reward.value}</div>
              </div>
            ) : (
              <div
                onClick={openMysteryBox}
                className="cursor-pointer inline-block p-6 rounded-3xl bg-amber-100/50 hover:bg-amber-100 border-2 border-dashed border-amber-400 transition-transform hover:scale-105"
              >
                <div className="text-6xl animate-bounce-short">🎁</div>
                <div className="text-xs font-extrabold text-amber-900 mt-2">TAP TO OPEN CHEST</div>
              </div>
            )}
          </div>

          <button
            onClick={openMysteryBox}
            disabled={boxOpened}
            className="w-full py-3 rounded-2xl font-bold text-xs text-slate-900 bg-amber-400 hover:bg-amber-300 shadow-md flex items-center justify-center gap-1.5 disabled:opacity-40"
          >
            <Sparkles size={14} />
            <span>{boxOpened ? 'Chest Claimed' : 'Open Shift Lucky Box'}</span>
          </button>
        </div>

        {/* Store Communal Chest Tracker */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs flex flex-col justify-between" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-purple-700 flex items-center gap-1.5">
              <Users size={15} /> Store Communal Chest (Nagpur)
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-1">80% Store Milestone Goal</h3>
            <p className="text-xs text-slate-500 mt-1">
              When 4 out of 5 associates complete their weekly Festive Product modules, every associate gets +200 bonus XP.
            </p>
          </div>

          <div className="space-y-3 my-4">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span>Store Team Completion</span>
              <span className="font-mono text-teal-700">3 of 4 Associates (75%)</span>
            </div>
            <ProgressBar pct={75} color={COLORS.teal} height={9} />
            <div className="text-[11px] text-slate-500 font-medium">
              Just 1 more associate completion needed to unlock the communal chest!
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 flex items-center gap-2">
            <CheckCircle2 size={16} className="text-teal-600" />
            <span>Sneha Patil &amp; Rahul Verma have completed!</span>
          </div>
        </div>
      </div>
    </div>
  );
}
