'use client';

import React, { useState } from 'react';
import {
  Languages,
  Sparkles,
  Send,
  Volume2,
  CheckCircle2,
  RotateCcw,
  Award,
  Star,
  Globe,
  Heart,
  Zap,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { BHASHA_SCENARIOS, evaluateVernacularResponse } from '../../lib/bhashaEngine';
import { DialectScenario, DialectEvaluation, VernacularLanguage } from '../../types';
import { COLORS } from '../../lib/constants';

export function VernacularDialectCoach() {
  const { fireCelebration, showToast } = useAppStore();

  const [selectedScenario, setSelectedScenario] = useState<DialectScenario>(BHASHA_SCENARIOS[0]);
  const [inputText, setInputText] = useState('');
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evaluation, setEvaluation] = useState<DialectEvaluation | null>(null);

  const selectLanguage = (lang: VernacularLanguage) => {
    const sc = BHASHA_SCENARIOS.find((s) => s.language === lang) || BHASHA_SCENARIOS[0];
    setSelectedScenario(sc);
    setInputText('');
    setEvaluation(null);
  };

  const handleEvaluate = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    setIsEvaluating(true);
    setTimeout(() => {
      const res = evaluateVernacularResponse(selectedScenario, inputText);
      setEvaluation(res);
      setIsEvaluating(false);

      fireCelebration({
        emoji: '🇮🇳',
        eyebrow: 'Vernacular Politeness Score',
        title: `${res.politenessScore}% Hospitality Score`,
        sub: `+${res.bonusXP} Vernacular XP Granted`,
      });
    }, 800);
  };

  const playSimulatedAudio = () => {
    showToast(`Playing audio query: "${selectedScenario.phoneticAudioText.slice(0, 35)}…"`, '🔊');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.amberDeep} 0%, ${COLORS.navy} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Vernacular AI &ldquo;Bhasha&rdquo; Engine
            </span>
            <span className="text-xs font-mono font-bold text-white/70">5 Indian Dialects</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Multilingual Customer Dialect &amp; Pitch Coach
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Master localized greetings, cultural hospitality etiquette, and bilingual product pitches in Hinglish, Hindi, Marathi, Tamil, and Telugu.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">Hospitality Bonus</div>
          <div className="text-2xl font-extrabold text-amber-300 mt-0.5">+120 XP</div>
        </div>
      </div>

      {/* Language Dialect Switcher Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 custom-scrollbar">
        {(['Hinglish', 'Hindi', 'Marathi', 'Tamil', 'Telugu'] as VernacularLanguage[]).map((lang) => {
          const isSelected = selectedScenario.language === lang;
          return (
            <button
              key={lang}
              onClick={() => selectLanguage(lang)}
              className={`px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all shrink-0 flex items-center gap-2 ${
                isSelected
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Globe size={15} className={isSelected ? 'text-amber-400' : 'text-slate-400'} />
              <span>{lang}</span>
            </button>
          );
        })}
      </div>

      {/* Main Dialect Practice Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Customer Scenario & Spoken Pitch Input */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold uppercase tracking-wider text-amber-700 font-mono">
                {selectedScenario.language} Scenario
              </span>
              <button
                onClick={playSimulatedAudio}
                className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold flex items-center gap-1.5 border border-amber-200 transition-colors"
              >
                <Volume2 size={14} /> Listen to Customer Query
              </button>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-1">{selectedScenario.nativeTitle}</h3>
            <div className="text-xs text-slate-500 mt-0.5">{selectedScenario.context}</div>
          </div>

          {/* Customer Speech Card */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
              <span>🗣️ Regional Shopper Audio Prompt:</span>
            </div>
            <p className="text-sm font-bold text-slate-900 leading-relaxed font-sans">
              {selectedScenario.customerQuery}
            </p>
            <div className="pt-2 border-t border-slate-200/60 text-xs text-slate-500 italic">
              <strong>English Translation:</strong> {selectedScenario.englishMeaning}
            </div>
          </div>

          {/* Quick Cultural Politeness Chips */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Recommended Cultural Politeness Phrases:
            </div>
            <div className="flex flex-wrap gap-2">
              {selectedScenario.keyPolitenessTokens.map((token, i) => (
                <button
                  key={i}
                  onClick={() => setInputText((prev) => (prev ? `${prev} ${token}` : token))}
                  className="px-3 py-1.5 rounded-full text-xs font-semibold bg-amber-50/70 border border-amber-200 text-amber-900 hover:bg-amber-100 transition-colors"
                >
                  + {token}
                </button>
              ))}
            </div>
          </div>

          {/* Associate Response Input */}
          <form onSubmit={handleEvaluate} className="space-y-3 pt-2">
            <textarea
              rows={3}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Type your response in ${selectedScenario.language} or bilingual mixed phrasing with respectful greetings...`}
              className="w-full border rounded-2xl p-4 text-xs sm:text-sm font-medium bg-slate-50 border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-slate-900"
            />

            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400 font-medium">
                AI grades cultural hospitality tokens, tone warmth, and product accuracy
              </span>

              <button
                type="submit"
                disabled={!inputText.trim() || isEvaluating}
                className="px-6 py-3 rounded-2xl font-bold text-xs text-slate-900 bg-amber-400 hover:bg-amber-300 shadow-md flex items-center gap-1.5 transition-all disabled:opacity-40"
              >
                <Sparkles size={14} />
                <span>{isEvaluating ? 'Evaluating Pitch…' : 'Grade Vernacular Pitch'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Col: Live Hospitality & Cultural Evaluation */}
        <div className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-amber-700 mb-1 flex items-center gap-1.5">
              <Award size={15} /> Cultural Hospitality Rubric
            </div>
            <h3 className="text-base font-bold text-slate-900">Vernacular Pitch Feedback</h3>

            {evaluation ? (
              <div className="space-y-4 mt-4 animate-in fade-in duration-300">
                {/* 3 Metric Badges */}
                <div className="grid grid-cols-3 gap-2 text-center font-mono">
                  <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200">
                    <div className="text-[10px] text-amber-700 font-sans font-bold">Politeness</div>
                    <div className="text-lg font-extrabold text-amber-900 mt-0.5">{evaluation.politenessScore}%</div>
                  </div>
                  <div className="bg-teal-50 p-3 rounded-2xl border border-teal-200">
                    <div className="text-[10px] text-teal-700 font-sans font-bold">Clarity</div>
                    <div className="text-lg font-extrabold text-teal-900 mt-0.5">{evaluation.clarityScore}%</div>
                  </div>
                  <div className="bg-purple-50 p-3 rounded-2xl border border-purple-200">
                    <div className="text-[10px] text-purple-700 font-sans font-bold">Accuracy</div>
                    <div className="text-lg font-extrabold text-purple-900 mt-0.5">{evaluation.translationAccuracy}%</div>
                  </div>
                </div>

                {/* Cultural Feedback */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1">
                    <Heart size={13} className="text-coral" /> Cultural Observation:
                  </div>
                  <p className="text-slate-600 leading-relaxed font-medium">
                    {evaluation.culturalEtiquetteFeedback}
                  </p>
                </div>

                {/* Recommended Vernacular Pitch */}
                <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs space-y-1">
                  <div className="font-bold text-amber-950">✨ Gold-Standard Regional Pitch:</div>
                  <p className="text-amber-950 font-medium italic leading-relaxed">
                    {evaluation.suggestedVernacularPitch}
                  </p>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-slate-400 space-y-3">
                <Languages size={36} className="mx-auto text-slate-300 animate-pulse" />
                <p>
                  Select a dialect, formulate your customer pitch with polite regional phrasing, and click <strong>Grade Vernacular Pitch</strong>.
                </p>
              </div>
            )}
          </div>

          <div className="text-[11px] text-slate-400 font-mono pt-4 border-t border-slate-100 text-center">
            Standardized for 1,200 Tier-3 Indian regional stores
          </div>
        </div>
      </div>
    </div>
  );
}
