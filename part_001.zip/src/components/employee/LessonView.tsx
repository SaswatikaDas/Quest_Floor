'use client';

import React, { useState } from 'react';
import {
  ChevronLeft,
  CheckCircle2,
  ArrowRight,
  Star,
  Award,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { TrainingModule } from '../../types';
import { Pill } from '../common/Pill';
import { ProgressBar } from '../common/ProgressBar';
import { COLORS } from '../../lib/constants';

interface LessonViewProps {
  module: TrainingModule;
  alreadyDone: boolean;
  onExit: () => void;
  onFinish: (
    moduleId: string,
    scorePct: number
  ) => { pointsEarned: number; unlockedBadge: { id: string; name: string; icon: string; desc: string } | null };
}

export function LessonView({ module, alreadyDone, onExit, onFinish }: LessonViewProps) {
  const [stage, setStage] = useState<'content' | 'quiz' | 'result'>('content');
  const [qIndex, setQIndex] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [result, setResult] = useState<{
    scorePct: number;
    pointsEarned: number;
    unlockedBadge: { id: string; name: string; icon: string; desc: string } | null;
  } | null>(null);

  const submitAnswer = () => {
    if (selected === null) return;
    const nextAnswers = [...answers, selected];
    setAnswers(nextAnswers);
    setSelected(null);

    if (qIndex + 1 < module.quiz.length) {
      setQIndex(qIndex + 1);
    } else {
      const correctCount = nextAnswers.filter((ans, idx) => ans === module.quiz[idx].correct).length;
      const scorePct = Math.round((correctCount / module.quiz.length) * 100);
      const res = onFinish(module.id, scorePct);
      setResult({ scorePct, ...res });
      setStage('result');
    }
  };

  const restartQuiz = () => {
    setQIndex(0);
    setAnswers([]);
    setSelected(null);
    setStage('quiz');
  };

  /* ==================== STAGE 1: LESSON CONTENT ==================== */
  if (stage === 'content') {
    return (
      <div className="bg-white rounded-3xl border p-6 sm:p-8 shadow-sm space-y-6 max-w-4xl mx-auto" style={{ borderColor: COLORS.line }}>
        <button
          onClick={onExit}
          className="flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-slate-900 transition-colors"
        >
          <ChevronLeft size={16} /> Back to Learning Center
        </button>

        {/* Header */}
        <div className="flex items-start gap-4">
          <div className="text-5xl shrink-0 p-3 rounded-2xl bg-slate-50 border border-slate-100">{module.emoji}</div>
          <div>
            <div className="flex items-center gap-2">
              <Pill color={COLORS.teal}>{module.category}</Pill>
              {alreadyDone && (
                <span className="text-[11px] font-bold text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 size={12} /> Completed
                </span>
              )}
            </div>
            <h2 className="text-2xl font-extrabold tracking-tight mt-1.5" style={{ color: COLORS.ink }}>
              {module.title}
            </h2>
            <p className="text-sm text-slate-600 mt-1">{module.description}</p>
          </div>
        </div>

        {/* Key Takeaways Card */}
        <div className="rounded-2xl p-6 bg-slate-50/80 border border-slate-200/80 space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Core Retail Key Points
          </div>
          <ul className="space-y-3">
            {module.keyPoints.map((point, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-slate-800">
                <CheckCircle2 size={18} className="text-teal-600 shrink-0 mt-0.5" />
                <span className="leading-relaxed font-medium">{point}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Footer info & Take Quiz CTA */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-100">
          <div className="text-xs font-semibold text-slate-500 flex items-center gap-2">
            <span>⏱️ {module.duration} reading time</span>
            <span>•</span>
            <span className="text-amber-600 font-bold">⭐ +{module.points} XP Reward</span>
          </div>

          <button
            onClick={() => setStage('quiz')}
            className="w-full sm:w-auto px-7 py-3 rounded-xl font-bold text-sm text-white shadow-md flex items-center justify-center gap-2 transition-all hover:opacity-90"
            style={{ backgroundColor: COLORS.navy }}
          >
            <span>{alreadyDone ? 'Review Knowledge Quiz' : 'Take 3-Min Quiz'}</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    );
  }

  /* ==================== STAGE 2: INTERACTIVE QUIZ ==================== */
  if (stage === 'quiz') {
    const q = module.quiz[qIndex];
    return (
      <div className="bg-white rounded-3xl border p-6 sm:p-8 shadow-sm space-y-6 max-w-2xl mx-auto" style={{ borderColor: COLORS.line }}>
        {/* Progress Header */}
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Question {qIndex + 1} of {module.quiz.length}
          </span>
          <div className="w-36">
            <ProgressBar
              pct={((qIndex + 1) / module.quiz.length) * 100}
              color={COLORS.amber}
              height={7}
            />
          </div>
        </div>

        {/* Question Title */}
        <div>
          <h3 className="text-lg sm:text-xl font-bold leading-snug" style={{ color: COLORS.ink }}>
            {q.q}
          </h3>
        </div>

        {/* Option Cards */}
        <div className="space-y-3">
          {q.options.map((opt, i) => {
            const isSelected = selected === i;
            return (
              <button
                key={i}
                onClick={() => setSelected(i)}
                className={`w-full text-left px-5 py-4 rounded-2xl text-sm font-medium border-2 transition-all duration-150 flex items-center gap-3.5 ${
                  isSelected
                    ? 'border-teal-600 bg-teal-50/70 text-slate-900 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                    isSelected ? 'bg-teal-600 text-white' : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {String.fromCharCode(65 + i)}
                </span>
                <span className="flex-1 leading-snug">{opt}</span>
              </button>
            );
          })}
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <button
            onClick={() => setStage('content')}
            className="text-xs font-bold text-slate-500 hover:text-slate-800"
          >
            Review Material
          </button>

          <button
            onClick={submitAnswer}
            disabled={selected === null}
            className="px-6 py-2.5 rounded-xl font-bold text-sm text-white shadow flex items-center gap-1.5 transition-all disabled:opacity-40"
            style={{ backgroundColor: COLORS.navy }}
          >
            <span>{qIndex + 1 < module.quiz.length ? 'Next Question' : 'Submit Quiz'}</span>
            <ArrowRight size={15} />
          </button>
        </div>
      </div>
    );
  }

  /* ==================== STAGE 3: QUIZ RESULT ==================== */
  const passed = (result?.scorePct || 0) >= 60;

  return (
    <div className="bg-white rounded-3xl border p-8 sm:p-10 text-center shadow-md space-y-5 max-w-lg mx-auto" style={{ borderColor: COLORS.line }}>
      <div className="text-6xl animate-bounce-short">{passed ? '🎉' : '📘'}</div>

      <div>
        <h3 className="text-2xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
          {passed ? 'Outstanding Score!' : 'Good Effort!'}
        </h3>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          {passed
            ? 'You have demonstrated mastery of the key retail standards.'
            : 'You scored below the 60% passing mark. Feel free to review and retry.'}
        </p>
      </div>

      {/* Score Big Pill */}
      <div
        className="inline-flex flex-col items-center justify-center p-5 rounded-2xl border"
        style={{
          backgroundColor: passed ? 'rgba(14,140,130,0.08)' : 'rgba(239,90,76,0.08)',
          borderColor: passed ? 'rgba(14,140,130,0.2)' : 'rgba(239,90,76,0.2)',
          minWidth: 160,
        }}
      >
        <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Quiz Accuracy</span>
        <span
          className="font-mono text-4xl font-extrabold mt-1"
          style={{ color: passed ? COLORS.teal : COLORS.coral }}
        >
          {result?.scorePct}%
        </span>
      </div>

      {/* Points Reward Banner */}
      {result && result.pointsEarned > 0 ? (
        <div
          className="rounded-2xl p-4 flex items-center justify-center gap-2 font-bold text-sm"
          style={{ backgroundColor: 'rgba(243,167,18,0.15)', color: COLORS.amberDeep }}
        >
          <Star size={18} />
          <span>+{result.pointsEarned} Experience Points (XP) Added</span>
        </div>
      ) : alreadyDone ? (
        <div className="text-xs text-slate-400">
          Module already completed previously. Review attempt recorded.
        </div>
      ) : null}

      {/* Unlocked Badge Alert */}
      {result?.unlockedBadge && (
        <div className="rounded-2xl p-4 border bg-purple-50/80 border-purple-200 flex items-center gap-3 text-left">
          <div className="text-4xl">{result.unlockedBadge.icon}</div>
          <div>
            <div className="text-xs font-bold text-purple-700 uppercase tracking-wider flex items-center gap-1">
              <Sparkles size={12} /> New Badge Unlocked!
            </div>
            <div className="text-sm font-bold text-slate-900">{result.unlockedBadge.name}</div>
            <div className="text-xs text-slate-500">{result.unlockedBadge.desc}</div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-center gap-3 pt-4 border-t border-slate-100">
        {!passed && (
          <button
            onClick={restartQuiz}
            className="px-5 py-2.5 rounded-xl font-bold text-xs border border-slate-300 text-slate-700 hover:bg-slate-50 flex items-center gap-1.5"
          >
            <RotateCcw size={14} /> Retry Quiz
          </button>
        )}
        <button
          onClick={onExit}
          className="px-6 py-2.5 rounded-xl font-bold text-xs text-white shadow-sm"
          style={{ backgroundColor: COLORS.navy }}
        >
          Return to Learning Center
        </button>
      </div>
    </div>
  );
}
