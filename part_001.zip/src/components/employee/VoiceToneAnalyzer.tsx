'use client';

import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  Sparkles,
  Award,
  Zap,
  Activity,
  Heart,
  TrendingUp,
  CheckCircle2,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { VoicePitchAnalysis } from '../../types';
import { COLORS } from '../../lib/constants';

export function VoiceToneAnalyzer() {
  const { fireCelebration, showToast } = useAppStore();

  const [isRecording, setIsRecording] = useState(false);
  const [recordedSeconds, setRecordedSeconds] = useState(0);
  const [analysis, setAnalysis] = useState<VoicePitchAnalysis | null>({
    wordsPerMinute: 132,
    warmthIndexPct: 91,
    clarityScorePct: 88,
    pacingStatus: 'Optimal (120-140 WPM)',
    coachingObservation: 'Excellent vocal cadence. Warm tone with respectful Indian hospitality pacing.',
  });

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRecording) {
      timer = setInterval(() => setRecordedSeconds((s) => s + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [isRecording]);

  const toggleRecording = () => {
    if (!isRecording) {
      setIsRecording(true);
      setRecordedSeconds(0);
      setAnalysis(null);
      showToast('Recording sales pitch audio… Speak naturally.', '🎙️');
    } else {
      setIsRecording(false);
      // Simulate real-time audio FFT pitch analysis
      setTimeout(() => {
        const result: VoicePitchAnalysis = {
          wordsPerMinute: 128,
          warmthIndexPct: 94,
          clarityScorePct: 92,
          pacingStatus: 'Optimal (120-140 WPM)',
          coachingObservation: 'Welcoming conversational pitch. Natural pauses and enthusiastic tone balance.',
        };
        setAnalysis(result);
        fireCelebration({
          emoji: '🎙️',
          eyebrow: 'Vocal Pitch Analyzed!',
          title: `${result.warmthIndexPct}% Warmth & Hospitality`,
          sub: '+80 Voice Delivery XP Granted',
        });
      }, 700);
    }
  };

  const sampleGreetings = [
    '“Namaste ji! Welcome to QuestFloor. How can I assist you with festive gifting today?”',
    '“Aaiye sir, we have our premium cotton-silk kurta collection with complimentary custom fitting!”',
    '“Vanakkam madam! In-store you get our verified 100% replacement warranty on all brass diyas.”',
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.plum} 0%, ${COLORS.coral} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Acoustic AI Speech Analyzer
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Web Audio FFT Model</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            AI Voice Pitch &amp; Vocal Tone Analyzer
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Evaluate your conversational speech pacing, warmth index, and vocal clarity during customer greetings on the retail floor.
          </p>
        </div>

        <button
          onClick={toggleRecording}
          className={`px-6 py-3.5 rounded-2xl font-extrabold text-xs shadow-lg flex items-center gap-2 transition-all shrink-0 ${
            isRecording
              ? 'bg-red-500 text-white animate-pulse'
              : 'bg-white text-slate-900 hover:bg-slate-100'
          }`}
        >
          {isRecording ? <MicOff size={16} /> : <Mic size={16} className="text-purple-600" />}
          <span>{isRecording ? `Stop Recording (${recordedSeconds}s)` : 'Start Voice Pitch Analysis'}</span>
        </button>
      </div>

      {/* Grid: Waveform Visualizer & Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Animated Waveform & Sample Greetings */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-purple-700">
              Vocal Frequency Spectrogram
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-0.5">Live Waveform Telemetry</h3>
          </div>

          {/* Animated Waveform Visualizer */}
          <div className="h-32 rounded-2xl bg-slate-950 p-4 flex items-center justify-center gap-1.5 overflow-hidden">
            {[40, 65, 80, 45, 90, 75, 30, 95, 60, 85, 40, 70, 90, 55, 80, 65, 95, 50, 75, 40, 85, 60, 45, 90].map((h, i) => (
              <div
                key={i}
                className="w-2.5 rounded-full transition-all duration-150"
                style={{
                  height: isRecording ? `${Math.max(15, Math.round(h * Math.random()))}%` : '20%',
                  backgroundColor: i % 2 === 0 ? COLORS.amber : COLORS.teal,
                }}
              />
            ))}
          </div>

          {/* Sample Pitch Scripts */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Try Practicing These Customer Greetings:
            </div>
            <div className="space-y-2">
              {sampleGreetings.map((script, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-800 flex items-center gap-2"
                >
                  <Volume2 size={14} className="text-purple-600 shrink-0" />
                  <span>{script}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Acoustic Rubric & Metrics */}
        <div className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-purple-700 flex items-center gap-1.5">
              <Activity size={15} /> Vocal Acoustic Metrics
            </div>
            <h3 className="text-base font-bold text-slate-900 mt-0.5">Pitch &amp; Delivery Analysis</h3>

            {analysis ? (
              <div className="space-y-4 mt-4 animate-in fade-in duration-300">
                {/* 3 Metric Cards */}
                <div className="space-y-2.5">
                  <div className="p-3.5 rounded-2xl bg-purple-50 border border-purple-200 flex justify-between items-center">
                    <div>
                      <div className="text-xs font-bold text-purple-950">Vocal Warmth Index</div>
                      <div className="text-[10px] text-purple-700">Hospitality &amp; Friendliness</div>
                    </div>
                    <div className="font-mono text-xl font-extrabold text-purple-900">
                      {analysis.warmthIndexPct}%
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-teal-50 border border-teal-200 flex justify-between items-center">
                    <div>
                      <div className="text-xs font-bold text-teal-950">Speech Pacing</div>
                      <div className="text-[10px] text-teal-700">{analysis.pacingStatus}</div>
                    </div>
                    <div className="font-mono text-xl font-extrabold text-teal-900">
                      {analysis.wordsPerMinute} WPM
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 flex justify-between items-center">
                    <div>
                      <div className="text-xs font-bold text-amber-950">Enunciation &amp; Clarity</div>
                      <div className="text-[10px] text-amber-700">Zero Slurred Words</div>
                    </div>
                    <div className="font-mono text-xl font-extrabold text-amber-900">
                      {analysis.clarityScorePct}%
                    </div>
                  </div>
                </div>

                {/* AI Coaching Note */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1">
                    <Sparkles size={13} className="text-amber-600" /> Speech Coach Note:
                  </div>
                  <p className="text-slate-600 leading-relaxed font-medium">
                    {analysis.coachingObservation}
                  </p>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-slate-400 space-y-3">
                <Mic size={36} className="mx-auto text-slate-300 animate-pulse" />
                <p>Click <strong>Start Voice Pitch Analysis</strong> to record and evaluate your customer greeting.</p>
              </div>
            )}
          </div>

          <div className="text-[11px] text-slate-400 font-mono pt-4 border-t border-slate-100 text-center">
            Standardized vocal cadence model
          </div>
        </div>
      </div>
    </div>
  );
}
