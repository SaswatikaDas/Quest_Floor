'use client';

import React from 'react';
import {
  Target,
  CheckCircle2,
  BookOpen,
  ClipboardList,
  Heart,
  Zap,
  Star,
  GraduationCap,
  Users,
  TrendingUp,
  ShieldCheck,
  Flame,
  Award,
  Sparkles,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { Challenge } from '../../types';
import { COLORS } from '../../lib/constants';

const ICON_MAP: Record<string, React.ElementType> = {
  BookOpen,
  ClipboardList,
  Heart,
  Zap,
  Star,
  GraduationCap,
  Users,
  TrendingUp,
  ShieldCheck,
  Flame,
  Target,
};

export function ChallengesScreen() {
  const { challenges, currentEmployeeId, completeChallenge } = useAppStore();

  const daily = challenges.filter((c) => c.type === 'daily');
  const weekly = challenges.filter((c) => c.type === 'weekly');

  const completedCount = challenges.filter((c) => c.completedBy.includes(currentEmployeeId)).length;

  const renderGroup = (title: string, subtitle: string, list: Challenge[]) => (
    <div className="space-y-4">
      <SectionHeader title={title} subtitle={subtitle} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {list.map((c) => {
          const isDone = c.completedBy.includes(currentEmployeeId);
          const Icon = ICON_MAP[c.icon] || Target;

          return (
            <div
              key={c.id}
              className={`rounded-3xl p-6 border shadow-xs flex flex-col justify-between transition-all ${
                isDone ? 'bg-slate-50/70 border-slate-200 opacity-80' : 'bg-white border-slate-200 hover:shadow-md'
              }`}
            >
              <div>
                <div className="flex items-start justify-between mb-3">
                  <div
                    className="w-11 h-11 rounded-2xl flex items-center justify-center shadow-xs"
                    style={{
                      backgroundColor: isDone ? 'rgba(14,140,130,0.1)' : 'rgba(243,167,18,0.15)',
                    }}
                  >
                    <Icon size={20} style={{ color: isDone ? COLORS.teal : COLORS.amberDeep }} />
                  </div>
                  <Pill color={c.type === 'daily' ? COLORS.teal : COLORS.plum}>
                    {c.type === 'daily' ? 'Daily Target' : 'Weekly Goal'}
                  </Pill>
                </div>

                <h3 className="font-bold text-base leading-snug" style={{ color: COLORS.ink }}>
                  {c.title}
                </h3>
                <p className="text-xs text-slate-500 mt-1">{c.desc}</p>
              </div>

              <div className="flex items-center justify-between pt-5 mt-4 border-t border-slate-100">
                <span className="font-mono text-xs font-bold text-amber-600 flex items-center gap-1">
                  <Star size={13} /> +{c.reward} XP
                </span>

                <button
                  onClick={() => completeChallenge(c.id)}
                  disabled={isDone}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
                    isDone
                      ? 'bg-teal-50 text-teal-700 border border-teal-200 cursor-default'
                      : 'bg-slate-900 text-white hover:bg-slate-800'
                  }`}
                >
                  {isDone ? (
                    <>
                      <CheckCircle2 size={14} /> Completed
                    </>
                  ) : (
                    <>
                      <Sparkles size={14} /> Claim XP
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.coral} 0%, ${COLORS.amber} 100%)`,
        }}
      >
        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full">
            Daily &amp; Weekly Missions
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Retail Challenges &amp; XP Bounties
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1">
            Complete high-impact store challenges to boost your level, maintain learning streaks, and top the leaderboard.
          </p>
        </div>

        <div className="bg-white/20 backdrop-blur-md rounded-2xl px-5 py-3.5 text-center shrink-0 border border-white/20">
          <div className="text-xs text-white/80 font-semibold">Your Progress</div>
          <div className="font-mono text-2xl font-extrabold text-white mt-0.5">
            {completedCount} / {challenges.length} Done
          </div>
        </div>
      </div>

      {renderGroup('Today’s Daily Challenges', 'Refreshes every 24 hours at midnight', daily)}
      {renderGroup('Weekly Sprint Challenges', 'Active through Sunday 11:59 PM', weekly)}
    </div>
  );
}
