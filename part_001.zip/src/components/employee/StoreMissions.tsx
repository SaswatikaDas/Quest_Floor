'use client';

import React from 'react';
import {
  Zap,
  Target,
  Star,
  Clock,
  CheckCircle2,
  Sparkles,
  TrendingUp,
  Flame,
  Award,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { ProgressBar } from '../common/ProgressBar';
import { COLORS } from '../../lib/constants';

export function StoreMissions() {
  const { storeMissions, claimMissionReward } = useAppStore();

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.coral} 0%, ${COLORS.navy} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Shift Operational Goals
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Live Floor Quests</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Daily Store Floor Missions &amp; Sprints
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Live operational floor missions connecting micro-learning directly to faster billing, consultative gifting recommendations, and 5-star CSAT delivery.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">Total Quest XP</div>
          <div className="text-3xl font-extrabold text-amber-300 mt-0.5">+1,000 XP</div>
        </div>
      </div>

      {/* Missions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {storeMissions.map((mission) => {
          const isCompleted =
            mission.category === 'Speed'
              ? mission.currentValue <= mission.targetValue
              : mission.currentValue >= mission.targetValue;

          const progressPct =
            mission.category === 'Speed'
              ? 100
              : Math.min(100, Math.round((mission.currentValue / mission.targetValue) * 100));

          return (
            <div
              key={mission.id}
              className={`bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4 transition-all ${
                mission.isClaimed
                  ? 'border-emerald-300 bg-emerald-50/20'
                  : isCompleted
                  ? 'border-amber-400 shadow-md ring-2 ring-amber-400/20'
                  : 'border-slate-200'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                    {mission.category} Mission
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-700">
                    +{mission.rewardXP} XP
                  </span>
                </div>

                <h3 className="font-bold text-base text-slate-900 leading-snug">{mission.title}</h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed font-medium">
                  {mission.description}
                </p>

                <div className="space-y-2 mt-4 pt-3 border-t border-slate-100">
                  <div className="flex justify-between text-xs font-bold text-slate-700">
                    <span>Current Floor Pacing</span>
                    <span className="font-mono text-teal-700">
                      {mission.currentValue} {mission.unit} (Target: {mission.targetValue} {mission.unit})
                    </span>
                  </div>
                  <ProgressBar
                    pct={progressPct}
                    color={isCompleted ? COLORS.teal : COLORS.amber}
                    height={8}
                  />
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>Expires: {mission.expiresIn}</span>
                    <span className="font-bold text-slate-600">
                      {isCompleted ? 'Goal Reached! 🎯' : `${progressPct}% Done`}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => claimMissionReward(mission.id)}
                  disabled={!isCompleted || mission.isClaimed}
                  className={`w-full py-3 rounded-xl font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all ${
                    mission.isClaimed
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 cursor-default'
                      : isCompleted
                      ? 'bg-amber-400 hover:bg-amber-300 text-slate-900 shadow-md'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  {mission.isClaimed ? (
                    <>
                      <CheckCircle2 size={15} /> Mission Reward Claimed
                    </>
                  ) : isCompleted ? (
                    <>
                      <Sparkles size={15} /> Claim +{mission.rewardXP} XP Reward
                    </>
                  ) : (
                    <span>In Progress on Store Floor</span>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
