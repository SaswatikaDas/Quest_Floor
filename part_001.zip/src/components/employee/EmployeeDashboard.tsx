'use client';

import React, { useState } from 'react';
import {
  Star,
  Award,
  GraduationCap,
  Trophy,
  Target,
  Sparkles,
  ArrowRight,
  Brain,
  CheckCircle2,
  Bell,
  Zap,
  Flame,
  ShieldCheck,
  Languages,
  Terminal,
  HeartHandshake,
  TrendingUp,
  Coins,
  BookOpen,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { StatCard } from '../common/StatCard';
import { ProgressBar } from '../common/ProgressBar';
import { SectionHeader } from '../common/SectionHeader';
import { EmptyState } from '../common/EmptyState';
import { MissionQuizModal } from '../common/MissionQuizModal';
import { Challenge } from '../../types';
import { BADGES, COLORS } from '../../lib/constants';
import { trainingPct, getStoreName, avg, getLevelInfo } from '../../lib/cxCalculator';

export function EmployeeDashboard() {
  const {
    currentEmployee,
    employees,
    stores,
    trainingModules,
    challenges,
    recognitions,
    notifications,
    setScreen,
    completeChallenge,
    fireCelebration,
    setIsStoryModalOpen,
    theme,
    t,
  } = useAppStore();

  const isDark = theme === 'dark';
  const [activeQuizChallenge, setActiveQuizChallenge] = useState<Challenge | null>(null);
  const storeEmployees = employees.filter((e) => e.storeId === currentEmployee.storeId);
  const storeAvgPos = avg(storeEmployees.map((e) => e.posAdoption));

  const sortedByPoints = [...employees].sort((a, b) => b.points - a.points);
  const leaderboardRank = sortedByPoints.findIndex((e) => e.id === currentEmployee.id) + 1;

  const recentBadges = [...currentEmployee.badges]
    .slice(-3)
    .reverse()
    .map((id) => BADGES.find((b) => b.id === id))
    .filter(Boolean) as typeof BADGES;

  const receivedCount = recognitions.filter((r) => r.toId === currentEmployee.id).length;
  const givenCount = recognitions.filter((r) => r.fromId === currentEmployee.id).length;

  const incompleteModules = trainingModules.filter((m) => !currentEmployee.completedModules.includes(m.id));
  const recommendedModule =
    currentEmployee.posAdoption < storeAvgPos
      ? incompleteModules.find((m) => m.category === 'POS Training') || incompleteModules[0]
      : incompleteModules[0];

  const unreadNotifCount = notifications.filter(
    (n) => (n.recipientId === currentEmployee.id || n.recipientId === 'all') && !n.read
  ).length;

  const handleClaimChallenge = (challengeId: string) => {
    completeChallenge(challengeId);
    fireCelebration({
      emoji: '🎯',
      eyebrow: 'Challenge Completed!',
      title: '+100 XP Claimed Successfully',
      sub: 'Floor Excellence Level Progressed',
    });
  };

  const daysOfWeek = [
    { day: 'Mon', active: true },
    { day: 'Tue', active: true },
    { day: 'Wed', active: true },
    { day: 'Thu', active: true },
    { day: 'Fri', active: true },
    { day: 'Sat', active: true },
    { day: 'Sun', active: true },
  ];

  const completedChallenges = challenges.filter((c) => c.completedBy.includes(currentEmployee.id)).length;
  const questProgressPct = Math.min(100, Math.round((completedChallenges / Math.max(1, challenges.length)) * 100));
  const levelInfo = getLevelInfo(currentEmployee.points);

  return (
    <div className="space-y-6 pb-12 transition-colors duration-200">
      {/* ── 🌟 LUXURY OBSIDIAN MIDNIGHT MESH HERO BANNER ─────────────────── */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-[#0c1222] to-slate-900 text-white p-6 sm:p-8 shadow-2xl border border-slate-800/80">
        {/* Ambient Backlight Glow Elements */}
        <div className="absolute -top-24 -left-20 w-72 h-72 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-20 w-80 h-80 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-6">
          {/* Top Status Capsule Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
            <div className="flex items-center space-x-2.5">
              <span className="bg-gradient-to-r from-indigo-500 via-purple-500 to-amber-500 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider shadow-sm flex items-center space-x-1.5">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>{t('brandTitle')}</span>
              </span>
              <span className="text-xs text-slate-300 font-medium hidden sm:inline">
                {getStoreName(stores, currentEmployee.storeId)} • Tier-3 Cluster
              </span>
            </div>

            {/* Live Shift Morale Indicator & Pitch launcher */}
            <div className="flex items-center space-x-2 text-xs font-mono">
              <span className="flex items-center space-x-1.5 bg-emerald-500/15 text-emerald-300 px-3 py-1 rounded-xl border border-emerald-500/30">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{t('storeCX')}</span>
              </span>
              <button
                onClick={() => setIsStoryModalOpen(true)}
                className="hidden md:flex items-center gap-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 px-3 py-1 rounded-xl border border-amber-500/30 transition-all font-sans font-bold active:scale-95"
              >
                <span>🎤</span>
                <span>{t('pitchBtn')}</span>
              </button>
            </div>
          </div>

          {/* Core Hero Message & Shift Telemetry */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* Left 7 Cols: Main Motto & Quick Launch Actions */}
            <div className="lg:col-span-7 space-y-3.5">
              <div className="flex items-center space-x-2 text-xs font-bold text-amber-400">
                <Flame className="w-4 h-4 fill-amber-400 animate-pulse" />
                <span>{t('streakActive')}</span>
              </div>

              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white leading-tight">
                {t('heroHeadingPrefix')}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-300 to-amber-300">
                  {t('heroHeadingHighlight')}
                </span>
              </h1>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl">
                {t('heroSub')}
              </p>

              {/* Quick Launch Buttons */}
              <div className="flex flex-wrap items-center gap-2.5 pt-2">
                <button
                  onClick={() => setScreen('learning')}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-extrabold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-1.5 transition-all active:scale-95"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>{t('startLesson')}</span>
                </button>

                <button
                  onClick={() => setScreen('posSandbox')}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 flex items-center gap-1.5 transition-all active:scale-95"
                >
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <span>{t('posTerminal')}</span>
                </button>

                <button
                  onClick={() => setScreen('learning')}
                  className="px-3.5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center gap-1.5 transition-all"
                >
                  <Languages className="w-4 h-4 text-indigo-400" />
                  <span>{t('bhashaCoach')}</span>
                </button>

                <button
                  onClick={() => setScreen('recognition')}
                  className="px-3.5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center gap-1.5 transition-all"
                >
                  <HeartHandshake className="w-4 h-4 text-rose-400" />
                  <span>{t('peerKudos')}</span>
                </button>
              </div>
            </div>

            {/* Right 5 Cols: Shift Telemetry Card */}
            <div className="lg:col-span-5 bg-slate-900/90 backdrop-blur-md rounded-2xl p-5 border border-slate-800 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
                    {t('shiftAssociate')}
                  </div>
                  <div className="text-base font-extrabold text-white">
                    {currentEmployee.name}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
                    {t('levelRank')}
                  </div>
                  <div className="text-sm font-black text-amber-400">
                    Level {levelInfo.level} ({levelInfo.name}) • #{leaderboardRank} Rank
                  </div>
                </div>
              </div>

              {/* XP Progress Bar */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">{t('xpProgress')}</span>
                  <span className="font-mono font-bold text-indigo-300">
                    {currentEmployee.points.toLocaleString('en-IN')} XP
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-amber-400 rounded-full transition-all duration-700"
                    style={{ width: `${levelInfo.progressPct}%` }}
                  />
                </div>
              </div>

              {/* 7-Day Consistency Week Strip */}
              <div>
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  {t('consistencyStreak')}
                </div>
                <div className="grid grid-cols-7 gap-1 text-center">
                  {daysOfWeek.map((d) => (
                    <div
                      key={d.day}
                      className="p-1.5 rounded-lg bg-slate-800/80 border border-amber-500/30 text-[10px]"
                    >
                      <div className="font-bold text-slate-300">{d.day}</div>
                      <div className="text-[9px] font-extrabold text-amber-400">🔥</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Shift Quests Progress */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">{t('shiftMissionsComplete')}</span>
                <span className="font-mono font-bold text-emerald-400">{questProgressPct}% Complete</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── 4 CORE STAT CARDS ────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Star}
          label={t('totalXP')}
          value={`${currentEmployee.points.toLocaleString('en-IN')} XP`}
          sub={t('thisWeek')}
          accent={COLORS.amber}
        />
        <StatCard
          icon={Award}
          label={t('badgesUnlocked')}
          value={`${currentEmployee.badges.length} / ${BADGES.length}`}
          sub={t('expertTier')}
          accent={COLORS.plum}
        />
        <StatCard
          icon={GraduationCap}
          label={t('curriculumCompleted')}
          value={`${trainingPct(currentEmployee, trainingModules)}%`}
          sub={`${currentEmployee.completedModules.length} / ${trainingModules.length}`}
          accent={COLORS.teal}
        />
        <StatCard
          icon={Trophy}
          label={t('chainRank')}
          value={`#${leaderboardRank}`}
          sub={t('topPerformer')}
          accent={COLORS.coral}
        />
      </div>

      {/* ── ACTIVE SHIFT MISSIONS & CHALLENGES ───────────────────────────── */}
      <div
        className={`rounded-3xl p-6 border shadow-xs space-y-4 transition-colors ${
          isDark ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <SectionHeader
          title={t('dailyMissionsTitle')}
          subtitle={t('dailyMissionsSub')}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
          {challenges.slice(0, 3).map((ch) => {
            const isCompleted = ch.completedBy.includes(currentEmployee.id);
            return (
              <div
                key={ch.id}
                className={`p-5 rounded-2xl border flex flex-col justify-between transition-all hover:shadow-md space-y-4 ${
                  isCompleted
                    ? isDark
                      ? 'bg-emerald-950/30 border-emerald-800/60'
                      : 'bg-emerald-50/70 border-emerald-200'
                    : isDark
                    ? 'bg-slate-800/60 border-slate-700'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                      {ch.type === 'daily' ? 'Daily Mission' : 'Speed Sprint'}
                    </span>
                    <span className="font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400">
                      +{ch.reward} XP
                    </span>
                  </div>

                  <h3 className={`font-bold text-sm leading-snug ${isDark ? 'text-white' : 'text-slate-900'}`}>
                    {ch.title}
                  </h3>
                  <p className={`text-xs mt-1 line-clamp-2 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                    {ch.desc}
                  </p>
                </div>

                <button
                  onClick={() => setActiveQuizChallenge(ch)}
                  disabled={isCompleted}
                  className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs ${
                    isCompleted
                      ? 'bg-emerald-600 text-white cursor-default'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white active:scale-95'
                  }`}
                >
                  {isCompleted ? (
                    <>
                      <CheckCircle2 size={15} />
                      <span>{t('completedClaimed')}</span>
                    </>
                  ) : (
                    <>
                      <span>{t('completeMission')} (+{ch.reward} XP Quiz)</span>
                      <ArrowRight size={14} />
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── ACHIEVEMENTS & AI SMART RECOMMENDATION ──────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left 2 Cols: Badges & Learning Progress */}
        <div
          className={`lg:col-span-2 rounded-3xl p-6 border shadow-xs space-y-6 transition-colors ${
            isDark ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}
        >
          <div>
            <SectionHeader
              title={t('recentBadgesTitle')}
              subtitle={t('recentBadgesSub')}
              action={
                <button
                  onClick={() => setScreen('leaderboard')}
                  className="text-xs font-bold hover:underline text-teal-600 dark:text-teal-400"
                >
                  {t('viewAllBadges')} ({currentEmployee.badges.length}) →
                </button>
              }
            />

            {recentBadges.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
                {recentBadges.map((b) => (
                  <div
                    key={b.id}
                    className={`rounded-2xl p-4 text-center border transition-all hover:shadow-xs ${
                      isDark ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="text-4xl mb-2 animate-bounce-short">{b.icon}</div>
                    <div className={`text-sm font-bold truncate ${isDark ? 'text-white' : 'text-slate-900'}`}>
                      {b.name}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                      {b.desc}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                icon={Award}
                title="No Badges Yet"
                text="Complete your first 3-minute lesson to unlock the Product Expert badge."
              />
            )}
          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between text-sm font-bold mb-2">
              <span className={isDark ? 'text-white' : 'text-slate-900'}>{t('trainingCurriculum')}</span>
              <span className="font-mono text-xs text-teal-600 dark:text-teal-400">
                {currentEmployee.completedModules.length} / {trainingModules.length} Modules
              </span>
            </div>
            <ProgressBar
              pct={trainingPct(currentEmployee, trainingModules)}
              color={COLORS.teal}
              height={9}
            />
          </div>
        </div>

        {/* Right Col: AI Recommendation & Quick Counters */}
        <div
          className={`rounded-3xl p-6 border shadow-xs space-y-5 transition-colors ${
            isDark ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-500">
                <Sparkles size={14} /> {t('smartAiRec')}
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300">
                AI Match
              </span>
            </div>

            {recommendedModule ? (
              <div
                className={`rounded-2xl p-4 border mt-2 ${
                  isDark ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-2xl">{recommendedModule.emoji}</span>
                  <div>
                    <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      {recommendedModule.category} · {recommendedModule.duration}
                    </div>
                    <div className={`text-sm font-bold leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                      {recommendedModule.title}
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-2">
                  {recommendedModule.description}
                </p>

                <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-200 dark:border-slate-700">
                  <button
                    onClick={() => setScreen('learning')}
                    className="text-xs font-bold flex items-center gap-1 hover:underline text-teal-600 dark:text-teal-400"
                  >
                    <span>{t('startLesson')}</span>
                    <ArrowRight size={13} />
                  </button>
                  <button
                    onClick={() => setScreen('learning')}
                    className="text-xs font-bold flex items-center gap-1 hover:underline text-purple-600 dark:text-purple-400"
                  >
                    <Brain size={13} />
                    <span>{t('whyThis')}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-500 mt-2 p-3 bg-slate-100 dark:bg-slate-800 rounded-xl">
                ✨ Excellent work! You have finished every available micro-learning module.
              </div>
            )}
          </div>

          {/* Recognition Summary */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              {t('peerRecSummary')}
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-500 dark:text-slate-400">{t('received')}</span>
                <span className="font-bold font-mono px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
                  {receivedCount} shoutouts
                </span>
              </div>
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-500 dark:text-slate-400">{t('given')}</span>
                <span className="font-bold font-mono px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300">
                  {givenCount} sent
                </span>
              </div>
            </div>
          </div>

          {/* Notifications Quick Link */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Bell size={14} className="text-slate-400" /> Notifications
            </span>
            <button
              onClick={() => setScreen('notifications')}
              className="text-xs font-bold flex items-center gap-1 hover:underline text-rose-600 dark:text-rose-400"
            >
              <span>{unreadNotifCount} unread →</span>
            </button>
          </div>
        </div>
      </div>

      {/* Daily Shift Mission Micro-Quiz Modal */}
      <MissionQuizModal
        challenge={activeQuizChallenge}
        isOpen={Boolean(activeQuizChallenge)}
        onClose={() => setActiveQuizChallenge(null)}
        onSuccess={(chId) => {
          handleClaimChallenge(chId);
        }}
      />
    </div>
  );
}
