'use client';

import React, { useState } from 'react';
import { Trophy, Award, Medal, Users, Store, Zap } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Avatar } from '../common/Avatar';
import { COLORS } from '../../lib/constants';
import { getStoreName } from '../../lib/cxCalculator';

export function LeaderboardScreen() {
  const { employees, stores, currentEmployeeId } = useAppStore();
  const [scope, setScope] = useState<'My Store' | 'All Stores'>('All Stores');
  const [period, setPeriod] = useState<'Weekly' | 'Monthly' | 'Overall'>('Overall');

  const me = employees.find((e) => e.id === currentEmployeeId) || employees[0];
  const scopedEmployees =
    scope === 'My Store' ? employees.filter((e) => e.storeId === me.storeId) : employees;

  const pointsKey = period === 'Weekly' ? 'weeklyPoints' : period === 'Monthly' ? 'monthlyPoints' : 'points';
  const sorted = [...scopedEmployees].sort((a, b) => b[pointsKey] - a[pointsKey]);

  const top3 = sorted.slice(0, 3);
  const myRank = sorted.findIndex((e) => e.id === currentEmployeeId) + 1;

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
            Workforce Leaderboard
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Recognizing excellence, peer learning, and service quality across Tier-3 stores
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            {(['All Stores', 'My Store'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setScope(s)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  scope === s ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            {(['Weekly', 'Monthly', 'Overall'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  period === p ? 'bg-amber-400 text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Top 3 Podium Cards */}
      {top3.length >= 3 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {/* Rank 2 (Left) */}
          <div
            className="rounded-3xl p-6 text-center border shadow-xs bg-white flex flex-col items-center justify-between order-2 sm:order-1"
            style={{ borderColor: COLORS.line }}
          >
            <div className="w-full flex justify-between items-center text-xs font-mono font-bold text-slate-400">
              <span className="px-2 py-0.5 rounded-full bg-slate-100">#2 RANK</span>
              <Medal size={20} className="text-slate-400" />
            </div>
            <div className="my-3">
              <Avatar name={top3[1].name} color={top3[1].color} size={64} />
              <div className="font-bold text-base mt-2" style={{ color: COLORS.ink }}>
                {top3[1].name}
              </div>
              <div className="text-xs text-slate-500">{getStoreName(stores, top3[1].storeId)}</div>
            </div>
            <div className="font-mono text-lg font-extrabold text-teal-600">
              {top3[1][pointsKey].toLocaleString('en-IN')} XP
            </div>
          </div>

          {/* Rank 1 (Center) */}
          <div
            className="rounded-3xl p-6 text-center border-2 shadow-lg text-white flex flex-col items-center justify-between order-1 sm:order-2 relative overflow-hidden"
            style={{
              background: `linear-gradient(145deg, ${COLORS.navy}, ${COLORS.navy2})`,
              borderColor: COLORS.amber,
            }}
          >
            <div className="w-full flex justify-between items-center text-xs font-mono font-bold text-amber-400">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-400/20">👑 #1 CHAMPION</span>
              <Trophy size={22} className="text-amber-400" />
            </div>
            <div className="my-3">
              <div className="relative inline-block">
                <Avatar name={top3[0].name} color={top3[0].color} size={76} />
                <span className="absolute -top-2 -right-2 text-2xl">🥇</span>
              </div>
              <div className="font-extrabold text-lg mt-2 text-white">{top3[0].name}</div>
              <div className="text-xs text-white/70">{getStoreName(stores, top3[0].storeId)}</div>
            </div>
            <div className="font-mono text-2xl font-extrabold text-amber-400">
              {top3[0][pointsKey].toLocaleString('en-IN')} XP
            </div>
          </div>

          {/* Rank 3 (Right) */}
          <div
            className="rounded-3xl p-6 text-center border shadow-xs bg-white flex flex-col items-center justify-between order-3 sm:order-3"
            style={{ borderColor: COLORS.line }}
          >
            <div className="w-full flex justify-between items-center text-xs font-mono font-bold text-amber-700">
              <span className="px-2 py-0.5 rounded-full bg-amber-100">#3 RANK</span>
              <Medal size={20} className="text-amber-700" />
            </div>
            <div className="my-3">
              <Avatar name={top3[2].name} color={top3[2].color} size={64} />
              <div className="font-bold text-base mt-2" style={{ color: COLORS.ink }}>
                {top3[2].name}
              </div>
              <div className="text-xs text-slate-500">{getStoreName(stores, top3[2].storeId)}</div>
            </div>
            <div className="font-mono text-lg font-extrabold text-amber-700">
              {top3[2][pointsKey].toLocaleString('en-IN')} XP
            </div>
          </div>
        </div>
      )}

      {/* Full Leaderboard Table */}
      <div className="bg-white rounded-3xl border shadow-xs overflow-hidden" style={{ borderColor: COLORS.line }}>
        <div className="px-6 py-4 border-b bg-slate-50/50 flex items-center justify-between" style={{ borderColor: COLORS.line }}>
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
            All Retail Associates ({sorted.length})
          </div>
          {myRank > 0 && (
            <div className="text-xs font-bold text-teal-700">
              Your Current Position: <span className="font-mono font-extrabold">#{myRank}</span>
            </div>
          )}
        </div>

        <div className="divide-y divide-slate-100">
          {sorted.map((emp, index) => {
            const isMe = emp.id === currentEmployeeId;
            return (
              <div
                key={emp.id}
                className={`flex items-center justify-between px-6 py-4 transition-colors ${
                  isMe ? 'bg-amber-50/60 font-semibold' : 'hover:bg-slate-50/60'
                }`}
              >
                <div className="flex items-center gap-4 min-w-0">
                  <span
                    className={`font-mono text-sm font-extrabold w-7 text-center ${
                      index === 0
                        ? 'text-amber-600'
                        : index === 1
                        ? 'text-slate-500'
                        : index === 2
                        ? 'text-amber-700'
                        : 'text-slate-400'
                    }`}
                  >
                    #{index + 1}
                  </span>

                  <Avatar name={emp.name} color={emp.color} size={38} />

                  <div className="min-w-0">
                    <div className="text-sm font-bold truncate flex items-center gap-2" style={{ color: COLORS.ink }}>
                      <span>{emp.name}</span>
                      {isMe && (
                        <span className="text-[10px] font-extrabold px-2 py-0.2 rounded-full bg-amber-400 text-slate-900">
                          YOU
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-500 truncate">
                      {getStoreName(stores, emp.storeId)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6 shrink-0">
                  <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-500">
                    <Award size={14} className="text-purple-600" />
                    <span>{emp.badges.length} Badges</span>
                  </div>

                  <div className="text-right">
                    <div className="font-mono text-sm font-extrabold" style={{ color: COLORS.ink }}>
                      {emp[pointsKey].toLocaleString('en-IN')} XP
                    </div>
                    <div className="text-[11px] text-teal-600 font-semibold">
                      {emp.posAdoption}% POS Adoption
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
