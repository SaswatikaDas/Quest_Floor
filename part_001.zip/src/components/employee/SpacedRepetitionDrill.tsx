'use client';

import React, { useState, useEffect } from 'react';
import {
  Brain,
  Timer,
  Zap,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Award,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { ProgressBar } from '../common/ProgressBar';
import { INITIAL_MEMORY_NODES, NEURO_DRILL_QUESTIONS } from '../../lib/spacedRepetitionEngine';
import { MemoryNode, SpacedDrillQuestion } from '../../types';
import { COLORS } from '../../lib/constants';

export function SpacedRepetitionDrill() {
  const { fireCelebration, showToast } = useAppStore();

  const [memoryNodes, setMemoryNodes] = useState<MemoryNode[]>(INITIAL_MEMORY_NODES);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [drillActive, setDrillActive] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(15);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [streak, setStreak] = useState(0);

  const currentQ: SpacedDrillQuestion = NEURO_DRILL_QUESTIONS[currentQuestionIndex] || NEURO_DRILL_QUESTIONS[0];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (drillActive && secondsLeft > 0 && !isAnswered) {
      timer = setInterval(() => setSecondsLeft((s) => s - 1), 1000);
    } else if (drillActive && secondsLeft === 0 && !isAnswered) {
      setIsAnswered(true);
      showToast('15 seconds elapsed! Time is up.', '⏱️');
    }
    return () => clearInterval(timer);
  }, [drillActive, secondsLeft, isAnswered, showToast]);

  const startDrill = (questionIndex = 0) => {
    setCurrentQuestionIndex(questionIndex);
    setDrillActive(true);
    setSecondsLeft(15);
    setSelectedOption(null);
    setIsAnswered(false);
  };

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correct;
    if (isCorrect) {
      setStreak((s) => s + 1);
      // Boost memory node retention
      setMemoryNodes((prev) =>
        prev.map((m) =>
          m.id === currentQ.topicId
            ? { ...m, retentionPct: Math.min(100, m.retentionPct + 35), decayStatus: 'Optimal' }
            : m
        )
      );

      fireCelebration({
        emoji: '🧠',
        eyebrow: '15s Neuro-Flash Reinforced!',
        title: 'Memory Strength Restored to 85%+',
        sub: '+60 Memory Retention XP Awarded',
      });
    } else {
      showToast('Incorrect recall. Review the quick fact below.', '⚠️');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.plum} 0%, ${COLORS.navy} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Neuro-Adaptive Learning
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Ebbinghaus Retention Model</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            15-Second Spaced Repetition &amp; Memory Matrix
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Combat knowledge decay on key product prices and store return policies. High-speed 15-second recall drills solidify long-term memory.
          </p>
        </div>

        <button
          onClick={() => startDrill(0)}
          className="px-5 py-3 rounded-2xl font-extrabold text-xs text-slate-900 bg-amber-400 hover:bg-amber-300 shadow-md flex items-center gap-2 shrink-0 transition-all"
        >
          <Zap size={16} />
          <span>Launch 15s Neuro-Drill</span>
        </button>
      </div>

      {/* Grid: 15s Active Drill Arena + Memory Matrix Decay Tracker */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Active Rapid-Fire Drill Console */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs flex flex-col justify-between" style={{ borderColor: COLORS.line }}>
          {drillActive ? (
            <div className="space-y-6">
              {/* Drill Header with Timer & Streak */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center font-mono font-extrabold text-lg transition-colors ${
                      secondsLeft <= 5 ? 'bg-red-100 text-red-700 animate-pulse' : 'bg-purple-100 text-purple-800'
                    }`}
                  >
                    {secondsLeft}s
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Rapid-Fire Recall Challenge</div>
                    <div className="text-xs font-mono text-purple-700">Streak: {streak} Consecutive</div>
                  </div>
                </div>

                <button
                  onClick={() => startDrill(currentQuestionIndex)}
                  className="text-xs font-bold text-slate-400 hover:text-slate-700 flex items-center gap-1"
                >
                  <RotateCcw size={13} /> Reset Timer
                </button>
              </div>

              {/* Prompt */}
              <div className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                {currentQ.prompt}
              </div>

              {/* Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {currentQ.options.map((opt, idx) => {
                  const isChosen = selectedOption === idx;
                  const isCorrect = isAnswered && idx === currentQ.correct;
                  const isWrong = isAnswered && isChosen && idx !== currentQ.correct;

                  return (
                    <button
                      key={idx}
                      disabled={isAnswered}
                      onClick={() => handleSelectOption(idx)}
                      className={`p-4 rounded-2xl border text-left font-bold text-xs sm:text-sm transition-all flex items-center justify-between ${
                        isCorrect
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-950 ring-2 ring-emerald-500/20'
                          : isWrong
                          ? 'bg-red-50 border-red-500 text-red-950'
                          : isChosen
                          ? 'bg-purple-50 border-purple-500 text-purple-950'
                          : 'bg-slate-50 border-slate-200 hover:border-purple-300 hover:bg-purple-50/40 text-slate-800'
                      }`}
                    >
                      <span>{opt}</span>
                      {isCorrect && <CheckCircle2 size={16} className="text-emerald-600" />}
                    </button>
                  );
                })}
              </div>

              {/* Quick Fact on Completion */}
              {isAnswered && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs space-y-1 animate-in fade-in duration-200">
                  <div className="font-bold text-amber-950 flex items-center gap-1">
                    <Sparkles size={13} className="text-amber-700" /> Neuro-Recall Fact:
                  </div>
                  <p className="text-amber-900 font-medium">{currentQ.quickFact}</p>
                </div>
              )}

              {/* Next Question Navigation */}
              <div className="pt-2 flex justify-end">
                <button
                  onClick={() =>
                    startDrill((currentQuestionIndex + 1) % NEURO_DRILL_QUESTIONS.length)
                  }
                  className="px-5 py-2.5 rounded-xl font-bold text-xs text-white shadow-sm flex items-center gap-1.5"
                  style={{ backgroundColor: COLORS.navy }}
                >
                  <span>Next 15s Recall Drill</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="py-16 text-center space-y-4">
              <Brain size={48} className="mx-auto text-purple-400 animate-pulse" />
              <div className="max-w-md mx-auto">
                <h3 className="text-lg font-bold text-slate-900">Ready to boost your memory retention?</h3>
                <p className="text-xs text-slate-500 mt-1">
                  15-second timed micro-challenges prevent cognitive decay on seasonal prices, discounts, and return lookup steps.
                </p>
              </div>
              <button
                onClick={() => startDrill(0)}
                className="px-6 py-3 rounded-2xl font-bold text-xs text-slate-900 bg-amber-400 hover:bg-amber-300 shadow-md"
              >
                Start Drill Now (+60 XP)
              </button>
            </div>
          )}
        </div>

        {/* Right Col: Personal Memory Matrix Decay Tracker */}
        <div className="bg-white rounded-3xl p-6 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-purple-700 flex items-center gap-1.5">
              <Brain size={15} /> Personal Memory Matrix
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-0.5">Ebbinghaus Retention Status</h3>
          </div>

          <div className="space-y-3 pt-1">
            {memoryNodes.map((node) => (
              <div
                key={node.id}
                className={`p-3 rounded-2xl border text-xs space-y-1.5 ${
                  node.decayStatus === 'Optimal'
                    ? 'bg-emerald-50/50 border-emerald-200'
                    : node.decayStatus === 'At Risk'
                    ? 'bg-amber-50/50 border-amber-200'
                    : 'bg-red-50/50 border-red-200'
                }`}
              >
                <div className="flex justify-between items-center font-bold text-slate-900">
                  <span className="truncate pr-1">{node.topic}</span>
                  <span className="font-mono text-[11px] shrink-0">{node.retentionPct}%</span>
                </div>
                <ProgressBar
                  pct={node.retentionPct}
                  color={
                    node.retentionPct >= 75
                      ? COLORS.teal
                      : node.retentionPct >= 50
                      ? COLORS.amber
                      : COLORS.coral
                  }
                  height={5}
                />
                <div className="text-[10px] text-slate-500 leading-snug">{node.decayRiskReason}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
