'use client';

import React, { useState } from 'react';
import {
  Gift,
  Award,
  Sparkles,
  CheckCircle2,
  Copy,
  Clock,
  Coffee,
  ShoppingBag,
  Headphones,
  Calendar,
  Zap,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { RewardItem } from '../../types';
import { COLORS } from '../../lib/constants';

const REWARD_CATALOG: RewardItem[] = [
  {
    id: 'rw-ccd',
    title: '☕ Café Coffee Day Free Beverage Voucher',
    costXP: 500,
    category: 'Vouchers',
    icon: 'Coffee',
    description: 'Enjoy a handcrafted cappuccino, latte, or iced tea on your shift break.',
    partnerBrand: 'Café Coffee Day',
    availableStock: 25,
  },
  {
    id: 'rw-break',
    title: '⏱️ Extra 30-Min Extended Paid Lunch Break',
    costXP: 800,
    category: 'Perks',
    icon: 'Clock',
    description: 'Redeem an additional 30 minutes on your scheduled shift break with manager approval.',
    partnerBrand: 'Store Ops Policy',
    availableStock: 50,
  },
  {
    id: 'rw-amazon',
    title: '🎟️ ₹250 Amazon / Flipkart Shopping Voucher',
    costXP: 1200,
    category: 'Vouchers',
    icon: 'ShoppingBag',
    description: 'Instant digital gift card credited for online festive or personal shopping.',
    partnerBrand: 'Amazon / Flipkart Pay',
    availableStock: 18,
  },
  {
    id: 'rw-cert',
    title: '🌟 Official "Employee of the Week" Certificate',
    costXP: 2000,
    category: 'Prestige',
    icon: 'Award',
    description: 'Framed physical leadership certificate signed by Regional Operations Manager & placed on the store wall.',
    partnerBrand: 'Central HR HQ',
    availableStock: 5,
  },
  {
    id: 'rw-earbuds',
    title: '🎧 Noise Wireless Bluetooth Earbuds',
    costXP: 3000,
    category: 'Merchandise',
    icon: 'Headphones',
    description: 'Premium noise-cancelling wireless earbuds delivered directly to your store.',
    partnerBrand: 'Noise India',
    availableStock: 8,
  },
  {
    id: 'rw-bonus',
    title: '💰 Quarterly Performance Incentive Multiplier (1.5X)',
    costXP: 4000,
    category: 'Perks',
    icon: 'Zap',
    description: 'Boosts your quarterly retail performance cash incentive payout by 1.5X.',
    partnerBrand: 'Corporate Payroll',
    availableStock: 3,
  },
];

export function RewardsMarketplace() {
  const { currentEmployee, redeemReward, redeemedVouchers, showToast } = useAppStore();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const filteredRewards =
    selectedCategory === 'All'
      ? REWARD_CATALOG
      : REWARD_CATALOG.filter((r) => r.category === selectedCategory);

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    showToast(`Copied voucher code ${code}!`, '📋');
    setTimeout(() => setCopiedCode(null), 2500);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.amberDeep} 0%, ${COLORS.navy} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Tangible Rewards &amp; Vouchers
            </span>
            <span className="text-xs font-mono font-bold text-white/70">XP Redemption Engine</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Rewards Marketplace &amp; Voucher Vault
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Convert your earned micro-learning and customer service XP into tangible digital shopping vouchers, shift perks, and official prestige recognition.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">Available XP Wallet</div>
          <div className="text-3xl font-extrabold text-amber-300 mt-0.5">
            {currentEmployee.points.toLocaleString()} XP
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 custom-scrollbar">
        {['All', 'Vouchers', 'Perks', 'Prestige', 'Merchandise'].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
              selectedCategory === cat
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Rewards Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredRewards.map((reward) => {
          const canAfford = currentEmployee.points >= reward.costXP;
          return (
            <div
              key={reward.id}
              className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4 hover:shadow-md transition-shadow"
              style={{ borderColor: COLORS.line }}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                    {reward.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-700">
                    {reward.costXP} XP
                  </span>
                </div>

                <h3 className="font-bold text-base text-slate-900 leading-snug">{reward.title}</h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed font-medium">
                  {reward.description}
                </p>

                {reward.partnerBrand && (
                  <div className="text-[11px] font-mono text-slate-400 mt-2">
                    Partner: <strong>{reward.partnerBrand}</strong>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100">
                <button
                  onClick={() => redeemReward(reward)}
                  disabled={!canAfford}
                  className={`w-full py-2.5 rounded-xl font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all ${
                    canAfford
                      ? 'bg-amber-400 hover:bg-amber-300 text-slate-900'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <Gift size={14} />
                  <span>{canAfford ? `Redeem for ${reward.costXP} XP` : `Need ${reward.costXP - currentEmployee.points} more XP`}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Redeemed Vouchers History */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
        <SectionHeader
          title="My Redeemed Voucher Vault"
          subtitle="Active digital voucher codes ready to use on your shift or online"
        />

        {redeemedVouchers.length > 0 ? (
          <div className="divide-y divide-slate-100">
            {redeemedVouchers.map((v) => (
              <div key={v.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="font-bold text-sm text-slate-900">{v.rewardTitle}</div>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    Redeemed {v.redeemedAt} · Valid {v.expiresAt}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="px-3 py-1.5 rounded-xl bg-slate-100 font-mono font-bold text-xs text-slate-800 border border-slate-200 tracking-wider">
                    {v.code}
                  </div>

                  <button
                    onClick={() => copyCode(v.code)}
                    className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors"
                    title="Copy code"
                  >
                    <Copy size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-8 text-center text-xs text-slate-400">
            No vouchers redeemed yet. Earn XP from micro-lessons and store missions to unlock rewards!
          </div>
        )}
      </div>
    </div>
  );
}
