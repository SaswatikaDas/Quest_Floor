'use client';

import React from 'react';
import { Award, Lock, CheckCircle2, Trophy, Star, Sparkles } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { LevelScoreboard } from '../common/LevelScoreboard';
import { SectionHeader } from '../common/SectionHeader';
import { BADGES, LEVELS, COLORS } from '../../lib/constants';
import { getLevelInfo } from '../../lib/cxCalculator';

export function AchievementsScreen() {
  const { currentEmployee } = useAppStore();
  const info = getLevelInfo(currentEmployee.points);

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
          Achievements &amp; Level Roadmap
        </h2>
        <p className="text-sm text-slate-500 mt-0.5">
          Unlock prestige badges, climb retail mastery tiers, and earn recognition across 1,200 stores
        </p>
      </div>

      {/* Level Scoreboard */}
      <LevelScoreboard points={currentEmployee.points} />

      {/* Badge Showcase Grid */}
      <div className="space-y-4">
        <SectionHeader
          title={`Prestige Badge Gallery (${currentEmployee.badges.length}/${BADGES.length})`}
          subtitle="Earn badges by passing micro-learning quizzes, hitting 90%+ POS adoption, and delighting customers"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {BADGES.map((b) => {
            const isEarned = currentEmployee.badges.includes(b.id);
            return (
              <div
                key={b.id}
                className={`rounded-3xl p-6 border text-center flex flex-col items-center justify-between transition-all duration-200 ${
                  isEarned
                    ? 'bg-white border-purple-200 shadow-sm hover:shadow-md'
                    : 'bg-slate-50/70 border-slate-200 opacity-60'
                }`}
              >
                <div>
                  <div
                    className={`text-5xl mb-3 transition-transform ${
                      isEarned ? 'animate-bounce-short' : 'grayscale opacity-50'
                    }`}
                  >
                    {b.icon}
                  </div>
                  <div className="font-bold text-base leading-snug" style={{ color: COLORS.ink }}>
                    {b.name}
                  </div>
                  <div className="text-xs text-slate-500 mt-1.5 line-clamp-2">{b.desc}</div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 w-full">
                  {isEarned ? (
                    <span className="text-[11px] font-bold text-teal-700 bg-teal-50 px-3 py-1 rounded-full border border-teal-200 inline-flex items-center gap-1">
                      <CheckCircle2 size={13} /> Unlocked
                    </span>
                  ) : (
                    <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full border border-slate-200 inline-flex items-center gap-1">
                      <Lock size={12} /> In Progress
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Level Path Roadmap */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6" style={{ borderColor: COLORS.line }}>
        <SectionHeader
          title="Retail Mastery Level Progression"
          subtitle="Tier thresholds and skill benchmarks"
        />

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
          {LEVELS.map((l) => {
            const isReached = currentEmployee.points >= l.min;
            const isCurrent = l.level === info.level;

            return (
              <div
                key={l.level}
                className={`rounded-2xl p-5 border text-center transition-all ${
                  isCurrent
                    ? 'border-amber-400 bg-amber-50/70 shadow-sm ring-2 ring-amber-400/20'
                    : isReached
                    ? 'border-teal-200 bg-teal-50/40'
                    : 'border-slate-200 bg-slate-50/60 opacity-60'
                }`}
              >
                <div
                  className="font-mono text-xs font-bold uppercase tracking-wider"
                  style={{ color: isCurrent ? COLORS.amberDeep : isReached ? COLORS.teal : COLORS.muted }}
                >
                  LEVEL {l.level}
                </div>
                <div className="font-extrabold text-base mt-1" style={{ color: COLORS.ink }}>
                  {l.name}
                </div>
                <div className="text-xs font-mono font-bold text-slate-500 mt-1">
                  {l.min.toLocaleString('en-IN')}+ XP
                </div>
                {isCurrent && (
                  <div className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-amber-400 text-slate-900 mt-2 font-mono">
                    ACTIVE LEVEL
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
