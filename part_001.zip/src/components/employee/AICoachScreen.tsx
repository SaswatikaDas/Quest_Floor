'use client';

import React, { useState } from 'react';
import {
  Brain,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Sparkles,
  Gauge,
  BookOpen,
  PlayCircle,
  Target,
  MessageSquare,
  RefreshCw,
  CheckCircle2,
  Mic,
  MicOff,
  Volume2,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { ProgressBar } from '../common/ProgressBar';
import { AnimatedNumber } from '../common/AnimatedNumber';
import { SkillGraphDiagram } from '../diagrams/SkillGraphDiagram';
import { COLORS } from '../../lib/constants';
import {
  computeSkillScores,
  primarySkillGap,
  aiConfidence,
  getExplainabilityFactors,
  SKILL_CATEGORY_MAP,
} from '../../lib/aiEngine';
import { avg } from '../../lib/cxCalculator';
import { api } from '../../lib/api';
import { Pill } from '../common/Pill';

export function AICoachScreen() {
  const { currentEmployee, employees, trainingModules, setScreen } = useAppStore();

  // Floor Copilot Live State
  const [copilotQuery, setCopilotQuery] = useState('');
  const [copilotLoading, setCopilotLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copilotResult, setCopilotResult] = useState<{
    answer: string;
    suggested_upsell?: string;
    pos_action_step?: string;
  } | null>({
    answer: '🤖 Namaste! I am QuestBot, your Floor AI Copilot. Ask me any product specification (e.g. 5000mAh battery specs), POS split billing steps, or consultative upsell scripts in Hindi or English!',
    suggested_upsell: 'Bundle ANC Earbuds with Smartphone for ₹999.',
    pos_action_step: 'Scan barcode or press F4 for instant promo lookup.',
  });

  const handleAskCopilot = async (q?: string) => {
    const textToAsk = q || copilotQuery;
    if (!textToAsk.trim()) return;
    setCopilotLoading(true);

    const res = await api.askCopilot(textToAsk, currentEmployee.id);
    setCopilotLoading(false);
    if (res) {
      setCopilotResult(res);
    }
  };

  const toggleVoiceInput = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-IN';

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        setCopilotQuery(text);
        handleAskCopilot(text);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } else {
      // Simulation
      setIsListening(true);
      setTimeout(() => {
        const mockQ = 'Explain festive smartphone discount rules in Hindi';
        setCopilotQuery(mockQ);
        handleAskCopilot(mockQ);
        setIsListening(false);
      }, 1000);
    }
  };

  const handleSpeakAnswer = (text: string) => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.onend = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  const storeEmployees = employees.filter((e) => e.storeId === currentEmployee.storeId);
  const storeAvgPos = avg(storeEmployees.map((e) => e.posAdoption));

  const scores = computeSkillScores(currentEmployee, trainingModules);
  const gap = primarySkillGap(currentEmployee, trainingModules);
  const confidence = aiConfidence(currentEmployee, gap.score);
  const factors = getExplainabilityFactors(currentEmployee, storeAvgPos, trainingModules);

  const targetCategory = SKILL_CATEGORY_MAP[gap.skill];
  const incompleteModules = trainingModules.filter((m) => !currentEmployee.completedModules.includes(m.id));
  const recommendedModule =
    incompleteModules.find((m) => m.category === targetCategory) ||
    trainingModules.find((m) => m.category === targetCategory) ||
    trainingModules[0];

  const projectedSkill = Math.min(96, gap.score + 25);
  const cx = currentEmployee.customerFeedbackScore;
  const projectedCx = Math.min(98, cx + Math.round((projectedSkill - gap.score) * 0.25));

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg"
            style={{ backgroundColor: COLORS.plum }}
          >
            <Brain size={24} />
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
              AI Coaching &amp; Floor Voice Copilot
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Personalized skill-gap analysis for {currentEmployee.name} with transparent rationale &amp; Voice AI
            </p>
          </div>
        </div>

        <button
          onClick={() => setScreen('learning')}
          className="px-4 py-2.5 rounded-xl font-bold text-xs text-white shadow flex items-center gap-2"
          style={{ backgroundColor: COLORS.navy }}
        >
          <span>Open Learning Center</span>
          <ArrowRight size={14} />
        </button>
      </div>

      {/* Ask QuestBot Floor Copilot Live Section */}
      <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 rounded-3xl p-6 sm:p-7 text-white border border-indigo-500/30 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-400 to-indigo-500 flex items-center justify-center text-xl shadow-lg shadow-indigo-500/30">
              🤖
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-white">Ask QuestBot — Real-Time Floor AI Copilot</h3>
                <Pill color={COLORS.amber}>LLM Copilot</Pill>
                <Pill color={COLORS.teal}>Bilingual Voice AI</Pill>
              </div>
              <p className="text-xs text-slate-400">
                Instant product spec lookups, POS billing troubleshooting, and consultative upsell pitches for floor associates.
              </p>
            </div>
          </div>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => handleAskCopilot('Compare 5G Smartphone vs 4G specs in Hindi')}
            className="px-3 py-1.5 rounded-full bg-slate-800/80 hover:bg-indigo-900/60 border border-slate-700 hover:border-indigo-400 text-slate-300 hover:text-white transition-all whitespace-nowrap"
          >
            📱 Compare 5G vs 4G Specs (Hindi)
          </button>
          <button
            onClick={() => handleAskCopilot('How to do Split Tender (Cash + UPI) in POS?')}
            className="px-3 py-1.5 rounded-full bg-slate-800/80 hover:bg-indigo-900/60 border border-slate-700 hover:border-indigo-400 text-slate-300 hover:text-white transition-all whitespace-nowrap"
          >
            💻 POS Split Payment Guide
          </button>
          <button
            onClick={() => handleAskCopilot('Pitch Smartphone + Earbuds combo to a festive customer')}
            className="px-3 py-1.5 rounded-full bg-slate-800/80 hover:bg-indigo-900/60 border border-slate-700 hover:border-indigo-400 text-slate-300 hover:text-white transition-all whitespace-nowrap"
          >
            🎧 Smartphone + Earbuds Upsell Pitch
          </button>
          <button
            onClick={() => handleAskCopilot('Explain 5000mAh Adaptive AI battery optimization in 30 seconds')}
            className="px-3 py-1.5 rounded-full bg-slate-800/80 hover:bg-indigo-900/60 border border-slate-700 hover:border-indigo-400 text-slate-300 hover:text-white transition-all whitespace-nowrap"
          >
            ⚡ 5000mAh Battery Feature Hook
          </button>
        </div>

        {/* Live Input Bar with Mic */}
        <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-700/80 rounded-2xl p-1.5 focus-within:border-indigo-400 transition-all">
          <button
            onClick={toggleVoiceInput}
            className={`p-2 rounded-xl border text-xs font-bold transition-all ${
              isListening
                ? 'bg-rose-500 text-white border-rose-600 animate-pulse'
                : 'bg-slate-800 text-slate-300 hover:text-white border-slate-700'
            }`}
            title="Speak with Voice AI"
          >
            {isListening ? <MicOff size={16} /> : <Mic size={16} className="text-amber-400" />}
          </button>

          <input
            type="text"
            value={copilotQuery}
            onChange={(e) => setCopilotQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAskCopilot()}
            placeholder="Ask QuestBot anything in English or Hindi (or click mic to speak)..."
            className="flex-1 bg-transparent px-2 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none"
          />
          <button
            onClick={() => handleAskCopilot()}
            disabled={copilotLoading}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-600 hover:to-indigo-700 text-white font-bold text-xs shadow-md transition-all disabled:opacity-50"
          >
            {copilotLoading ? 'Thinking...' : 'Ask Copilot ✨'}
          </button>
        </div>

        {/* Response Box */}
        {copilotResult && (
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-indigo-500/30 space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between text-xs font-bold text-indigo-300">
              <span className="flex items-center gap-1.5">
                <Sparkles size={14} className="text-amber-400" /> QuestBot Real-Time Guidance:
              </span>
              <button
                onClick={() => handleSpeakAnswer(copilotResult.answer)}
                className="flex items-center gap-1 text-slate-300 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-[11px]"
              >
                <Volume2 size={13} className={isSpeaking ? 'animate-bounce text-amber-400' : ''} />
                <span>{isSpeaking ? 'Stop Readout' : '🔊 Voice Readout'}</span>
              </button>
            </div>

            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-line">
              {copilotResult.answer}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800 text-xs">
              {copilotResult.suggested_upsell && (
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300">
                  <span className="font-bold">🎯 Consultative Upsell:</span> {copilotResult.suggested_upsell}
                </div>
              )}
              {copilotResult.pos_action_step && (
                <div className="p-2.5 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-300">
                  <span className="font-bold">💻 POS Action:</span> {copilotResult.pos_action_step}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Skill Diagnostic & Explainable Graph */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 5 Cols: Skill Breakdown */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <SectionHeader
            title="Associate Competency Radar"
            subtitle="Live competency distribution across 4 core retail capabilities"
          />

          <div className="space-y-3 mt-4">
            {scores.map((s) => (
              <div key={s.skill} className="space-y-1">
                <div className="flex justify-between text-xs font-bold text-slate-800">
                  <span>{s.skill}</span>
                  <span className="font-mono">{s.score}%</span>
                </div>
                <ProgressBar pct={s.score} color={s.score > 70 ? COLORS.teal : COLORS.amber} height={8} />
              </div>
            ))}
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 mt-4 text-xs space-y-2">
            <div className="font-bold text-slate-900 flex items-center gap-1.5">
              <AlertTriangle size={15} className="text-amber-500" />
              <span>Primary Skill Gap Identified:</span>
            </div>
            <p className="text-slate-600">
              {currentEmployee.name} scores lowest in <strong>{gap.skill} ({gap.score}%)</strong> compared to peer average ({storeAvgPos}%).
            </p>
          </div>
        </div>

        {/* Right 7 Cols: Skill Graph Diagram */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <SectionHeader
            title="Explainable AI Skill Dependency Graph"
            subtitle="Transparent path showing how micro-learning unlocks floor confidence"
          />

          <div className="mt-4">
            <SkillGraphDiagram employee={currentEmployee} modules={trainingModules} />
          </div>
        </div>
      </div>
    </div>
  );
}
