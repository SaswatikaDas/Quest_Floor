'use client';

import React, { useState, useEffect } from 'react';
import {
  Zap,
  Barcode,
  ShoppingCart,
  QrCode,
  CreditCard,
  Banknote,
  CheckCircle2,
  Trash2,
  Plus,
  Minus,
  Sparkles,
  Trophy,
  RotateCcw,
  Timer,
  ShieldCheck,
  TrendingUp,
  Mic,
  MicOff,
  Volume2,
  Radio,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { POSProductItem, POSCartItem } from '../../types';
import { COLORS } from '../../lib/constants';
import { api } from '../../lib/api';

const DEMO_PRODUCTS: POSProductItem[] = [
  {
    id: 'p-phone-5g',
    barcode: '89012345001',
    name: 'Flagship 5G Smartphone (128GB)',
    price: 14999,
    category: 'Smartphones',
    emoji: '📱',
    comboOffer: 'Bundle ANC Earbuds for ₹999 (Save ₹1,000)',
  },
  {
    id: 'p-earbuds',
    barcode: '89012345002',
    name: 'True Wireless ANC Earbuds (30h)',
    price: 1999,
    category: 'Accessories',
    emoji: '🎧',
    hasDiscount: true,
    comboOffer: '40% off when attached to Smartphone',
  },
  {
    id: 'p-screen',
    barcode: '89012345003',
    name: '9H Tempered Glass + 1-Yr Screen Shield',
    price: 499,
    category: 'Protection',
    emoji: '🛡️',
  },
  {
    id: 'p-charger',
    barcode: '89012345004',
    name: '45W SuperVOOC Fast Power Adapter',
    price: 899,
    category: 'Accessories',
    emoji: '⚡',
  },
  {
    id: 'p-watch',
    barcode: '89012345005',
    name: 'AMOLED Smartwatch Fitness Tracker',
    price: 2499,
    category: 'Wearables',
    emoji: '⌚',
  },
];

export function POSSandboxArena() {
  const { fireCelebration, showToast, currentEmployeeId } = useAppStore();

  const [cart, setCart] = useState<POSCartItem[]>([
    { product: DEMO_PRODUCTS[0], quantity: 1, discount: 0 },
    { product: DEMO_PRODUCTS[1], quantity: 1, discount: 500 },
  ]);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>('GOLD5 (5% Off)');
  const [paymentStep, setPaymentStep] = useState<'cart' | 'tender' | 'success'>('cart');
  const [tenderMethod, setTenderMethod] = useState<'upi' | 'cash' | 'split'>('split');
  const [cashAmount, setCashAmount] = useState<number>(5000);

  // Speed Challenge State
  const [speedMode, setSpeedMode] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);
  const [billsCompleted, setBillsCompleted] = useState(0);

  // Voice AI Assistant State
  const [isListening, setIsListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [soundboxMuted, setSoundboxMuted] = useState(false);

  // Upsell Attachment Detection
  const hasPhone = cart.some((c) => c.product.category === 'Smartphones');
  const hasEarbuds = cart.some((c) => c.product.category === 'Accessories' || c.product.name.includes('Earbuds'));
  const isUpsellAttached = hasPhone && hasEarbuds;

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (speedMode && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft((t) => t - 1), 1000);
    } else if (speedMode && timeLeft === 0) {
      setSpeedMode(false);
      fireCelebration({
        emoji: '⚡',
        eyebrow: 'POS Speed Sprint Complete!',
        title: `${billsCompleted} Rapid Bills Processed!`,
        sub: '+150 XP POS Velocity Bonus Claimed',
      });
    }
    return () => clearInterval(timer);
  }, [speedMode, timeLeft, billsCompleted, fireCelebration]);

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountTotal = cart.reduce((sum, item) => sum + item.discount * item.quantity, 0);
  const couponDiscount = appliedCoupon ? Math.round((subtotal - discountTotal) * 0.05) : 0;
  const grandTotal = Math.max(0, subtotal - discountTotal - couponDiscount);

  const cashPay = tenderMethod === 'cash' ? grandTotal : tenderMethod === 'split' ? Math.min(cashAmount, grandTotal) : 0;
  const upiPay = tenderMethod === 'upi' ? grandTotal : tenderMethod === 'split' ? Math.max(0, grandTotal - cashAmount) : 0;

  const handleAddToCart = (product: POSProductItem) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1, discount: product.hasDiscount ? 300 : 0 }];
    });
    showToast(`Added ${product.name} to POS Cart`);
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as POSCartItem[]
    );
  };

  // Soundbox Voice Readout
  const speakSoundbox = (text: string) => {
    if (soundboxMuted) return;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.1;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Voice AI Assistant recognition
  const toggleVoiceAssistant = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-IN';

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceTranscript('Listening... Speak command (e.g., "Add smartphone", "Split payment")');
      };

      recognition.onresult = (event: any) => {
        const speech = event.results[0][0].transcript.toLowerCase();
        setVoiceTranscript(`Voice recognized: "${speech}"`);
        handleVoiceCommand(speech);
      };

      recognition.onerror = () => {
        setIsListening(false);
        simulateVoiceCommand();
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } else {
      simulateVoiceCommand();
    }
  };

  const simulateVoiceCommand = () => {
    setIsListening(true);
    setVoiceTranscript('🎤 Voice AI: "Add Tempered Glass and prepare UPI QR split"');
    setTimeout(() => {
      handleAddToCart(DEMO_PRODUCTS[2]);
      setTenderMethod('split');
      setIsListening(false);
      showToast('✨ Voice AI Command Executed: Added Tempered Glass!');
    }, 1200);
  };

  const handleVoiceCommand = (cmd: string) => {
    if (cmd.includes('phone') || cmd.includes('mobile')) {
      handleAddToCart(DEMO_PRODUCTS[0]);
    } else if (cmd.includes('earbud') || cmd.includes('headphone')) {
      handleAddToCart(DEMO_PRODUCTS[1]);
    } else if (cmd.includes('glass') || cmd.includes('shield')) {
      handleAddToCart(DEMO_PRODUCTS[2]);
    } else if (cmd.includes('pay') || cmd.includes('checkout') || cmd.includes('upi')) {
      setPaymentStep('tender');
    }
    showToast(`Voice Command: "${cmd}" executed!`, '🎙️');
  };

  const handleCompleteCheckout = async () => {
    setPaymentStep('success');
    setBillsCompleted((b) => b + 1);

    // Trigger Voice Soundbox
    const formattedAmt = grandTotal.toLocaleString('en-IN');
    speakSoundbox(`QuestFloor Soundbox: Rupeeyaz ${formattedAmt} received via UPI and Cash payment!`);

    await api.processPOSCheckout({
      employee_id: currentEmployeeId,
      items: cart.map((c) => ({ product_id: c.product.id, quantity: c.quantity })),
      payment_method: tenderMethod,
      discount_amount: discountTotal + couponDiscount,
    });

    fireCelebration({
      emoji: '💳',
      eyebrow: 'Fast-Lane POS Transaction Authorized!',
      title: `₹${grandTotal.toLocaleString('en-IN')} Billed Successfully`,
      sub: isUpsellAttached
        ? '🔥 +120 XP (Consultative Upsell Attachment Bonus Included)'
        : '+50 XP Speed Billing Standard Reward',
    });
  };

  const handleResetCheckout = () => {
    setCart([
      { product: DEMO_PRODUCTS[0], quantity: 1, discount: 0 },
      { product: DEMO_PRODUCTS[1], quantity: 1, discount: 500 },
    ]);
    setPaymentStep('cart');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
              Digital POS Speed Terminal &amp; Voice Assistant
            </h2>
            <Pill color={COLORS.amber}>Fast-Lane v3.4</Pill>
            <Pill color={COLORS.teal}>UPI Soundbox Live</Pill>
          </div>
          <p className="text-sm text-slate-500 mt-0.5">
            Voice-enabled barcode scanning, dynamic UPI QR generation, split tender, and upsell combos.
          </p>
        </div>

        {/* Speed Sprint & Voice Mode Bar */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleVoiceAssistant}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition-all shadow-xs ${
              isListening
                ? 'bg-rose-500 text-white border-rose-600 animate-pulse'
                : 'bg-white hover:bg-slate-50 border-slate-300 text-slate-700'
            }`}
          >
            {isListening ? <MicOff size={15} /> : <Mic size={15} className="text-indigo-600" />}
            <span>{isListening ? 'Listening...' : 'Voice Billing Copilot'}</span>
          </button>

          <button
            onClick={() => {
              setSpeedMode(true);
              setTimeLeft(60);
              setBillsCompleted(0);
            }}
            disabled={speedMode}
            className="px-4 py-2 rounded-xl text-xs font-bold text-white shadow-md flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
            style={{ backgroundColor: COLORS.amberDeep }}
          >
            <Timer size={15} />
            <span>{speedMode ? `Sprint: ${timeLeft}s Left` : '⚡ Start 60s Speed Sprint'}</span>
          </button>
        </div>
      </div>

      {voiceTranscript && (
        <div className="p-3 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-semibold flex items-center justify-between animate-in fade-in">
          <span className="flex items-center gap-2">
            <Sparkles size={14} className="text-indigo-600" />
            <span>{voiceTranscript}</span>
          </span>
          <button onClick={() => setVoiceTranscript('')} className="text-slate-400 hover:text-slate-600 text-xs">
            ✕
          </button>
        </div>
      )}

      {/* Main Terminal Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 Columns: Catalog & Barcode Fast Picks */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <SectionHeader
              title="Aisle Product Barcode Catalog"
              subtitle="Click any SKU to scan into active POS bill or speak via Voice Copilot"
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
              {DEMO_PRODUCTS.map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => handleAddToCart(prod)}
                  className="p-4 rounded-2xl border border-slate-200 hover:border-amber-400 hover:shadow-md transition-all cursor-pointer bg-slate-50/50 flex flex-col justify-between group"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-3xl">{prod.emoji}</span>
                    <span className="text-[10px] font-mono text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {prod.barcode}
                    </span>
                  </div>

                  <div className="mt-3">
                    <div className="font-bold text-xs text-slate-900 group-hover:text-amber-600 transition-colors line-clamp-1">
                      {prod.name}
                    </div>
                    <div className="text-xs font-black text-slate-900 mt-1 font-mono">
                      ₹{prod.price.toLocaleString('en-IN')}
                    </div>
                    {prod.comboOffer && (
                      <div className="text-[10px] text-teal-700 bg-teal-50 border border-teal-200 px-2 py-0.5 rounded-md mt-2 font-medium">
                        ✨ {prod.comboOffer}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upsell Attachment Advice */}
          <div
            className={`p-4 rounded-2xl border transition-all flex items-center justify-between ${
              isUpsellAttached
                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                : 'bg-amber-50 border-amber-300 text-amber-950'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">{isUpsellAttached ? '🎯' : '💡'}</span>
              <div>
                <div className="font-bold text-xs">
                  {isUpsellAttached
                    ? 'Consultative Combo Active: Smartphone + ANC Earbuds'
                    : 'Upsell Tip: Recommend ANC Earbuds (+₹999) with Smartphone'}
                </div>
                <div className="text-[11px] text-slate-600">
                  {isUpsellAttached
                    ? 'Floor attachment target achieved. +120 XP will be credited upon billing.'
                    : 'Attachment boosts customer delight & store commission index.'}
                </div>
              </div>
            </div>
            {isUpsellAttached && <Pill color={COLORS.teal}>+120 XP Bonus</Pill>}
          </div>
        </div>

        {/* Right 5 Columns: Active Bill & Checkout Station */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <ShoppingCart size={18} className="text-amber-500" />
                <span className="font-bold text-sm text-slate-900">Active Register #01</span>
              </div>
              <button
                onClick={handleResetCheckout}
                className="text-[11px] text-slate-400 hover:text-rose-600 flex items-center gap-1 font-semibold"
              >
                <RotateCcw size={12} />
                <span>Clear Bill</span>
              </button>
            </div>

            {/* STEP 1: CART REVIEW */}
            {paymentStep === 'cart' && (
              <div className="space-y-4">
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {cart.map((item) => (
                    <div
                      key={item.product.id}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">{item.product.emoji}</span>
                        <div>
                          <div className="font-bold text-slate-900">{item.product.name}</div>
                          <div className="text-[11px] text-slate-500 font-mono">
                            ₹{item.product.price.toLocaleString('en-IN')} × {item.quantity}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleUpdateQuantity(item.product.id, -1)}
                          className="w-6 h-6 rounded-md bg-white border border-slate-300 text-slate-600 flex items-center justify-center hover:bg-slate-100"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="font-bold font-mono">{item.quantity}</span>
                        <button
                          onClick={() => handleUpdateQuantity(item.product.id, 1)}
                          className="w-6 h-6 rounded-md bg-white border border-slate-300 text-slate-600 flex items-center justify-center hover:bg-slate-100"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Price Breakdown */}
                <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-2 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Subtotal</span>
                    <span>₹{subtotal.toLocaleString('en-IN')}</span>
                  </div>
                  {discountTotal > 0 && (
                    <div className="flex justify-between text-emerald-400 font-semibold">
                      <span>Bundle Combo Savings</span>
                      <span>-₹{discountTotal.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  {appliedCoupon && (
                    <div className="flex justify-between text-amber-300 font-semibold">
                      <span>{appliedCoupon}</span>
                      <span>-₹{couponDiscount.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  <div className="pt-2 border-t border-slate-800 flex justify-between font-black text-sm text-white">
                    <span>Grand Total</span>
                    <span className="text-amber-400 font-mono">₹{grandTotal.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <button
                  onClick={() => setPaymentStep('tender')}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-1.5 transition-all active:scale-95"
                >
                  <QrCode size={16} />
                  <span>Proceed to Payment Tender (UPI / Cash)</span>
                </button>
              </div>
            )}

            {/* STEP 2: TENDER & DYNAMIC UPI QR */}
            {paymentStep === 'tender' && (
              <div className="space-y-4 animate-in fade-in">
                <div className="text-xs font-bold text-slate-700">Select Payment Tender:</div>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setTenderMethod('upi')}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      tenderMethod === 'upi'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    📱 100% UPI QR
                  </button>
                  <button
                    onClick={() => setTenderMethod('split')}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      tenderMethod === 'split'
                        ? 'border-amber-600 bg-amber-50 text-amber-700'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    ⚡ Split Tender
                  </button>
                  <button
                    onClick={() => setTenderMethod('cash')}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      tenderMethod === 'cash'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    💵 100% Cash
                  </button>
                </div>

                {tenderMethod === 'split' && (
                  <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2 text-xs">
                    <label className="font-bold text-slate-800 block">Cash Tender Received (₹):</label>
                    <input
                      type="number"
                      value={cashAmount}
                      onChange={(e) => setCashAmount(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900"
                    />
                    <div className="flex justify-between text-[11px] text-slate-600 pt-1">
                      <span>Cash Paid: ₹{cashPay.toLocaleString('en-IN')}</span>
                      <span className="font-bold text-indigo-700">Remaining for UPI: ₹{upiPay.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                )}

                {/* Dynamic UPI Soundbox Display */}
                {(tenderMethod === 'upi' || tenderMethod === 'split') && upiPay > 0 && (
                  <div className="p-4 rounded-2xl bg-slate-950 text-white text-center space-y-2 border border-slate-800">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Radio size={13} className="text-emerald-400 animate-pulse" />
                        <span>QuestFloor Soundbox Connected</span>
                      </span>
                      <button
                        onClick={() => setSoundboxMuted(!soundboxMuted)}
                        className="text-amber-400 hover:underline"
                      >
                        {soundboxMuted ? '🔇 Soundbox Muted' : '🔊 Voice Enabled'}
                      </button>
                    </div>

                    <div className="w-32 h-32 bg-white rounded-2xl mx-auto flex items-center justify-center p-2 shadow-inner">
                      <QrCode size={100} className="text-slate-900" />
                    </div>

                    <div className="text-xs font-black text-amber-400 font-mono">
                      Scan to Pay ₹{upiPay.toLocaleString('en-IN')}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      UPI ID: retailrise.store104@icici • Instant Soundbox Readout
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    onClick={() => setPaymentStep('cart')}
                    className="w-1/3 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-bold hover:bg-slate-100"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleCompleteCheckout}
                    className="w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs shadow-md shadow-emerald-500/20 flex items-center justify-center gap-1.5 transition-all active:scale-95"
                  >
                    <CheckCircle2 size={16} />
                    <span>Authorize &amp; Print E-Bill</span>
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: SUCCESS STATE */}
            {paymentStep === 'success' && (
              <div className="text-center py-6 space-y-4 animate-in fade-in">
                <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center shadow-lg">
                  <CheckCircle2 size={36} />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">Payment Authorized &amp; Billed!</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Receipt #QF-POS-10499 dispatched to customer WhatsApp &amp; SMS.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-700">
                  Total: ₹{grandTotal.toLocaleString('en-IN')} • {tenderMethod.toUpperCase()}
                </div>

                <button
                  onClick={handleResetCheckout}
                  className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-md transition-all"
                >
                  Start Next Customer Bill →
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
