'use client';

import React, { useState } from 'react';
import {
  Brain,
  Sliders,
  TrendingUp,
  Award,
  Sparkles,
  Trophy,
  ArrowRight,
  Info,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { ProgressBar } from '../common/ProgressBar';
import { AnimatedNumber } from '../common/AnimatedNumber';
import { getGlassboxAttributions, simulateCounterfactual } from '../../lib/xaiEngine';
import { COLORS } from '../../lib/constants';

export function XAICounterfactualScreen() {
  const { currentEmployee, employees, trainingModules } = useAppStore();

  const [posAdoption, setPosAdoption] = useState(currentEmployee.posAdoption);
  const [completedCount, setCompletedCount] = useState(currentEmployee.completedModules.length);
  const [csatScore, setCsatScore] = useState(currentEmployee.customerFeedbackScore);
  const [upsellConversion, setUpsellConversion] = useState(currentEmployee.salesConversion);

  const attributions = getGlassboxAttributions(currentEmployee, trainingModules);

  const simulation = simulateCounterfactual(currentEmployee, employees, trainingModules.length, {
    posAdoption,
    completedModulesCount: completedCount,
    csatScore,
    upsellConversion,
  });

  const resetSliders = () => {
    setPosAdoption(currentEmployee.posAdoption);
    setCompletedCount(currentEmployee.completedModules.length);
    setCsatScore(currentEmployee.customerFeedbackScore);
    setUpsellConversion(currentEmployee.salesConversion);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.teal} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-teal-300">
              Explainable AI (XAI) Feature
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Glassbox Architecture</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Explainable AI &amp; Counterfactual &ldquo;What-If&rdquo; Simulator
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            See exactly how every retail operational factor shapes your performance rating. Simulate potential interventions to predict CX score lift and leaderboard jumps.
          </p>
        </div>

        <button
          onClick={resetSliders}
          className="bg-white/10 hover:bg-white/20 border border-white/20 px-4 py-2.5 rounded-xl font-bold text-xs text-white flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <RotateCcw size={14} />
          <span>Reset to Current Baseline</span>
        </button>
      </div>

      {/* Main Grid: Interactive Counterfactual Sliders + Real-Time Simulation Projection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive What-If Sliders */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6" style={{ borderColor: COLORS.line }}>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-teal-700 flex items-center gap-1.5">
                <Sliders size={15} /> Counterfactual Input Parameters
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                Adjust Variables to Simulate Outcomes
              </h3>
            </div>
            <span className="text-xs font-mono font-bold text-slate-400">Live Model Telemetry</span>
          </div>

          <div className="space-y-6 pt-2">
            {/* Slider 1: POS Adoption */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700 flex items-center gap-1.5">
                  <span>Digital POS Floor Adoption</span>
                  <span className="text-[10px] text-slate-400 font-normal">(Weight: 25%)</span>
                </span>
                <span className="font-mono text-sm text-teal-700">{posAdoption}%</span>
              </div>
              <input
                type="range"
                min={30}
                max={100}
                value={posAdoption}
                onChange={(e) => setPosAdoption(Number(e.target.value))}
                className="w-full accent-teal-600 cursor-pointer h-2 bg-slate-100 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>30% (Severe Delays)</span>
                <span>Current: {currentEmployee.posAdoption}%</span>
                <span>100% (Zero Friction)</span>
              </div>
            </div>

            {/* Slider 2: Micro-Curriculum Modules */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700 flex items-center gap-1.5">
                  <span>Completed Micro-Learning Modules</span>
                  <span className="text-[10px] text-slate-400 font-normal">(Weight: 20%)</span>
                </span>
                <span className="font-mono text-sm text-purple-700">
                  {completedCount} / {trainingModules.length} Modules
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={trainingModules.length}
                value={completedCount}
                onChange={(e) => setCompletedCount(Number(e.target.value))}
                className="w-full accent-purple-600 cursor-pointer h-2 bg-slate-100 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0 Modules</span>
                <span>Current: {currentEmployee.completedModules.length} Modules</span>
                <span>{trainingModules.length} Modules (Complete)</span>
              </div>
            </div>

            {/* Slider 3: Customer Feedback CSAT */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700 flex items-center gap-1.5">
                  <span>Customer CSAT Rating Score</span>
                  <span className="text-[10px] text-slate-400 font-normal">(Weight: 25%)</span>
                </span>
                <span className="font-mono text-sm text-amber-700">{csatScore}% 5-Star</span>
              </div>
              <input
                type="range"
                min={50}
                max={100}
                value={csatScore}
                onChange={(e) => setCsatScore(Number(e.target.value))}
                className="w-full accent-amber-600 cursor-pointer h-2 bg-slate-100 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>50%</span>
                <span>Current: {currentEmployee.customerFeedbackScore}%</span>
                <span>100%</span>
              </div>
            </div>

            {/* Slider 4: Sales Upsell Conversion */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700 flex items-center gap-1.5">
                  <span>Consultative Upsell Conversion</span>
                  <span className="text-[10px] text-slate-400 font-normal">(Weight: 15%)</span>
                </span>
                <span className="font-mono text-sm text-rose-700">{upsellConversion}%</span>
              </div>
              <input
                type="range"
                min={30}
                max={100}
                value={upsellConversion}
                onChange={(e) => setUpsellConversion(Number(e.target.value))}
                className="w-full accent-rose-600 cursor-pointer h-2 bg-slate-100 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>30%</span>
                <span>Current: {currentEmployee.salesConversion}%</span>
                <span>100%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Real-Time Projected Outcomes */}
        <div className="space-y-4">
          <div
            className="rounded-3xl p-6 text-white shadow-md flex flex-col justify-between"
            style={{
              background: `linear-gradient(145deg, ${COLORS.navy}, ${COLORS.navy2})`,
            }}
          >
            <div>
              <div className="text-xs uppercase tracking-wider font-extrabold text-amber-400">
                Simulated CX Score Outcome
              </div>
              <div className="font-mono text-5xl font-extrabold mt-2 flex items-baseline gap-2">
                <AnimatedNumber value={simulation.simulatedCX} />
                <span className="text-sm font-sans text-slate-400">/ 100</span>
              </div>

              <div className="mt-2 flex items-center gap-2">
                <span
                  className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full ${
                    simulation.cxDelta >= 0 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                  }`}
                >
                  {simulation.cxDelta >= 0 ? `+${simulation.cxDelta} pts lift` : `${simulation.cxDelta} pts drop`}
                </span>
                <span className="text-xs text-slate-400">vs Current Baseline</span>
              </div>
            </div>

            <div className="space-y-3 pt-6 border-t border-white/10 mt-6 text-xs font-medium">
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Projected Leaderboard Rank:</span>
                <span className="font-mono text-sm font-extrabold text-amber-400">
                  #{simulation.projectedRank}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-300">Days to Level 5 Champion:</span>
                <span className="font-mono font-bold text-teal-300">
                  {simulation.daysToNextLevel === 0 ? 'Reached! 🏆' : `~${simulation.daysToNextLevel} days`}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-300">Estimated Store Revenue Lift:</span>
                <span className="font-mono font-bold text-emerald-400">
                  +{simulation.storeRevenueLiftPct}%
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-300">Total Unlocked Badges:</span>
                <span className="font-mono font-bold text-purple-300">
                  {simulation.unlockedBadgesCount} / 8 Badges
                </span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 text-xs text-amber-950 font-medium space-y-1">
            <div className="font-bold flex items-center gap-1">
              <Sparkles size={13} className="text-amber-700" /> Key Recommendation Insight:
            </div>
            <p>
              Raising POS adoption to <strong>85%+</strong> yields the highest mathematical sensitivity (+2.8 CX lift per hour) across your store floor.
            </p>
          </div>
        </div>
      </div>

      {/* Glassbox Feature Attribution Matrix (SHAP / LIME-style) */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
        <SectionHeader
          title="Glassbox AI Mathematical Attribution Matrix"
          subtitle="Transparent breakdown of feature weights and contribution vectors behind every recommendation"
        />

        <div className="overflow-x-auto mt-2">
          <table className="w-full text-left text-xs sm:text-sm" style={{ minWidth: 640 }}>
            <thead>
              <tr className="border-b bg-slate-50/70" style={{ borderColor: COLORS.line }}>
                <th className="px-5 py-3 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Feature Name
                </th>
                <th className="px-4 py-3 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Model Weight
                </th>
                <th className="px-4 py-3 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Current Value
                </th>
                <th className="px-4 py-3 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Contribution
                </th>
                <th className="px-5 py-3 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Mathematical Explanation
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {attributions.map((attr) => (
                <tr key={attr.feature} className="hover:bg-slate-50/60 transition-colors">
                  <td className="px-5 py-3.5 font-bold text-slate-900">{attr.feature}</td>
                  <td className="px-4 py-3.5 font-mono font-bold text-teal-700">{attr.weightPct}%</td>
                  <td className="px-4 py-3.5 font-mono font-semibold text-slate-800">{attr.currentValue}</td>
                  <td className="px-4 py-3.5">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        attr.impactDirection === 'positive'
                          ? 'bg-emerald-50 text-emerald-700'
                          : attr.impactDirection === 'negative'
                          ? 'bg-red-50 text-red-700'
                          : 'bg-amber-50 text-amber-700'
                      }`}
                    >
                      {attr.impactDirection.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-xs text-slate-500 font-medium leading-relaxed">
                    {attr.explanation}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
