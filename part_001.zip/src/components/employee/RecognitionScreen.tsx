'use client';

import React, { useState } from 'react';
import {
  Heart,
  Plus,
  ThumbsUp,
  Sparkles,
  Send,
  MessageSquare,
  Award,
  Filter,
  Wand2,
  Users,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Avatar } from '../common/Avatar';
import { Pill } from '../common/Pill';
import { Recognition } from '../../types';
import { COLORS, RECOGNITION_CATEGORIES } from '../../lib/constants';
import { getEmployeeName, getStoreName } from '../../lib/cxCalculator';
import { api } from '../../lib/api';

interface RecognitionScreenProps {
  currentRoleOverride?: string;
  allowedRecipientList?: { id: string; name: string; storeId: string }[];
}

export function RecognitionScreen({ currentRoleOverride, allowedRecipientList }: RecognitionScreenProps) {
  const {
    employees,
    stores,
    recognitions,
    currentEmployeeId,
    currentManagerId,
    admin,
    role,
    giveRecognition,
    likeRecognition,
    showToast,
    fireCelebration,
  } = useAppStore();

  const [showForm, setShowForm] = useState(false);
  const [toId, setToId] = useState('');
  const [category, setCategory] = useState<Recognition['category']>('Teamwork');
  const [message, setMessage] = useState('');
  const [isPolishing, setIsPolishing] = useState(false);

  const activeUserId =
    role === 'employee' ? currentEmployeeId : role === 'manager' ? currentManagerId : admin.id;

  const activeUser = employees.find((e) => e.id === activeUserId);
  const recipientOptions = allowedRecipientList || employees;

  const handlePolishKudos = async () => {
    if (!message.trim()) {
      setMessage('helped me with POS split billing and inventory lookup during evening peak rush');
    }
    setIsPolishing(true);
    const targetEmp = employees.find((e) => e.id === toId);
    const receiverName = targetEmp ? targetEmp.name : 'Teammate';
    const senderName = activeUser ? activeUser.name : 'Colleague';

    const res = await api.polishKudos(
      message || 'helped me with POS split billing during evening peak rush',
      receiverName,
      senderName
    );
    setIsPolishing(false);

    if (res && res.polished_message) {
      setMessage(res.polished_message);
      showToast(`✨ AI polished your appreciation note! Recommended Tag: ${res.recommended_badge}`);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!toId || !message.trim()) return;

    // Call Python FastAPI Backend with fallback
    api.sendRecognition({
      sender_id: activeUserId,
      receiver_id: toId,
      message: message.trim(),
      badge_tagged: category === 'Teamwork' ? 'team-player' : 'customer-champion',
    });

    giveRecognition(activeUserId, toId, category, message.trim());
    
    const receiverEmp = employees.find((e) => e.id === toId);
    fireCelebration({
      emoji: '🤝',
      eyebrow: 'Peer Recognition Published!',
      title: `Appreciation Sent to ${receiverEmp?.name || 'Teammate'}`,
      sub: '+20 Team Player Points Awarded',
    });

    setShowForm(false);
    setToId('');
    setMessage('');
    setCategory('Teamwork');
  };

  const getCategoryMeta = (cat: string) => {
    const found = RECOGNITION_CATEGORIES.find((c) => c.name === cat);
    return found || { name: cat, icon: '🌟', color: COLORS.teal };
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
              Peer Recognition &amp; Wall of Fame
            </h2>
            <Pill label="Employee ↔ Employee" variant="green" />
          </div>
          <p className="text-sm text-slate-500 mt-0.5">
            Recognition comes from colleagues as well as managers. Every recognition awards <strong>+20 XP</strong> and <strong>Team Player badges</strong>.
          </p>
        </div>

        <button
          onClick={() => setShowForm(!showForm)}
          className="px-5 py-2.5 rounded-xl font-bold text-xs text-white shadow-md flex items-center gap-2 transition-all hover:opacity-90 active:scale-95"
          style={{ backgroundColor: COLORS.navy }}
        >
          <Plus size={16} />
          <span>{showForm ? 'Close Form' : 'Give Peer Recognition'}</span>
        </button>
      </div>

      {/* Give Recognition Form Modal / Card */}
      {showForm && (
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-3xl p-6 sm:p-8 border shadow-lg space-y-5 animate-in fade-in slide-in-from-top-4 duration-200"
          style={{ borderColor: COLORS.line }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-purple-700">
              <Sparkles size={15} /> Send an Appreciation Shoutout (+20 XP for Receiver)
            </div>
            <button
              type="button"
              onClick={handlePolishKudos}
              disabled={isPolishing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-xs font-bold transition-all shadow-xs"
            >
              <Wand2 size={13} />
              <span>{isPolishing ? 'Polishing...' : '✨ AI Polish Kudos'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Colleague Select */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1.5">
                Select Colleague to Recognize
              </label>
              <select
                value={toId}
                onChange={(e) => setToId(e.target.value)}
                required
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs font-semibold bg-slate-50 text-slate-900 border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
              >
                <option value="">Choose an associate…</option>
                {recipientOptions
                  .filter((e) => e.id !== activeUserId)
                  .map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} · {getStoreName(stores, emp.storeId)}
                    </option>
                  ))}
              </select>
            </div>

            {/* Category Select */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1.5">
                Core Recognition Pillar
              </label>
              <div className="flex flex-wrap gap-1.5">
                {RECOGNITION_CATEGORIES.map((cat) => {
                  const isSelected = category === cat.name;
                  return (
                    <button
                      key={cat.name}
                      type="button"
                      onClick={() => setCategory(cat.name as Recognition['category'])}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all border flex items-center gap-1 ${
                        isSelected
                          ? 'border-purple-600 bg-purple-50 text-purple-700 shadow-xs'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <span>{cat.icon}</span>
                      <span>{cat.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Message Textarea */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">
                Appreciation Note &amp; Story
              </label>
              <button
                type="button"
                onClick={() => setMessage('Thanks for helping me understand the new POS billing process during the evening rush!')}
                className="text-[11px] text-indigo-600 hover:underline font-semibold"
              >
                Insert Example (Priya → Rahul POS Help)
              </button>
            </div>
            <textarea
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
              placeholder="Type your appreciation or rough bullet notes, then click 'AI Polish Kudos'..."
              className="w-full border rounded-2xl p-3.5 text-xs text-slate-900 border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-purple-500/20 resize-none"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl font-bold text-xs text-white shadow-md flex items-center gap-2 transition-all hover:opacity-90"
              style={{ backgroundColor: COLORS.coral }}
            >
              <Send size={14} />
              <span>Publish Recognition (+20 XP)</span>
            </button>
          </div>
        </form>
      )}

      {/* Recognition Feed Cards */}
      <div className="space-y-4">
        {recognitions.map((rec) => {
          const fromName = getEmployeeName(employees, rec.fromId);
          const toName = getEmployeeName(employees, rec.toId);
          const catMeta = getCategoryMeta(rec.category);

          return (
            <div
              key={rec.id}
              className="bg-white rounded-3xl p-6 border shadow-xs transition-all hover:shadow-md flex flex-col sm:flex-row items-start gap-4"
              style={{ borderColor: COLORS.line }}
            >
              <Avatar name={fromName} color={COLORS.navy3} size={44} />

              <div className="flex-1 min-w-0">
                {/* Header author line */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-sm text-slate-800">
                    <span className="font-bold text-slate-900">{fromName}</span>
                    <span className="text-slate-500"> recognized </span>
                    <span className="font-bold text-slate-900">{toName}</span>
                  </div>

                  <span className="text-[11px] font-mono text-slate-400">{rec.time}</span>
                </div>

                {/* Category Pill */}
                <div className="mt-1.5 flex items-center gap-2">
                  <Pill color={catMeta.color}>
                    <span className="mr-1">{catMeta.icon}</span>
                    {rec.category}
                  </Pill>
                  <Pill label="+20 XP Granted" variant="gold" />
                </div>

                {/* Message Body */}
                <p className="text-xs sm:text-sm text-slate-700 mt-3 leading-relaxed font-medium bg-slate-50/70 p-3.5 rounded-2xl border border-slate-100">
                  &ldquo;{rec.message}&rdquo;
                </p>

                {/* Like / Clap Interaction */}
                <div className="flex items-center gap-4 mt-3 pt-2">
                  <button
                    onClick={() => likeRecognition(rec.id)}
                    className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full border border-slate-200 bg-white hover:bg-rose-50 hover:border-rose-200 hover:text-rose-600 transition-all text-slate-600 shadow-xs"
                  >
                    <Heart size={14} className="text-rose-500 fill-rose-500/20" />
                    <span>{rec.likes} Claps</span>
                  </button>

                  <span className="text-[11px] text-slate-400">
                    🤝 Employee ↔ Employee Recognition Loop
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
