'use client';

import React from 'react';
import {
  Zap,
  Star,
  TrendingUp,
  Heart,
  Award,
  GraduationCap,
  Calendar,
  Building2,
  Mail,
  ShieldCheck,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { Avatar } from '../common/Avatar';
import { Pill } from '../common/Pill';
import { StatCard } from '../common/StatCard';
import { SectionHeader } from '../common/SectionHeader';
import { COLORS } from '../../lib/constants';
import { getLevelInfo, getStoreName, getEmployeeName, trainingPct } from '../../lib/cxCalculator';

export function ProfileScreen() {
  const { currentEmployee, stores, employees, recognitions, trainingModules } = useAppStore();
  const info = getLevelInfo(currentEmployee.points);

  const receivedRecognitions = recognitions.filter((r) => r.toId === currentEmployee.id);

  return (
    <div className="space-y-6 pb-12">
      {/* Bio Header Card */}
      <div
        className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs flex flex-col sm:flex-row items-center sm:items-start gap-6 text-center sm:text-left"
        style={{ borderColor: COLORS.line }}
      >
        <Avatar name={currentEmployee.name} color={currentEmployee.color} size={84} />

        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
            <h2 className="text-2xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
              {currentEmployee.name}
            </h2>
            <Pill color={COLORS.amberDeep}>Level {info.level} · {info.name}</Pill>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              Active Associate
            </span>
          </div>

          <div className="text-sm text-slate-500 font-medium mt-1">
            Store Associate · {getStoreName(stores, currentEmployee.storeId)}
          </div>

          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs text-slate-500 mt-3 pt-3 border-t border-slate-100 font-medium">
            <span className="flex items-center gap-1.5">
              <Mail size={13} /> {currentEmployee.email}
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar size={13} /> Joined {currentEmployee.joinDate || 'Jan 2025'}
            </span>
            <span className="flex items-center gap-1.5">
              <Building2 size={13} /> Store Code: {currentEmployee.storeId.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      {/* 4 Performance Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Zap}
          label="Digital POS Adoption"
          value={`${currentEmployee.posAdoption}%`}
          sub="Store Target: 75%"
          accent={COLORS.teal}
        />
        <StatCard
          icon={Star}
          label="Customer CSAT Score"
          value={`${currentEmployee.customerFeedbackScore}%`}
          sub="91% 5-Star ratings"
          accent={COLORS.amber}
        />
        <StatCard
          icon={TrendingUp}
          label="Sales Conversion"
          value={`${currentEmployee.salesConversion}%`}
          sub="+8% vs store peer avg"
          accent={COLORS.coral}
        />
        <StatCard
          icon={Heart}
          label="Team Engagement"
          value={`${currentEmployee.engagementScore}%`}
          sub="High morale indicator"
          accent={COLORS.plum}
        />
      </div>

      {/* Received Peer Recognition History */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
        <SectionHeader
          title={`Recognition History Received (${receivedRecognitions.length})`}
          subtitle="Direct praise and shoutouts logged from store peers and regional managers"
        />

        <div className="space-y-3">
          {receivedRecognitions.length > 0 ? (
            receivedRecognitions.map((r) => (
              <div
                key={r.id}
                className="rounded-2xl p-4 border bg-slate-50/70 border-slate-100 flex flex-col sm:flex-row items-start justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="text-slate-500">From</span>
                    <span>{getEmployeeName(employees, r.fromId)}</span>
                    <span className="text-slate-400">•</span>
                    <Pill color={COLORS.plum}>{r.category}</Pill>
                  </div>
                  <p className="text-xs text-slate-700 font-medium leading-relaxed">&ldquo;{r.message}&rdquo;</p>
                </div>
                <div className="text-[11px] font-mono text-slate-400 shrink-0">{r.time}</div>
              </div>
            ))
          ) : (
            <div className="text-xs text-slate-500 py-6 text-center">
              No peer recognition received yet. Keep doing great work on the store floor!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
