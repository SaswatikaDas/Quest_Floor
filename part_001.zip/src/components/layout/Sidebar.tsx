'use client';

import React from 'react';
import {
  Home,
  BookOpen,
  Zap,
  MessageSquare,
  Heart,
  Trophy,
  Gift,
  AlertTriangle,
  Users,
  Store as StoreIcon,
  Brain,
  Building2,
  BarChart3,
  RotateCcw,
  Sparkles,
  LogOut,
  Languages,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { COLORS } from '../../lib/constants';

interface NavItem {
  id: string;
  labelKey: string;
  defaultLabel: string;
  icon: React.ElementType;
}

const STREAMLINED_NAV_CONFIG: Record<string, NavItem[]> = {
  employee: [
    { id: 'dashboard', labelKey: 'dashboard', defaultLabel: 'Dashboard', icon: Home },
    { id: 'learning', labelKey: 'learning', defaultLabel: 'Learning & Quizzes', icon: BookOpen },
    { id: 'posSandbox', labelKey: 'posSandbox', defaultLabel: 'POS Speed Terminal', icon: Zap },
    { id: 'roleplayArena', labelKey: 'roleplayArena', defaultLabel: 'AI Customer Roleplay', icon: MessageSquare },
    { id: 'recognition', labelKey: 'recognition', defaultLabel: 'Peer Recognition', icon: Heart },
    { id: 'leaderboard', labelKey: 'leaderboard', defaultLabel: 'Leaderboard & Badges', icon: Trophy },
    { id: 'rewards', labelKey: 'rewards', defaultLabel: 'Rewards Marketplace', icon: Gift },
  ],
  manager: [
    { id: 'dashboard', labelKey: 'dashboard', defaultLabel: 'Store Dashboard', icon: Home },
    { id: 'actionCenter', labelKey: 'actionCenter', defaultLabel: 'Manager Action Center', icon: AlertTriangle },
    { id: 'employees', labelKey: 'employees', defaultLabel: 'Team Directory', icon: Users },
    { id: 'storeAnalytics', labelKey: 'storeAnalytics', defaultLabel: 'Store Analytics', icon: StoreIcon },
    { id: 'recognition', labelKey: 'recognition', defaultLabel: 'Team Recognition', icon: Heart },
  ],
  admin: [
    { id: 'dashboard', labelKey: 'dashboard', defaultLabel: 'Executive Dashboard', icon: Home },
    { id: 'aiStudio', labelKey: 'aiStudio', defaultLabel: 'Generative AI Studio', icon: Brain },
    { id: 'employees', labelKey: 'employees', defaultLabel: 'Associate Directory', icon: Users },
    { id: 'stores', labelKey: 'stores', defaultLabel: 'Store Network', icon: Building2 },
    { id: 'analytics', labelKey: 'analytics', defaultLabel: 'Chain Analytics', icon: BarChart3 },
  ],
};

export function Sidebar() {
  const {
    role,
    screen,
    setScreen,
    mobileOpen,
    setMobileOpen,
    handleLogout,
    resetDemoData,
    theme,
    t,
  } = useAppStore();

  if (!role) return null;

  const items = STREAMLINED_NAV_CONFIG[role] || [];
  const isDark = theme === 'dark';

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-xs transition-opacity"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Main Streamlined Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 h-screen z-50 w-64 shrink-0 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 border-r ${
          mobileOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        } ${
          isDark
            ? 'bg-slate-950 text-slate-100 border-slate-800'
            : 'bg-slate-900 text-white border-slate-800'
        }`}
      >
        {/* Brand Header */}
        <div className="px-6 py-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 via-purple-500 to-indigo-600 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/25">
              <Sparkles size={20} />
            </div>
            <div>
              <div className="font-extrabold text-base tracking-tight leading-none text-white">
                Quest<span className="text-amber-400">Floor</span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono font-medium mt-1">
                Autonomous HCM
              </div>
            </div>
          </div>
        </div>

        {/* Streamlined Menu Section */}
        <div className="px-4 py-3">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-2">
            {role === 'employee' ? 'Store Associate Menu' : role === 'manager' ? 'Store Manager Menu' : 'Admin Hub'}
          </div>
        </div>

        {/* Navigation Item List */}
        <nav className="flex-1 px-3 space-y-1.5 overflow-y-auto">
          {items.map((item) => {
            const Icon = item.icon;
            const active = screen === item.id;
            const localizedLabel = t(item.labelKey) || item.defaultLabel;

            return (
              <button
                key={item.id}
                onClick={() => {
                  setScreen(item.id);
                  setMobileOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                  active
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md shadow-amber-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Icon size={18} className={active ? 'text-white' : 'text-slate-400'} />
                <span className="truncate">{localizedLabel}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer Actions */}
        <div className="p-4 border-t border-white/10 space-y-2">
          <button
            onClick={() => resetDemoData()}
            className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-[11px] font-bold text-slate-400 hover:text-white hover:bg-white/10 transition-all"
          >
            <RotateCcw size={13} />
            <span>Reset Demo Data</span>
          </button>

          <button
            onClick={() => handleLogout()}
            className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/40 transition-all"
          >
            <LogOut size={14} />
            <span>Switch Role / Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}
