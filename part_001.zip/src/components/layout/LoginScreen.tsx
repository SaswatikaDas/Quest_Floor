'use client';

import React, { useState } from 'react';
import {
  User,
  Users,
  Building2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  Lock,
  Mail,
  Eye,
  EyeOff,
  UserPlus,
  KeyRound,
  Store as StoreIcon,
  CheckCircle2,
  Clock,
  AlertCircle,
  X,
} from 'lucide-react';
import { Role } from '../../types';
import { COLORS } from '../../lib/constants';
import { useAppStore } from '../../lib/store/useAppStore';
import { api } from '../../lib/api';

export function LoginScreen() {
  const {
    handleLogin,
    stores,
    showToast,
    pendingRegistrations,
    registerPendingEmployee,
    setRole,
  } = useAppStore();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [selectedRole, setSelectedRole] = useState<Role>('employee');
  const [emailOrUser, setEmailOrUser] = useState('amit@retailrise.com');
  const [password, setPassword] = useState('pass123');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Pending Approval Modal State
  const [pendingModalData, setPendingModalData] = useState<{
    name: string;
    email: string;
    storeName: string;
  } | null>(null);

  // Registration Form State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regRole, setRegRole] = useState<Role>('employee');
  const [regStoreId, setRegStoreId] = useState('s1');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');

  // Quick Demo Auto-fill Credentials
  const handleSelectDemoPersona = (role: Role, email: string, pass: string) => {
    setSelectedRole(role);
    setEmailOrUser(email);
    setPassword(pass);
    setErrorMessage('');
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!emailOrUser.trim() || !password.trim()) {
      setErrorMessage('Please enter both username/email and password.');
      return;
    }

    // Check if this account is pending approval
    const isPending = pendingRegistrations.find(
      (p) => p.email.toLowerCase() === emailOrUser.toLowerCase().trim()
    );

    if (isPending) {
      const storeObj = stores.find((s) => s.id === isPending.storeId);
      setPendingModalData({
        name: isPending.name,
        email: isPending.email,
        storeName: storeObj ? `${storeObj.name} (${storeObj.city})` : 'Store #104 Nagpur Hub',
      });
      return;
    }

    setIsLoading(true);
    const res = await api.login({
      email_or_username: emailOrUser,
      password: password,
      role: selectedRole,
    });

    setIsLoading(false);

    if (res && res.status === 'pending_approval') {
      setPendingModalData({
        name: res.user?.name || emailOrUser,
        email: emailOrUser,
        storeName: `Store #${res.user?.store_id || '104'}`,
      });
      return;
    }

    handleLogin(selectedRole);
    showToast(`Welcome to QuestFloor, ${emailOrUser.split('@')[0]}!`);
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!regName.trim() || !regEmail.trim() || !regPassword.trim()) {
      setErrorMessage('Please fill in all required registration fields.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    setIsLoading(true);

    await registerPendingEmployee({
      name: regName,
      email: regEmail,
      role: regRole,
      storeId: regStoreId,
      password: regPassword,
    });

    setIsLoading(false);

    const storeObj = stores.find((s) => s.id === regStoreId);
    setPendingModalData({
      name: regName,
      email: regEmail,
      storeName: storeObj ? `${storeObj.name} (${storeObj.city})` : 'Store #104 Nagpur Hub',
    });

    // Reset inputs
    setRegName('');
    setRegEmail('');
    setRegPassword('');
    setRegConfirmPassword('');
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 lg:p-8 relative overflow-hidden bg-slate-950">
      {/* Background ambient lighting */}
      <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full blur-3xl opacity-20 pointer-events-none bg-amber-500" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full blur-3xl opacity-20 pointer-events-none bg-indigo-600" />

      {/* ── 🌟 PENDING APPROVAL NOTIFICATION MODAL ───────────────────────── */}
      {pendingModalData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full text-white shadow-2xl space-y-6 relative overflow-hidden">
            {/* Ambient backlight glow */}
            <div className="absolute -top-16 -right-16 w-40 h-40 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                <Clock size={16} className="animate-spin text-amber-400" />
                <span>Verification Request Pending</span>
              </div>
              <button
                onClick={() => setPendingModalData(null)}
                className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
              >
                <X size={16} />
              </button>
            </div>

            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-3xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-amber-500/10">
                📋
              </div>

              <h3 className="text-xl font-extrabold text-white">
                Registration Request Sent to Store Manager!
              </h3>

              <p className="text-xs text-slate-300 leading-relaxed">
                Dear <strong>{pendingModalData.name}</strong>, your employee registration for <strong>{pendingModalData.storeName}</strong> has been submitted.
              </p>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-left space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Account Status:</span>
                  <span className="font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                    Awaiting Manager Verification
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Store Manager:</span>
                  <span className="font-bold text-white">Priya Patel (Store #104)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Registered Email:</span>
                  <span className="font-mono text-slate-300">{pendingModalData.email}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Onboarding Bonus:</span>
                  <span className="font-bold text-emerald-400">+100 XP (Pending Activation)</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 italic">
                💡 You will be able to log in immediately once the Store Manager accepts your verification in their Action Center.
              </p>
            </div>

            {/* Quick Demo Action: Switch to Manager View to Approve */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => {
                  setPendingModalData(null);
                  handleLogin('manager');
                  showToast('Switched to Store Manager View (Priya Patel) to review pending requests.', '👨‍💼');
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white font-extrabold text-xs shadow-lg shadow-teal-500/20 flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <span>Switch to Store Manager View to Approve This Staff →</span>
              </button>

              <button
                onClick={() => setPendingModalData(null)}
                className="w-full py-2 text-xs text-slate-400 hover:text-white"
              >
                Close & Return to Login
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="w-full max-w-4xl relative z-10 py-6">
        {/* Header Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-3 border border-amber-400/30 bg-amber-500/10">
            <Sparkles size={15} className="text-amber-400" />
            <span className="text-xs font-bold tracking-wider uppercase text-amber-400">
              1,200 Stores · 3,000 Associates · Tier-3 Town Cluster
            </span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Quest<span className="text-amber-400">Floor</span>
          </h1>
          <p className="text-xs sm:text-sm mt-2 max-w-xl mx-auto text-slate-300">
            Autonomous HCM, micro-learning simulations, digital POS speed billing, and customer experience standardizer.
          </p>
        </div>

        {/* Main Auth Box */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
          {/* Mode Switcher Tabs */}
          <div className="flex rounded-2xl bg-slate-950/80 p-1.5 border border-slate-800 mb-6 max-w-md mx-auto">
            <button
              onClick={() => {
                setMode('login');
                setErrorMessage('');
              }}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-extrabold transition-all ${
                mode === 'login'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <KeyRound size={15} />
              <span>Sign In (Login)</span>
            </button>

            <button
              onClick={() => {
                setMode('register');
                setErrorMessage('');
              }}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-extrabold transition-all ${
                mode === 'register'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserPlus size={15} />
              <span>Register New Staff</span>
            </button>
          </div>

          {errorMessage && (
            <div className="mb-5 p-3 rounded-xl bg-rose-950/50 border border-rose-800/60 text-rose-300 text-xs font-semibold text-center animate-in fade-in">
              ⚠️ {errorMessage}
            </div>
          )}

          {/* ===================== MODE 1: LOGIN ===================== */}
          {mode === 'login' && (
            <div className="space-y-6">
              {/* Role Selection Segment */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-2 text-center">
                  Select Role to Enter:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => handleSelectDemoPersona('employee', 'amit@retailrise.com', 'pass123')}
                    className={`p-3.5 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                      selectedRole === 'employee'
                        ? 'border-amber-500 bg-amber-500/15 text-white shadow-md shadow-amber-500/10'
                        : 'border-slate-800 bg-slate-950/50 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                      <User size={20} />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Store Associate</div>
                      <div className="text-[10px] text-slate-400">Amit Kumar • 1,500 XP</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSelectDemoPersona('manager', 'priya@retailrise.com', 'manager123')}
                    className={`p-3.5 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                      selectedRole === 'manager'
                        ? 'border-teal-500 bg-teal-500/15 text-white shadow-md shadow-teal-500/10'
                        : 'border-slate-800 bg-slate-950/50 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
                      <Users size={20} />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Store Manager</div>
                      <div className="text-[10px] text-slate-400">Priya Patel • Store #104</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSelectDemoPersona('admin', 'admin@retailrise.com', 'admin123')}
                    className={`p-3.5 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                      selectedRole === 'admin'
                        ? 'border-purple-500 bg-purple-500/15 text-white shadow-md shadow-purple-500/10'
                        : 'border-slate-800 bg-slate-950/50 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
                      <Building2 size={20} />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Regional Admin</div>
                      <div className="text-[10px] text-slate-400">Neha Kapoor • 1,200 Stores</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Login Form */}
              <form onSubmit={handleLoginSubmit} className="space-y-4 max-w-md mx-auto">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Username / Email / Staff ID
                  </label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-3.5 text-slate-500" />
                    <input
                      type="text"
                      value={emailOrUser}
                      onChange={(e) => setEmailOrUser(e.target.value)}
                      placeholder="e.g. amit@retailrise.com"
                      required
                      className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-3.5 text-slate-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded accent-amber-500" />
                    <span>Remember this device</span>
                  </label>
                  <span className="text-amber-400 text-[11px] font-mono">Shift Active</span>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-sm shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-60"
                >
                  <span>{isLoading ? 'Verifying...' : 'Sign In & Enter Dashboard'}</span>
                  <ArrowRight size={16} />
                </button>
              </form>
            </div>
          )}

          {/* ===================== MODE 2: REGISTRATION ===================== */}
          {mode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4 max-w-lg mx-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="e.g. Rohan Sharma"
                    required
                    className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-400 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Staff Email / User ID
                  </label>
                  <input
                    type="email"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="rohan@retailrise.com"
                    required
                    className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-400 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Assigned Role
                  </label>
                  <select
                    value={regRole}
                    onChange={(e) => setRegRole(e.target.value as Role)}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-400 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
                  >
                    <option value="employee">Store Associate</option>
                    <option value="manager">Store Manager</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Store Location / Cluster
                  </label>
                  <select
                    value={regStoreId}
                    onChange={(e) => setRegStoreId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-400 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
                  >
                    {stores.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.city})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-400 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-400 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-800/40 text-amber-300 text-xs flex items-center gap-2.5">
                <Clock size={18} className="text-amber-400 shrink-0" />
                <span>
                  <strong>Manager Verification Required:</strong> Your registration will be sent to the Store Manager for approval before account activation.
                </span>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-extrabold text-sm shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-60"
              >
                <span>{isLoading ? 'Submitting Registration...' : 'Submit Registration to Store Manager'}</span>
                <ArrowRight size={16} />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
