'use client';

import React, { useState } from 'react';
import {
  Menu,
  Bell,
  Search,
  Languages,
  Sun,
  Moon,
  ChevronDown,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { Avatar } from '../common/Avatar';
import { Pill } from '../common/Pill';
import { COLORS, ROLE_LABEL } from '../../lib/constants';
import { LANGUAGES, LanguageCode } from '../../lib/translations';

export function Topbar() {
  const {
    role,
    screen,
    setScreen,
    setMobileOpen,
    notifications,
    currentEmployee,
    currentManager,
    admin,
    currentEmployeeId,
    currentManagerId,
    setIsStoryModalOpen,
    language,
    setLanguage,
    theme,
    toggleTheme,
    t,
  } = useAppStore();

  const [langMenuOpen, setLangMenuOpen] = useState(false);

  if (!role) return null;

  const currentRecipientId = role === 'employee' ? currentEmployeeId : role === 'manager' ? currentManagerId : admin.id;
  const unreadCount = notifications.filter(
    (n) => (n.recipientId === currentRecipientId || n.recipientId === 'all') && !n.read
  ).length;

  const user =
    role === 'employee'
      ? { name: currentEmployee.name, title: t('associateRole') || 'Store Associate', color: currentEmployee.color }
      : role === 'manager'
      ? { name: currentManager.name, title: t('managerRole') || 'Senior Store Manager', color: COLORS.teal }
      : { name: admin.name, title: t('adminRole') || admin.title, color: COLORS.plum };

  const pageTitle = t(screen) || screen;
  const isDark = theme === 'dark';
  const activeLangMeta = LANGUAGES.find((l) => l.code === language) || LANGUAGES[0];

  return (
    <header
      className={`sticky top-0 z-30 flex items-center justify-between gap-3 px-4 sm:px-6 lg:px-8 py-3.5 backdrop-blur-md border-b transition-colors duration-200 ${
        isDark
          ? 'bg-slate-950/90 border-slate-800 text-white'
          : 'bg-white/90 border-slate-200 text-slate-900'
      }`}
    >
      {/* Left section: Mobile menu + Page Title */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={() => setMobileOpen(true)}
          className={`lg:hidden p-2 -ml-2 rounded-xl transition-colors ${
            isDark ? 'text-slate-200 hover:bg-slate-800' : 'text-slate-700 hover:bg-slate-100'
          }`}
          aria-label="Open mobile navigation"
        >
          <Menu size={22} />
        </button>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-base sm:text-lg font-extrabold truncate">
              {pageTitle}
            </h1>
            <Pill color={role === 'employee' ? COLORS.amberDeep : role === 'manager' ? COLORS.teal : COLORS.plum}>
              {ROLE_LABEL[role]}
            </Pill>
          </div>
        </div>
      </div>

      {/* Right section: Language + Theme Toggle + Pitch Button + Notifications + Profile */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Language Selector Dropdown */}
        <div className="relative">
          <button
            onClick={() => setLangMenuOpen(!langMenuOpen)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
              isDark
                ? 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span className="text-sm">{activeLangMeta.flag}</span>
            <span className="hidden sm:inline font-mono">{activeLangMeta.nativeLabel}</span>
            <ChevronDown size={13} className="text-slate-400" />
          </button>

          {langMenuOpen && (
            <div
              className={`absolute right-0 top-full mt-1.5 w-60 max-h-96 overflow-y-auto rounded-2xl shadow-2xl border py-2 z-50 animate-in fade-in slide-in-from-top-2 ${
                isDark
                  ? 'bg-slate-900 border-slate-700 text-slate-100 divide-slate-800'
                  : 'bg-white border-slate-200 text-slate-800 divide-slate-100'
              }`}
            >
              <div className="px-3.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                12 Regional Languages Available
              </div>
              {LANGUAGES.map((l) => (
                <button
                  key={l.code}
                  onClick={() => {
                    setLanguage(l.code);
                    setLangMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-semibold transition-colors text-left ${
                    language === l.code
                      ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 font-bold'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800/80'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-base">{l.flag}</span>
                    <div>
                      <div className="font-bold leading-tight">{l.nativeLabel}</div>
                      <div className="text-[10px] text-slate-400 leading-tight">{l.region}</div>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400 uppercase font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                    {l.code}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Light / Dark Mode Toggle */}
        <button
          onClick={toggleTheme}
          title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-all ${
            isDark
              ? 'bg-slate-900 border-slate-700 text-amber-400 hover:bg-slate-800'
              : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          {isDark ? <Sun size={17} /> : <Moon size={17} />}
        </button>

        {/* 1-Min Pitch & Story Mode Button */}
        <button
          onClick={() => setIsStoryModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-600 hover:to-indigo-700 text-white text-xs font-bold shadow-md shadow-amber-500/20 transition-all active:scale-95"
        >
          <span className="text-sm">🎤</span>
          <span className="hidden sm:inline font-sans">{t('pitchBtn')}</span>
        </button>

        {/* Live Network Status Indicator */}
        <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-semibold">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>1,200 Stores Connected</span>
        </div>

        {/* Notifications Bell */}
        <button
          onClick={() => setScreen('notifications')}
          className={`relative w-9 h-9 rounded-xl border flex items-center justify-center transition-all ${
            isDark
              ? 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
          aria-label="Notifications"
        >
          <Bell size={16} />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
              {unreadCount}
            </span>
          )}
        </button>

        {/* User Profile Pill */}
        <div
          onClick={() => setScreen('profile')}
          className={`flex items-center gap-2 pl-1.5 pr-3 py-1 rounded-2xl border transition-all cursor-pointer ${
            isDark
              ? 'bg-slate-900 border-slate-800 hover:border-slate-700'
              : 'bg-slate-50 border-slate-200 hover:border-slate-300'
          }`}
        >
          <Avatar name={user.name} color={user.color} size={30} />
          <div className="hidden md:block text-left">
            <div className="text-xs font-bold leading-tight truncate max-w-[120px]">
              {user.name}
            </div>
            <div className="text-[10px] text-slate-400 leading-tight truncate max-w-[120px]">
              {user.title}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
