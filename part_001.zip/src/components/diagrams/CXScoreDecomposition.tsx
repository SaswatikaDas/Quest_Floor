'use client';

import React from 'react';
import { CXBreakdown } from '../../types';
import { COLORS } from '../../lib/constants';
import { ProgressBar } from '../common/ProgressBar';

interface CXScoreDecompositionProps {
  cx: CXBreakdown;
  className?: string;
}

export function CXScoreDecomposition({ cx, className = '' }: CXScoreDecompositionProps) {
  const components = [
    { label: 'Product Training Completion', weight: '20%', value: cx.trainingAvg, color: COLORS.teal },
    { label: 'Digital POS Adoption', weight: '25%', value: cx.posAvg, color: COLORS.amberDeep },
    { label: 'Customer CSAT Feedback', weight: '25%', value: cx.feedbackAvg, color: COLORS.coral },
    { label: 'Sales & Upsell Conversion', weight: '15%', value: cx.salesAvg, color: COLORS.plum },
    { label: 'Associate Morale & Engagement', weight: '15%', value: cx.engagementAvg, color: COLORS.navy3 },
  ];

  return (
    <div className={`rounded-2xl p-6 bg-white border ${className}`} style={{ borderColor: COLORS.line }}>
      <div className="flex items-center justify-between mb-5 flex-wrap gap-2">
        <div>
          <h3 className="font-bold text-base" style={{ color: COLORS.ink }}>
            Customer Experience (CX) Index Decomposition
          </h3>
          <p className="text-xs mt-0.5" style={{ color: COLORS.muted }}>
            Weighted blend across 5 core operational pillars
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full" style={{ backgroundColor: `${cx.color}18`, color: cx.color }}>
            {cx.label} ({cx.score}/100)
          </span>
        </div>
      </div>

      <div className="space-y-4">
        {components.map((c) => (
          <div key={c.label}>
            <div className="flex items-center justify-between text-xs font-semibold mb-1">
              <span className="flex items-center gap-2" style={{ color: COLORS.ink }}>
                {c.label}
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 font-mono text-slate-600">
                  wt: {c.weight}
                </span>
              </span>
              <span className="font-mono text-xs" style={{ color: c.color }}>
                {c.value}%
              </span>
            </div>
            <ProgressBar pct={c.value} color={c.color} height={7} />
          </div>
        ))}
      </div>
    </div>
  );
}
