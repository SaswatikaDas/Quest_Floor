'use client';

import React from 'react';
import { Employee, TrainingModule } from '../../types';
import { COLORS } from '../../lib/constants';
import { computeSkillScores, primarySkillGap } from '../../lib/aiEngine';

interface SkillGraphDiagramProps {
  employee: Employee;
  modules: TrainingModule[];
}

export function SkillGraphDiagram({ employee, modules }: SkillGraphDiagramProps) {
  const scores = computeSkillScores(employee, modules);
  const gap = primarySkillGap(employee, modules);

  const nodeColor = (s: typeof scores[0]) => (s.skill === gap.skill ? COLORS.coral : COLORS.teal);
  const width = 740;
  const topY = 70;
  const skillY = 155;
  const gapY = 240;
  const recY = 315;
  const actY = 390;
  const reassessY = 465;

  const cols = scores.length;
  const xs = scores.map((_, i) => 70 + (i * (width - 140)) / (cols - 1));
  const gapIdx = scores.findIndex((s) => s.skill === gap.skill);
  const gapX = xs[gapIdx >= 0 ? gapIdx : 0];

  const actions = ['Micro-Lesson', 'POS Simulation', 'Daily Challenge'];
  const actXs = actions.map((_, i) => Math.min(width - 80, Math.max(80, gapX - 150 + i * 150)));

  return (
    <div className="w-full overflow-x-auto rounded-2xl bg-slate-50/70 p-4 border" style={{ borderColor: COLORS.line }}>
      <svg viewBox={`0 0 ${width} 520`} className="w-full max-w-full" style={{ minWidth: 620 }}>
        <defs>
          <linearGradient id="headerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={COLORS.navy} />
            <stop offset="100%" stopColor={COLORS.navy2} />
          </linearGradient>
          <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.08" />
          </filter>
        </defs>

        {/* Header Node */}
        <rect x={width / 2 - 110} y={15} width="220" height="36" rx="18" fill="url(#headerGrad)" filter="url(#shadow)" />
        <text x={width / 2} y={38} textAnchor="middle" fontSize="13" fontWeight="700" fill="white">
          👤 {employee.name} (Associate Graph)
        </text>

        {/* Lines from Root to Skills */}
        {xs.map((x, i) => (
          <line
            key={`l1-${i}`}
            x1={width / 2}
            y1={51}
            x2={x}
            y2={skillY - 26}
            stroke={COLORS.line}
            strokeWidth="2.5"
          />
        ))}

        {/* Skill Score Nodes */}
        {scores.map((s, i) => {
          const isGap = s.skill === gap.skill;
          return (
            <g key={s.skill} filter="url(#shadow)">
              <circle
                cx={xs[i]}
                cy={skillY}
                r="24"
                fill={isGap ? 'rgba(239,90,76,0.12)' : 'rgba(14,140,130,0.12)'}
                stroke={nodeColor(s)}
                strokeWidth="2.5"
              />
              <text
                x={xs[i]}
                y={skillY + 5}
                textAnchor="middle"
                fontSize="13"
                fontWeight="800"
                fill={nodeColor(s)}
              >
                {s.score}%
              </text>
              <text
                x={xs[i]}
                y={skillY + 40}
                textAnchor="middle"
                fontSize="11"
                fontWeight="600"
                fill={COLORS.ink}
              >
                {s.skill}
              </text>
            </g>
          );
        })}

        {/* Connector from Gap to Identified Skill Gap */}
        <line
          x1={gapX}
          y1={skillY + 24}
          x2={gapX}
          y2={gapY - 16}
          stroke={COLORS.coral}
          strokeWidth="2"
          strokeDasharray="5 4"
        />
        <rect
          x={gapX - 75}
          y={gapY - 16}
          width="150"
          height="32"
          rx="16"
          fill={COLORS.coral}
          filter="url(#shadow)"
        />
        <text x={gapX} y={gapY + 5} textAnchor="middle" fontSize="12" fontWeight="700" fill="white">
          ⚠️ Identified Skill Gap
        </text>

        {/* Connector to AI Recommendation Engine */}
        <line
          x1={gapX}
          y1={gapY + 16}
          x2={gapX}
          y2={recY - 16}
          stroke={COLORS.plum}
          strokeWidth="2"
          strokeDasharray="5 4"
        />
        <rect
          x={gapX - 105}
          y={recY - 16}
          width="210"
          height="32"
          rx="16"
          fill={COLORS.plum}
          filter="url(#shadow)"
        />
        <text x={gapX} y={recY + 5} textAnchor="middle" fontSize="12" fontWeight="700" fill="white">
          🧠 AI Adaptive Recommendation
        </text>

        {/* Connectors to 3 Action Interventions */}
        {actXs.map((x, i) => (
          <line
            key={`l2-${i}`}
            x1={gapX}
            y1={recY + 16}
            x2={x}
            y2={actY - 16}
            stroke={COLORS.line}
            strokeWidth="2"
          />
        ))}

        {actions.map((a, i) => (
          <g key={a} filter="url(#shadow)">
            <rect
              x={actXs[i] - 60}
              y={actY - 16}
              width="120"
              height="32"
              rx="10"
              fill="white"
              stroke={COLORS.amberDeep}
              strokeWidth="1.5"
            />
            <text
              x={actXs[i]}
              y={actY + 5}
              textAnchor="middle"
              fontSize="11"
              fontWeight="700"
              fill={COLORS.amberDeep}
            >
              {a}
            </text>
          </g>
        ))}

        {/* Reassessment Feedback Loop */}
        {actXs.map((x, i) => (
          <line
            key={`l3-${i}`}
            x1={x}
            y1={actY + 16}
            x2={gapX}
            y2={reassessY - 22}
            stroke={COLORS.line}
            strokeWidth="2"
          />
        ))}

        <circle
          cx={gapX}
          cy={reassessY}
          r="24"
          fill={COLORS.teal}
          filter="url(#shadow)"
        />
        <text
          x={gapX}
          y={reassessY + 4}
          textAnchor="middle"
          fontSize="9.5"
          fontWeight="800"
          fill="white"
        >
          VERIFY 🔄
        </text>
      </svg>
    </div>
  );
}
