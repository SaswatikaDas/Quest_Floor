import React from 'react';
import { COLORS } from '../../lib/constants';

interface SectionHeaderProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}

export function SectionHeader({ title, subtitle, action, className = '' }: SectionHeaderProps) {
  return (
    <div className={`flex items-end justify-between mb-4 flex-wrap gap-3 ${className}`}>
      <div>
        <h2 className="text-xl font-bold tracking-tight" style={{ color: COLORS.ink }}>
          {title}
        </h2>
        {subtitle && (
          <p className="text-sm mt-0.5" style={{ color: COLORS.muted }}>
            {subtitle}
          </p>
        )}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}
