import React from 'react';
import { LucideIcon } from 'lucide-react';
import { COLORS } from '../../lib/constants';

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: React.ReactNode;
  sub?: string;
  accent?: string;
  trend?: string;
  className?: string;
}

export function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  accent = COLORS.amber,
  trend,
  className = '',
}: StatCardProps) {
  return (
    <div
      className={`rounded-2xl p-5 bg-white border transition-all duration-200 hover:shadow-sm ${className}`}
      style={{ borderColor: COLORS.line }}
    >
      <div className="flex items-center justify-between mb-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: `${accent}18` }}
        >
          <Icon size={18} style={{ color: accent }} />
        </div>
        {trend && (
          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: `${COLORS.teal}18`, color: COLORS.teal }}>
            {trend}
          </span>
        )}
      </div>
      <div className="font-mono text-2xl font-bold tracking-tight" style={{ color: COLORS.ink }}>
        {value}
      </div>
      <div className="text-sm mt-1 font-medium" style={{ color: COLORS.muted }}>
        {label}
      </div>
      {sub && (
        <div className="text-xs mt-1.5 font-semibold" style={{ color: accent }}>
          {sub}
        </div>
      )}
    </div>
  );
}
