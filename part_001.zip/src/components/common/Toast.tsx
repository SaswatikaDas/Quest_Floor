'use client';

import React from 'react';
import { ToastMessage } from '../../types';
import { COLORS } from '../../lib/constants';

interface ToastProps {
  toast: ToastMessage | null;
}

export function Toast({ toast }: ToastProps) {
  if (!toast) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-bounce-short">
      <div
        className="flex items-center gap-3 bg-white rounded-2xl shadow-2xl px-5 py-4 border backdrop-blur-sm"
        style={{ borderColor: COLORS.line, minWidth: 300, maxWidth: 440 }}
      >
        <div className="text-2xl shrink-0">{toast.icon}</div>
        <div className="text-sm font-semibold" style={{ color: COLORS.ink }}>
          {toast.message}
        </div>
      </div>
    </div>
  );
}
