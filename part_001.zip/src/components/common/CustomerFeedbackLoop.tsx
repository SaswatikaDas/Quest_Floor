'use client';

import React, { useState } from 'react';
import {
  Star,
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Send,
  Users,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from './SectionHeader';
import { Pill } from './Pill';
import { COLORS } from '../../lib/constants';

const SENTIMENT_TAGS = [
  'Helpful Staff',
  'Fast Billing',
  'Polite Hospitality',
  'Product Knowledge',
  'Custom Gifting',
  'Clean Store',
  'Billing Queue Delay',
  'Missing Size',
];

export function CustomerFeedbackLoop() {
  const { employees, stores, feedbackSubmissions, submitCustomerFeedback, showToast } = useAppStore();

  const [rating, setRating] = useState<number>(5);
  const [selectedAssociate, setSelectedAssociate] = useState<string>(employees[0]?.id || 'e1');
  const [selectedTags, setSelectedTags] = useState<string[]>(['Helpful Staff', 'Polite Hospitality']);
  const [comment, setComment] = useState<string>('');
  const [isHelpful, setIsHelpful] = useState<boolean>(true);

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitCustomerFeedback({
      rating,
      associateId: selectedAssociate,
      storeId: 's1',
      helpful: isHelpful,
      selectedTags,
      comment: comment.trim() || 'Great customer experience on the sales floor.',
    });
    setComment('');
  };

  const totalReviews = feedbackSubmissions.length;
  const avgRating = totalReviews > 0 ? (feedbackSubmissions.reduce((acc, f) => acc + f.rating, 0) / totalReviews).toFixed(1) : '4.8';
  const fiveStarPct = totalReviews > 0 ? Math.round((feedbackSubmissions.filter((f) => f.rating >= 4).length / totalReviews) * 100) : 92;

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.teal} 0%, ${COLORS.navy} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-teal-300">
              Voice of the Customer (VoC)
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Real-Time CSAT Telemetry</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Customer Experience Feedback &amp; CSAT Loop
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Simulate digital post-checkout customer survey submissions and monitor store-wide customer sentiment and associate compliments.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">Store CSAT Index</div>
          <div className="text-3xl font-extrabold text-amber-300 mt-0.5">{fiveStarPct}% 5-Star</div>
        </div>
      </div>

      {/* Grid: Customer Survey Console + VoC Intelligence Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: Customer Survey Simulator */}
        <div className="lg:col-span-1 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5" style={{ borderColor: COLORS.line }}>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-teal-700">
              Checkout Tablet Survey Simulator
            </div>
            <h3 className="text-base font-bold text-slate-900 mt-0.5">Submit Customer Voice</h3>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Star Picker */}
            <div className="space-y-1.5 text-center p-4 rounded-2xl bg-amber-50/50 border border-amber-200">
              <div className="text-xs font-bold text-slate-700">How was your shopping experience?</div>
              <div className="flex justify-center gap-2 pt-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    type="button"
                    key={star}
                    onClick={() => setRating(star)}
                    className="p-1 text-2xl transition-transform hover:scale-125"
                  >
                    <Star
                      size={24}
                      className={star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Associate Selector */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Select Floor Associate:</label>
              <select
                value={selectedAssociate}
                onChange={(e) => setSelectedAssociate(e.target.value)}
                className="w-full border rounded-xl px-3 py-2 text-xs font-bold bg-slate-50 border-slate-200 text-slate-900 focus:outline-none"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} (Nagpur Central)
                  </option>
                ))}
              </select>
            </div>

            {/* Quick Sentiment Tags */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">What stood out?</label>
              <div className="flex flex-wrap gap-1.5">
                {SENTIMENT_TAGS.map((tag) => {
                  const isSelected = selectedTags.includes(tag);
                  return (
                    <button
                      type="button"
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-teal-600 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Comment */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Customer Comment:</label>
              <textarea
                rows={2}
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Staff explained festive kurta sizing and helped pack gift hampers..."
                className="w-full border rounded-xl p-2.5 text-xs bg-slate-50 border-slate-200 text-slate-900 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl font-bold text-xs text-white shadow-md flex items-center justify-center gap-1.5"
              style={{ backgroundColor: COLORS.navy }}
            >
              <Send size={13} />
              <span>Submit Survey Response</span>
            </button>
          </form>
        </div>

        {/* Right 2 Cols: Live Voice of Customer Stream & Sentiments */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5" style={{ borderColor: COLORS.line }}>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-teal-700">
                Live Store Feedback Stream
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">Voice of Customer Telemetry</h3>
            </div>
            <span className="text-xs font-mono font-bold text-slate-500">
              {feedbackSubmissions.length} Verified Reviews
            </span>
          </div>

          <div className="space-y-3 pt-1">
            {feedbackSubmissions.map((fb) => {
              const emp = employees.find((e) => e.id === fb.associateId);
              return (
                <div
                  key={fb.id}
                  className={`p-4 rounded-2xl border text-xs space-y-2 ${
                    fb.rating >= 4
                      ? 'bg-emerald-50/40 border-emerald-200'
                      : 'bg-red-50/40 border-red-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="flex text-amber-400">
                        {Array.from({ length: fb.rating }).map((_, i) => (
                          <Star key={i} size={13} className="fill-amber-400" />
                        ))}
                      </div>
                      <span className="font-bold text-slate-900">
                        Assisted by: <strong>{emp?.name || 'Floor Associate'}</strong>
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">{fb.createdAt}</span>
                  </div>

                  <p className="text-slate-700 font-medium leading-relaxed italic">
                    &ldquo;{fb.comment}&rdquo;
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {fb.selectedTags.map((tag, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-white border border-slate-200 text-slate-700"
                      >
                        🏷️ {tag}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
