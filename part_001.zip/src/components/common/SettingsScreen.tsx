'use client';

import React, { useState } from 'react';
import { Settings, Bell, Shield, Smartphone, Mail, Sparkles, Check } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from './SectionHeader';
import { Avatar } from './Avatar';
import { Pill } from './Pill';
import { COLORS, ROLE_LABEL } from '../../lib/constants';

export function SettingsScreen() {
  const { role, currentManager, admin, showToast } = useAppStore();

  const [toggles, setToggles] = useState({
    emailAlerts: true,
    posDropAlert: true,
    weeklyDigest: false,
    audioSoundEffects: true,
    instantPush: true,
  });

  const activeUser =
    role === 'manager'
      ? { name: currentManager.name, email: currentManager.email, title: 'Senior Store Manager', color: COLORS.teal }
      : { name: admin.name, email: admin.email, title: admin.title, color: COLORS.plum };

  const toggle = (key: keyof typeof toggles) => {
    setToggles((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      showToast(`Preference updated.`, '⚙️');
      return next;
    });
  };

  return (
    <div className="space-y-6 pb-12 max-w-3xl">
      <SectionHeader title="Settings &amp; Notification Preferences" />

      {/* User Card */}
      <div className="bg-white rounded-3xl p-6 border shadow-xs flex items-center gap-4" style={{ borderColor: COLORS.line }}>
        <Avatar name={activeUser.name} color={activeUser.color} size={56} />
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-lg text-slate-900">{activeUser.name}</h3>
            <Pill color={activeUser.color}>{ROLE_LABEL[role || 'manager']}</Pill>
          </div>
          <div className="text-xs text-slate-500 font-mono mt-0.5">{activeUser.email}</div>
          <div className="text-xs text-slate-400 mt-1">{activeUser.title}</div>
        </div>
      </div>

      {/* Preferences List */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6" style={{ borderColor: COLORS.line }}>
        <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Workforce Alerts &amp; Telemetry
        </div>

        <div className="divide-y divide-slate-100">
          <div className="flex items-center justify-between py-4">
            <div>
              <div className="text-sm font-bold text-slate-900">Email Notifications</div>
              <div className="text-xs text-slate-500">Receive weekly executive digest and major store alerts</div>
            </div>
            <button
              onClick={() => toggle('emailAlerts')}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                toggles.emailAlerts ? 'bg-teal-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${
                  toggles.emailAlerts ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-4">
            <div>
              <div className="text-sm font-bold text-slate-900">POS Adoption Drop Alerts</div>
              <div className="text-xs text-slate-500">Trigger instant alert when associate POS usage drops below 55%</div>
            </div>
            <button
              onClick={() => toggle('posDropAlert')}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                toggles.posDropAlert ? 'bg-teal-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${
                  toggles.posDropAlert ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-4">
            <div>
              <div className="text-sm font-bold text-slate-900">Gamification Sound Effects</div>
              <div className="text-xs text-slate-500">Synthesize audio tones on quiz success, badge unlock &amp; claps</div>
            </div>
            <button
              onClick={() => toggle('audioSoundEffects')}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                toggles.audioSoundEffects ? 'bg-teal-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${
                  toggles.audioSoundEffects ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-4">
            <div>
              <div className="text-sm font-bold text-slate-900">Instant Mobile Push</div>
              <div className="text-xs text-slate-500">Real-time alerts for peer recognitions and new daily challenges</div>
            </div>
            <button
              onClick={() => toggle('instantPush')}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                toggles.instantPush ? 'bg-teal-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${
                  toggles.instantPush ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
