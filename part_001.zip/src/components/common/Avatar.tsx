import React from 'react';
import { getInitials } from '../../lib/cxCalculator';

interface AvatarProps {
  name: string;
  color?: string;
  size?: number;
  className?: string;
}

export function Avatar({ name, color = '#1B2354', size = 40, className = '' }: AvatarProps) {
  return (
    <div
      className={`rounded-full flex items-center justify-center text-white font-bold shrink-0 shadow-sm ${className}`}
      style={{
        width: size,
        height: size,
        backgroundColor: color,
        fontSize: Math.max(11, Math.round(size * 0.36)),
      }}
    >
      {getInitials(name)}
    </div>
  );
}
