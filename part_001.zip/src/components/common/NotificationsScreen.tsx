'use client';

import React, { useEffect } from 'react';
import {
  Bell,
  Trophy,
  Award,
  Heart,
  BookOpen,
  Target,
  AlertTriangle,
  Building2,
  Megaphone,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from './SectionHeader';
import { EmptyState } from './EmptyState';
import { COLORS } from '../../lib/constants';

const NOTIF_ICONS: Record<string, React.ElementType> = {
  Trophy,
  Award,
  Heart,
  BookOpen,
  Target,
  AlertTriangle,
  Building2,
  Megaphone,
  Sparkles,
  Bell,
};

interface NotificationsScreenProps {
  extraHeaderAction?: React.ReactNode;
}

export function NotificationsScreen({ extraHeaderAction }: NotificationsScreenProps) {
  const {
    notifications,
    role,
    currentEmployeeId,
    currentManagerId,
    admin,
    markNotificationsRead,
  } = useAppStore();

  const recipientId =
    role === 'employee' ? currentEmployeeId : role === 'manager' ? currentManagerId : admin.id;

  useEffect(() => {
    markNotificationsRead(recipientId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recipientId]);

  const list = notifications
    .filter((n) => n.recipientId === recipientId || n.recipientId === 'all')
    .sort((a, b) => (a.read === b.read ? 0 : a.read ? 1 : -1));

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
            Notifications &amp; Activity Alerts
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Real-time feed of learning rewards, peer recognitions, manager alerts, and chain announcements
          </p>
        </div>

        {extraHeaderAction}
      </div>

      {/* Notifications list card */}
      {list.length > 0 ? (
        <div className="bg-white rounded-3xl border shadow-xs divide-y divide-slate-100 overflow-hidden" style={{ borderColor: COLORS.line }}>
          {list.map((n) => {
            const Icon = NOTIF_ICONS[n.icon] || Bell;
            return (
              <div
                key={n.id}
                className={`flex items-start gap-4 p-5 transition-colors ${
                  n.read ? 'bg-white' : 'bg-amber-50/40'
                }`}
              >
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-xs"
                  style={{
                    backgroundColor: n.read ? COLORS.paper : 'rgba(243,167,18,0.15)',
                  }}
                >
                  <Icon size={18} style={{ color: n.read ? COLORS.muted : COLORS.amberDeep }} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="text-xs sm:text-sm font-bold leading-snug" style={{ color: COLORS.ink }}>
                    {n.text}
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 mt-1">{n.time}</div>
                </div>

                {!n.read && (
                  <span
                    className="w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 shadow-xs animate-pulse"
                    style={{ backgroundColor: COLORS.coral }}
                  />
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <EmptyState
          icon={Bell}
          title="All Caught Up!"
          text="You have no unread notifications or pending announcements."
        />
      )}
    </div>
  );
}
