'use client';

import React, { useState } from 'react';
import {
  Wifi,
  WifiOff,
  Signal,
  RefreshCw,
  Database,
  Cloud,
  CheckCircle2,
  HardDrive,
  Sparkles,
  Zap,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from './SectionHeader';
import { Pill } from './Pill';
import { NetworkMode, EdgeSyncQueueItem } from '../../types';
import { COLORS } from '../../lib/constants';

const INITIAL_QUEUE: EdgeSyncQueueItem[] = [
  { id: 'q-1', type: 'Quiz Score', payloadSummary: 'Festive Range Quiz Passed (100% Score)', queuedAt: '2 mins ago', sizeBytes: 512, status: 'Queued Locally' },
  { id: 'q-2', type: 'Roleplay Attempt', payloadSummary: 'Ramesh Gupta AI Objection Evaluation (92%)', queuedAt: '4 mins ago', sizeBytes: 1024, status: 'Queued Locally' },
  { id: 'q-3', type: 'POS Transaction', payloadSummary: 'Offline Split Payment Ticket #4892 (₹1,349)', queuedAt: '7 mins ago', sizeBytes: 256, status: 'Queued Locally' },
  { id: 'q-4', type: 'Peer Shoutout', payloadSummary: 'Recognition to Rahul Verma (+10 XP)', queuedAt: '12 mins ago', sizeBytes: 128, status: 'Queued Locally' },
];

export function OfflineEdgeSyncConsole() {
  const { showToast, fireCelebration } = useAppStore();

  const [networkMode, setNetworkMode] = useState<NetworkMode>('2G_RURAL');
  const [queue, setQueue] = useState<EdgeSyncQueueItem[]>(INITIAL_QUEUE);
  const [isSyncing, setIsSyncing] = useState(false);

  const handleSync = () => {
    setIsSyncing(true);
    setQueue((prev) => prev.map((item) => ({ ...item, status: 'Syncing...' })));

    setTimeout(() => {
      setQueue((prev) => prev.map((item) => ({ ...item, status: 'Synced to Cloud' })));
      setIsSyncing(false);

      fireCelebration({
        emoji: '📴',
        eyebrow: 'Tier-3 Edge Queue Flushed!',
        title: '4 Offline Records Synchronized',
        sub: 'Zero Data Loss across 1,200 store edges',
      });
    }, 1200);
  };

  const pendingCount = queue.filter((i) => i.status !== 'Synced to Cloud').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.navy3} 0%, ${COLORS.teal} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-teal-300">
              Tier-3 Resilience Architecture
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Local-First PWA Storage</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Offline Edge Sync &amp; Network Condition Simulator
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Simulate how QuestFloor operates during connectivity drops in remote Indian towns. All quizzes, roleplay dialogues, and POS offline logs queue locally and sync with zero data loss.
          </p>
        </div>

        <button
          onClick={handleSync}
          disabled={networkMode === 'OFFLINE' || isSyncing || pendingCount === 0}
          className="px-5 py-3 rounded-2xl font-extrabold text-xs text-slate-900 bg-amber-400 hover:bg-amber-300 shadow-md flex items-center gap-2 shrink-0 transition-all disabled:opacity-40"
        >
          <RefreshCw size={16} className={isSyncing ? 'animate-spin' : ''} />
          <span>{isSyncing ? 'Syncing Edge Queue…' : 'Sync Offline Queue to Cloud'}</span>
        </button>
      </div>

      {/* Network Mode Switcher */}
      <div className="space-y-2">
        <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Select Simulated Store Network Environment:
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { id: '5G_HIGH' as NetworkMode, label: '5G High-Speed Metro', desc: '< 20ms Latency', icon: Wifi, color: 'text-teal-600' },
            { id: '2G_RURAL' as NetworkMode, label: '2G / 3G Remote Store Edge', desc: '~600ms Latency · Edge Queued', icon: Signal, color: 'text-amber-600' },
            { id: 'OFFLINE' as NetworkMode, label: 'Zero Internet (100% Offline)', desc: 'Local IndexedDB Ledger', icon: WifiOff, color: 'text-red-600' },
          ].map((mode) => {
            const isSelected = networkMode === mode.id;
            const Icon = mode.icon;
            return (
              <button
                key={mode.id}
                onClick={() => setNetworkMode(mode.id)}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-md ring-2 ring-slate-900/20'
                    : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Icon size={18} className={isSelected ? 'text-amber-400' : mode.color} />
                  <span className="font-bold text-xs sm:text-sm">{mode.label}</span>
                </div>
                <div className={`text-[11px] font-mono ${isSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                  {mode.desc}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Edge Sync Ledger & Storage Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Edge Queue Items */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HardDrive size={18} className="text-teal-600" />
              <h3 className="text-base font-bold text-slate-900">Local Edge Storage Sync Ledger</h3>
            </div>
            <span className="text-xs font-mono font-bold text-slate-500">
              {pendingCount} Item(s) Pending Cloud Sync
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {queue.map((item) => (
              <div key={item.id} className="py-3.5 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{item.type}</span>
                    <span className="text-[10px] font-mono text-slate-400">{item.queuedAt}</span>
                  </div>
                  <div className="text-xs text-slate-600 font-medium mt-0.5">{item.payloadSummary}</div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-mono text-[11px] text-slate-400">{item.sizeBytes} B</span>
                  <span
                    className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full ${
                      item.status === 'Synced to Cloud'
                        ? 'bg-emerald-50 text-emerald-700'
                        : item.status === 'Syncing...'
                        ? 'bg-amber-50 text-amber-700 animate-pulse'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Bandwidth Saving Telemetry */}
        <div className="space-y-4">
          <div
            className="rounded-3xl p-6 text-white shadow-md flex flex-col justify-between"
            style={{
              background: `linear-gradient(145deg, ${COLORS.navy}, ${COLORS.navy2})`,
            }}
          >
            <div>
              <div className="text-xs uppercase tracking-wider font-extrabold text-amber-400">
                Tier-3 Bandwidth Optimization
              </div>
              <div className="font-mono text-4xl font-extrabold mt-2 text-emerald-400">
                94.2%
              </div>
              <div className="text-xs text-slate-300 mt-1">
                Data Saved via Local Edge Processing
              </div>
            </div>

            <div className="space-y-2.5 pt-6 border-t border-white/10 mt-6 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-300">Local Cache Hit Rate:</span>
                <span className="font-mono font-bold text-teal-300">99.1%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Offline Quiz Storage:</span>
                <span className="font-mono font-bold text-amber-300">2.4 MB IndexedDB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Auto-Retry Backoff:</span>
                <span className="font-mono font-bold text-purple-300">Exponential</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-950 font-medium space-y-1">
            <div className="font-bold flex items-center gap-1">
              <Sparkles size={13} className="text-amber-700" /> Architectural Advantage:
            </div>
            <p>
              Enables uninterrupted micro-learning in rural Tier-3 store locations even during local power or ISP outages.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
