'use client';

import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Trophy,
  BookOpen,
  Zap,
  Users,
  CheckCircle2,
  TrendingUp,
  Store as StoreIcon,
  Award,
  ArrowRight,
  Copy,
  Check,
  Brain,
  ShieldCheck,
  ShoppingCart
} from 'lucide-react';
import { Pill } from './Pill';

interface LearnathonStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function LearnathonStoryModal({ isOpen, onClose }: LearnathonStoryModalProps) {
  const [activeTab, setActiveTab] = useState<'pitch' | 'amit_story' | 'metrics' | 'flow' | 'llm'>('pitch');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const pitchText = `Our problem is that the company is expanding to 1,200 Tier-3 stores with around 3,000 associates, and maintaining consistent employee knowledge, POS adoption, and customer experience becomes difficult.

Our solution, QuestFloor, is a workforce engagement platform that combines micro-learning, gamification, recognition, and performance tracking. Associates receive short product and POS learning modules directly through the platform, complete quizzes and challenges, and earn XP, badges, and rewards. Employees can also recognize their peers, while managers get dashboards showing training completion, POS adoption, engagement, and customer-related performance.

The main idea is to create a continuous cycle: Learn, Practice, Perform, Get Recognized, and Improve. We measure success using engagement scores, training completion rates, POS adoption, customer feedback, and upsell conversion. This helps the company scale its workforce while maintaining a consistent customer experience across all 1,200 stores.`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(pitchText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl max-h-[90vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-indigo-600 flex items-center justify-center text-xl shadow-lg shadow-amber-500/20">
              🏪
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-lg text-white">RetailRise / QuestFloor</h2>
                <Pill label="Learnathon Edition" variant="gold" />
                <Pill label="1,200 Stores • 3,000 Associates" variant="blue" />
              </div>
              <p className="text-xs text-slate-400">Enterprise Retail Workforce Engagement, Micro-Learning & CX Platform</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-800 bg-slate-900/60 overflow-x-auto">
          <button
            onClick={() => setActiveTab('pitch')}
            className={`px-4 py-2.5 text-xs font-semibold rounded-t-lg border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'pitch'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            🎤 1-Min Pitch & Context
          </button>
          <button
            onClick={() => setActiveTab('amit_story')}
            className={`px-4 py-2.5 text-xs font-semibold rounded-t-lg border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'amit_story'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            🧠 Amit's Journey
          </button>
          <button
            onClick={() => setActiveTab('metrics')}
            className={`px-4 py-2.5 text-xs font-semibold rounded-t-lg border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'metrics'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            📊 Measurement Framework
          </button>
          <button
            onClick={() => setActiveTab('flow')}
            className={`px-4 py-2.5 text-xs font-semibold rounded-t-lg border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'flow'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            🔄 Closed-Loop CX Cycle
          </button>
          <button
            onClick={() => setActiveTab('llm')}
            className={`px-4 py-2.5 text-xs font-semibold rounded-t-lg border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'llm'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            🤖 5 LLM Copilots
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm">
          
          {/* TAB 1: PITCH & CONTEXT */}
          {activeTab === 'pitch' && (
            <div className="space-y-6">
              {/* One-Line Pitch */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/20 via-orange-500/10 to-indigo-500/20 border border-amber-500/30">
                <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
                  <Sparkles className="w-4 h-4" /> The One-Line Pitch
                </div>
                <p className="text-base font-semibold text-white">
                  "QuestFloor turns everyday retail work into a learning and recognition journey where employees learn faster, perform better, get recognized, and ultimately deliver a better customer experience."
                </p>
              </div>

              {/* 1-Minute Explanation Box */}
              <div className="p-5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                    <span>🎤</span> 1-Minute Mentor Presentation Script
                  </div>
                  <button
                    onClick={copyToClipboard}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-xs flex items-center gap-1.5 border border-indigo-500/30 transition-all"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied!' : 'Copy Pitch'}
                  </button>
                </div>
                <div className="bg-slate-950/70 p-4 rounded-lg border border-slate-800 text-slate-300 leading-relaxed font-mono text-xs whitespace-pre-line">
                  {pitchText}
                </div>
              </div>

              {/* The Two Core Bottlenecks */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-800/30 space-y-2">
                  <div className="flex items-center gap-2 text-rose-400 font-bold">
                    <span>❌ Problem 1</span>
                    <span>Uneven Product Knowledge</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Associate A knows smartphone features, Associate B knows only basic specs, Associate C knows nothing. Customers receive inconsistent advice across 1,200 stores.
                  </p>
                  <div className="text-[11px] text-rose-300/80 bg-rose-900/20 p-2 rounded">
                    <strong>Solution:</strong> 2-3 minute micro-lessons + quizzes integrated directly on the floor.
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-800/30 space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 font-bold">
                    <span>❌ Problem 2</span>
                    <span>Poor Digital POS Adoption</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Associates avoid POS billing features (vouchers, split payments, inventory lookup, order returns) because 30-page manuals are intimidating.
                  </p>
                  <div className="text-[11px] text-amber-300/80 bg-amber-900/20 p-2 rounded">
                    <strong>Solution:</strong> 2-minute POS challenges inside an interactive sandbox (+50 XP).
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: AMIT'S JOURNEY */}
          {activeTab === 'amit_story' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700">
                <h3 className="font-bold text-white mb-1 flex items-center gap-2">
                  <span>🧠</span> The Employee Journey: Amit Kumar (Store #104 Associate)
                </h3>
                <p className="text-xs text-slate-400">
                  How a store associate evolves through micro-learning, gamification, and peer recognition.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="p-4 rounded-xl bg-slate-800/90 border border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-400 text-xs">Day 1</span>
                    <Pill label="+30 XP" variant="gold" />
                  </div>
                  <h4 className="font-semibold text-white text-xs">Product Micro-Lesson</h4>
                  <p className="text-[11px] text-slate-300">
                    Amit receives: <em>"Learn the new smartphone in 3 minutes."</em> Passes battery optimization quiz.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/90 border border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-indigo-400 text-xs">Day 2</span>
                    <Pill label="+50 XP" variant="blue" />
                  </div>
                  <h4 className="font-semibold text-white text-xs">POS Speed Challenge</h4>
                  <p className="text-[11px] text-slate-300">
                    Completes <em>"Create customer order using split tender."</em> Earns 🏅 <strong>POS Pro Badge</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/90 border border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-400 text-xs">Day 5</span>
                    <Pill label="+20 XP" variant="green" />
                  </div>
                  <h4 className="font-semibold text-white text-xs">Peer Recognition</h4>
                  <p className="text-[11px] text-slate-300">
                    Colleague recognizes him: <em>"Thanks for helping me with POS billing!"</em> Earns 🤝 <strong>Team Player</strong> tag.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/20 to-indigo-500/20 border border-amber-500/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-300 text-xs">End of Month</span>
                    <Pill label="Level 7" variant="gold" />
                  </div>
                  <h4 className="font-semibold text-white text-xs">Top Performer</h4>
                  <p className="text-[11px] text-slate-200">
                    ⭐ 1,500 XP • 🏅 5 Badges • 📚 95% Training • 💻 92% POS • ⭐ 4.7/5 Rating.
                  </p>
                </div>
              </div>

              {/* Badges Earned */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700 space-y-3">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Badges That Recognize Desired Behaviors
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-xl mb-1">📚</div>
                    <div className="font-bold text-amber-400">Product Expert</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Product training completed</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-xl mb-1">💻</div>
                    <div className="font-bold text-indigo-400">POS Pro</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">POS features mastered</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-xl mb-1">🤝</div>
                    <div className="font-bold text-emerald-400">Team Player</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Peer appreciation earned</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-xl mb-1">⭐</div>
                    <div className="font-bold text-yellow-400">Customer Champion</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">High CSAT ratings</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-xl mb-1">🔥</div>
                    <div className="font-bold text-rose-400">Learning Streak</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">8-day continuous streak</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: MEASUREMENT FRAMEWORK */}
          {activeTab === 'metrics' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                  <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider">1. Engagement Score</div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-white">78%</span>
                    <span className="text-xs text-emerald-400 font-bold">▲ Up from 52%</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Measures daily logins, micro-challenges completed, streak maintenance, and peer recognitions sent.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                  <div className="text-xs font-bold text-amber-400 uppercase tracking-wider">2. Training Completion</div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-white">90%</span>
                    <span className="text-xs text-slate-400 font-mono">(2,700 / 3,000 associates)</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    <strong>Formula:</strong> Completed Training / Assigned Training × 100 across all 1,200 stores.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                  <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider">3. Upsell Conversion</div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-white">18%</span>
                    <span className="text-xs text-indigo-400 font-bold">Target: 24%</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Measures consultative combo attachment (e.g. 📱 Smartphone + 🎧 Earbuds combo bundle).
                  </p>
                </div>
              </div>

              {/* Value Table */}
              <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">
                  Why QuestFloor Solves Enterprise Challenges
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-900 text-slate-400 uppercase text-[10px]">
                      <tr>
                        <th className="p-2.5 rounded-l-lg">Enterprise Problem</th>
                        <th className="p-2.5 rounded-r-lg">QuestFloor Solution</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-slate-300">
                      <tr>
                        <td className="p-2.5 font-medium">Uneven product knowledge</td>
                        <td className="p-2.5 text-amber-400">2-3 min interactive micro-learning modules + quizzes</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-medium">Poor POS adoption & billing errors</td>
                        <td className="p-2.5 text-indigo-400">POS Sandbox + Speed Challenges with instant XP</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-medium">Low employee motivation in Tier-3 towns</td>
                        <td className="p-2.5 text-emerald-400">Levels, Streaks, Badges & Redeemable Rewards</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-medium">Employees feeling unnoticed</td>
                        <td className="p-2.5 text-pink-400">Peer-to-peer Kudos & Social Recognition Wall</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-medium">Managers lack visibility over 1,200 stores</td>
                        <td className="p-2.5 text-cyan-400">Manager Action Center + Outlier associate diagnosis (40% vs 90%)</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CLOSED-LOOP CYCLE */}
          {activeTab === 'flow' && (
            <div className="space-y-6">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700">
                <h3 className="font-bold text-white mb-1">
                  🔄 The 360° Customer Experience Cycle
                </h3>
                <p className="text-xs text-slate-400">
                  The platform does not reward employees only for selling more; it rewards the right behaviors.
                </p>
              </div>

              <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-center">
                <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-700/50 flex-1 w-full">
                  <div className="text-lg mb-1">📚</div>
                  <div className="font-bold text-indigo-300 text-xs">1. LEARN</div>
                  <div className="text-[10px] text-slate-400">Bite-sized product & POS micro-modules</div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-500 hidden md:block" />
                <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-700/50 flex-1 w-full">
                  <div className="text-lg mb-1">🎮</div>
                  <div className="font-bold text-blue-300 text-xs">2. PRACTICE</div>
                  <div className="text-[10px] text-slate-400">POS Sandbox & AI customer roleplay</div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-500 hidden md:block" />
                <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-700/50 flex-1 w-full">
                  <div className="text-lg mb-1">⚡</div>
                  <div className="font-bold text-emerald-300 text-xs">3. PERFORM</div>
                  <div className="text-[10px] text-slate-400">Flawless floor checkout & combo upsells</div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-500 hidden md:block" />
                <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-700/50 flex-1 w-full">
                  <div className="text-lg mb-1">🤝</div>
                  <div className="font-bold text-amber-300 text-xs">4. RECOGNIZE</div>
                  <div className="text-[10px] text-slate-400">Peer Kudos & Manager Badges</div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-500 hidden md:block" />
                <div className="p-3.5 rounded-xl bg-pink-950/40 border border-pink-700/50 flex-1 w-full">
                  <div className="text-lg mb-1">🎁</div>
                  <div className="font-bold text-pink-300 text-xs">5. REWARD</div>
                  <div className="text-[10px] text-slate-400">Vouchers, Shift perks & Level upgrades</div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: LLM COPILOTS */}
          {activeTab === 'llm' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs">
                    <Brain className="w-4 h-4" /> 1. AI Customer Roleplay Simulator
                  </div>
                  <p className="text-xs text-slate-300">
                    Interactive roleplay where associates practice pitching smartphone specs, handling price objections, and attaching earbuds with real-time multi-dimensional scoring and XP rewards.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                    <Zap className="w-4 h-4" /> 2. AI Floor Copilot ("Ask QuestBot")
                  </div>
                  <p className="text-xs text-slate-300">
                    Floor assistant for instant product comparisons in Hindi/English, POS step-by-step troubleshooting, and consultative upsell scripts.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                    <BookOpen className="w-4 h-4" /> 3. AI Micro-Lesson & Quiz Studio
                  </div>
                  <p className="text-xs text-slate-300">
                    Generates complete 2-minute micro-learning modules and interactive quizzes on demand from newly launched products or POS policy updates.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2 text-pink-400 font-bold text-xs">
                    <Users className="w-4 h-4" /> 4. AI Peer Kudos Polisher
                  </div>
                  <p className="text-xs text-slate-300">
                    Transforms rough bullet notes into warm, professional recognition shoutouts with automatic badge recommendations (e.g. Team Player, POS Pro).
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/30 to-indigo-950/30 border border-purple-800/40 space-y-2">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-xs">
                  <ShieldCheck className="w-4 h-4" /> 5. AI Manager Diagnostic & Coaching Copilot
                </div>
                <p className="text-xs text-slate-300">
                  Analyzes Store #104 metrics, identifies associates at 40% vs 90% completion, and generates automated 1-click coaching interventions and challenge nudges.
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/80 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            Powered by <strong>Python (FastAPI) Backend</strong> + <strong>React Frontend</strong> + <strong>LLM Engine</strong>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-indigo-600/30"
          >
            Explore Platform Live
          </button>
        </div>

      </div>
    </div>
  );
}
