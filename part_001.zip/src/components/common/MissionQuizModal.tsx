'use client';

import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  XCircle,
  ArrowRight,
  HelpCircle,
  Award,
  X,
  Target,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Challenge, QuizQuestion } from '../../types';
import { useAppStore } from '../../lib/store/useAppStore';
import { COLORS } from '../../lib/constants';

interface MissionQuizModalProps {
  challenge: Challenge | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (challengeId: string) => void;
}

const DEFAULT_QUIZ_QUESTIONS: Record<string, QuizQuestion[]> = {
  c1: [
    {
      id: 'mq1-1',
      q: 'What is the optimal price point for impulse festive diya & lantern combos?',
      options: ['₹1,999 with warranty', 'Under ₹499 for impulse checkout', '₹2,499 premium tier', 'Free with grocery'],
      correct: 1,
      explanation: 'At under ₹499, combos trigger instant impulse purchases without customer price resistance.',
    },
    {
      id: 'mq1-2',
      q: 'Can in-store gifting hampers be custom-packed for shoppers?',
      options: ['No, pre-packed only', 'Yes, custom packaging is available and must be offered', 'Only for online deliveries', 'Only for VIP cardholders'],
      correct: 1,
      explanation: 'Highlighting in-store custom packing delights shoppers and elevates basket size.',
    },
  ],
  c4: [
    {
      id: 'mq4-1',
      q: 'When performing a Split Tender (Cash + UPI), what is the correct workflow?',
      options: [
        'Cancel the transaction and start over',
        'Enter Cash received first, POS auto-computes the remaining balance for the UPI QR code',
        'Ask customer to pay entirely in cash',
        'Swipe manager override card',
      ],
      correct: 1,
      explanation: 'Entering partial cash first lets the POS calculate the exact balance for the dynamic UPI QR code.',
    },
    {
      id: 'mq4-2',
      q: 'How do you trigger the Flagship Smartphone + ANC Earbuds combo discount?',
      options: [
        'Scan both items in the same bill; POS auto-applies the ₹999 bundle price',
        'Manual coupon sticker required from store manager',
        'Cannot be billed on digital POS',
        'Requires 2 separate bills',
      ],
      correct: 0,
      explanation: 'Scanning both qualifying SKUs together automatically unlocks the consultative upsell combo.',
    },
  ],
  c3: [
    {
      id: 'mq3-1',
      q: 'How does peer recognition impact store customer experience (CX)?',
      options: [
        'Has zero correlation with floor metrics',
        'Strengthens team coordination during peak rush and reduces billing friction',
        'Replaces daily inventory audits',
        'Only matters for corporate HQ staff',
      ],
      correct: 1,
      explanation: 'Cross-functional teamwork directly accelerates floor customer assistance and CSAT scores.',
    },
    {
      id: 'mq3-2',
      q: 'What badge is unlocked when you frequently support teammates with POS help?',
      options: ['Solo Achiever', 'Team Player Badge (+20 XP)', 'Offline Auditor', 'Warehouse Specialist'],
      correct: 1,
      explanation: 'The Team Player badge celebrates associates who actively mentor and support peers.',
    },
  ],
  default: [
    {
      id: 'mq-def-1',
      q: 'What is QuestFloor’s standard response time for customer greeting on the store floor?',
      options: ['Within 30 seconds of entry with a warm smile', 'After 5 minutes', 'Only if the customer approaches first', 'When they reach the billing counter'],
      correct: 0,
      explanation: 'Immediate hospitality greeting makes shoppers feel welcomed and comfortable.',
    },
    {
      id: 'mq-def-2',
      q: 'When a customer asks about a product spec you are unsure about, what should you do?',
      options: [
        'Guess the answer',
        'Use Ask QuestBot Copilot or check the digital catalog to give accurate specs',
        'Tell the customer to check online',
        'Ignore the question',
      ],
      correct: 1,
      explanation: 'Using the Floor Copilot guarantees 100% accurate product specifications.',
    },
  ],
};

export function MissionQuizModal({
  challenge,
  isOpen,
  onClose,
  onSuccess,
}: MissionQuizModalProps) {
  const { currentEmployee } = useAppStore();
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen || !challenge) return null;

  const questions =
    challenge.quiz ||
    DEFAULT_QUIZ_QUESTIONS[challenge.id] ||
    DEFAULT_QUIZ_QUESTIONS.default;

  const currentQ = questions[currentQIndex];
  const selectedOption = selectedAnswers[currentQIndex];
  const hasAnswered = selectedOption !== undefined;

  const handleSelectOption = (optIndex: number) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [currentQIndex]: optIndex }));
  };

  const handleNext = () => {
    if (currentQIndex < questions.length - 1) {
      setCurrentQIndex((prev) => prev + 1);
    } else {
      // Finished all questions
      setIsSubmitted(true);
      const isAllCorrect = questions.every(
        (q, idx) => selectedAnswers[idx] === q.correct
      );

      if (isAllCorrect) {
        confetti({
          particleCount: 90,
          spread: 80,
          origin: { y: 0.6 },
        });
        onSuccess(challenge.id);
      }
    }
  };

  const allAnswered = questions.every((_, i) => selectedAnswers[i] !== undefined);
  const isAllCorrect = questions.every((q, idx) => selectedAnswers[idx] === q.correct);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-lg w-full text-white shadow-2xl space-y-6 relative overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Target size={20} />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                Shift Mission Skill Verification
              </span>
              <h3 className="text-sm font-extrabold text-white leading-tight">
                {challenge.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Quiz Body */}
        {!isSubmitted ? (
          <div className="space-y-5">
            {/* Question Counter & Progress */}
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>
                Question {currentQIndex + 1} of {questions.length}
              </span>
              <span className="text-amber-400 font-bold font-mono">
                +{challenge.reward} XP Reward
              </span>
            </div>

            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-amber-500 to-indigo-500 h-full transition-all duration-300"
                style={{ width: `${((currentQIndex + 1) / questions.length) * 100}%` }}
              />
            </div>

            {/* Question Text */}
            <div className="text-sm font-bold text-slate-100 leading-snug">
              {currentQ.q}
            </div>

            {/* Options */}
            <div className="space-y-2.5">
              {currentQ.options.map((opt, optIdx) => {
                const isSelected = selectedOption === optIdx;
                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(optIdx)}
                    className={`w-full text-left p-3.5 rounded-2xl border text-xs font-semibold transition-all flex items-center justify-between ${
                      isSelected
                        ? 'border-amber-500 bg-amber-500/20 text-white shadow-sm'
                        : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700 hover:bg-slate-800/40'
                    }`}
                  >
                    <span>{opt}</span>
                    <span
                      className={`w-5 h-5 rounded-full border flex items-center justify-center text-[10px] font-mono shrink-0 ${
                        isSelected
                          ? 'border-amber-400 bg-amber-400 text-slate-950 font-bold'
                          : 'border-slate-700 text-slate-500'
                      }`}
                    >
                      {String.fromCharCode(65 + optIdx)}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={onClose}
                className="text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleNext}
                disabled={!hasAnswered}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-xs shadow-md flex items-center gap-1.5 transition-all disabled:opacity-50 active:scale-95"
              >
                <span>{currentQIndex === questions.length - 1 ? 'Verify & Claim XP' : 'Next Question'}</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>
        ) : (
          /* Result Card */
          <div className="text-center py-4 space-y-4 animate-in fade-in">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-400 to-indigo-600 mx-auto flex items-center justify-center text-3xl shadow-xl shadow-amber-500/20">
              {isAllCorrect ? '🏆' : '📚'}
            </div>

            <div>
              <h3 className="text-lg font-black text-white">
                {isAllCorrect ? 'Mission Mastered & XP Credited!' : 'Almost There! Review & Retry'}
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-sm mx-auto">
                {isAllCorrect
                  ? `You answered all mission questions correctly. +${challenge.reward} XP added to your shift wallet.`
                  : 'Review the correct product and POS guidelines below to master this mission.'}
              </p>
            </div>

            <div className="space-y-2 text-left bg-slate-950 p-4 rounded-2xl border border-slate-800 text-xs">
              {questions.map((q, i) => (
                <div key={q.id} className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-slate-200">
                    {selectedAnswers[i] === q.correct ? (
                      <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle size={14} className="text-rose-400 shrink-0" />
                    )}
                    <span>{q.q}</span>
                  </div>
                  <div className="text-[11px] text-emerald-300 pl-5 font-mono">
                    ✓ Correct: {q.options[q.correct]}
                  </div>
                  {q.explanation && (
                    <div className="text-[10px] text-slate-400 pl-5 italic">
                      💡 {q.explanation}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-600 hover:to-indigo-700 text-white font-bold text-xs shadow-lg transition-all"
            >
              Continue Shift
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
