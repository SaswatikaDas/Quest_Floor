import React from 'react';
import { LucideIcon } from 'lucide-react';
import { COLORS } from '../../lib/constants';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  text: string;
  action?: React.ReactNode;
  className?: string;
}

export function EmptyState({ icon: Icon, title, text, action, className = '' }: EmptyStateProps) {
  return (
    <div
      className={`rounded-2xl border border-dashed p-10 text-center flex flex-col items-center justify-center ${className}`}
      style={{ borderColor: COLORS.line, backgroundColor: 'rgba(255,255,255,0.6)' }}
    >
      <div
        className="w-12 h-12 rounded-xl mb-3 flex items-center justify-center"
        style={{ backgroundColor: COLORS.paper }}
      >
        <Icon size={22} style={{ color: COLORS.muted }} />
      </div>
      <div className="font-semibold text-base" style={{ color: COLORS.ink }}>
        {title}
      </div>
      <div className="text-sm mt-1 max-w-sm" style={{ color: COLORS.muted }}>
        {text}
      </div>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
