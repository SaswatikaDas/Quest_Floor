import React from 'react';
import { COLORS } from '../../lib/constants';

interface PillProps {
  children?: React.ReactNode;
  label?: string;
  variant?: 'gold' | 'blue' | 'green' | 'coral' | 'purple' | string;
  color?: string;
  bg?: string;
  className?: string;
}

export function Pill({
  children,
  label,
  variant,
  color = COLORS.navy,
  bg,
  className = '',
}: PillProps) {
  let finalColor = color;
  let finalBg = bg;

  if (variant === 'gold') {
    finalColor = '#d97706';
    finalBg = '#fef3c7';
  } else if (variant === 'blue') {
    finalColor = '#2563eb';
    finalBg = '#dbeafe';
  } else if (variant === 'green') {
    finalColor = '#059669';
    finalBg = '#d1fae5';
  } else if (variant === 'coral') {
    finalColor = '#dc2626';
    finalBg = '#fee2e2';
  } else if (variant === 'purple') {
    finalColor = '#7c3aed';
    finalBg = '#ede9fe';
  }

  return (
    <span
      className={`inline-flex items-center text-xs font-semibold px-2.5 py-1 rounded-full ${className}`}
      style={{
        color: finalColor,
        backgroundColor: finalBg || `${finalColor}18`,
      }}
    >
      {label || children}
    </span>
  );
}
