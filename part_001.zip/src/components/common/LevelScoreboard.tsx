'use client';

import React from 'react';
import { Trophy } from 'lucide-react';
import { COLORS, LEVELS } from '../../lib/constants';
import { getLevelInfo } from '../../lib/cxCalculator';
import { ProgressBar } from './ProgressBar';
import { AnimatedNumber } from './AnimatedNumber';

interface LevelScoreboardProps {
  points: number;
  className?: string;
}

export function LevelScoreboard({ points, className = '' }: LevelScoreboardProps) {
  const info = getLevelInfo(points);

  return (
    <div
      className={`rounded-2xl p-6 relative overflow-hidden text-white shadow-md ${className}`}
      style={{
        background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.navy2} 100%)`,
      }}
    >
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div>
          <div className="flex items-center gap-2">
            <span
              className="text-xs uppercase tracking-wider font-bold px-2.5 py-0.5 rounded-full"
              style={{ backgroundColor: `${COLORS.amber}25`, color: COLORS.amber }}
            >
              Level {info.level} · {info.name}
            </span>
          </div>
          <div className="font-mono text-3xl sm:text-4xl font-extrabold text-white mt-2">
            <AnimatedNumber value={points} format={(v) => `${v.toLocaleString('en-IN')} pts`} />
          </div>
        </div>
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-transform hover:scale-105"
          style={{ backgroundColor: COLORS.amber }}
        >
          <Trophy size={28} style={{ color: COLORS.navy }} />
        </div>
      </div>

      <div className="relative z-10 mt-5">
        <div className="flex justify-between mb-2">
          {LEVELS.map((l) => (
            <span
              key={l.level}
              className="text-[11px] font-mono font-semibold"
              style={{
                color: points >= l.min ? COLORS.amber : 'rgba(255,255,255,0.35)',
              }}
            >
              L{l.level} · {l.name}
            </span>
          ))}
        </div>
        <ProgressBar
          pct={info.progressPct}
          color={COLORS.amber}
          height={10}
          track="rgba(255,255,255,0.12)"
        />
      </div>

      <div className="text-sm mt-3 relative z-10" style={{ color: 'rgba(255,255,255,0.75)' }}>
        {info.next ? (
          <>
            You&apos;re{' '}
            <span className="font-bold text-white">
              {info.pointsToNext.toLocaleString('en-IN')} points
            </span>{' '}
            away from <span className="text-amber-400 font-semibold">Level {info.next.level} ({info.next.name})</span>!
          </>
        ) : (
          <span className="text-amber-300 font-semibold">
            🏆 You have reached the ultimate Champion tier! Top 1% retail associate.
          </span>
        )}
      </div>

      {/* Subtle background glow */}
      <div
        className="absolute -bottom-10 -right-10 w-44 h-44 rounded-full blur-3xl opacity-20 pointer-events-none"
        style={{ backgroundColor: COLORS.amber }}
      />
    </div>
  );
}
