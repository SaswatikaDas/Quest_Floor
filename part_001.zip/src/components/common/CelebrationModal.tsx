'use client';

import React from 'react';
import { CelebrationData } from '../../types';
import { COLORS } from '../../lib/constants';

interface CelebrationModalProps {
  celebration: CelebrationData | null;
}

export function CelebrationModal({ celebration }: CelebrationModalProps) {
  if (!celebration) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm pointer-events-none transition-all">
      <div
        className="rounded-3xl p-8 text-center shadow-2xl border pointer-events-auto transform scale-100 transition-all duration-300 max-w-sm w-full"
        style={{
          background: `linear-gradient(145deg, ${COLORS.navy}, ${COLORS.plum})`,
          borderColor: 'rgba(255,255,255,0.15)',
        }}
      >
        <div className="text-6xl mb-3 animate-bounce">{celebration.emoji}</div>
        <div
          className="text-xs uppercase tracking-widest font-extrabold"
          style={{ color: COLORS.amber }}
        >
          {celebration.eyebrow}
        </div>
        <div className="text-2xl font-bold text-white mt-1.5">{celebration.title}</div>
        {celebration.sub && (
          <div className="text-sm mt-2 font-medium" style={{ color: 'rgba(255,255,255,0.85)' }}>
            {celebration.sub}
          </div>
        )}
      </div>
    </div>
  );
}
