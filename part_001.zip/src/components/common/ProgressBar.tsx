import React from 'react';
import { COLORS } from '../../lib/constants';

interface ProgressBarProps {
  pct: number;
  color?: string;
  height?: number;
  track?: string;
  className?: string;
}

export function ProgressBar({
  pct,
  color = COLORS.amber,
  height = 8,
  track = '#EEEEF6',
  className = '',
}: ProgressBarProps) {
  const safePct = Math.min(100, Math.max(0, isNaN(pct) ? 0 : pct));

  return (
    <div
      className={`w-full rounded-full overflow-hidden ${className}`}
      style={{ height, backgroundColor: track }}
    >
      <div
        className="h-full rounded-full transition-all duration-700 ease-out"
        style={{ width: `${safePct}%`, backgroundColor: color }}
      />
    </div>
  );
}
