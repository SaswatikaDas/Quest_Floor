'use client';

import React from 'react';
import { BarChart3, TrendingUp, Heart, Zap, Star } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Avatar } from '../common/Avatar';
import { ProgressBar } from '../common/ProgressBar';
import { COLORS } from '../../lib/constants';
import { trainingPct, getStoreName } from '../../lib/cxCalculator';

export function ManagerPerformance() {
  const { currentManager, stores, employees, trainingModules } = useAppStore();

  const managedEmployees = employees.filter((e) => currentManager.stores.includes(e.storeId));
  const sorted = [...managedEmployees].sort((a, b) => b.engagementScore - a.engagementScore);

  return (
    <div className="space-y-6 pb-12">
      <SectionHeader
        title="Associate Performance &amp; Engagement Matrix"
        subtitle="Ranked by overall morale and operational consistency"
      />

      <div className="space-y-4">
        {sorted.map((emp, index) => {
          const trnPct = trainingPct(emp, trainingModules);

          return (
            <div
              key={emp.id}
              className="bg-white rounded-3xl p-6 border shadow-xs transition-all hover:shadow-md"
              style={{ borderColor: COLORS.line }}
            >
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
                {/* Left: Associate Bio & Rank */}
                <div className="flex items-center gap-3.5 min-w-[220px]">
                  <span className="font-mono text-sm font-extrabold text-slate-400 w-6">
                    #{index + 1}
                  </span>
                  <Avatar name={emp.name} color={emp.color} size={44} />
                  <div>
                    <div className="font-bold text-base text-slate-900 leading-tight">
                      {emp.name}
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {getStoreName(stores, emp.storeId)}
                    </div>
                  </div>
                </div>

                {/* Right: 4 Metrics Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 flex-1 w-full">
                  {/* Training */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-500">
                      <span>Curriculum</span>
                      <span className="font-mono text-teal-600">{trnPct}%</span>
                    </div>
                    <ProgressBar pct={trnPct} color={COLORS.teal} height={6} />
                  </div>

                  {/* POS */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-500">
                      <span>POS Usage</span>
                      <span className="font-mono text-amber-600">{emp.posAdoption}%</span>
                    </div>
                    <ProgressBar pct={emp.posAdoption} color={COLORS.amberDeep} height={6} />
                  </div>

                  {/* Sales */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-500">
                      <span>Sales Conv.</span>
                      <span className="font-mono text-coral-600">{emp.salesConversion}%</span>
                    </div>
                    <ProgressBar pct={emp.salesConversion} color={COLORS.coral} height={6} />
                  </div>

                  {/* Engagement */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-500">
                      <span>Engagement</span>
                      <span className="font-mono text-purple-600">{emp.engagementScore}%</span>
                    </div>
                    <ProgressBar pct={emp.engagementScore} color={COLORS.plum} height={6} />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
