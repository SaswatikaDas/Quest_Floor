'use client';

import React from 'react';
import { MapPin, Store as StoreIcon, BarChart3, TrendingUp, Users } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';
import { calculateCX, trainingPct, avg } from '../../lib/cxCalculator';

export function StoreAnalytics() {
  const { currentManager, stores, employees, trainingModules } = useAppStore();

  const managedStores = stores.filter((s) => currentManager.stores.includes(s.id));

  const comparisonData = managedStores.map((s) => {
    const storeEmps = employees.filter((e) => e.storeId === s.id);
    const cx = calculateCX(storeEmps, trainingModules);
    const trn = avg(storeEmps.map((e) => trainingPct(e, trainingModules)));
    const pos = avg(storeEmps.map((e) => e.posAdoption));
    const csat = avg(storeEmps.map((e) => e.customerFeedbackScore));

    return {
      name: s.city,
      cx: cx.score,
      training: trn,
      pos: pos,
      csat: csat,
      count: storeEmps.length,
    };
  });

  return (
    <div className="space-y-6 pb-12">
      <SectionHeader
        title="Multi-Store Comparative Analytics"
        subtitle="Benchmark customer experience, training adoption, and POS usage across your assigned regional stores"
      />

      {/* Store Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {managedStores.map((s) => {
          const storeEmps = employees.filter((e) => e.storeId === s.id);
          const cx = calculateCX(storeEmps, trainingModules);

          return (
            <div
              key={s.id}
              className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4"
              style={{ borderColor: COLORS.line }}
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-bold text-base" style={{ color: COLORS.ink }}>
                    <MapPin size={17} className="text-teal-600" />
                    <span>{s.city} ({s.state})</span>
                  </div>
                  <Pill color={cx.color}>
                    {cx.label} ({cx.score}/100)
                  </Pill>
                </div>
                <div className="text-xs text-slate-500 mt-1">{s.name}</div>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-100 text-center font-mono">
                <div className="bg-slate-50 p-2.5 rounded-xl">
                  <div className="text-[10px] text-slate-400 font-sans font-bold">Associates</div>
                  <div className="text-sm font-extrabold text-slate-900 mt-0.5">{storeEmps.length}</div>
                </div>
                <div className="bg-teal-50 p-2.5 rounded-xl">
                  <div className="text-[10px] text-teal-600 font-sans font-bold">Training</div>
                  <div className="text-sm font-extrabold text-teal-700 mt-0.5">
                    {avg(storeEmps.map((e) => trainingPct(e, trainingModules)))}%
                  </div>
                </div>
                <div className="bg-amber-50 p-2.5 rounded-xl">
                  <div className="text-[10px] text-amber-600 font-sans font-bold">POS %</div>
                  <div className="text-sm font-extrabold text-amber-700 mt-0.5">
                    {avg(storeEmps.map((e) => e.posAdoption))}%
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Comparative Multi-Bar Chart */}
      <div className="bg-white rounded-3xl p-6 border shadow-xs" style={{ borderColor: COLORS.line }}>
        <SectionHeader
          title="Direct Store Metric Benchmarking"
          subtitle="Customer Experience (CX), Micro-Training %, and POS Adoption"
        />

        <div style={{ height: 300 }} className="w-full mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={comparisonData} barGap={6}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.line} vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: COLORS.ink, fontWeight: 700 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: COLORS.muted }} axisLine={false} tickLine={false} domain={[0, 100]} />
              <Tooltip cursor={{ fill: 'rgba(245,245,251,0.6)' }} />
              <Legend wrapperStyle={{ fontSize: 12, paddingTop: 10 }} />
              <Bar dataKey="cx" name="CX Score" fill={COLORS.navy3} radius={[6, 6, 0, 0]} />
              <Bar dataKey="training" name="Training %" fill={COLORS.teal} radius={[6, 6, 0, 0]} />
              <Bar dataKey="pos" name="POS Adoption %" fill={COLORS.amberDeep} radius={[6, 6, 0, 0]} />
              <Bar dataKey="csat" name="Customer CSAT %" fill={COLORS.coral} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
