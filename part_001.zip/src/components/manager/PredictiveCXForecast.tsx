'use client';

import React, { useState } from 'react';
import {
  TrendingUp,
  Brain,
  AlertTriangle,
  Rocket,
  CheckCircle2,
  Calendar,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { RootCauseInsight } from '../../types';
import { COLORS } from '../../lib/constants';

const PREDICTIVE_SERIES = [
  { day: 'Mon', actualCX: 74, predictedCX: 74, revenueEst: 140 },
  { day: 'Tue', actualCX: 76, predictedCX: 76, revenueEst: 152 },
  { day: 'Wed', actualCX: 79, predictedCX: 80, revenueEst: 168 },
  { day: 'Thu (Today)', actualCX: 82, predictedCX: 83, revenueEst: 185 },
  { day: 'Fri (Pred)', actualCX: null, predictedCX: 86, revenueEst: 210 },
  { day: 'Sat (Pred)', actualCX: null, predictedCX: 89, revenueEst: 245 },
  { day: 'Sun (Pred)', actualCX: null, predictedCX: 92, revenueEst: 280 },
];

const ROOT_CAUSES: RootCauseInsight[] = [
  {
    id: 'rc-1',
    storeId: 's1',
    counterOrShift: 'Evening Rush Counter 2 (6–8 PM)',
    bottleneck: '18% slower returns processing due to missing Split-Tender POS training.',
    impactScore: 82,
    aiPrescription: 'Assign the 5-min POS Advanced: Loyalty & Split Payments module to 2 floor associates.',
    playbookTitle: '3-Day POS Speed & Customer Return Recovery Sprint',
  },
  {
    id: 'rc-2',
    storeId: 's2',
    counterOrShift: 'Apparel Fitting Rooms',
    bottleneck: 'Lower upsell conversion on festive ethnic wear due to size chart confusion.',
    impactScore: 74,
    aiPrescription: 'Deploy digital size chart QR cards to fitting room doors and assign module m1.',
    playbookTitle: 'Festive Basket Size Expansion Playbook',
  },
];

export function PredictiveCXForecast() {
  const { showToast, fireCelebration } = useAppStore();
  const [activePlaybook, setActivePlaybook] = useState<string | null>(null);

  const launchPlaybook = (rc: RootCauseInsight) => {
    setActivePlaybook(rc.id);
    setTimeout(() => {
      showToast(`Playbook "${rc.playbookTitle}" launched across store floor!`, '🚀');
      fireCelebration({
        emoji: '🔮',
        eyebrow: 'Autonomous AI Playbook Dispatched!',
        title: rc.playbookTitle,
        sub: 'Shift briefings & micro-lessons assigned automatically',
      });
    }, 800);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.plum} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Predictive AI Forecasting
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Next 72-Hour Horizon</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Predictive Store CX &amp; Root-Cause Playbooks
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Forecast customer satisfaction and store revenue trajectories before weekend rush hours. Proactively dispatch 3-day recovery playbooks to resolve operational bottlenecks.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">Weekend Projected CX</div>
          <div className="text-2xl font-extrabold text-amber-300 mt-0.5">92 / 100</div>
        </div>
      </div>

      {/* 7-Day Line Chart */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
        <SectionHeader
          title="7-Day Predictive CX Index &amp; Revenue Projection"
          subtitle="Machine learning model correlating floor micro-training pacing with expected weekend sales"
        />

        <div style={{ height: 300 }} className="w-full mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={PREDICTIVE_SERIES}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.line} vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: COLORS.muted, fontWeight: 600 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: COLORS.muted }} axisLine={false} tickLine={false} domain={[60, 100]} />
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 12, paddingTop: 10 }} />
              <Line type="monotone" dataKey="actualCX" name="Historical CX" stroke={COLORS.teal} strokeWidth={3} dot={{ r: 5 }} />
              <Line type="monotone" dataKey="predictedCX" name="AI Projected CX" stroke={COLORS.plum} strokeWidth={3} strokeDasharray="5 5" dot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Root-Cause Bottleneck Cards with 1-Click Playbooks */}
      <div className="space-y-4">
        <SectionHeader
          title="AI Root-Cause Bottleneck Diagnostics"
          subtitle="Automated floor shift friction detection with 1-click recovery playbooks"
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {ROOT_CAUSES.map((rc) => {
            const isLaunched = activePlaybook === rc.id;
            return (
              <div
                key={rc.id}
                className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4"
                style={{ borderColor: COLORS.line }}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-500 font-mono flex items-center gap-1.5">
                      <Calendar size={13} className="text-purple-600" />
                      {rc.counterOrShift}
                    </span>
                    <Pill color={COLORS.coral}>Impact: {rc.impactScore}%</Pill>
                  </div>

                  <h3 className="font-bold text-base text-slate-900 mt-1 leading-snug">{rc.playbookTitle}</h3>
                  <div className="p-3 rounded-2xl bg-red-50/60 border border-red-200 text-xs text-red-950 mt-2.5 font-medium leading-relaxed">
                    <strong>⚠️ Bottleneck:</strong> {rc.bottleneck}
                  </div>

                  <div className="p-3 rounded-2xl bg-teal-50/60 border border-teal-200 text-xs text-teal-950 mt-2 font-medium leading-relaxed">
                    <strong>💡 AI Prescription:</strong> {rc.aiPrescription}
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => launchPlaybook(rc)}
                    disabled={isLaunched}
                    className={`w-full py-3 rounded-2xl font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all ${
                      isLaunched
                        ? 'bg-teal-50 text-teal-700 border border-teal-300 cursor-default'
                        : 'bg-slate-900 text-white hover:bg-slate-800'
                    }`}
                  >
                    {isLaunched ? (
                      <>
                        <CheckCircle2 size={16} /> Playbook Active on Store Floor
                      </>
                    ) : (
                      <>
                        <Rocket size={16} className="text-amber-400" />
                        <span>Launch 3-Day Recovery Playbook</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
