'use client';

import React from 'react';
import { GraduationCap, Clock, Star, BookOpen } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';

interface TrainingOverviewProps {
  title?: string;
  subtitle?: string;
  scopeFilter?: 'manager' | 'all';
}

export function TrainingOverview({
  title = 'Micro-Curriculum Completion Overview',
  subtitle = 'Module-by-module breakdown across associate roster',
  scopeFilter = 'manager',
}: TrainingOverviewProps) {
  const { currentManager, employees, trainingModules, role } = useAppStore();

  const relevantEmployees =
    scopeFilter === 'manager' && role === 'manager'
      ? employees.filter((e) => currentManager.stores.includes(e.storeId))
      : employees;

  const chartData = trainingModules.map((m) => {
    const completedCount = relevantEmployees.filter((e) => e.completedModules.includes(m.id)).length;
    const pct = relevantEmployees.length
      ? Math.round((completedCount / relevantEmployees.length) * 100)
      : 0;

    return {
      name: m.title.length > 20 ? `${m.title.slice(0, 18)}…` : m.title,
      fullName: m.title,
      pct,
      category: m.category,
    };
  });

  return (
    <div className="space-y-6 pb-12">
      <SectionHeader title={title} subtitle={subtitle} />

      {/* Horizontal Bar Chart */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs" style={{ borderColor: COLORS.line }}>
        <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
          Associate Completion Rate by Module (%)
        </div>

        <div style={{ height: 360 }} className="w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" margin={{ left: 20, right: 30 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.line} horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: COLORS.muted }} axisLine={false} tickLine={false} />
              <YAxis
                type="category"
                dataKey="name"
                width={170}
                tick={{ fontSize: 11, fill: COLORS.ink, fontWeight: 600 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                cursor={{ fill: 'rgba(245,245,251,0.6)' }}
                formatter={(val) => [`${val}% of associates`, 'Completed']}
              />
              <Bar dataKey="pct" name="Completion Rate" fill={COLORS.plum} radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Modules Catalog Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {trainingModules.map((m) => {
          const completedCount = relevantEmployees.filter((e) => e.completedModules.includes(m.id)).length;
          const pct = relevantEmployees.length
            ? Math.round((completedCount / relevantEmployees.length) * 100)
            : 0;

          return (
            <div
              key={m.id}
              className="bg-white rounded-3xl p-5 border shadow-xs flex items-center gap-3.5"
              style={{ borderColor: COLORS.line }}
            >
              <div className="text-3xl p-2 rounded-2xl bg-slate-50 border border-slate-100 shrink-0">
                {m.emoji}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <Pill color={COLORS.teal}>{m.category}</Pill>
                  <span className="font-mono text-xs font-bold text-slate-700">{pct}%</span>
                </div>
                <div className="font-bold text-sm truncate mt-1 text-slate-900">{m.title}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{m.duration} · +{m.points} XP</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
