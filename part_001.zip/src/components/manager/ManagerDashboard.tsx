'use client';

import React, { useState, useEffect } from 'react';
import {
  Users,
  GraduationCap,
  Zap,
  Heart,
  AlertTriangle,
  ShieldCheck,
  TrendingUp,
  ArrowRight,
  Sparkles,
  Target,
  CheckCircle2,
  Brain,
  ShoppingCart,
  Star,
  Clock,
  Check,
  X,
  UserCheck,
  Settings,
  Mic,
  Volume2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { useAppStore } from '../../lib/store/useAppStore';
import { StatCard } from '../common/StatCard';
import { SectionHeader } from '../common/SectionHeader';
import { EmptyState } from '../common/EmptyState';
import { Avatar } from '../common/Avatar';
import { Pill } from '../common/Pill';
import { ProgressBar } from '../common/ProgressBar';
import { COLORS, WEEKLY_TREND } from '../../lib/constants';
import { calculateCX, trainingPct, getStoreName, avg } from '../../lib/cxCalculator';
import { api } from '../../lib/api';
import { ManagerProfileModal } from './ManagerProfileModal';

export function ManagerDashboard() {
  const {
    currentManager,
    stores,
    employees,
    trainingModules,
    pendingRegistrations,
    approveRegistration,
    rejectRegistration,
    managerProfile,
    setScreen,
    showToast,
    fireCelebration,
    theme,
  } = useAppStore();

  const isDark = theme === 'dark';
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [aiInsights, setAiInsights] = useState<{
    executive_summary?: string;
    high_priority_interventions?: any[];
    coaching_talking_points?: string[];
  } | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const primaryStore = stores.find((s) => s.id === 's1') || stores[0];
  const managedEmployees = employees.filter((e) => e.storeId === primaryStore.id || e.storeId === 's1');

  const cx = calculateCX(managedEmployees, trainingModules);

  const trainingData = [
    { name: 'Amit', training: 95, pos: 92, upsell: 24 },
    { name: 'Sneha', training: 92, pos: 82, upsell: 22 },
    { name: 'Rahul', training: 40, pos: 58, upsell: 11 },
    { name: 'Vikram', training: 98, pos: 93, upsell: 28 },
  ];

  const handleGenerateAIInsights = async () => {
    setLoadingInsights(true);
    const res = await api.generateManagerInsights('s104', {
      training_completion_rate: managerProfile.targetTrainingRate || 92.0,
      pos_adoption_rate: managerProfile.targetPosRate || 87.0,
      customer_satisfaction: 4.6,
      upsell_conversion_rate: 18.0,
    });
    setLoadingInsights(false);
    if (res) {
      setAiInsights(res);
      showToast('✨ AI Manager Insights & Coaching Playbook Generated!');
    }
  };

  const handleSpeakSummary = (text: string) => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.onend = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleAssignChallengeToAssociate = async (empId: string, empName: string) => {
    await api.assignNudge('s104', empId, '2-Minute POS Split-Billing Challenge');
    fireCelebration({
      emoji: '🎯',
      eyebrow: 'Targeted Intervention Dispatched!',
      title: `Challenge Sent to ${empName}`,
      sub: '+50 XP Skill-Gap Challenge Assigned',
    });
  };

  return (
    <div className="space-y-6 pb-12 transition-colors duration-200">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Store Manager Dashboard — {managerProfile.storeName}
            </h2>
            <Pill color={COLORS.amber}>Manager: {managerProfile.name}</Pill>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Shift: {managerProfile.shiftHours} • Focus: {managerProfile.coachingFocus}
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsProfileModalOpen(true)}
            className="px-3.5 py-2 rounded-xl text-xs font-bold border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 shadow-xs flex items-center gap-1.5 transition-all"
          >
            <Settings size={14} className="text-slate-400" />
            <span>Profile &amp; Shift Targets</span>
          </button>

          <button
            onClick={handleGenerateAIInsights}
            disabled={loadingInsights}
            className="px-4 py-2 rounded-xl text-xs font-bold text-white shadow-md bg-gradient-to-r from-teal-500 to-indigo-600 hover:from-teal-600 hover:to-indigo-700 flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-60"
          >
            <Sparkles size={14} />
            <span>{loadingInsights ? 'Analyzing Store...' : '✨ GenAI Coaching Copilot'}</span>
          </button>
        </div>
      </div>

      {/* ── 🔔 PENDING ASSOCIATE VERIFICATION QUEUE ─────────────────────── */}
      {pendingRegistrations.length > 0 && (
        <div className="p-5 sm:p-6 rounded-3xl bg-amber-500/10 border-2 border-amber-500/40 text-slate-900 dark:text-white shadow-lg space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold">
                <UserCheck size={20} />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-amber-600 dark:text-amber-400">
                  New Associate Registration Requests ({pendingRegistrations.length})
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  New associates registered online. Verify and approve to grant dashboard access &amp; +100 XP onboarding bonus.
                </p>
              </div>
            </div>

            <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-500 text-slate-950">
              Action Required
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
            {pendingRegistrations.map((p) => (
              <div
                key={p.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-amber-500/30 shadow-xs flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <Avatar name={p.name} color={p.avatarColor || COLORS.amber} size={40} />
                  <div>
                    <div className="text-xs font-extrabold text-slate-900 dark:text-white">
                      {p.name}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono">{p.email}</div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <Clock size={11} />
                      <span>{p.joinDate}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => approveRegistration(p.id)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 shadow-xs transition-all active:scale-95"
                  >
                    <Check size={14} />
                    <span>Approve (+100 XP)</span>
                  </button>

                  <button
                    onClick={() => rejectRegistration(p.id)}
                    className="p-1.5 rounded-xl bg-rose-100 dark:bg-rose-950/60 hover:bg-rose-200 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 transition-colors"
                    title="Reject Request"
                  >
                    <X size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5 Core Store #104 KPI Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        <StatCard
          icon={GraduationCap}
          label="Training Completion"
          value={`${managerProfile.targetTrainingRate || 92}%`}
          sub="Target: 90%+ (Met)"
          accent={COLORS.teal}
        />
        <StatCard
          icon={Zap}
          label="POS Adoption"
          value={`${managerProfile.targetPosRate || 87}%`}
          sub="Speed billing active"
          accent={COLORS.amberDeep}
        />
        <StatCard
          icon={Star}
          label="Customer Rating"
          value="4.6 / 5.0"
          sub="5-Star CSAT feedback"
          accent={COLORS.plum}
        />
        <StatCard
          icon={ShoppingCart}
          label="Upsell Conversion"
          value="18%"
          sub="Target: 24% (Earbuds combo)"
          accent={COLORS.navy2}
        />
        <StatCard
          icon={Users}
          label="Active Associates"
          value={String(managedEmployees.length)}
          sub="100% on duty shift"
          accent={COLORS.coral}
        />
      </div>

      {/* AI Manager Insights Card with Voice Playback */}
      {aiInsights && (
        <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border border-purple-500/40 text-white shadow-xl space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-sm text-purple-300">
              <Brain className="w-5 h-5 text-purple-400" />
              <span>AI Manager Executive Diagnostic &amp; Talking Points</span>
            </div>

            <button
              onClick={() => handleSpeakSummary(aiInsights.executive_summary || '')}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30 text-xs font-bold transition-all"
            >
              <Volume2 size={14} className={isSpeaking ? 'animate-bounce text-amber-300' : ''} />
              <span>{isSpeaking ? 'Stop Audio' : '🔊 Voice Readout'}</span>
            </button>
          </div>

          <p className="text-xs text-slate-200 leading-relaxed bg-slate-950/60 p-3.5 rounded-2xl border border-purple-900/40">
            {aiInsights.executive_summary}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                🎯 High Priority Interventions
              </h4>
              {aiInsights.high_priority_interventions?.map((item: any, i: number) => (
                <div key={i} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-1">
                  <div className="font-bold text-white flex items-center justify-between">
                    <span>{item.target}</span>
                    <span className="text-[10px] text-rose-400 font-mono">{item.severity}</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">{item.suggested_action}</p>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-teal-400 uppercase tracking-wider">
                🗣️ Morning Huddle Talking Points
              </h4>
              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-2">
                {aiInsights.coaching_talking_points?.map((tp: string, i: number) => (
                  <div key={i} className="flex items-start gap-2 text-slate-300 text-[11px]">
                    <span className="text-teal-400 font-bold">•</span>
                    <span>{tp}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Outlier Diagnosis: Rahul Verma 40% vs Store 92% */}
      <div className="rounded-3xl p-6 border shadow-xs space-y-4 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white">
        <SectionHeader
          title="Floor Attention &amp; Lagging Skill Matrix"
          subtitle="Outlier associates requiring consultative micro-coaching or POS split-tender drills"
        />

        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold">
              <AlertTriangle size={20} />
            </div>
            <div>
              <div className="text-sm font-extrabold">
                Rahul Verma — Training Lagging at 40% (Store Avg: 92%)
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                POS Adoption: 58% · Diagnostic: Struggles with split payments and seasonal combo pricing.
              </div>
            </div>
          </div>

          <button
            onClick={() => handleAssignChallengeToAssociate('e2', 'Rahul Verma')}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-xs font-bold shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all active:scale-95 shrink-0"
          >
            <Sparkles size={14} />
            <span>Dispatch 2-Min POS Nudge (+50 XP)</span>
          </button>
        </div>
      </div>

      {/* Charts & Associate Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-3xl p-6 border shadow-xs space-y-4 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white">
          <SectionHeader
            title="Skill Metrics by Associate"
            subtitle="Training completion vs POS adoption vs Upsell conversion rate"
          />
          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={trainingData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '12px',
                    color: '#fff',
                  }}
                />
                <Legend />
                <Bar dataKey="training" name="Training %" fill="#0d9488" radius={[6, 6, 0, 0]} />
                <Bar dataKey="pos" name="POS Adoption %" fill="#f59e0b" radius={[6, 6, 0, 0]} />
                <Bar dataKey="upsell" name="Upsell %" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-3xl p-6 border shadow-xs space-y-4 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white">
          <SectionHeader
            title="Store CX &amp; CSAT 7-Day Trajectory"
            subtitle="Customer satisfaction score trend across 1,200 store network"
          />
          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={WEEKLY_TREND}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={12} />
                <YAxis domain={[70, 100]} stroke="#94a3b8" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '12px',
                    color: '#fff',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="cx"
                  name="Store CX Index"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{ r: 5, fill: '#10b981' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Manager Profile Modal */}
      <ManagerProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />
    </div>
  );
}
