'use client';

import React from 'react';
import { Users, AlertTriangle, Send, CheckCircle2, Award } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Avatar } from '../common/Avatar';
import { ProgressBar } from '../common/ProgressBar';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';
import { trainingPct, getStoreName } from '../../lib/cxCalculator';

export function ManagerEmployees() {
  const { currentManager, stores, employees, trainingModules, nudgeEmployee } = useAppStore();

  const managedEmployees = employees.filter((e) => currentManager.stores.includes(e.storeId));

  return (
    <div className="space-y-6 pb-12">
      <SectionHeader
        title={`Cluster Associate Directory (${managedEmployees.length})`}
        subtitle="Live tracking of micro-learning progress, digital POS adoption, and points"
      />

      <div className="bg-white rounded-3xl border shadow-xs overflow-hidden" style={{ borderColor: COLORS.line }}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm" style={{ minWidth: 720 }}>
            <thead>
              <tr className="border-b bg-slate-50/70" style={{ borderColor: COLORS.line }}>
                <th className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Associate Name
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Store
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Training Progress
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  POS Adoption
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Points (XP)
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Badges
                </th>
                <th className="px-6 py-4 text-right font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Action
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {managedEmployees.map((emp) => {
                const trnPct = trainingPct(emp, trainingModules);
                const isPosLow = emp.posAdoption < 55;
                const isTrnLow = trnPct < 50;

                return (
                  <tr key={emp.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <Avatar name={emp.name} color={emp.color} size={34} />
                        <div>
                          <div className="font-bold text-slate-900">{emp.name}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{emp.email}</div>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-4 font-medium text-slate-600">
                      {getStoreName(stores, emp.storeId)}
                    </td>

                    <td className="px-4 py-4">
                      <div className="space-y-1 w-28">
                        <div className="flex justify-between text-[11px] font-mono font-bold">
                          <span style={{ color: isTrnLow ? COLORS.coral : COLORS.teal }}>
                            {trnPct}%
                          </span>
                        </div>
                        <ProgressBar
                          pct={trnPct}
                          color={isTrnLow ? COLORS.coral : COLORS.teal}
                          height={6}
                        />
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <span
                        className={`font-mono font-bold px-2 py-0.5 rounded-full text-xs ${
                          isPosLow ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-700'
                        }`}
                      >
                        {emp.posAdoption}%
                      </span>
                    </td>

                    <td className="px-4 py-4 font-mono font-bold text-slate-800">
                      {emp.points.toLocaleString('en-IN')} XP
                    </td>

                    <td className="px-4 py-4 font-semibold text-slate-600 flex items-center gap-1 mt-3">
                      <Award size={14} className="text-purple-600" />
                      <span>{emp.badges.length}</span>
                    </td>

                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => nudgeEmployee(emp)}
                        className="px-3 py-1.5 rounded-xl font-bold text-xs bg-slate-100 hover:bg-amber-50 hover:text-amber-800 text-slate-700 border border-slate-200 transition-all shadow-xs"
                      >
                        Nudge / Remind
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
