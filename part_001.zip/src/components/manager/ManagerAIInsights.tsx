'use client';

import React, { useState } from 'react';
import {
  Brain,
  Rocket,
  CheckCircle2,
  Circle,
  RefreshCw,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Avatar } from '../common/Avatar';
import { ProgressBar } from '../common/ProgressBar';
import { SkillGraphDiagram } from '../diagrams/SkillGraphDiagram';
import { COLORS } from '../../lib/constants';
import { primarySkillGap } from '../../lib/aiEngine';
import { getStoreName } from '../../lib/cxCalculator';

const INTERVENTION_STEPS = [
  'Analyzing store associate telemetry & POS logs…',
  'Isolating primary operational skill gaps…',
  'Synthesizing tailored micro-curriculum assignments…',
  'Automated AI Interventions Dispatched ✓',
];

export function ManagerAIInsights() {
  const { currentManager, stores, employees, trainingModules, nudgeEmployee } = useAppStore();
  const [running, setRunning] = useState(false);
  const [stepIndex, setStepIndex] = useState(-1);

  const managedEmployees = employees.filter((e) => currentManager.stores.includes(e.storeId));

  const withGaps = managedEmployees
    .map((e) => ({ emp: e, gap: primarySkillGap(e, trainingModules) }))
    .sort((a, b) => a.gap.score - b.gap.score);

  const atRisk = withGaps.filter((w) => w.gap.score < 65).map((w) => w.emp);
  const spotlight = withGaps[0];

  const launchIntervention = () => {
    setRunning(true);
    setStepIndex(0);

    INTERVENTION_STEPS.forEach((_, i) => {
      setTimeout(() => setStepIndex(i), (i + 1) * 700);
    });

    setTimeout(() => {
      atRisk.forEach((e) => nudgeEmployee(e));
    }, INTERVENTION_STEPS.length * 700);

    setTimeout(() => setRunning(false), INTERVENTION_STEPS.length * 700 + 1500);
  };

  return (
    <div className="space-y-6 pb-12">
      <SectionHeader
        title="AI Manager Assistant &amp; Skill Diagnostics"
        subtitle="Automatic detection of retail skill gaps with 1-click tailored intervention workflows"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Associate Skill Gap Ranking */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 border shadow-xs" style={{ borderColor: COLORS.line }}>
          <SectionHeader
            title="Identified Skill Gaps by Associate"
            subtitle="Sorted by lowest proficiency metric requiring coaching"
          />

          <div className="space-y-3 mt-4">
            {withGaps.map(({ emp, gap }) => {
              const isAtRisk = gap.score < 65;
              return (
                <div
                  key={emp.id}
                  className={`rounded-2xl p-4 border flex items-center justify-between gap-4 transition-colors ${
                    isAtRisk ? 'bg-red-50/40 border-red-200' : 'bg-slate-50/60 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar name={emp.name} color={emp.color} size={36} />
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-slate-900 truncate">{emp.name}</div>
                      <div className="text-xs text-slate-500 truncate">
                        {getStoreName(stores, emp.storeId)}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-32 text-right">
                      <div className="flex items-center justify-between text-xs mb-1 font-bold">
                        <span className="text-slate-500">{gap.skill}</span>
                        <span className="font-mono" style={{ color: isAtRisk ? COLORS.coral : COLORS.teal }}>
                          {gap.score}%
                        </span>
                      </div>
                      <ProgressBar
                        pct={gap.score}
                        color={isAtRisk ? COLORS.coral : COLORS.teal}
                        height={6}
                      />
                    </div>

                    {isAtRisk && <AlertTriangle size={18} className="text-red-500 shrink-0" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: 1-Click AI Intervention Launcher */}
        <div
          className="rounded-3xl p-6 text-white shadow-md flex flex-col justify-between"
          style={{
            background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.plum} 100%)`,
          }}
        >
          <div>
            <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-amber-400">
              <Brain size={16} /> Autonomous AI Manager
            </div>

            <h3 className="text-xl font-bold text-white mt-2">1-Click Team Intervention</h3>
            <p className="text-xs text-white/70 mt-1 leading-relaxed">
              Dispatches targeted micro-curriculums and POS practice missions directly to {atRisk.length} flagged associates.
            </p>
          </div>

          <div className="my-6">
            {!running ? (
              <button
                onClick={launchIntervention}
                disabled={atRisk.length === 0}
                className="w-full bg-white rounded-2xl py-3.5 text-sm font-extrabold text-slate-900 shadow-md flex items-center justify-center gap-2 hover:bg-slate-100 transition-all disabled:opacity-50"
              >
                <Rocket size={17} className="text-purple-600" />
                <span>Launch AI Intervention ({atRisk.length} Associates)</span>
              </button>
            ) : (
              <div className="space-y-2.5 bg-black/20 p-4 rounded-2xl border border-white/10">
                {INTERVENTION_STEPS.map((step, i) => {
                  const isDone = i < stepIndex;
                  const isCurrent = i === stepIndex;
                  return (
                    <div
                      key={step}
                      className="flex items-center gap-2.5 text-xs transition-opacity duration-200"
                      style={{ opacity: i <= stepIndex ? 1 : 0.35 }}
                    >
                      {isDone ? (
                        <CheckCircle2 size={15} className="text-amber-400 shrink-0" />
                      ) : isCurrent ? (
                        <RefreshCw size={15} className="animate-spin text-amber-400 shrink-0" />
                      ) : (
                        <Circle size={15} className="text-white/30 shrink-0" />
                      )}
                      <span className="font-medium text-white">{step}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="text-[11px] text-white/60 text-center font-mono">
            Empowering store managers across 1,200 stores
          </div>
        </div>
      </div>

      {/* Spotlight Associate Skill Graph */}
      {spotlight && (
        <div className="bg-white rounded-3xl p-6 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
          <SectionHeader
            title={`Spotlight Skill Graph: ${spotlight.emp.name}`}
            subtitle="Automated DAG tracing diagnosis to tailored training and verification"
          />
          <SkillGraphDiagram employee={spotlight.emp} modules={trainingModules} />
        </div>
      )}
    </div>
  );
}
