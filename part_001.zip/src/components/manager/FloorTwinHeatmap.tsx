'use client';

import React, { useState } from 'react';
import {
  MapPin,
  Users,
  Flame,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Zap,
  TrendingUp,
  RotateCcw,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { AnimatedNumber } from '../common/AnimatedNumber';
import { FloorZone, StaffAllocationSim } from '../../types';
import { COLORS } from '../../lib/constants';

const INITIAL_ZONES: FloorZone[] = [
  {
    id: 'z-entrance',
    name: '1. Festive Entrance Display Table',
    footfallDensity: 'Low',
    customerCount: 8,
    assignedAssociates: ['Ayesha Khan'],
    zoneColor: '#0E8C82',
  },
  {
    id: 'z-ethnic',
    name: '2. Ethnic Wear & Kurtas Aisle',
    footfallDensity: 'Moderate',
    customerCount: 19,
    assignedAssociates: ['Vikram Singh'],
    zoneColor: '#6C3FA0',
  },
  {
    id: 'z-gifting',
    name: '3. Gifting & Diya Hamper Island',
    footfallDensity: 'High',
    customerCount: 26,
    assignedAssociates: [],
    frictionType: 'Unattended Gifting Shoppers',
    zoneColor: '#F3A712',
  },
  {
    id: 'z-pos',
    name: '4. Digital POS Billing Counters (1 & 2)',
    footfallDensity: 'Critical Bottleneck',
    customerCount: 38,
    assignedAssociates: ['Rahul Verma'],
    frictionType: 'Long Billing Queue',
    zoneColor: '#EF5A4C',
  },
  {
    id: 'z-fitting',
    name: '5. Fitting Rooms & Tailoring Desk',
    footfallDensity: 'Moderate',
    customerCount: 14,
    assignedAssociates: ['Sneha Patil'],
    zoneColor: '#232C63',
  },
];

export function FloorTwinHeatmap() {
  const { showToast, fireCelebration } = useAppStore();

  const [zones, setZones] = useState<FloorZone[]>(INITIAL_ZONES);
  const [selectedAssociate, setSelectedAssociate] = useState<string>('Sneha Patil');
  const [isReallocated, setIsReallocated] = useState<boolean>(false);

  const reallocateAssociate = (targetZoneId: string) => {
    setZones((prev) =>
      prev.map((z) => {
        const withoutAssoc = z.assignedAssociates.filter((a) => a !== selectedAssociate);
        if (z.id === targetZoneId) {
          return {
            ...z,
            assignedAssociates: [...withoutAssoc, selectedAssociate],
            footfallDensity: z.footfallDensity === 'Critical Bottleneck' ? 'Moderate' : z.footfallDensity,
            frictionType: z.id === 'z-pos' ? 'Smooth' : z.frictionType,
          };
        }
        return { ...z, assignedAssociates: withoutAssoc };
      })
    );
    setIsReallocated(true);

    showToast(`Reallocated ${selectedAssociate} to target zone!`, '🎯');
    fireCelebration({
      emoji: '🗺️',
      eyebrow: 'Floor Coverage Optimized!',
      title: '+4.8 CX Score Lift Projected',
      sub: 'Billing queue reduced by -4.5 minutes',
    });
  };

  const resetFloor = () => {
    setZones(INITIAL_ZONES);
    setIsReallocated(false);
  };

  const sim: StaffAllocationSim = isReallocated
    ? { projectedQueueDropMin: 4.5, projectedCXLift: 4.8, estimatedBasketIncreasePct: 14 }
    : { projectedQueueDropMin: 0, projectedCXLift: 0, estimatedBasketIncreasePct: 0 };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.teal} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-teal-300">
              Autonomous Store Digital Twin
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Live Floor Telemetry</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Store Floor Heatmap &amp; Staffing Optimizer
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Live 2D floor footprint simulating customer footfall density, queue bottlenecks, and dynamic associate reallocation.
          </p>
        </div>

        <button
          onClick={resetFloor}
          className="bg-white/10 hover:bg-white/20 border border-white/20 px-4 py-2.5 rounded-xl font-bold text-xs text-white flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <RotateCcw size={14} />
          <span>Reset Floor Positions</span>
        </button>
      </div>

      {/* Main Floor Grid + Allocation Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive 2D Floor Layout */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5" style={{ borderColor: COLORS.line }}>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-teal-700">
                Interactive Store Map Viewport
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">Nagpur Central Flagship Floor</h3>
            </div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>105 Shoppers on Floor</span>
            </div>
          </div>

          {/* Associate Selector */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="font-bold text-slate-700">Select Floor Associate to Reassign:</span>
            <div className="flex gap-2">
              {['Sneha Patil', 'Rahul Verma', 'Ayesha Khan', 'Vikram Singh'].map((name) => (
                <button
                  key={name}
                  onClick={() => setSelectedAssociate(name)}
                  className={`px-3 py-1 rounded-xl font-bold transition-all ${
                    selectedAssociate === name
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {name}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Zone Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {zones.map((z) => {
              const isBottleneck = z.footfallDensity === 'Critical Bottleneck';
              const isHigh = z.footfallDensity === 'High';
              return (
                <div
                  key={z.id}
                  className={`rounded-3xl p-5 border-2 transition-all flex flex-col justify-between space-y-3 ${
                    isBottleneck
                      ? 'bg-red-50/70 border-red-400 shadow-md ring-2 ring-red-400/20'
                      : isHigh
                      ? 'bg-amber-50/70 border-amber-400 shadow-sm'
                      : 'bg-slate-50/70 border-slate-200 hover:border-teal-400'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span
                        className={`text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-full ${
                          isBottleneck
                            ? 'bg-red-200 text-red-900'
                            : isHigh
                            ? 'bg-amber-200 text-amber-900'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {z.footfallDensity}
                      </span>
                      <span className="text-xs font-mono font-bold text-slate-600">
                        {z.customerCount} Shoppers
                      </span>
                    </div>
                    <div className="font-bold text-sm text-slate-900">{z.name}</div>
                    {z.frictionType && (
                      <div className="text-xs font-semibold text-red-700 mt-1 flex items-center gap-1">
                        <AlertTriangle size={12} /> {z.frictionType}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-200/60">
                    <div className="text-[11px] font-bold text-slate-500">
                      Assigned Associates ({z.assignedAssociates.length}):
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {z.assignedAssociates.length > 0 ? (
                        z.assignedAssociates.map((a, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded-lg text-xs font-bold bg-white border border-slate-200 text-slate-800 shadow-xs"
                          >
                            👤 {a}
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-red-600 font-semibold italic">
                          ⚠️ No associates stationed here!
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => reallocateAssociate(z.id)}
                      className="w-full py-2 rounded-xl text-xs font-bold text-slate-900 bg-teal-400/80 hover:bg-teal-400 transition-colors mt-2 shadow-xs"
                    >
                      Assign {selectedAssociate.split(' ')[0]} Here
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Live CX Recovery & Queue Projection */}
        <div className="space-y-5">
          <div
            className="rounded-3xl p-6 text-white shadow-md flex flex-col justify-between"
            style={{
              background: `linear-gradient(145deg, ${COLORS.navy}, ${COLORS.navy2})`,
            }}
          >
            <div>
              <div className="text-xs uppercase tracking-wider font-extrabold text-amber-400">
                Live Floor CX Recovery Simulation
              </div>
              <div className="font-mono text-4xl font-extrabold mt-2 flex items-baseline gap-2">
                {isReallocated ? '+4.8 pts Lift' : 'Floor Baseline'}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {isReallocated
                  ? 'Active optimization: Counter 2 & Gifting Island covered'
                  : 'Floor has 1 bottleneck at POS Counter 1 & unattended shoppers'}
              </div>
            </div>

            <div className="space-y-3 pt-6 border-t border-white/10 mt-6 text-xs font-medium">
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Queue Time Drop:</span>
                <span className="font-mono text-sm font-extrabold text-emerald-400">
                  {isReallocated ? `-${sim.projectedQueueDropMin} mins` : '0 mins'}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-300">Gifting Basket Expansion:</span>
                <span className="font-mono font-bold text-amber-400">
                  {isReallocated ? `+${sim.estimatedBasketIncreasePct}%` : '0%'}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-300">Overall Store CX:</span>
                <span className="font-mono font-bold text-teal-300">
                  {isReallocated ? '91 / 100 (Excellent)' : '84 / 100 (Good)'}
                </span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 text-xs text-teal-950 font-medium space-y-1">
            <div className="font-bold flex items-center gap-1">
              <Sparkles size={13} className="text-teal-700" /> AI Floor Recommendation:
            </div>
            <p>
              Moving <strong>Sneha Patil</strong> from fitting rooms to <strong>POS Counter 2</strong> reduces customer billing queue friction during peak evening rush.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
