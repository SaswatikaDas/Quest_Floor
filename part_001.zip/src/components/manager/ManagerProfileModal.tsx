'use client';

import React, { useState } from 'react';
import {
  User,
  ShieldCheck,
  Building2,
  Clock,
  Phone,
  Target,
  X,
  Save,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { COLORS } from '../../lib/constants';

interface ManagerProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ManagerProfileModal({ isOpen, onClose }: ManagerProfileModalProps) {
  const { managerProfile, updateManagerProfileData, showToast } = useAppStore();

  const [name, setName] = useState(managerProfile.name);
  const [shiftHours, setShiftHours] = useState(managerProfile.shiftHours);
  const [coachingFocus, setCoachingFocus] = useState(managerProfile.coachingFocus);
  const [phone, setPhone] = useState(managerProfile.phone);
  const [targetPosRate, setTargetPosRate] = useState(managerProfile.targetPosRate);
  const [targetTrainingRate, setTargetTrainingRate] = useState(managerProfile.targetTrainingRate);
  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    await updateManagerProfileData({
      name,
      shiftHours,
      coachingFocus,
      phone,
      targetPosRate: Number(targetPosRate),
      targetTrainingRate: Number(targetTrainingRate),
    });
    setIsSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-xl w-full text-white shadow-2xl space-y-6 relative overflow-hidden">
        {/* Ambient background glow */}
        <div className="absolute -top-16 -right-16 w-44 h-44 bg-teal-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
              <User size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">
                  Store Manager Operational Profile
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
                  Store #104
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Manage operational store targets, shift timings, and coaching quotas.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Form Fields */}
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                Store Manager Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 focus:border-teal-400 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                Store Contact / Hotline
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 focus:border-teal-400 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">
              Active Shift Schedule
            </label>
            <input
              type="text"
              value={shiftHours}
              onChange={(e) => setShiftHours(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-700 focus:border-teal-400 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">
              Store Daily Coaching Focus
            </label>
            <input
              type="text"
              value={coachingFocus}
              onChange={(e) => setCoachingFocus(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-700 focus:border-teal-400 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                Target POS Adoption Rate (%)
              </label>
              <input
                type="number"
                min="50"
                max="100"
                value={targetPosRate}
                onChange={(e) => setTargetPosRate(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 focus:border-teal-400 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                Target Training Completion (%)
              </label>
              <input
                type="number"
                min="50"
                max="100"
                value={targetTrainingRate}
                onChange={(e) => setTargetTrainingRate(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 focus:border-teal-400 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white font-extrabold text-xs shadow-md shadow-teal-500/20 flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-60"
            >
              <Save size={15} />
              <span>{isSaving ? 'Saving...' : 'Save Profile & Store Targets'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
