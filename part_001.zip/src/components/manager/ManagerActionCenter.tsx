'use client';

import React, { useState } from 'react';
import {
  AlertTriangle,
  Sparkles,
  Award,
  Zap,
  CheckCircle2,
  Users,
  Send,
  Rocket,
  Flame,
  ArrowRight,
} from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';

export function ManagerActionCenter() {
  const { employees, sendManagerAction, showToast } = useAppStore();

  const [executedActions, setExecutedActions] = useState<string[]>([]);

  const handleExecuteAction = (actionId: string, empId: string, title: string, rewardXP = 0) => {
    setExecutedActions((prev) => [...prev, actionId]);
    sendManagerAction(empId, title, rewardXP);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.coral} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Manager Command Console
            </span>
            <span className="text-xs font-mono font-bold text-white/70">Detect → Explain → Act</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            🚨 Store Manager Action &amp; Intervention Center
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Single-pane operational console to proactively assign micro-learning drills, resolve floor queue friction, and dispatch real-time manager praise.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">Actionable Alerts</div>
          <div className="text-3xl font-extrabold text-amber-300 mt-0.5">3 Pending</div>
        </div>
      </div>

      {/* Action Categories */}
      <div className="space-y-6">
        {/* Category 1: Targeted Micro-Interventions */}
        <div className="space-y-3">
          <div className="text-xs font-extrabold uppercase tracking-wider text-rose-700 flex items-center gap-1.5">
            <AlertTriangle size={15} /> 1. Targeted Associate Interventions (Floor Gaps Detected)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Card 1 */}
            <div className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4" style={{ borderColor: COLORS.line }}>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm text-slate-900">Rahul Verma (Nagpur Central)</span>
                  <Pill color={COLORS.coral}>POS Adoption: 58% 🔴</Pill>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  <strong>Issue:</strong> High manual SKU typing error rate during evening rush.
                </p>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 mt-3">
                  💡 AI Recommendation: Assign 5-minute &ldquo;POS Basics: Fast Barcode Scanning&rdquo; drill.
                </div>
              </div>

              <button
                onClick={() => handleExecuteAction('act-1', 'e2', 'Assigned POS Basics Micro-Drill', 50)}
                disabled={executedActions.includes('act-1')}
                className={`w-full py-2.5 rounded-xl font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all ${
                  executedActions.includes('act-1')
                    ? 'bg-teal-50 text-teal-800 border border-teal-200'
                    : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                {executedActions.includes('act-1') ? (
                  <>
                    <CheckCircle2 size={14} /> Training Dispatched to Rahul
                  </>
                ) : (
                  <>
                    <Zap size={14} className="text-amber-400" />
                    <span>Assign POS Speed Drill (+50 XP)</span>
                  </>
                )}
              </button>
            </div>

            {/* Card 2 */}
            <div className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4" style={{ borderColor: COLORS.line }}>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm text-slate-900">Ayesha Khan (Indore Palasia)</span>
                  <Pill color={COLORS.amberDeep}>CSAT: 66% 🟡</Pill>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  <strong>Issue:</strong> Lower customer sentiment on return requests due to paper receipt confusion.
                </p>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 mt-3">
                  💡 AI Recommendation: Assign &ldquo;De-escalation &amp; Omnichannel Returns&rdquo; module.
                </div>
              </div>

              <button
                onClick={() => handleExecuteAction('act-2', 'e3', 'Assigned Omnichannel Returns Module', 50)}
                disabled={executedActions.includes('act-2')}
                className={`w-full py-2.5 rounded-xl font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all ${
                  executedActions.includes('act-2')
                    ? 'bg-teal-50 text-teal-800 border border-teal-200'
                    : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                {executedActions.includes('act-2') ? (
                  <>
                    <CheckCircle2 size={14} /> Training Dispatched to Ayesha
                  </>
                ) : (
                  <>
                    <Zap size={14} className="text-amber-400" />
                    <span>Assign Returns Module (+50 XP)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Category 2: Real-Time Manager Praise & Recognition */}
        <div className="space-y-3 pt-2">
          <div className="text-xs font-extrabold uppercase tracking-wider text-teal-700 flex items-center gap-1.5">
            <Award size={15} /> 2. Real-Time Manager Recognition Triggers (Performance Milestones)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Card 3 */}
            <div className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4" style={{ borderColor: COLORS.line }}>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm text-slate-900">Sneha Patil (Nagpur Central)</span>
                  <Pill color={COLORS.teal}>CSAT: 95% ⭐</Pill>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Sneha logged 5 verified 5-star customer compliments in today&apos;s shift!
                </p>
                <div className="p-3 rounded-2xl bg-teal-50/60 border border-teal-200 text-xs font-semibold text-teal-900 mt-3">
                  🏆 Milestone Reached: Customer Champion Spotlight eligible.
                </div>
              </div>

              <button
                onClick={() => handleExecuteAction('act-3', 'e1', 'Manager Praise: 5-Star Customer Champion', 250)}
                disabled={executedActions.includes('act-3')}
                className={`w-full py-2.5 rounded-xl font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all ${
                  executedActions.includes('act-3')
                    ? 'bg-teal-50 text-teal-800 border border-teal-200'
                    : 'bg-amber-400 hover:bg-amber-300 text-slate-900'
                }`}
              >
                {executedActions.includes('act-3') ? (
                  <>
                    <CheckCircle2 size={14} /> Manager Praise Sent
                  </>
                ) : (
                  <>
                    <Sparkles size={14} />
                    <span>Send Manager Recognition (+250 XP)</span>
                  </>
                )}
              </button>
            </div>

            {/* Card 4 */}
            <div className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4" style={{ borderColor: COLORS.line }}>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm text-slate-900">Vikram Singh (Indore Palasia)</span>
                  <Pill color={COLORS.plum}>10/10 Modules 🏅</Pill>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Vikram became the 1st associate in the Madhya Pradesh cluster to complete all 10 modules!
                </p>
                <div className="p-3 rounded-2xl bg-purple-50/60 border border-purple-200 text-xs font-semibold text-purple-900 mt-3">
                  🏆 Milestone Reached: Master Knowledge Seeker Award.
                </div>
              </div>

              <button
                onClick={() => handleExecuteAction('act-4', 'e4', 'Manager Praise: Curriculum Mastery', 250)}
                disabled={executedActions.includes('act-4')}
                className={`w-full py-2.5 rounded-xl font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all ${
                  executedActions.includes('act-4')
                    ? 'bg-purple-50 text-purple-800 border border-purple-200'
                    : 'bg-amber-400 hover:bg-amber-300 text-slate-900'
                }`}
              >
                {executedActions.includes('act-4') ? (
                  <>
                    <CheckCircle2 size={14} /> Manager Praise Sent
                  </>
                ) : (
                  <>
                    <Sparkles size={14} />
                    <span>Send Manager Recognition (+250 XP)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
