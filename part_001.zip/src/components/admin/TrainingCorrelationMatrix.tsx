'use client';

import React from 'react';
import {
  TrendingUp,
  Brain,
  Award,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  BarChart3,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';

const CORRELATION_DATA = [
  { store: 'Nagpur Central', trainingPct: 78, posAdoption: 86, csatPct: 93, compositeCX: 91 },
  { store: 'Jaipur Malviya', trainingPct: 72, posAdoption: 82, csatPct: 89, compositeCX: 87 },
  { store: 'Indore Palasia', trainingPct: 65, posAdoption: 74, csatPct: 84, compositeCX: 82 },
  { store: 'Coimbatore RS', trainingPct: 60, posAdoption: 68, csatPct: 80, compositeCX: 78 },
  { store: 'Patna Boring Rd', trainingPct: 38, posAdoption: 45, csatPct: 68, compositeCX: 64 },
];

export function TrainingCorrelationMatrix() {
  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{
          background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.plum} 100%)`,
        }}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full text-amber-300">
              Business Outcome Causality
            </span>
            <span className="text-xs font-mono font-bold text-white/70">R² = 0.88 Statistical Correlation</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Training $\rightarrow$ Performance $\rightarrow$ CX Correlation Matrix
          </h2>
          <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
            Statistical proof that completing 3–5 minute micro-lessons directly accelerates digital POS adoption, elevates CSAT, and boosts overall store revenue.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 shrink-0 text-center font-mono">
          <div className="text-xs text-white/70 font-semibold font-sans">CX Sensitivity Lift</div>
          <div className="text-3xl font-extrabold text-emerald-400 mt-0.5">+27 pts</div>
        </div>
      </div>

      {/* Causality Chain Flow Visual */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
        <SectionHeader
          title="The 4-Stage Retail Value Creation Pipeline"
          subtitle="How micro-learning translates into floor execution and customer loyalty"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          {/* Step 1 */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="text-[10px] font-mono uppercase font-bold text-amber-700">Stage 1: Micro-Learning</div>
            <div className="font-extrabold text-sm text-slate-900">Training Completion</div>
            <div className="font-mono text-2xl font-extrabold text-amber-600">38% → 78%</div>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              Associates master seasonal pricing, return policies, and fast barcode scanning.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-4 rounded-2xl bg-purple-50/50 border border-purple-200 space-y-2">
            <div className="text-[10px] font-mono uppercase font-bold text-purple-700">Stage 2: Floor Practice</div>
            <div className="font-extrabold text-sm text-slate-900">POS Floor Adoption</div>
            <div className="font-mono text-2xl font-extrabold text-purple-600">45% → 86%</div>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              Eliminates manual SKU typing errors and cuts queue waiting times by 4.5 minutes.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-4 rounded-2xl bg-teal-50/50 border border-teal-200 space-y-2">
            <div className="text-[10px] font-mono uppercase font-bold text-teal-700">Stage 3: Customer Voice</div>
            <div className="font-extrabold text-sm text-slate-900">Shopper CSAT Rating</div>
            <div className="font-mono text-2xl font-extrabold text-teal-600">68% → 93%</div>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              Polite vernacular hospitality and consultative gifting recommendations boost 5-star ratings.
            </p>
          </div>

          {/* Step 4 */}
          <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200 space-y-2">
            <div className="text-[10px] font-mono uppercase font-bold text-emerald-700">Stage 4: Business Lift</div>
            <div className="font-extrabold text-sm text-slate-900">Composite CX Index</div>
            <div className="font-mono text-2xl font-extrabold text-emerald-600">64 → 91 / 100</div>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              Consistent store brand reputation and measurable repeat footfall revenue lift.
            </p>
          </div>
        </div>
      </div>

      {/* Multi-Store Comparison Bar Chart */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs space-y-4" style={{ borderColor: COLORS.line }}>
        <SectionHeader
          title="Cross-Store Correlation Telemetry (1,200 Store Network Sample)"
          subtitle="Direct comparison showing stores with higher training completion consistently achieve superior CX scores"
        />

        <div style={{ height: 320 }} className="w-full mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={CORRELATION_DATA}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.line} vertical={false} />
              <XAxis dataKey="store" tick={{ fontSize: 11, fill: COLORS.muted, fontWeight: 600 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: COLORS.muted }} axisLine={false} tickLine={false} domain={[0, 100]} />
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 12, paddingTop: 10 }} />
              <Bar dataKey="trainingPct" name="Training Completion %" fill={COLORS.amber} radius={[6, 6, 0, 0]} />
              <Bar dataKey="posAdoption" name="POS Adoption %" fill={COLORS.plum} radius={[6, 6, 0, 0]} />
              <Bar dataKey="csatPct" name="CSAT 5-Star %" fill={COLORS.teal} radius={[6, 6, 0, 0]} />
              <Bar dataKey="compositeCX" name="Composite Store CX" fill={COLORS.navy} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
