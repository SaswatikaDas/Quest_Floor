'use client';

import React from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { CXScoreDecomposition } from '../diagrams/CXScoreDecomposition';
import { COLORS, WEEKLY_TREND } from '../../lib/constants';
import { calculateCX, trainingPct, avg } from '../../lib/cxCalculator';

export function AdminAnalytics() {
  const { employees, trainingModules } = useAppStore();

  const orgCx = calculateCX(employees, trainingModules);

  const categoryData = [
    'Product Knowledge',
    'Customer Service',
    'POS Training',
    'Sales Skills',
    'Company Policies',
  ].map((cat) => {
    const mods = trainingModules.filter((m) => m.category === cat);
    const pct = mods.length
      ? avg(
          employees.map(
            (e) => Math.round((mods.filter((m) => e.completedModules.includes(m.id)).length / mods.length) * 100)
          )
        )
      : 0;

    return { name: cat, value: pct };
  });

  const pieColors = [COLORS.amber, COLORS.teal, COLORS.coral, COLORS.plum, COLORS.navy3];

  return (
    <div className="space-y-6 pb-12">
      <SectionHeader
        title="Organization Analytics &amp; Workforce Insights"
        subtitle="Aggregated micro-curriculum metrics, operational adoption, and customer satisfaction indices"
      />

      {/* Top CX Decomposition Visualizer */}
      <CXScoreDecomposition cx={orgCx} />

      {/* Grid: Pie Chart by Category + 4-Week Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs" style={{ borderColor: COLORS.line }}>
          <SectionHeader
            title="Curriculum Completion by Skill Domain"
            subtitle="Average associate completion percentage"
          />

          <div style={{ height: 280 }} className="w-full mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={95}
                  innerRadius={45}
                  paddingAngle={3}
                  label={(d) => `${d.value}%`}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(val) => [`${val}% avg completion`, 'Category']} />
                <Legend wrapperStyle={{ fontSize: 11, paddingTop: 10 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 4-Week Line Chart */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs" style={{ borderColor: COLORS.line }}>
          <SectionHeader
            title="Chain-Wide 4-Week Engagement Lift"
            subtitle="Correlating training progress with real-world digital POS adoption"
          />

          <div style={{ height: 280 }} className="w-full mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={WEEKLY_TREND}>
                <CartesianGrid strokeDasharray="3 3" stroke={COLORS.line} vertical={false} />
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: COLORS.muted }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: COLORS.muted }} axisLine={false} tickLine={false} domain={[0, 100]} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 12, paddingTop: 10 }} />
                <Line type="monotone" dataKey="engagement" name="Engagement" stroke={COLORS.coral} strokeWidth={3} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="training" name="Training %" stroke={COLORS.teal} strokeWidth={3} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="pos" name="POS %" stroke={COLORS.amberDeep} strokeWidth={3} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="cx" name="CX Index" stroke={COLORS.plum} strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
