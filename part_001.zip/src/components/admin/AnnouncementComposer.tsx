'use client';

import React, { useState } from 'react';
import { Megaphone, Send, Sparkles } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { COLORS } from '../../lib/constants';

export function AnnouncementComposer() {
  const { sendAnnouncement } = useAppStore();
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    sendAnnouncement(text.trim());
    setText('');
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-3xl p-6 sm:p-7 border shadow-xs space-y-4"
      style={{ borderColor: COLORS.line }}
    >
      <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-rose-600">
        <Megaphone size={16} /> Broadcast Priority Announcement (1,200 Stores)
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-3">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          required
          placeholder="e.g. Festive season promotion goes live Monday! Complete product modules by Sunday…"
          className="flex-1 w-full border rounded-2xl px-4 py-3 text-xs sm:text-sm font-semibold bg-slate-50 border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500/20 text-slate-900"
        />

        <button
          type="submit"
          className="w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs text-white shadow-md flex items-center justify-center gap-2 hover:opacity-90 transition-all shrink-0"
          style={{ backgroundColor: COLORS.coral }}
        >
          <Send size={14} />
          <span>Broadcast Live</span>
        </button>
      </div>
    </form>
  );
}
