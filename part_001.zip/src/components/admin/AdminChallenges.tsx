'use client';

import React, { useState } from 'react';
import { Target, Plus, Star, CheckCircle2, Sparkles } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';

export function AdminChallenges() {
  const { challenges, createChallenge } = useAppStore();

  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'daily' | 'weekly'>('weekly');
  const [reward, setReward] = useState(120);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    createChallenge({
      title: title.trim(),
      type,
      reward: Number(reward) || 100,
    });

    setShowModal(false);
    setTitle('');
    setType('weekly');
    setReward(120);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
            Organization Challenge Manager
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Create and broadcast daily floor missions and weekly competitive sprints across all 1,200 stores
          </p>
        </div>

        <button
          onClick={() => setShowModal(!showModal)}
          className="px-5 py-2.5 rounded-xl font-bold text-xs text-white shadow-md flex items-center gap-2"
          style={{ backgroundColor: COLORS.navy }}
        >
          <Plus size={16} />
          <span>{showModal ? 'Close Form' : 'Publish New Challenge'}</span>
        </button>
      </div>

      {/* Create Challenge Form */}
      {showModal && (
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-3xl p-6 sm:p-8 border shadow-lg space-y-4 animate-in fade-in slide-in-from-top-4 duration-200"
          style={{ borderColor: COLORS.line }}
        >
          <div className="text-xs font-bold uppercase tracking-wider text-amber-600 flex items-center gap-1.5">
            <Sparkles size={14} /> New Gamified Retail Challenge
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Challenge Objective &amp; Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              placeholder="e.g. Master Festive Gifting Consultation with 0 errors..."
              className="w-full border rounded-2xl px-4 py-3 text-xs sm:text-sm font-semibold bg-slate-50 border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Challenge Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as 'daily' | 'weekly')}
                className="w-full border rounded-xl px-3 py-2 text-xs font-semibold bg-slate-50 border-slate-200"
              >
                <option value="daily">Daily Target (24 Hours)</option>
                <option value="weekly">Weekly Sprint (7 Days)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">XP Points Reward</label>
              <input
                type="number"
                min={50}
                max={500}
                step={10}
                value={reward}
                onChange={(e) => setReward(Number(e.target.value))}
                className="w-full border rounded-xl px-3 py-2 text-xs font-mono font-bold bg-slate-50 border-slate-200"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl font-bold text-xs text-white shadow-md"
              style={{ backgroundColor: COLORS.navy }}
            >
              Publish Challenge Nationwide
            </button>
          </div>
        </form>
      )}

      {/* Challenges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {challenges.map((c) => (
          <div
            key={c.id}
            className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4"
            style={{ borderColor: COLORS.line }}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <Pill color={c.type === 'daily' ? COLORS.teal : COLORS.plum}>
                  {c.type === 'daily' ? 'Daily Mission' : 'Weekly Sprint'}
                </Pill>
                <span className="font-mono text-xs font-bold text-amber-700 flex items-center gap-1">
                  <Star size={13} /> +{c.reward} XP
                </span>
              </div>

              <h3 className="font-bold text-base mt-2 text-slate-900 leading-snug">{c.title}</h3>
              <p className="text-xs text-slate-500 mt-1">{c.desc}</p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-semibold font-mono">
              <span>{c.completedBy.length} Associates Completed</span>
              <CheckCircle2 size={15} className="text-teal-600" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
