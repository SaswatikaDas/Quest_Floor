'use client';

import React from 'react';
import { MapPin, Building2, Users, Store as StoreIcon } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';
import { calculateCX, trainingPct, avg } from '../../lib/cxCalculator';

export function AdminStores() {
  const { stores, employees, managers, trainingModules } = useAppStore();

  return (
    <div className="space-y-6 pb-12">
      <SectionHeader
        title={`QuestFloor Store Network (${stores.length} Pilot Regional Hubs)`}
        subtitle="Operational governance across Tier-3 expansion store network"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {stores.map((s) => {
          const storeEmps = employees.filter((e) => e.storeId === s.id);
          const cx = calculateCX(storeEmps, trainingModules);
          const mgr = managers.find((m) => m.stores.includes(s.id));

          return (
            <div
              key={s.id}
              className="bg-white rounded-3xl p-6 border shadow-xs flex flex-col justify-between space-y-4"
              style={{ borderColor: COLORS.line }}
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-bold text-base text-slate-900">
                    <MapPin size={17} className="text-teal-600" />
                    <span>{s.city}, {s.state}</span>
                  </div>
                  <Pill color={cx.color}>{cx.score}/100 CX</Pill>
                </div>

                <div className="text-xs text-slate-500 font-medium mt-1">{s.name}</div>
                <div className="text-[11px] font-mono text-slate-400 mt-0.5">Code: {s.code} · {s.tier}</div>
              </div>

              <div className="space-y-2 pt-3 border-t border-slate-100 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Assigned Cluster Manager:</span>
                  <span className="font-bold text-slate-900">{mgr?.name || 'Central Ops'}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Active Floor Associates:</span>
                  <span className="font-mono font-bold text-slate-900">{storeEmps.length}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Avg Curriculum Completion:</span>
                  <span className="font-mono font-bold text-teal-600">
                    {avg(storeEmps.map((e) => trainingPct(e, trainingModules)))}%
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
