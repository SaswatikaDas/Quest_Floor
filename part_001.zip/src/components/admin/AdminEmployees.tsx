'use client';

import React, { useState } from 'react';
import { Users, ShieldCheck, Power, Search, Filter } from 'lucide-react';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Avatar } from '../common/Avatar';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';
import { trainingPct, getStoreName } from '../../lib/cxCalculator';

export function AdminEmployees() {
  const { employees, stores, trainingModules, toggleEmployeeActive } = useAppStore();
  const [search, setSearch] = useState('');
  const [storeFilter, setStoreFilter] = useState('All');

  const filtered = employees.filter((emp) => {
    const matchesSearch =
      emp.name.toLowerCase().includes(search.toLowerCase()) ||
      emp.email.toLowerCase().includes(search.toLowerCase());
    const matchesStore = storeFilter === 'All' || emp.storeId === storeFilter;
    return matchesSearch && matchesStore;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Search */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
            Organization Associate Directory
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Manage associate roster status, active assignments, and training progress
          </p>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-56">
            <Search size={15} className="absolute left-3.5 top-3 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name/email…"
              className="w-full pl-9 pr-3 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
            />
          </div>

          <select
            value={storeFilter}
            onChange={(e) => setStoreFilter(e.target.value)}
            className="px-3 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 focus:outline-none"
          >
            <option value="All">All Stores</option>
            {stores.map((s) => (
              <option key={s.id} value={s.id}>{s.city}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Associates Table Card */}
      <div className="bg-white rounded-3xl border shadow-xs overflow-hidden" style={{ borderColor: COLORS.line }}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm" style={{ minWidth: 720 }}>
            <thead>
              <tr className="border-b bg-slate-50/70" style={{ borderColor: COLORS.line }}>
                <th className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Associate Name
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Store
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Points (XP)
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Training %
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  POS Usage
                </th>
                <th className="px-4 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Status
                </th>
                <th className="px-6 py-4 text-right font-bold text-slate-500 uppercase tracking-wider text-[11px]">
                  Toggle
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {filtered.map((emp) => {
                const trnPct = trainingPct(emp, trainingModules);

                return (
                  <tr key={emp.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <Avatar name={emp.name} color={emp.color} size={34} />
                        <div>
                          <div className="font-bold text-slate-900">{emp.name}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{emp.email}</div>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-4 font-semibold text-slate-600">
                      {getStoreName(stores, emp.storeId)}
                    </td>

                    <td className="px-4 py-4 font-mono font-bold text-slate-800">
                      {emp.points.toLocaleString('en-IN')}
                    </td>

                    <td className="px-4 py-4 font-mono font-bold text-teal-700">
                      {trnPct}%
                    </td>

                    <td className="px-4 py-4 font-mono font-bold text-slate-800">
                      {emp.posAdoption}%
                    </td>

                    <td className="px-4 py-4">
                      <Pill color={emp.active ? COLORS.teal : COLORS.muted}>
                        {emp.active ? 'Active' : 'Inactive'}
                      </Pill>
                    </td>

                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => toggleEmployeeActive(emp.id)}
                        className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all border ${
                          emp.active
                            ? 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-red-50 hover:text-red-600'
                            : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                        }`}
                      >
                        {emp.active ? 'Deactivate' : 'Reactivate'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
