'use client';

import React from 'react';
import {
  Building2,
  Users,
  ShieldCheck,
  GraduationCap,
  Store as StoreIcon,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Brain,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { useAppStore } from '../../lib/store/useAppStore';
import { StatCard } from '../common/StatCard';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { COLORS } from '../../lib/constants';
import { calculateCX, trainingPct, avg } from '../../lib/cxCalculator';

export function AdminDashboard() {
  const { stores, employees, trainingModules, setScreen } = useAppStore();

  const orgCx = calculateCX(employees, trainingModules);

  const storeStats = stores
    .map((s) => {
      const storeEmps = employees.filter((e) => e.storeId === s.id);
      const cx = calculateCX(storeEmps, trainingModules);
      return {
        ...s,
        cx: cx.score,
        count: storeEmps.length,
        training: avg(storeEmps.map((e) => trainingPct(e, trainingModules))),
      };
    })
    .sort((a, b) => b.cx - a.cx);

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
            Organization-Wide HR &amp; Workforce Executive Dashboard
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Real-time governance across 1,200 stores &amp; 3,000 associates in Tier-3 retail expansion
          </p>
        </div>

        <button
          onClick={() => setScreen('aiStudio')}
          className="px-4 py-2 rounded-xl text-xs font-bold text-white shadow-md flex items-center gap-1.5"
          style={{ backgroundColor: COLORS.plum }}
        >
          <Brain size={15} />
          <span>Launch AI Curriculum Studio</span>
        </button>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Building2}
          label="Total Active Stores"
          value="1,200 Stores"
          sub="5 Pilot Clusters"
          accent={COLORS.navy3}
        />
        <StatCard
          icon={Users}
          label="Store Associates"
          value="3,000 Staff"
          sub="100% Onboarded"
          accent={COLORS.plum}
        />
        <StatCard
          icon={ShieldCheck}
          label="Active Floor Staff"
          value={employees.filter((e) => e.active).length}
          sub="98.5% Shift Attendance"
          accent={COLORS.teal}
        />
        <StatCard
          icon={GraduationCap}
          label="Chain Micro-Training Rate"
          value={`${avg(employees.map((e) => trainingPct(e, trainingModules)))}%`}
          sub="+19% vs baseline"
          accent={COLORS.amberDeep}
        />
      </div>

      {/* Main Grid: Store CX Bar Chart + Org CX Score */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Bar Chart of Store CX Scores */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 border shadow-xs" style={{ borderColor: COLORS.line }}>
          <SectionHeader
            title="Customer Experience (CX) Index by Store Location"
            subtitle="Comparing standardized customer satisfaction &amp; retail standards"
          />

          <div style={{ height: 280 }} className="w-full mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={storeStats}>
                <CartesianGrid strokeDasharray="3 3" stroke={COLORS.line} vertical={false} />
                <XAxis dataKey="city" tick={{ fontSize: 11, fill: COLORS.muted, fontWeight: 600 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: COLORS.muted }} axisLine={false} tickLine={false} domain={[0, 100]} />
                <Tooltip cursor={{ fill: 'rgba(245,245,251,0.6)' }} />
                <Bar dataKey="cx" name="CX Score" fill={COLORS.navy3} radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right: Org-wide CX Card */}
        <div
          className="rounded-3xl p-6 text-white shadow-md flex flex-col justify-between"
          style={{
            background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.plum} 100%)`,
          }}
        >
          <div>
            <div className="text-xs uppercase tracking-wider font-extrabold text-amber-400">
              National Retail CX Index
            </div>
            <div className="font-mono text-5xl sm:text-6xl font-extrabold text-white mt-3">
              {orgCx.score}
              <span className="text-xl text-white/50">/100</span>
            </div>
            <div className="mt-2">
              <Pill bg="rgba(255,255,255,0.15)" color="white">
                {orgCx.label} Nationwide Benchmark
              </Pill>
            </div>
            <p className="text-xs text-white/70 mt-4 leading-relaxed">
              Standardized across 1,200 stores. Measures consistent product advisory, frictionless digital POS checkout, and associate engagement.
            </p>
          </div>

          <div className="pt-4 border-t border-white/10 mt-4">
            <button
              onClick={() => setScreen('analytics')}
              className="w-full py-2.5 rounded-xl font-bold text-xs bg-white text-slate-900 shadow flex items-center justify-center gap-1.5 hover:bg-slate-100 transition-colors"
            >
              <span>View Deep Analytics</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Top vs Needing Attention Stores Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top Stores */}
        <div className="bg-white rounded-3xl p-6 border shadow-xs" style={{ borderColor: COLORS.line }}>
          <SectionHeader
            title="Top Performing Pilot Stores"
            subtitle="Leading the chain in customer satisfaction and POS adoption"
          />
          <div className="space-y-3 mt-4">
            {storeStats.slice(0, 3).map((s, idx) => (
              <div key={s.id} className="rounded-2xl p-4 border bg-emerald-50/40 border-emerald-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-teal-100 text-teal-700 font-bold font-mono text-xs">
                    #{idx + 1}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{s.name}</div>
                    <div className="text-xs text-slate-500">{s.city} ({s.state}) · {s.count} Associates</div>
                  </div>
                </div>
                <div className="font-mono text-base font-extrabold text-teal-700">{s.cx} CX</div>
              </div>
            ))}
          </div>
        </div>

        {/* Attention Stores */}
        <div className="bg-white rounded-3xl p-6 border shadow-xs" style={{ borderColor: COLORS.line }}>
          <SectionHeader
            title="Stores Requiring Coaching &amp; Interventions"
            subtitle="Below regional target standards in training or POS adoption"
          />
          <div className="space-y-3 mt-4">
            {storeStats.slice(-2).reverse().map((s) => (
              <div key={s.id} className="rounded-2xl p-4 border bg-red-50/40 border-red-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-red-100 text-red-700">
                    <AlertTriangle size={18} />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{s.name}</div>
                    <div className="text-xs text-slate-500">{s.city} ({s.state}) · {s.training}% Trained</div>
                  </div>
                </div>
                <div className="font-mono text-base font-extrabold text-red-600">{s.cx} CX</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
