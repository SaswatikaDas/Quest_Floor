'use client';

import React, { useState } from 'react';
import {
  Brain,
  Wand2,
  Rocket,
  RefreshCw,
  CheckCircle2,
  Circle,
  Pencil,
  Target,
  Sparkles,
  Award,
  BookOpen,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { useAppStore } from '../../lib/store/useAppStore';
import { SectionHeader } from '../common/SectionHeader';
import { Pill } from '../common/Pill';
import { AIQuizDraft, GeneratedQuestion } from '../../types';
import { COLORS } from '../../lib/constants';
import { generateAIQuiz, evaluateScenarioRubric } from '../../lib/aiEngine';

const SKILLS = ['Product Knowledge', 'Customer Service', 'POS Training', 'Sales Skills', 'Company Policies'];
const LANGUAGES = ['English', 'Hindi (हिंदी)', 'Tamil (தமிழ்)', 'Marathi (मराठी)'];
const GEN_STEPS = [
  'Parsing product catalog specs & retail guidelines…',
  'Drafting consultative customer interaction questions…',
  'Building adaptive difficulty scenario simulation…',
  'AI Micro-Lesson & Quiz Ready for Preview ✓',
];

const ADAPTIVE_PROGRESSION = [
  { attempt: 'Quiz 1', score: 68 },
  { attempt: 'Quiz 2', score: 78 },
  { attempt: 'Quiz 3', score: 92 },
  { attempt: 'Quiz 4 (Adaptive Hard)', score: 86 },
];

export function AdminAIStudio() {
  const { publishAIQuiz, publishedQuizzes } = useAppStore();

  const [product, setProduct] = useState('Ayurvedic Hair Therapy Oil');
  const [skill, setSkill] = useState('Product Knowledge');
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [numQuestions, setNumQuestions] = useState(4);
  const [language, setLanguage] = useState('English');
  const [scenarioBased, setScenarioBased] = useState(true);
  const [timeLimit, setTimeLimit] = useState(4);

  const [stage, setStage] = useState<'form' | 'generating' | 'preview'>('form');
  const [genStep, setGenStep] = useState(-1);
  const [draft, setDraft] = useState<AIQuizDraft | null>(null);

  const handleGenerate = () => {
    setStage('generating');
    setGenStep(0);

    GEN_STEPS.forEach((_, i) => {
      setTimeout(() => setGenStep(i), (i + 1) * 600);
    });

    setTimeout(() => {
      const generatedDraft = generateAIQuiz({
        product: product.trim() || 'Festive Ethnic Apparel',
        skill,
        difficulty,
        numQuestions,
        scenarioBased,
        language,
        timeLimit,
      });
      setDraft(generatedDraft);
      setStage('preview');
    }, GEN_STEPS.length * 600 + 200);
  };

  const updateQuestionPrompt = (qId: string, text: string) => {
    if (!draft) return;
    setDraft({
      ...draft,
      questions: draft.questions.map((q) => (q.id === qId ? { ...q, prompt: text } : q)),
    });
  };

  const handlePublish = () => {
    if (!draft) return;
    publishAIQuiz(draft);
    setStage('form');
    setDraft(null);
  };

  const scenarioRubric = evaluateScenarioRubric(difficulty);

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: COLORS.ink }}>
            Generative AI Curriculum Studio
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Instantly create localized micro-learning lessons, quizzes, and scenario challenges for all 1,200 stores
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive AI Generator / Preview */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border shadow-xs" style={{ borderColor: COLORS.line }}>
            <SectionHeader
              title="Autonomous Quiz &amp; Challenge Creator"
              subtitle="Provide product specifications — AI drafts the interactive lesson and attached XP challenge"
            />

            {/* FORM STAGE */}
            {stage === 'form' && (
              <div className="space-y-4 mt-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Target Retail Product / Standard
                  </label>
                  <input
                    type="text"
                    value={product}
                    onChange={(e) => setProduct(e.target.value)}
                    placeholder="e.g. Silk Saree Festive Range, POS Return Flow, Organic Tea Hampers..."
                    className="w-full border rounded-2xl px-4 py-3 text-xs sm:text-sm font-semibold bg-slate-50 text-slate-900 border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Target Skill Domain
                    </label>
                    <select
                      value={skill}
                      onChange={(e) => setSkill(e.target.value)}
                      className="w-full border rounded-xl px-3.5 py-2.5 text-xs font-semibold bg-slate-50 text-slate-900 border-slate-200 focus:outline-none"
                    >
                      {SKILLS.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Adaptive Difficulty
                    </label>
                    <select
                      value={difficulty}
                      onChange={(e) => setDifficulty(e.target.value as 'Easy' | 'Medium' | 'Hard')}
                      className="w-full border rounded-xl px-3.5 py-2.5 text-xs font-semibold bg-slate-50 text-slate-900 border-slate-200 focus:outline-none"
                    >
                      <option value="Easy">Easy (Onboarding Associates)</option>
                      <option value="Medium">Medium (Standard Floor Shift)</option>
                      <option value="Hard">Hard (Expert Roleplay)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Questions</label>
                    <input
                      type="number"
                      min={2}
                      max={8}
                      value={numQuestions}
                      onChange={(e) => setNumQuestions(Number(e.target.value))}
                      className="w-full border rounded-xl px-3 py-2 text-xs font-mono font-bold bg-slate-50 border-slate-200"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Language</label>
                    <select
                      value={language}
                      onChange={(e) => setLanguage(e.target.value)}
                      className="w-full border rounded-xl px-2 py-2 text-xs font-semibold bg-slate-50 border-slate-200"
                    >
                      {LANGUAGES.map((l) => (
                        <option key={l} value={l}>{l}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Time Limit (Min)</label>
                    <input
                      type="number"
                      min={2}
                      max={10}
                      value={timeLimit}
                      onChange={(e) => setTimeLimit(Number(e.target.value))}
                      className="w-full border rounded-xl px-3 py-2 text-xs font-mono font-bold bg-slate-50 border-slate-200"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={scenarioBased}
                      onChange={(e) => setScenarioBased(e.target.checked)}
                      className="rounded text-purple-600 focus:ring-purple-500"
                    />
                    <span>Include AI Scenario Roleplay Question &amp; Rubric Evaluation</span>
                  </label>
                </div>

                <div className="pt-4">
                  <button
                    onClick={handleGenerate}
                    className="w-full py-3.5 rounded-2xl font-bold text-sm text-white shadow-md flex items-center justify-center gap-2 hover:opacity-90 transition-all"
                    style={{ backgroundColor: COLORS.plum }}
                  >
                    <Wand2 size={16} />
                    <span>Generate AI Micro-Lesson &amp; Quiz</span>
                  </button>
                </div>
              </div>
            )}

            {/* GENERATING ANIMATION STAGE */}
            {stage === 'generating' && (
              <div className="py-12 space-y-4">
                <div className="text-center mb-6">
                  <Wand2 size={36} className="mx-auto text-purple-600 animate-spin" />
                  <div className="font-bold text-base mt-2 text-slate-900">
                    Generating Adaptive Retail Curriculum…
                  </div>
                </div>

                <div className="max-w-md mx-auto space-y-2.5 bg-slate-50 p-5 rounded-2xl border border-slate-200">
                  {GEN_STEPS.map((step, i) => {
                    const isDone = i < genStep;
                    const isCurrent = i === genStep;
                    return (
                      <div
                        key={step}
                        className="flex items-center gap-2.5 text-xs font-medium transition-opacity"
                        style={{ opacity: i <= genStep ? 1 : 0.3 }}
                      >
                        {isDone ? (
                          <CheckCircle2 size={15} className="text-teal-600 shrink-0" />
                        ) : isCurrent ? (
                          <RefreshCw size={15} className="animate-spin text-purple-600 shrink-0" />
                        ) : (
                          <Circle size={15} className="text-slate-300 shrink-0" />
                        )}
                        <span className="text-slate-800">{step}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* PREVIEW & PUBLISH STAGE */}
            {stage === 'preview' && draft && (
              <div className="space-y-6 mt-4">
                {/* Meta pills */}
                <div className="flex flex-wrap items-center gap-2">
                  <Pill color={COLORS.navy3}>{draft.skill}</Pill>
                  <Pill color={COLORS.amberDeep}>{draft.difficulty} Difficulty</Pill>
                  <Pill color={COLORS.plum}>{draft.language}</Pill>
                  <Pill color={COLORS.teal}>{draft.timeLimit} Min Duration</Pill>
                </div>

                {/* Question cards editor */}
                <div className="space-y-4">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Generated Quiz Questions (Click to edit text)
                  </div>

                  {draft.questions.map((q, idx) => (
                    <div
                      key={q.id}
                      className="rounded-2xl p-4 border bg-slate-50/80 border-slate-200 space-y-2"
                    >
                      <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                        <span>Q{idx + 1} · {q.type}</span>
                        <Pencil size={12} className="text-slate-400" />
                      </div>

                      <textarea
                        rows={2}
                        value={q.prompt}
                        onChange={(e) => updateQuestionPrompt(q.id, e.target.value)}
                        className="w-full text-xs font-semibold bg-white p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-purple-500/30 resize-none"
                      />

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                        {q.options.map((opt, oIdx) => (
                          <div
                            key={oIdx}
                            className={`text-xs p-2 rounded-xl border flex items-center gap-2 ${
                              oIdx === q.correct
                                ? 'bg-teal-50 border-teal-200 text-teal-800 font-bold'
                                : 'bg-white border-slate-200 text-slate-600 font-medium'
                            }`}
                          >
                            {oIdx === q.correct && <CheckCircle2 size={13} className="text-teal-600 shrink-0" />}
                            <span className="truncate">{opt}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Scenario Rubric Preview */}
                {scenarioBased && (
                  <div className="rounded-2xl p-5 border bg-purple-50/40 border-purple-200 space-y-3">
                    <div className="text-xs font-extrabold uppercase tracking-wider text-purple-700 flex items-center gap-1.5">
                      <Brain size={14} /> AI Scenario Evaluation Rubric Preview
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {scenarioRubric.rubric.map((r) => (
                        <div key={r.label} className="bg-white p-2.5 rounded-xl border border-purple-100 text-xs">
                          <div className="text-slate-500 font-medium">{r.label}</div>
                          <div className="font-mono font-extrabold text-teal-700 mt-0.5">{r.score}/100</div>
                        </div>
                      ))}
                    </div>
                    <p className="text-[11px] text-purple-900 font-medium">
                      AI Feedback: &ldquo;{scenarioRubric.feedback}&rdquo;
                    </p>
                  </div>
                )}

                {/* Attached Challenge Banner */}
                <div
                  className="rounded-2xl p-4 text-white flex items-center justify-between shadow-sm"
                  style={{
                    background: `linear-gradient(135deg, ${COLORS.coral} 0%, ${COLORS.amber} 100%)`,
                  }}
                >
                  <div>
                    <div className="text-xs font-bold flex items-center gap-1">
                      <Target size={14} /> Attached Weekly Store Challenge
                    </div>
                    <div className="text-sm font-extrabold mt-0.5">{draft.challengeTitle}</div>
                  </div>
                  <div className="text-right font-mono font-extrabold text-sm shrink-0 pl-3">
                    +{draft.rewardPoints} XP
                  </div>
                </div>

                {/* Action CTA Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <button
                    onClick={() => setStage('form')}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800"
                  >
                    Discard Draft
                  </button>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={handleGenerate}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-slate-200 flex items-center gap-1.5"
                    >
                      <RefreshCw size={13} /> Regenerate
                    </button>
                    <button
                      onClick={handlePublish}
                      className="px-6 py-2.5 rounded-xl font-bold text-xs text-white shadow-md flex items-center gap-2"
                      style={{ backgroundColor: COLORS.navy }}
                    >
                      <Rocket size={15} />
                      <span>Publish Live to 1,200 Stores</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Adaptive Difficulty Preview & Published Quizzes */}
        <div className="space-y-6">
          {/* Adaptive Learning Trend */}
          <div className="bg-white rounded-3xl p-6 border shadow-xs" style={{ borderColor: COLORS.line }}>
            <SectionHeader
              title="Adaptive Difficulty Engine"
              subtitle="AI escalates question complexity as associates demonstrate mastery"
            />
            <div style={{ height: 160 }} className="w-full mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ADAPTIVE_PROGRESSION}>
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.line} vertical={false} />
                  <XAxis dataKey="attempt" tick={{ fontSize: 10, fill: COLORS.muted }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: COLORS.muted }} axisLine={false} tickLine={false} domain={[0, 100]} />
                  <Tooltip />
                  <Line type="monotone" dataKey="score" stroke={COLORS.plum} strokeWidth={2.5} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-500">3 High Scores in a Row:</span>
              <span className="text-amber-600 font-bold">Hard Scenario Unlocked 🔥</span>
            </div>
          </div>

          {/* Published AI Quizzes List */}
          {publishedQuizzes.length > 0 && (
            <div className="bg-white rounded-3xl p-6 border shadow-xs space-y-3" style={{ borderColor: COLORS.line }}>
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Live AI Curriculums ({publishedQuizzes.length})
              </div>

              <div className="space-y-2.5">
                {publishedQuizzes.map((p) => (
                  <div key={p.id} className="p-3 rounded-2xl border border-slate-200 bg-slate-50/60">
                    <div className="flex items-center justify-between">
                      <Pill color={COLORS.navy3}>{p.skill}</Pill>
                      <span className="text-[11px] font-bold text-amber-700">+{p.rewardPoints} XP</span>
                    </div>
                    <div className="font-bold text-xs text-slate-900 mt-1">{p.product}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{p.questions.length} Questions · {p.language}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
