import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), "app", "questfloor.db")
conn = sqlite3.connect(db_path)
cur = conn.cursor()

cur.execute("PRAGMA table_info(employees)")
cols = [r[1] for r in cur.fetchall()]

if "approval_status" not in cols:
    cur.execute("ALTER TABLE employees ADD COLUMN approval_status VARCHAR DEFAULT 'approved'")
    conn.commit()
    print("Added approval_status column to employees table.")
else:
    print("approval_status column already exists.")

conn.close()
