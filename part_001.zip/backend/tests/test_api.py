import pytest
from fastapi.testclient import TestClient
from backend.app.main import app
from backend.app.seed import seed_database

@pytest.fixture(scope="session", autouse=True)
def init_test_db():
    seed_database()

@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c

def test_health_check(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_personas_and_employees(client):
    response = client.get("/api/auth/personas")
    assert response.status_code == 200
    personas = response.json()["personas"]
    assert len(personas) >= 3
    amit = next((p for p in personas if p["name"] == "Amit Kumar"), None)
    assert amit is not None
    assert amit["store_id"] == "s104"

def test_micro_learning_and_quiz(client):
    # 1. Fetch modules
    res_mod = client.get("/api/learning/modules")
    assert res_mod.status_code == 200
    modules = res_mod.json()
    assert len(modules) >= 1
    m1 = modules[0]
    assert "Smartphone" in m1["title"] or "POS" in m1["title"]

    # 2. Submit quiz for m1
    quiz_payload = {
        "employee_id": "e-amit",
        "module_id": "m1",
        "selected_answers": {
            "q-m1-1": 1,
            "q-m1-2": 1
        }
    }
    res_quiz = client.post("/api/learning/quiz/submit", json=quiz_payload)
    assert res_quiz.status_code == 200
    quiz_res = res_quiz.json()
    assert quiz_res["passed"] is True
    assert quiz_res["xp_earned"] == 30

def test_pos_checkout_upsell(client):
    checkout_payload = {
        "employee_id": "e-amit",
        "store_id": "s104",
        "customer_name": "Rajesh Sharma",
        "items": [
            {
                "product_id": "p-phone-5g",
                "name": "Flagship 5G Smartphone (128GB)",
                "price": 14999,
                "category": "Smartphones",
                "quantity": 1,
                "barcode": "89012345001"
            },
            {
                "product_id": "p-earbuds-anc",
                "name": "True Wireless ANC Earbuds (30h Playtime)",
                "price": 1999,
                "category": "Accessories",
                "quantity": 1,
                "barcode": "89012345002"
            }
        ],
        "coupon_code": "GOLD5",
        "discount_amount": 750,
        "payment_method": "UPI"
    }
    res_pos = client.post("/api/pos/checkout", json=checkout_payload)
    assert res_pos.status_code == 200
    pos_res = res_pos.json()
    assert pos_res["upsell_attached"] is True
    assert pos_res["xp_awarded"] == 50

def test_peer_recognition(client):
    kudos_payload = {
        "sender_id": "e-priya-mgr",
        "receiver_id": "e-rahul",
        "message": "Thanks for helping me understand the new POS billing process!",
        "badge_tagged": "team-player"
    }
    res = client.post("/api/recognition/send", json=kudos_payload)
    assert res.status_code == 200
    assert res.json()["success"] is True

    feed_res = client.get("/api/recognition/feed")
    assert feed_res.status_code == 200
    assert len(feed_res.json()["feed"]) >= 1

def test_manager_store_analytics(client):
    res = client.get("/api/manager/store/s104")
    assert res.status_code == 200
    data = res.json()
    store = data["store"]
    assert store["training_completion_rate"] == 92.0
    assert store["pos_adoption_rate"] == 87.0
    assert store["customer_satisfaction"] == 4.6
    assert store["upsell_conversion_rate"] == 18.0
    assert store["active_associates"] == 24
    assert "measurement_framework" in data

def test_llm_endpoints(client):
    copilot_res = client.post("/api/llm/copilot", json={"query": "Compare 5G smartphone battery specs in Hindi"})
    assert copilot_res.status_code == 200
    assert "battery" in copilot_res.json()["answer"].lower()

    roleplay_turn = client.post("/api/llm/roleplay/turn", json={
        "persona_id": "cust-1",
        "persona_name": "Ramesh Patel",
        "conversation_history": [],
        "associate_message": "Sir, isme 5000mAh battery aur 45W fast charger sath me milta hai."
    })
    assert roleplay_turn.status_code == 200
    assert "customer_reply" in roleplay_turn.json()

    roleplay_eval = client.post("/api/llm/roleplay/evaluate", json={
        "persona_name": "Ramesh Patel",
        "scenario_title": "Festive Smartphone Upsell",
        "conversation_history": [
            {"sender": "customer", "text": "Bhaiya battery kitni der chalegi?"},
            {"sender": "associate", "text": "Sir bilkul, 5000mAh battery aur fast charger ke sath 1.5 din chalegi. Sath me ANC earbuds combo offer me bhi mil jayega."}
        ]
    })
    assert roleplay_eval.status_code == 200
    assert roleplay_eval.json()["overall_score"] >= 80

    kudos_res = client.post("/api/llm/polish-kudos", json={
        "raw_notes": "thanks for fast billing support in POS during rush hour",
        "receiver_name": "Rahul",
        "sender_name": "Priya"
    })
    assert kudos_res.status_code == 200
    assert "Rahul" in kudos_res.json()["polished_message"]

    lesson_res = client.post("/api/llm/generate-lesson", json={
        "topic": "5G AI Camera Modes & Nightography",
        "target_role": "Store Associate"
    })
    assert lesson_res.status_code == 200
    assert len(lesson_res.json()["quiz_questions"]) >= 1
