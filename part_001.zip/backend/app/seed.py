import datetime
from .database import SessionLocal, engine, Base
from .models import Store, Employee, TrainingModule, Challenge, Recognition, POSTransaction, Notification, RewardItem

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    # If already seeded, return
    if db.query(Store).first():
        db.close()
        return

    # 1. Seed Stores
    stores_data = [
        Store(
            id="s104",
            code="QF-STORE-104",
            name="QuestFloor Store #104 (Nagpur Hub)",
            city="Nagpur",
            state="Maharashtra",
            tier="Tier-3",
            active_associates=24,
            training_completion_rate=92.0,
            pos_adoption_rate=87.0,
            customer_satisfaction=4.6,
            upsell_conversion_rate=18.0,
            engagement_score=78.0
        ),
        Store(
            id="s102",
            code="QF-STORE-102",
            name="QuestFloor Indore Palasia Hub",
            city="Indore",
            state="Madhya Pradesh",
            tier="Tier-3",
            active_associates=26,
            training_completion_rate=88.0,
            pos_adoption_rate=84.0,
            customer_satisfaction=4.5,
            upsell_conversion_rate=16.5,
            engagement_score=74.0
        ),
        Store(
            id="s103",
            code="QF-STORE-103",
            name="QuestFloor Jaipur Malviya Nagar",
            city="Jaipur",
            state="Rajasthan",
            tier="Tier-3",
            active_associates=22,
            training_completion_rate=94.0,
            pos_adoption_rate=89.0,
            customer_satisfaction=4.7,
            upsell_conversion_rate=21.0,
            engagement_score=82.0
        ),
        Store(
            id="s105",
            code="QF-STORE-105",
            name="QuestFloor Coimbatore RS Puram",
            city="Coimbatore",
            state="Tamil Nadu",
            tier="Tier-3",
            active_associates=20,
            training_completion_rate=90.0,
            pos_adoption_rate=85.0,
            customer_satisfaction=4.6,
            upsell_conversion_rate=19.0,
            engagement_score=77.0
        ),
        Store(
            id="s106",
            code="QF-STORE-106",
            name="QuestFloor Patna Boring Road",
            city="Patna",
            state="Bihar",
            tier="Tier-3",
            active_associates=18,
            training_completion_rate=85.0,
            pos_adoption_rate=79.0,
            customer_satisfaction=4.3,
            upsell_conversion_rate=14.0,
            engagement_score=71.0
        )
    ]
    db.add_all(stores_data)
    db.commit()

    # 2. Seed Employees
    employees_data = [
        Employee(
            id="e-amit",
            name="Amit Kumar",
            email="amit.kumar@questfloor.in",
            role="associate",
            store_id="s104",
            level=7,
            xp=1500,
            weekly_xp=350,
            monthly_xp=1100,
            streak_days=8,
            pos_adoption=92.0,
            customer_feedback_score=4.7,
            sales_conversion=78.0,
            upsell_conversion=24.0,
            engagement_score=92.0,
            badges=["product-expert", "pos-pro", "team-player", "customer-champion", "learning-streak"],
            completed_modules=["m1", "m2", "m3", "m4", "m5"],
            active=True,
            avatar_color="#3b82f6"
        ),
        Employee(
            id="e-rahul",
            name="Rahul Verma",
            email="rahul.verma@questfloor.in",
            role="associate",
            store_id="s104",
            level=4,
            xp=980,
            weekly_xp=180,
            monthly_xp=560,
            streak_days=3,
            pos_adoption=58.0,
            customer_feedback_score=4.1,
            sales_conversion=60.0,
            upsell_conversion=11.0,
            engagement_score=65.0,
            badges=["team-player", "knowledge-seeker"],
            completed_modules=["m2", "m3"],
            active=True,
            avatar_color="#0d9488"
        ),
        Employee(
            id="e-sneha",
            name="Sneha Patil",
            email="sneha.patil@questfloor.in",
            role="associate",
            store_id="s104",
            level=7,
            xp=1480,
            weekly_xp=320,
            monthly_xp=890,
            streak_days=7,
            pos_adoption=82.0,
            customer_feedback_score=4.8,
            sales_conversion=74.0,
            upsell_conversion=22.0,
            engagement_score=88.0,
            badges=["product-expert", "customer-champion", "team-player", "learning-streak"],
            completed_modules=["m1", "m2", "m3", "m4"],
            active=True,
            avatar_color="#f59e0b"
        ),
        Employee(
            id="e-vikram",
            name="Vikram Singh",
            email="vikram.singh@questfloor.in",
            role="associate",
            store_id="s102",
            level=9,
            xp=2150,
            weekly_xp=410,
            monthly_xp=1200,
            streak_days=14,
            pos_adoption=93.0,
            customer_feedback_score=4.9,
            sales_conversion=88.0,
            upsell_conversion=28.0,
            engagement_score=95.0,
            badges=["product-expert", "pos-pro", "customer-champion", "top-performer", "team-player"],
            completed_modules=["m1", "m2", "m3", "m4", "m5"],
            active=True,
            avatar_color="#8b5cf6"
        ),
        Employee(
            id="e-priya-mgr",
            name="Priya Patel",
            email="priya.patel@questfloor.in",
            role="manager",
            store_id="s104",
            level=10,
            xp=3400,
            weekly_xp=500,
            monthly_xp=1800,
            streak_days=25,
            pos_adoption=98.0,
            customer_feedback_score=4.9,
            sales_conversion=85.0,
            upsell_conversion=25.0,
            engagement_score=96.0,
            badges=["top-performer", "customer-champion", "pos-pro"],
            completed_modules=["m1", "m2", "m3", "m4", "m5"],
            active=True,
            avatar_color="#ec4899"
        ),
        Employee(
            id="e-admin-neha",
            name="Neha Kapoor",
            email="neha.kapoor@questfloor.in",
            role="admin",
            store_id="s104",
            level=12,
            xp=5000,
            weekly_xp=700,
            monthly_xp=2400,
            streak_days=30,
            pos_adoption=99.0,
            customer_feedback_score=5.0,
            sales_conversion=90.0,
            upsell_conversion=30.0,
            engagement_score=98.0,
            badges=["top-performer", "product-expert", "pos-pro", "customer-champion"],
            completed_modules=["m1", "m2", "m3", "m4", "m5"],
            active=True,
            avatar_color="#6366f1"
        )
    ]
    db.add_all(employees_data)
    db.commit()

    # 3. Seed Training Modules
    modules_data = [
        TrainingModule(
            id="m1",
            title="Learn Top 5 Features of the New Smartphone",
            category="Product Knowledge",
            duration_minutes=3,
            xp_reward=30,
            badge_reward="product-expert",
            summary="A rapid 3-minute masterclass on flagship 5G specs, camera sensors, and smart battery optimization for festive walk-in shoppers.",
            content=[
                {
                    "slideNumber": 1,
                    "title": "5000mAh Battery & Adaptive AI Power",
                    "content": "Delivers up to 36 hours of battery backup. In Tier-3 towns where power cuts happen, highlight the 45W SuperVOOC charging (0 to 50% in 18 minutes)."
                },
                {
                    "slideNumber": 2,
                    "title": "50MP Nightography OIS Camera",
                    "content": "Optical Image Stabilization eliminates blurry festive and wedding photos. Demo the night mode directly on your floor showcase unit."
                },
                {
                    "slideNumber": 3,
                    "title": "120Hz Sunlight-Readable AMOLED Display",
                    "content": "1000-nits peak brightness ensures screen remains sharp outdoors under direct sunlight."
                }
            ],
            key_takeaways=[
                "Adaptive AI Battery management extends battery life to 1.5 days",
                "Nightography sensor takes clear low-light pictures",
                "45W SuperVOOC charger is bundled in the box"
            ],
            questions=[
                {
                    "id": "q-m1-1",
                    "question": "Which feature provides better battery optimization during power outages in Tier-3 towns?",
                    "options": [
                        "Manual screen dimming only",
                        "Adaptive AI Battery Management + 5000mAh Cell",
                        "Disabling 5G connectivity permanently",
                        "Restarting phone every 2 hours"
                    ],
                    "correct_index": 1,
                    "explanation": "Adaptive AI Battery Management intelligently manages background apps to ensure 36-hour runtime on a 5000mAh capacity."
                },
                {
                    "id": "q-m1-2",
                    "question": "How should an associate pitch the 45W fast charger to an on-the-go customer?",
                    "options": [
                        "Say it charges very slowly overnight",
                        "Explain it reaches 0-50% in just 18 minutes",
                        "Tell them they need to purchase an extra cable",
                        "Avoid mentioning charging speed"
                    ],
                    "correct_index": 1,
                    "explanation": "0-50% in 18 mins provides instant clarity and urgency for busy customers."
                }
            ]
        ),
        TrainingModule(
            id="m2",
            title="2-Minute POS Challenge: Create Customer Order & Split Tender",
            category="POS System",
            duration_minutes=2,
            xp_reward=30,
            badge_reward="pos-pro",
            summary="Master the new digital POS speed-billing flow: barcode lookup, applying festive discount coupons, and handling split cash+UPI payments.",
            content=[
                {
                    "slideNumber": 1,
                    "title": "Fast Barcode Scanning & Item Addition",
                    "content": "Point barcode gun at packaging or enter 11-digit SKU (e.g. 89012345001). Item auto-adds with current festive pricing."
                },
                {
                    "slideNumber": 2,
                    "title": "Applying Instant Vouchers",
                    "content": "Click 'Promo Code', enter 'GOLD5' (5% loyalty) or 'FESTIVE100' (₹100 flat discount). POS re-calculates tax breakdown instantly."
                },
                {
                    "slideNumber": 3,
                    "title": "Split Payment (Cash + UPI)",
                    "content": "Choose Tender -> Split. Type cash received (e.g. ₹500), remaining balance generates dynamic UPI QR code on customer-facing display."
                }
            ],
            key_takeaways=[
                "Barcode scanning reduces checkout time by 60%",
                "Split tender lets customers pay partially with Cash and UPI",
                "E-receipt is auto-sent to customer WhatsApp number"
            ],
            questions=[
                {
                    "id": "q-m2-1",
                    "question": "What is the fastest way to process a customer wanting to pay ₹500 in Cash and remainder on UPI?",
                    "options": [
                        "Create two separate bills",
                        "Select 'Split Tender' in POS, type ₹500 in Cash, and generate UPI QR for remainder",
                        "Decline the customer transaction",
                        "Ask the customer to withdraw ATM cash"
                    ],
                    "correct_index": 1,
                    "explanation": "Split Tender handles multi-mode settlement in one seamless invoice."
                }
            ]
        ),
        TrainingModule(
            id="m3",
            title="Consultative Upsell: Smartphone + Earbuds Attachment",
            category="Upsell Strategy",
            duration_minutes=3,
            xp_reward=30,
            badge_reward="customer-champion",
            summary="Learn how to naturally recommend True Wireless Earbuds and 1-Year Screen Protection when a customer buys a smartphone.",
            content=[
                {
                    "slideNumber": 1,
                    "title": "The Golden Rule of In-Store Upselling",
                    "content": "Never sell aggressively; recommend with customer value: 'Sir, naye phone ke sath agar yeh ANC Earbuds bundle karte hain, toh ₹999 me mil jayenge (regular ₹1,999).'"
                },
                {
                    "slideNumber": 2,
                    "title": "Attachment Timing at POS",
                    "content": "Present the combo offer right before closing the bill so the discount appears directly on the final invoice."
                }
            ],
            key_takeaways=[
                "Attaching audio accessories increases store ticket size by 28%",
                "Customers appreciate genuine combo bundle savings"
            ],
            questions=[
                {
                    "id": "q-m3-1",
                    "question": "When is the most effective moment to recommend an accessory combo bundle?",
                    "options": [
                        "After the customer has already left the billing counter",
                        "During phone demo and right before finalizing the POS invoice",
                        "Never mention accessories unless asked",
                        "Only if the customer complains about the price"
                    ],
                    "correct_index": 1,
                    "explanation": "Presenting the bundle during product demo lets the customer visualize the complete experience."
                }
            ]
        )
    ]
    db.add_all(modules_data)
    db.commit()

    # 4. Seed Challenges
    challenges_data = [
        Challenge(
            id="c1",
            title="Daily Learning Challenge: Master Smartphone 5G Specs",
            description="Complete the 3-minute micro-module and score 100% on the battery quiz.",
            type="daily",
            target_count=1,
            xp_reward=50,
            badge_reward="product-expert",
            deadline="Today, 9:00 PM"
        ),
        Challenge(
            id="c2",
            title="2-Minute POS Challenge: Process Split-Tender Order",
            description="Simulate an order with a discount voucher and split cash+UPI payment in the POS Sandbox.",
            type="pos_speed",
            target_count=1,
            xp_reward=50,
            badge_reward="pos-pro",
            deadline="Today, 9:00 PM"
        ),
        Challenge(
            id="c3",
            title="Upsell Sprint: Attach Earbuds to Smartphone Order",
            description="Recommend and attach audio accessories to an order in POS terminal.",
            type="upsell_sprint",
            target_count=1,
            xp_reward=50,
            badge_reward="customer-champion",
            deadline="Tomorrow, 6:00 PM"
        ),
        Challenge(
            id="c4",
            title="Peer Appreciation: Give Kudos to a Teammate",
            description="Send a peer recognition shoutout to appreciate a colleague on your shift.",
            type="peer_kudos",
            target_count=1,
            xp_reward=20,
            badge_reward="team-player",
            deadline="Ongoing"
        )
    ]
    db.add_all(challenges_data)
    db.commit()

    # 5. Seed Recognitions
    recognitions_data = [
        Recognition(
            id="r1",
            sender_id="e-priya-mgr",
            receiver_id="e-rahul",
            message="Thanks for helping me understand the new POS billing process during the evening rush! Your patience was super helpful.",
            badge_tagged="team-player",
            xp_awarded=20,
            likes_count=6,
            created_at=datetime.datetime.utcnow() - datetime.timedelta(hours=2)
        ),
        Recognition(
            id="r2",
            sender_id="e-amit",
            receiver_id="e-sneha",
            message="Sneha explained the 5000mAh battery and camera specs to an elderly customer with so much patience and clarity! True customer champion.",
            badge_tagged="customer-champion",
            xp_awarded=20,
            likes_count=4,
            created_at=datetime.datetime.utcnow() - datetime.timedelta(hours=5)
        ),
        Recognition(
            id="r3",
            sender_id="e-sneha",
            receiver_id="e-vikram",
            message="Vikram shared a brilliant tip on how to resolve POS barcode errors quickly. Saved our team 15 minutes today!",
            badge_tagged="pos-pro",
            xp_awarded=20,
            likes_count=5,
            created_at=datetime.datetime.utcnow() - datetime.timedelta(days=1)
        )
    ]
    db.add_all(recognitions_data)
    db.commit()

    # 6. Seed Notifications
    notifications_data = [
        Notification(
            id="n1",
            user_id="e-amit",
            title="🔔 New Challenge Available!",
            message="Learn the new product's top 3 features in 5 minutes. Reward: +50 XP",
            type="challenge",
            xp_bonus=50,
            is_read=False
        ),
        Notification(
            id="n2",
            user_id="e-amit",
            title="🎉 Congratulations!",
            message="You reached Level 7 with 1,240+ XP and maintained an 8-day learning streak!",
            type="level_up",
            xp_bonus=0,
            is_read=True
        ),
        Notification(
            id="n3",
            user_id="e-priya-mgr",
            title="⚠️ Attention Needed (Store #104)",
            message="5 associates in your store have not completed the latest POS training update. Targeted coaching recommended.",
            type="manager_alert",
            xp_bonus=0,
            is_read=False
        )
    ]
    db.add_all(notifications_data)
    db.commit()

    # 7. Seed Rewards
    rewards_data = [
        RewardItem(
            id="rw1",
            title="Amazon / Flipkart ₹500 Shopping Voucher",
            category="Voucher",
            points_cost=500,
            description="Instant e-voucher redeemable across 10,000+ products.",
            icon_emoji="🛍️",
            stock_count=40
        ),
        RewardItem(
            id="rw2",
            title="Preferred Shift Pick (Weekend Priority)",
            category="Shift Perk",
            points_cost=400,
            description="Choose your preferred morning or evening floor shift for the upcoming week.",
            icon_emoji="🗓️",
            stock_count=15
        ),
        RewardItem(
            id="rw3",
            title="Barista Coffee & Snack Card (₹250)",
            category="Perk",
            points_cost=250,
            description="Enjoy complimentary cafe snacks during break times.",
            icon_emoji="☕",
            stock_count=60
        ),
        RewardItem(
            id="rw4",
            title="Store Champion Trophy & Digital Certificate",
            category="Recognition",
            points_cost=800,
            description="Personalized recognition plaque presented during monthly regional townhall.",
            icon_emoji="🏆",
            stock_count=10
        )
    ]
    db.add_all(rewards_data)
    db.commit()
    db.close()
    print("Database seeded successfully with QuestFloor Enterprise Retail data!")

if __name__ == "__main__":
    seed_database()
