import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from .database import Base

class Store(Base):
    __tablename__ = "stores"

    id = Column(String, primary_key=True, index=True) # e.g. 's104', 's1'
    code = Column(String, unique=True, index=True)   # e.g. 'QF-STORE-104'
    name = Column(String, nullable=False)            # e.g. 'QuestFloor Store #104 (Nagpur Hub)'
    city = Column(String, nullable=False)            # 'Nagpur', 'Indore', 'Jaipur'
    state = Column(String, nullable=False)
    tier = Column(String, default="Tier-3")          # 'Tier-3', 'Tier-2'
    active_associates = Column(Integer, default=24)
    training_completion_rate = Column(Float, default=92.0)  # 92%
    pos_adoption_rate = Column(Float, default=87.0)         # 87%
    customer_satisfaction = Column(Float, default=4.6)      # 4.6 / 5.0
    upsell_conversion_rate = Column(Float, default=18.0)    # 18%
    engagement_score = Column(Float, default=78.0)          # 78% (up from 52%)

    employees = relationship("Employee", back_populates="store")
    transactions = relationship("POSTransaction", back_populates="store")

class Employee(Base):
    __tablename__ = "employees"

    id = Column(String, primary_key=True, index=True) # e.g. 'e-amit', 'e-rahul'
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True)
    role = Column(String, default="associate")        # 'associate', 'manager', 'admin'
    store_id = Column(String, ForeignKey("stores.id"), nullable=True)
    level = Column(Integer, default=7)
    xp = Column(Integer, default=1240)
    weekly_xp = Column(Integer, default=320)
    monthly_xp = Column(Integer, default=890)
    streak_days = Column(Integer, default=8)
    pos_adoption = Column(Float, default=82.0)
    customer_feedback_score = Column(Float, default=4.7)
    sales_conversion = Column(Float, default=74.0)
    upsell_conversion = Column(Float, default=22.0)
    engagement_score = Column(Float, default=88.0)
    badges = Column(JSON, default=list)              # ['product-expert', 'pos-pro', 'team-player', 'customer-champion', 'learning-streak']
    completed_modules = Column(JSON, default=list)   # ['m1', 'm2', 'm3']
    active = Column(Boolean, default=True)
    approval_status = Column(String, default="approved") # 'approved', 'pending', 'rejected'
    avatar_color = Column(String, default="#3b82f6")
    join_date = Column(String, default="2025-01-15")

    store = relationship("Store", back_populates="employees")
    sent_recognitions = relationship("Recognition", foreign_keys="Recognition.sender_id", back_populates="sender")
    received_recognitions = relationship("Recognition", foreign_keys="Recognition.receiver_id", back_populates="receiver")
    transactions = relationship("POSTransaction", back_populates="employee")

class TrainingModule(Base):
    __tablename__ = "training_modules"

    id = Column(String, primary_key=True, index=True) # 'm-phone-5g', 'm-pos-order'
    title = Column(String, nullable=False)
    category = Column(String, nullable=False)         # 'Product Knowledge', 'POS System', 'Customer Delight', 'Upsell Strategy'
    duration_minutes = Column(Integer, default=3)     # 2-5 min micro-learning
    xp_reward = Column(Integer, default=30)
    badge_reward = Column(String, nullable=True)      # 'product-expert', 'pos-pro'
    summary = Column(Text, nullable=False)
    content = Column(JSON, nullable=False)            # List of sections/slides with bullet points & tips
    key_takeaways = Column(JSON, default=list)
    questions = Column(JSON, default=list)            # Interactive quiz questions with options & explanations
    is_active = Column(Boolean, default=True)

class Challenge(Base):
    __tablename__ = "challenges"

    id = Column(String, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    type = Column(String, default="daily")            # 'daily', 'pos_speed', 'upsell_sprint', 'peer_kudos'
    target_count = Column(Integer, default=1)
    xp_reward = Column(Integer, default=50)
    badge_reward = Column(String, nullable=True)
    deadline = Column(String, default="Today, 9:00 PM")
    is_active = Column(Boolean, default=True)

class Recognition(Base):
    __tablename__ = "recognitions"

    id = Column(String, primary_key=True, index=True)
    sender_id = Column(String, ForeignKey("employees.id"), nullable=False)
    receiver_id = Column(String, ForeignKey("employees.id"), nullable=False)
    message = Column(Text, nullable=False)
    badge_tagged = Column(String, default="team-player") # 'team-player', 'pos-pro', 'customer-champion'
    xp_awarded = Column(Integer, default=20)
    likes_count = Column(Integer, default=3)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    sender = relationship("Employee", foreign_keys=[sender_id], back_populates="sent_recognitions")
    receiver = relationship("Employee", foreign_keys=[receiver_id], back_populates="received_recognitions")

class POSTransaction(Base):
    __tablename__ = "pos_transactions"

    id = Column(String, primary_key=True, index=True)
    store_id = Column(String, ForeignKey("stores.id"), nullable=False)
    employee_id = Column(String, ForeignKey("employees.id"), nullable=False)
    customer_name = Column(String, default="Walk-in Customer")
    cart_items = Column(JSON, nullable=False)          # list of items {id, name, price, qty, category}
    total_amount = Column(Float, nullable=False)
    discount_amount = Column(Float, default=0.0)
    coupon_applied = Column(String, nullable=True)
    payment_method = Column(String, default="UPI")     # 'UPI', 'Cash', 'Card', 'Split'
    upsell_attached = Column(Boolean, default=False)   # e.g. Smartphone + Earbuds/Warranty attached!
    upsell_item_name = Column(String, nullable=True)   # 'Active Noise Cancelling Earbuds'
    xp_awarded = Column(Integer, default=20)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    store = relationship("Store", back_populates="transactions")
    employee = relationship("Employee", back_populates="transactions")

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, index=True, nullable=True) # None = broadcast to all
    title = Column(String, nullable=False)
    message = Column(Text, nullable=False)
    type = Column(String, default="challenge")         # 'challenge', 'badge', 'peer_kudos', 'manager_alert', 'level_up'
    xp_bonus = Column(Integer, default=0)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class RewardItem(Base):
    __tablename__ = "rewards"

    id = Column(String, primary_key=True, index=True)
    title = Column(String, nullable=False)
    category = Column(String, default="Voucher")       # 'Voucher', 'Shift Perk', 'Merchandise', 'Recognition'
    points_cost = Column(Integer, nullable=False)      # e.g. 500 XP
    description = Column(Text, nullable=False)
    icon_emoji = Column(String, default="🎁")
    stock_count = Column(Integer, default=50)
