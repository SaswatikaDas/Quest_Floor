import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .seed import seed_database
from .routers import auth, employees, learning, pos, recognition, manager, llm

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Seed database with initial retail network data
    seed_database()
    yield
    # Shutdown

app = FastAPI(
    title="QuestFloor / RetailRise API",
    description="Workforce Engagement, Gamified Micro-Learning & Recognition Platform for 1,200 Tier-3 Retail Stores",
    version="2.0.0",
    lifespan=lifespan
)

# Enable CORS for Next.js / Vite / React frontends
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API Routers
app.include_router(auth.router, prefix="/api")
app.include_router(employees.router, prefix="/api")
app.include_router(learning.router, prefix="/api")
app.include_router(pos.router, prefix="/api")
app.include_router(recognition.router, prefix="/api")
app.include_router(manager.router, prefix="/api")
app.include_router(llm.router, prefix="/api")

@app.get("/")
def root():
    return {
        "platform": "QuestFloor / RetailRise Enterprise HCM",
        "status": "online",
        "stores_network": 1200,
        "associates_count": 3000,
        "docs_url": "/docs"
    }

@app.get("/api/health")
def health_check():
    return {"status": "healthy", "service": "QuestFloor Python Backend"}
