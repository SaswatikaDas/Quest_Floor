from fastapi import APIRouter, HTTPException
from typing import Dict, Any
from ..schemas import (
    RoleplayTurnRequest,
    RoleplayTurnResponse,
    RoleplayEvaluationRequest,
    RoleplayEvaluationResponse,
    CopilotMessageRequest,
    CopilotMessageResponse,
    PolishKudosRequest,
    PolishKudosResponse,
    GenerateLessonRequest,
    GenerateLessonResponse,
    ManagerInsightsResponse
)
from ..llm_engine import llm_engine

router = APIRouter(prefix="/llm", tags=["LLM Features & GenAI Copilots"])

@router.post("/roleplay/turn", response_model=RoleplayTurnResponse)
def roleplay_turn(req: RoleplayTurnRequest):
    """Simulates realistic customer turn in sales roleplay with AI coach tip."""
    result = llm_engine.simulate_customer_turn(
        persona_name=req.persona_name,
        conversation_history=req.conversation_history,
        associate_message=req.associate_message
    )
    return RoleplayTurnResponse(**result)

@router.post("/roleplay/evaluate", response_model=RoleplayEvaluationResponse)
def evaluate_roleplay(req: RoleplayEvaluationRequest):
    """Generates multi-attribute roleplay scorecard with XP reward."""
    result = llm_engine.evaluate_roleplay_session(
        persona_name=req.persona_name,
        scenario_title=req.scenario_title,
        conversation_history=req.conversation_history
    )
    return RoleplayEvaluationResponse(**result)

@router.post("/copilot", response_model=CopilotMessageResponse)
def ask_copilot(req: CopilotMessageRequest):
    """Real-time floor assistant for associates to query specs, POS troubleshooting, and upsell pitches."""
    result = llm_engine.ask_copilot(query=req.query, context_type=req.context_type)
    return CopilotMessageResponse(**result)

@router.post("/polish-kudos", response_model=PolishKudosResponse)
def polish_kudos(req: PolishKudosRequest):
    """Refines rough notes into inspiring peer recognition shoutouts."""
    result = llm_engine.polish_kudos(
        raw_notes=req.raw_notes,
        receiver_name=req.receiver_name,
        sender_name=req.sender_name,
        help_context=req.help_context
    )
    return PolishKudosResponse(**result)

@router.post("/generate-lesson", response_model=GenerateLessonResponse)
def generate_lesson(req: GenerateLessonRequest):
    """Generates a complete 2-minute micro-learning module with quiz on demand."""
    result = llm_engine.generate_micro_lesson(topic=req.topic, store_tier=req.store_tier)
    return GenerateLessonResponse(**result)

@router.post("/manager-insights", response_model=ManagerInsightsResponse)
def generate_manager_insights(payload: Dict[str, Any]):
    """Generates actionable AI coaching and intervention playbook for store managers."""
    store_id = payload.get("store_id", "s104")
    metrics = payload.get("metrics", {})
    result = llm_engine.generate_manager_insights(store_id=store_id, metrics=metrics)
    return ManagerInsightsResponse(**result)
