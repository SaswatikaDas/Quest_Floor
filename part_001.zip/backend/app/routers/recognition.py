import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..models import Recognition, Employee, Notification
from ..schemas import CreateRecognitionRequest, RecognitionResponse
from ..llm_engine import llm_engine

router = APIRouter(prefix="/recognition", tags=["Peer Recognition & Kudos"])

@router.get("/feed")
def get_recognition_feed(limit: int = 20, db: Session = Depends(get_db)):
    recognitions = db.query(Recognition).order_by(Recognition.created_at.desc()).limit(limit).all()
    feed = []
    for r in recognitions:
        sender_name = r.sender.name if r.sender else "Colleague"
        receiver_name = r.receiver.name if r.receiver else "Colleague"
        feed.append({
            "id": r.id,
            "sender_id": r.sender_id,
            "sender_name": sender_name,
            "receiver_id": r.receiver_id,
            "receiver_name": receiver_name,
            "message": r.message,
            "badge_tagged": r.badge_tagged,
            "xp_awarded": r.xp_awarded,
            "likes_count": r.likes_count,
            "created_at": r.created_at.isoformat()
        })
    return {"feed": feed}

@router.post("/send")
def send_peer_recognition(req: CreateRecognitionRequest, db: Session = Depends(get_db)):
    sender = db.query(Employee).filter(Employee.id == req.sender_id).first()
    receiver = db.query(Employee).filter(Employee.id == req.receiver_id).first()

    if not sender or not receiver:
        raise HTTPException(status_code=404, detail="Sender or receiver not found")

    if sender.id == receiver.id:
        raise HTTPException(status_code=400, detail="Cannot send kudos to yourself")

    # Award receiver +20 XP
    xp_award = 20
    receiver.xp += xp_award
    receiver.weekly_xp += xp_award
    receiver.monthly_xp += xp_award
    receiver.level = max(1, (receiver.xp // 200) + 1)

    badges = list(receiver.badges) if receiver.badges else []
    if req.badge_tagged and req.badge_tagged not in badges:
        badges.append(req.badge_tagged)
        receiver.badges = badges

    rec_id = f"rec-{uuid.uuid4().hex[:8]}"
    recognition = Recognition(
        id=rec_id,
        sender_id=sender.id,
        receiver_id=receiver.id,
        message=req.message,
        badge_tagged=req.badge_tagged,
        xp_awarded=xp_award,
        likes_count=1
    )
    db.add(recognition)

    # Notification for receiver
    notif = Notification(
        id=f"notif-kudos-{rec_id}",
        user_id=receiver.id,
        title="🤝 You Received Peer Kudos!",
        message=f"{sender.name} recognized you: '{req.message}' (+{xp_award} XP, '{req.badge_tagged}' Tag)!",
        type="peer_kudos",
        xp_bonus=xp_award
    )
    db.add(notif)
    db.commit()

    return {
        "success": True,
        "recognition_id": rec_id,
        "receiver_new_xp": receiver.xp,
        "message": f"Kudos sent to {receiver.name}! They earned +{xp_award} XP."
    }

@router.post("/{recognition_id}/like")
def like_recognition(recognition_id: str, db: Session = Depends(get_db)):
    rec = db.query(Recognition).filter(Recognition.id == recognition_id).first()
    if not rec:
        raise HTTPException(status_code=404, detail="Recognition not found")
    rec.likes_count += 1
    db.commit()
    return {"success": True, "likes_count": rec.likes_count}
