from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from ..database import get_db
from ..models import TrainingModule, Employee, Notification, Challenge
from ..schemas import TrainingModuleSchema, QuizSubmitRequest, QuizSubmitResponse
from ..llm_engine import llm_engine

router = APIRouter(prefix="/learning", tags=["Micro-Learning & Quizzes"])

@router.get("/modules", response_model=List[TrainingModuleSchema])
def get_all_modules(category: str = None, db: Session = Depends(get_db)):
    query = db.query(TrainingModule).filter(TrainingModule.is_active == True)
    if category:
        query = query.filter(TrainingModule.category == category)
    return query.all()

@router.get("/modules/{module_id}", response_model=TrainingModuleSchema)
def get_module(module_id: str, db: Session = Depends(get_db)):
    mod = db.query(TrainingModule).filter(TrainingModule.id == module_id).first()
    if not mod:
        raise HTTPException(status_code=404, detail="Training module not found")
    return mod

@router.post("/quiz/submit", response_model=QuizSubmitResponse)
def submit_quiz(req: QuizSubmitRequest, db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == req.employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    mod = db.query(TrainingModule).filter(TrainingModule.id == req.module_id).first()
    if not mod:
        raise HTTPException(status_code=404, detail="Module not found")

    questions = mod.questions or []
    correct_count = 0
    total_count = len(questions)
    explanations = {}

    for q in questions:
        qid = q.get("id")
        user_ans = req.selected_answers.get(qid)
        correct_idx = q.get("correct_index", 0)
        explanations[qid] = q.get("explanation", "Review the key product features.")

        if user_ans == correct_idx:
            correct_count += 1

    score_pct = (correct_count / total_count * 100) if total_count > 0 else 100.0
    passed = score_pct >= 70.0

    xp_earned = 0
    badge_unlocked = None

    if passed:
        xp_earned = mod.xp_reward # +30 XP
        emp.xp += xp_earned
        emp.weekly_xp += xp_earned
        emp.monthly_xp += xp_earned
        emp.streak_days += 1 # maintain streak
        emp.level = max(1, (emp.xp // 200) + 1)

        # Mark completed
        completed = list(emp.completed_modules) if emp.completed_modules else []
        if mod.id not in completed:
            completed.append(mod.id)
            emp.completed_modules = completed

        # Unlock module badge
        badges = list(emp.badges) if emp.badges else []
        if mod.badge_reward and mod.badge_reward not in badges:
            badges.append(mod.badge_reward)
            emp.badges = badges
            badge_unlocked = mod.badge_reward

        # Add notification
        notif = Notification(
            id=f"notif-quiz-{int(emp.xp)}",
            user_id=emp.id,
            title="🎉 Micro-Learning Quiz Passed!",
            message=f"You completed '{mod.title}' (+{xp_earned} XP)! Current Streak: {emp.streak_days} days 🔥",
            type="challenge",
            xp_bonus=xp_earned
        )
        db.add(notif)
        db.commit()
        db.refresh(emp)

    return QuizSubmitResponse(
        score_percentage=score_pct,
        passed=passed,
        correct_count=correct_count,
        total_count=total_count,
        xp_earned=xp_earned,
        new_total_xp=emp.xp,
        new_level=emp.level,
        badge_unlocked=badge_unlocked,
        streak_updated=emp.streak_days,
        explanations=explanations
    )

@router.get("/challenges/active")
def get_active_challenges(db: Session = Depends(get_db)):
    challenges = db.query(Challenge).filter(Challenge.is_active == True).all()
    return {"challenges": challenges}
