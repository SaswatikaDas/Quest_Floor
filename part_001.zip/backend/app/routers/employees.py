from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from ..database import get_db
from ..models import Employee, Notification, RewardItem
from ..schemas import EmployeeResponse, AddXPRequest

router = APIRouter(prefix="/employees", tags=["Employees & Gamification"])

def calculate_level(xp: int) -> int:
    """Calculates level based on XP (every 200 XP = 1 Level)."""
    return max(1, (xp // 200) + 1)

@router.get("/", response_model=List[EmployeeResponse])
def list_employees(store_id: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(Employee)
    if store_id:
        query = query.filter(Employee.store_id == store_id)
    return query.all()

@router.get("/{employee_id}", response_model=EmployeeResponse)
def get_employee(employee_id: str, db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    return emp

@router.post("/{employee_id}/add-xp")
def add_employee_xp(employee_id: str, req: AddXPRequest, db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    emp.xp += req.xp_amount
    emp.weekly_xp += req.xp_amount
    emp.monthly_xp += req.xp_amount
    new_lvl = calculate_level(emp.xp)
    leveled_up = new_lvl > emp.level
    emp.level = new_lvl

    # Badge unlocks
    badges_list = list(emp.badges) if emp.badges else []
    if req.badge_to_unlock and req.badge_to_unlock not in badges_list:
        badges_list.append(req.badge_to_unlock)
        emp.badges = badges_list
        # Trigger notification
        notif = Notification(
            id=f"notif-badge-{int(emp.xp)}",
            user_id=emp.id,
            title="🏅 New Badge Unlocked!",
            message=f"You earned the '{req.badge_to_unlock.replace('-', ' ').title()}' badge! Reason: {req.reason}",
            type="badge",
            xp_bonus=req.xp_amount
        )
        db.add(notif)

    db.commit()
    db.refresh(emp)

    return {
        "success": True,
        "new_xp": emp.xp,
        "new_level": emp.level,
        "leveled_up": leveled_up,
        "badges": emp.badges,
        "reason": req.reason
    }

@router.get("/leaderboard/top")
def get_leaderboard(scope: str = "store", store_id: str = "s104", db: Session = Depends(get_db)):
    query = db.query(Employee).filter(Employee.role == "associate")
    if scope == "store":
        query = query.filter(Employee.store_id == store_id)
    
    associates = query.order_by(Employee.xp.desc()).all()
    results = []
    for rank, a in enumerate(associates, start=1):
        results.append({
            "rank": rank,
            "id": a.id,
            "name": a.name,
            "store_id": a.store_id,
            "level": a.level,
            "xp": a.xp,
            "streak_days": a.streak_days,
            "badges_count": len(a.badges) if a.badges else 0,
            "customer_feedback_score": a.customer_feedback_score,
            "pos_adoption": a.pos_adoption,
            "avatar_color": a.avatar_color
        })
    return {"leaderboard": results, "scope": scope}

@router.get("/{employee_id}/notifications")
def get_employee_notifications(employee_id: str, db: Session = Depends(get_db)):
    notifs = db.query(Notification).filter(
        (Notification.user_id == employee_id) | (Notification.user_id == None)
    ).order_by(Notification.created_at.desc()).all()
    return {"notifications": notifs}

@router.get("/{employee_id}/rewards")
def get_rewards_catalog(employee_id: str, db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    rewards = db.query(RewardItem).all()
    return {
        "employee_xp": emp.xp if emp else 0,
        "rewards": rewards
    }
