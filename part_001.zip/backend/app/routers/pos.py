import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..models import POSTransaction, Employee, Store, Notification
from ..schemas import POSCheckoutRequest, POSCheckoutResponse

router = APIRouter(prefix="/pos", tags=["POS Sandbox & Speed Billing"])

# In-memory POS product demo catalog
POS_CATALOG = [
    {
        "id": "p-phone-5g",
        "barcode": "89012345001",
        "name": "Flagship 5G Smartphone (128GB)",
        "price": 14999,
        "category": "Smartphones",
        "emoji": "📱",
        "is_upsell_eligible": True,
        "combo_offer": "Bundle ANC Earbuds for ₹999 (Save ₹1,000)"
    },
    {
        "id": "p-earbuds-anc",
        "barcode": "89012345002",
        "name": "True Wireless ANC Earbuds (30h Playtime)",
        "price": 1999,
        "category": "Accessories",
        "emoji": "🎧",
        "is_upsell_eligible": False,
        "combo_offer": "40% off when attached to Smartphone"
    },
    {
        "id": "p-screen-guard",
        "barcode": "89012345003",
        "name": "9H Tempered Glass + 1-Yr Screen Care",
        "price": 499,
        "category": "Protection",
        "emoji": "🛡️",
        "is_upsell_eligible": False
    },
    {
        "id": "p-fast-charger",
        "barcode": "89012345004",
        "name": "45W SuperVOOC Fast Power Adapter",
        "price": 899,
        "category": "Accessories",
        "emoji": "⚡"
    },
    {
        "id": "p-smartwatch",
        "barcode": "89012345005",
        "name": "Fitness Tracker AMOLED Smartwatch",
        "price": 2499,
        "category": "Wearables",
        "emoji": "⌚"
    }
]

@router.get("/catalog")
def get_pos_catalog():
    return {"catalog": POS_CATALOG}

@router.post("/checkout", response_model=POSCheckoutResponse)
def process_checkout(req: POSCheckoutRequest, db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == req.employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    total_amt = sum(item.price * item.quantity for item in req.items)
    final_amt = max(0.0, total_amt - req.discount_amount)

    # Detect smartphone + accessory upsell attachment
    has_phone = any(item.category == "Smartphones" for item in req.items)
    has_audio = any("earbud" in item.name.lower() or "buds" in item.name.lower() or item.category == "Accessories" for item in req.items)
    
    upsell_attached = has_phone and has_audio
    upsell_item_name = "True Wireless ANC Earbuds Combo" if upsell_attached else None

    # Calculate XP reward
    base_xp = 20 # for standard error-free POS transaction
    bonus_xp = 30 if upsell_attached else 0 # +30 bonus for upsell
    total_xp_awarded = base_xp + bonus_xp

    emp.xp += total_xp_awarded
    emp.weekly_xp += total_xp_awarded
    emp.monthly_xp += total_xp_awarded
    emp.level = max(1, (emp.xp // 200) + 1)
    emp.pos_adoption = min(100.0, emp.pos_adoption + 0.5)

    badge_unlocked = None
    badges = list(emp.badges) if emp.badges else []
    
    if "pos-pro" not in badges:
        badges.append("pos-pro")
        badge_unlocked = "pos-pro"
        emp.badges = badges

    # Create transaction record
    tx_id = f"TX-{uuid.uuid4().hex[:8].upper()}"
    tx = POSTransaction(
        id=tx_id,
        store_id=req.store_id,
        employee_id=emp.id,
        customer_name=req.customer_name or "Walk-in Customer",
        cart_items=[item.model_dump() for item in req.items],
        total_amount=final_amt,
        discount_amount=req.discount_amount,
        coupon_applied=req.coupon_code,
        payment_method=req.payment_method,
        upsell_attached=upsell_attached,
        upsell_item_name=upsell_item_name,
        xp_awarded=total_xp_awarded
    )
    db.add(tx)

    # Notification
    notif_msg = f"POS Transaction {tx_id} completed (+{total_xp_awarded} XP)."
    if upsell_attached:
        notif_msg += " 🚀 Smartphone + Earbuds Upsell Combo attached (+30 XP Bonus)!"
    
    notif = Notification(
        id=f"notif-pos-{tx_id}",
        user_id=emp.id,
        title="🧾 POS Order Settled!",
        message=notif_msg,
        type="challenge",
        xp_bonus=total_xp_awarded
    )
    db.add(notif)
    db.commit()
    db.refresh(emp)

    return POSCheckoutResponse(
        transaction_id=tx_id,
        total_amount=total_amt,
        final_amount=final_amt,
        discount_applied=req.discount_amount,
        upsell_attached=upsell_attached,
        upsell_item_name=upsell_item_name,
        xp_awarded=total_xp_awarded,
        badge_unlocked=badge_unlocked,
        message="Transaction processed successfully! E-Receipt dispatched."
    )
