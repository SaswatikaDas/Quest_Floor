from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
import uuid
from ..database import get_db
from ..models import Employee
from ..schemas import LoginRequest, RegisterRequest

router = APIRouter(prefix="/auth", tags=["Authentication & Personas"])

@router.get("/personas")
def get_available_personas(db: Session = Depends(get_db)):
    """Returns available personas to switch roles effortlessly in UI."""
    employees = db.query(Employee).all()
    personas = []
    for emp in employees:
        personas.append({
            "id": emp.id,
            "name": emp.name,
            "role": emp.role,
            "email": emp.email,
            "store_id": emp.store_id,
            "level": emp.level,
            "xp": emp.xp,
            "streak_days": emp.streak_days,
            "approval_status": getattr(emp, "approval_status", "approved"),
            "avatar_color": emp.avatar_color
        })
    return {"personas": personas}

@router.post("/login")
def login_user(payload: LoginRequest, db: Session = Depends(get_db)):
    """Authenticates user with username/email and password."""
    # Find matching employee
    emp = db.query(Employee).filter(
        (Employee.email == payload.email_or_username.lower().strip()) |
        (Employee.name.ilike(f"%{payload.email_or_username.strip()}%"))
    ).first()

    if not emp:
        # If user logs in with role-based default demo credentials
        if payload.role == "manager" or "manager" in payload.email_or_username.lower():
            emp = db.query(Employee).filter(Employee.role == "manager").first()
        elif payload.role == "admin" or "admin" in payload.email_or_username.lower():
            emp = db.query(Employee).filter(Employee.role == "admin").first()
        else:
            emp = db.query(Employee).first()

    if not emp:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password"
        )

    # Check approval status
    if getattr(emp, "approval_status", "approved") == "pending":
        return {
            "status": "pending_approval",
            "message": f"Your account request is currently pending verification by Store Manager (Store #{emp.store_id}). You will be able to sign in once approved.",
            "user": {
                "id": emp.id,
                "name": emp.name,
                "email": emp.email,
                "role": emp.role,
                "store_id": emp.store_id,
                "approval_status": "pending"
            }
        }

    return {
        "status": "success",
        "message": f"Welcome back, {emp.name}!",
        "token": f"bearer_{emp.id}_{uuid.uuid4().hex[:8]}",
        "user": {
            "id": emp.id,
            "name": emp.name,
            "email": emp.email,
            "role": emp.role,
            "store_id": emp.store_id,
            "level": emp.level,
            "xp": emp.xp,
            "streak_days": emp.streak_days,
            "approval_status": getattr(emp, "approval_status", "approved"),
            "avatar_color": emp.avatar_color,
        }
    }

@router.post("/register")
def register_user(payload: RegisterRequest, db: Session = Depends(get_db)):
    """Registers a new store associate and routes for Store Manager verification."""
    existing = db.query(Employee).filter(Employee.email == payload.email.lower().strip()).first()
    if existing:
        if getattr(existing, "approval_status", "approved") == "pending":
            return {
                "status": "pending_approval",
                "message": f"Registration request for {existing.name} is already submitted and pending Store Manager approval.",
                "user": {
                    "id": existing.id,
                    "name": existing.name,
                    "email": existing.email,
                    "role": existing.role,
                    "store_id": existing.store_id,
                    "approval_status": "pending"
                }
            }
        return {
            "status": "success",
            "message": f"Welcome back, {existing.name}!",
            "user": {
                "id": existing.id,
                "name": existing.name,
                "email": existing.email,
                "role": existing.role,
                "store_id": existing.store_id,
                "level": existing.level,
                "xp": existing.xp,
                "avatar_color": existing.avatar_color,
            }
        }

    new_id = f"e_{uuid.uuid4().hex[:6]}"
    colors = ["#3b82f6", "#10b981", "#8b5cf6", "#f59e0b", "#ec4899", "#06b6d4"]
    avatar_color = colors[len(new_id) % len(colors)]

    new_emp = Employee(
        id=new_id,
        name=payload.name.strip(),
        email=payload.email.lower().strip(),
        role=payload.role.lower().strip(),
        store_id=payload.store_id or "s104",
        level=1,
        xp=100,  # Welcome onboarding XP bonus
        weekly_xp=100,
        monthly_xp=100,
        streak_days=1,
        pos_adoption=75.0,
        customer_feedback_score=4.5,
        sales_conversion=70.0,
        upsell_conversion=15.0,
        engagement_score=85.0,
        badges=["knowledge-seeker"],
        completed_modules=[],
        active=False,
        approval_status="pending",  # Requires Store Manager acceptance
        avatar_color=avatar_color,
    )
    db.add(new_emp)
    db.commit()
    db.refresh(new_emp)

    return {
        "status": "pending_approval",
        "message": f"Registration request submitted! Your verification request has been sent to Store Manager (Store #{new_emp.store_id}). You can log in once the manager approves.",
        "user": {
            "id": new_emp.id,
            "name": new_emp.name,
            "email": new_emp.email,
            "role": new_emp.role,
            "store_id": new_emp.store_id,
            "approval_status": "pending",
            "avatar_color": new_emp.avatar_color,
        }
    }
