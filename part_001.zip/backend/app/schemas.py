from typing import List, Optional, Any, Dict
from pydantic import BaseModel, Field
from datetime import datetime

# ==================== EMPLOYEE SCHEMAS ====================
class EmployeeBase(BaseModel):
    id: str
    name: str
    email: str
    role: str = "associate"
    store_id: Optional[str] = "s104"
    level: int = 7
    xp: int = 1240
    weekly_xp: int = 320
    monthly_xp: int = 890
    streak_days: int = 8
    pos_adoption: float = 82.0
    customer_feedback_score: float = 4.7
    sales_conversion: float = 74.0
    upsell_conversion: float = 22.0
    engagement_score: float = 88.0
    badges: List[str] = []
    completed_modules: List[str] = []
    active: bool = True
    avatar_color: str = "#3b82f6"

class EmployeeResponse(EmployeeBase):
    class Config:
        from_attributes = True

class AddXPRequest(BaseModel):
    xp_amount: int
    reason: str
    badge_to_unlock: Optional[str] = None

class LoginRequest(BaseModel):
    email_or_username: str
    password: str
    role: Optional[str] = "employee"

class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str
    role: str = "employee"
    store_id: Optional[str] = "s104"
    staff_id: Optional[str] = None

# ==================== STORE SCHEMAS ====================
class StoreBase(BaseModel):
    id: str
    code: str
    name: str
    city: str
    state: str
    tier: str = "Tier-3"
    active_associates: int = 24
    training_completion_rate: float = 92.0
    pos_adoption_rate: float = 87.0
    customer_satisfaction: float = 4.6
    upsell_conversion_rate: float = 18.0
    engagement_score: float = 78.0

class StoreResponse(StoreBase):
    employees: Optional[List[EmployeeResponse]] = []
    class Config:
        from_attributes = True

# ==================== LEARNING SCHEMAS ====================
class QuizQuestion(BaseModel):
    id: str
    question: str
    options: List[str]
    correct_index: int
    explanation: str

class TrainingModuleSchema(BaseModel):
    id: str
    title: str
    category: str
    duration_minutes: int = 3
    xp_reward: int = 30
    badge_reward: Optional[str] = None
    summary: str
    content: List[Dict[str, Any]]
    key_takeaways: List[str] = []
    questions: List[QuizQuestion] = []
    is_active: bool = True

    class Config:
        from_attributes = True

class QuizSubmitRequest(BaseModel):
    employee_id: str
    module_id: str
    selected_answers: Dict[str, int] # question_id -> selected_index

class QuizSubmitResponse(BaseModel):
    score_percentage: float
    passed: bool
    correct_count: int
    total_count: int
    xp_earned: int
    new_total_xp: int
    new_level: int
    badge_unlocked: Optional[str] = None
    streak_updated: int
    explanations: Dict[str, str]

# ==================== POS SCHEMAS ====================
class POSCartItemSchema(BaseModel):
    product_id: str
    name: str
    price: float
    category: str
    quantity: int = 1
    barcode: str
    emoji: str = "📦"
    is_upsell_eligible: bool = False

class POSCheckoutRequest(BaseModel):
    employee_id: str
    store_id: str = "s104"
    customer_name: Optional[str] = "Walk-in Customer"
    items: List[POSCartItemSchema]
    coupon_code: Optional[str] = None
    discount_amount: float = 0.0
    payment_method: str = "UPI"

class POSCheckoutResponse(BaseModel):
    transaction_id: str
    total_amount: float
    final_amount: float
    discount_applied: float
    upsell_attached: bool
    upsell_item_name: Optional[str] = None
    xp_awarded: int
    badge_unlocked: Optional[str] = None
    message: str

# ==================== RECOGNITION SCHEMAS ====================
class CreateRecognitionRequest(BaseModel):
    sender_id: str
    receiver_id: str
    message: str
    badge_tagged: str = "team-player"

class RecognitionResponse(BaseModel):
    id: str
    sender_id: str
    sender_name: str
    receiver_id: str
    receiver_name: str
    message: str
    badge_tagged: str
    xp_awarded: int
    likes_count: int
    created_at: datetime

    class Config:
        from_attributes = True

# ==================== LLM SCHEMAS ====================
class RoleplayTurnRequest(BaseModel):
    persona_id: str
    persona_name: str
    conversation_history: List[Dict[str, str]] # [{'sender': 'customer'|'associate', 'text': '...'}]
    associate_message: str

class RoleplayTurnResponse(BaseModel):
    customer_reply: str
    customer_sentiment: str # 'positive', 'neutral', 'hesitant', 'satisfied', 'frustrated'
    coach_quick_tip: str
    detected_intent: str

class RoleplayEvaluationRequest(BaseModel):
    persona_name: str
    scenario_title: str
    conversation_history: List[Dict[str, str]]

class RoleplayEvaluationResponse(BaseModel):
    overall_score: int
    product_knowledge_score: int
    empathy_score: int
    objection_handling_score: int
    upsell_technique_score: int
    xp_earned: int
    strengths: List[str]
    growth_areas: List[str]
    coaching_verdict: str

class CopilotMessageRequest(BaseModel):
    query: str
    employee_id: Optional[str] = "e1"
    language_preference: str = "auto" # 'en', 'hi', 'hinglish'
    context_type: str = "general" # 'product_comparison', 'pos_troubleshoot', 'upsell_pitch'

class CopilotMessageResponse(BaseModel):
    answer: str
    suggested_upsell: Optional[str] = None
    pos_action_step: Optional[str] = None
    confidence_score: float = 0.95

class PolishKudosRequest(BaseModel):
    raw_notes: str
    receiver_name: str
    sender_name: str
    help_context: Optional[str] = None

class PolishKudosResponse(BaseModel):
    polished_message: str
    recommended_badge: str
    tone: str

class GenerateLessonRequest(BaseModel):
    topic: str # e.g. "5G Flagship Camera & Battery Specs" or "POS Return with Split Tender"
    target_role: str = "Store Associate"
    duration_minutes: int = 3
    store_tier: str = "Tier-3 Retail Hub"

class GenerateLessonResponse(BaseModel):
    module_title: str
    category: str
    summary: str
    key_points: List[str]
    content_slides: List[Dict[str, Any]]
    quiz_questions: List[QuizQuestion]
    xp_value: int = 30

class ManagerInsightsResponse(BaseModel):
    store_id: str
    executive_summary: str
    high_priority_interventions: List[Dict[str, Any]]
    coaching_talking_points: List[str]
    recommended_challenges: List[Dict[str, Any]]
    upsell_opportunity_zones: List[str]
