import os
import json
import random
from typing import Dict, List, Any, Optional

# Check for API keys
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

class LLMEngine:
    def __init__(self):
        self.gemini_available = bool(GEMINI_API_KEY)
        self.openai_available = bool(OPENAI_API_KEY)
        
    def simulate_customer_turn(
        self,
        persona_name: str,
        conversation_history: List[Dict[str, str]],
        associate_message: str
    ) -> Dict[str, Any]:
        """
        Simulates customer reply in real-time retail roleplay, evaluating empathy,
        product knowledge, and objection resolution.
        """
        lower_msg = associate_message.lower()
        turn_count = len(conversation_history) // 2

        # Intelligent retail conversational heuristics
        if any(w in lower_msg for w in ["battery", "mah", "charging", "5000mah", "backup", "fast charger"]):
            reply = "Achha, 5000mAh battery aur 45W charging hai? Mere gaon me light ka issue rehta hai, toh battery 1.5 din chal jayegi na? Aur heating ka kya?"
            sentiment = "positive"
            tip = "Great highlight! Now reassure about battery cooling chamber and suggest the high-speed fast charging combo."
            intent = "Battery & Endurance Ingestion"
        elif any(w in lower_msg for w in ["earbud", "buds", "headphone", "tws", "earphone", "combo", "offer", "discount", "free packaging"]):
            reply = "Earbuds combo me 40% discount mil raha hai agar sath me le? Sounds interesting! Sound quality aur calling mic kaisa hai?"
            sentiment = "satisfied"
            tip = "Upsell hook connected! Explain active noise cancellation (ANC) and 2-year damage protection."
            intent = "Upsell Receptivity"
        elif any(w in lower_msg for w in ["expensive", "budget", "discount", "rate", "cost", "kam", "mehenga", "price", "emi"]):
            reply = "Bhaiya online pe ₹1,000 sasta dikh raha hai. Store se lene pe mujhe kya extra fayda ya warranty milegi?"
            sentiment = "hesitant"
            tip = "Customer is price-sensitive. Highlight instant in-store data transfer, genuine 1-year brand warranty, and zero-cost EMI."
            intent = "Price Objection"
        elif any(w in lower_msg for w in ["pos", "bill", "invoice", "upi", "scanner", "card", "split", "cash"]):
            reply = "Theek hai, aadha payment Cash me aur aadha UPI se ho sakta hai kya? Fast bill bana do, train nikal rahi hai."
            sentiment = "neutral"
            tip = "Test POS Split Tender workflow! Select Split payment in POS terminal."
            intent = "POS Checkout Speed"
        elif any(w in lower_msg for w in ["camera", "photo", "50mp", "night", "zoom", "selfie", "portrait"]):
            reply = "Camera me low-light me photo clear aati hai? Shaadi aur festive photos ke liye chahiye."
            sentiment = "positive"
            tip = "Show camera sample mode, mention AI Portrait engine and Nightography sensor."
            intent = "Camera Feature Exploration"
        elif turn_count >= 3:
            reply = "Aapne bahut achhe se explain kiya! Theek hai, main ye phone aur sath me earbuds pack karwa leta hoon. Billing counter par chalte hain."
            sentiment = "satisfied"
            tip = "Deal closed! Guide the customer to POS terminal and scan the combo barcode."
            intent = "Purchase Decision Reached"
        else:
            replies = [
                "Hmm, feature toh achha hai par mujhe screen brightness aur sunlight visibility ke bare me janana hai.",
                "Processor kaisa hai iska? Gaming ya multitasking me hang toh nahi karega?",
                "Isme brand service center hamare city me available hai na?",
                "Mujhe durability aur gorilla glass protection chahiye, girne par toote toh nahi?"
            ]
            reply = random.choice(replies)
            sentiment = "neutral"
            tip = "Acknowledge the customer's query with warmth, quote concrete specs, and tie back to everyday reliability."
            intent = "General Feature Inquiry"

        return {
            "customer_reply": reply,
            "customer_sentiment": sentiment,
            "coach_quick_tip": tip,
            "detected_intent": intent
        }

    def evaluate_roleplay_session(
        self,
        persona_name: str,
        scenario_title: str,
        conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """
        Evaluates the entire roleplay session across 4 core competencies.
        """
        text_corp = " ".join([m.get("text", "") for m in conversation_history]).lower()
        
        # Scoring metrics calculation
        has_product_knowledge = any(k in text_corp for k in ["mah", "5g", "processor", "camera", "display", "amoled", "warranty", "fast charge"])
        has_empathy = any(k in text_corp for k in ["bilkul", "samajh", "aapke", "fayda", "perfect", "tension", "welcome", "zaroor", "namaste", "help"])
        has_objection_handled = any(k in text_corp for k in ["online", "emi", "discount", "service", "guarantee", "exchange", "cashback"])
        has_upsell = any(k in text_corp for k in ["combo", "earbud", "buds", "cover", "screen guard", "protection", "charger", "bundle"])

        knowledge_score = 92 if has_product_knowledge else 70
        empathy_score = 95 if has_empathy else 74
        objection_score = 88 if has_objection_handled else 68
        upsell_score = 94 if has_upsell else 65

        overall = int((knowledge_score + empathy_score + objection_score + upsell_score) / 4)
        xp_earned = 100 if overall >= 85 else 60

        strengths = []
        growth_areas = []

        if has_product_knowledge:
            strengths.append("Crisp technical articulation of 5G, battery mAh, and processor speed.")
        else:
            growth_areas.append("Include specific hardware specs like 5000mAh battery and AMOLED display.")

        if has_empathy:
            strengths.append("High emotional intelligence and welcoming vernacular rapport with Tier-3 customer.")
        else:
            growth_areas.append("Use warm acknowledgments ('Bilkul sir/ma'am') before explaining features.")

        if has_upsell:
            strengths.append("Natural combo recommendation (Smartphone + Earbuds) demonstrating consultative selling.")
        else:
            growth_areas.append("Practice bundling accessories (TWS earbuds/tempered glass) to boost upsell conversion.")

        if has_objection_handled:
            strengths.append("Handled online price comparison by emphasizing local warranty and instant store setup.")

        return {
            "overall_score": overall,
            "product_knowledge_score": knowledge_score,
            "empathy_score": empathy_score,
            "objection_handling_score": objection_score,
            "upsell_technique_score": upsell_score,
            "xp_earned": xp_earned,
            "strengths": strengths,
            "growth_areas": growth_areas,
            "coaching_verdict": "🌟 Outstanding Performance! Ready for premium floor consultations." if overall >= 85 else "👍 Good foundation! Focus on consultative combo upsells."
        }

    def ask_copilot(self, query: str, context_type: str = "general") -> Dict[str, Any]:
        """
        Floor Copilot 'Ask QuestBot' answering product comparisons, POS errors, and pitches.
        """
        q = query.lower()
        
        if "compare" in q or "vs" in q or "difference" in q:
            ans = (
                "📱 **Product Comparison (Retail Floor Quick Sheet)**:\n\n"
                "• **Model Alpha 5G (₹14,999)**: 5000mAh battery (45W Fast Charging), 50MP OIS Camera, Dimensity 7050. Best for customers wanting battery backup & festive photography.\n"
                "• **Model Beta 4G (₹11,499)**: 5000mAh (18W Charging), 50MP standard camera, Snapdragon 680. Good for basic social media and daily calls.\n\n"
                "💡 **Floor Recommendation**: Reassure customer on 5G network longevity for just ₹3,500 difference (₹299/mo on Zero-cost EMI)."
            )
            upsell = "Recommend ₹999 True Wireless Earbuds combo (+40% margin)."
            pos_step = "Scan Barcode 89012345001 -> Apply Combo Promo 'FESTIVE_COMBO'."
        elif "pos" in q or "bill" in q or "error" in q or "split" in q or "discount" in q:
            ans = (
                "💻 **POS Floor Action Guide**:\n\n"
                "1. **Apply Voucher**: Type coupon code (e.g., `GOLD5` for 5% loyalty or `FESTIVE100` for ₹100 flat) and click **'Apply Promo'**.\n"
                "2. **Split Payment**: Select *Tender Method -> Split*, enter Cash amount, remaining balance auto-routes to UPI QR Code.\n"
                "3. **Print E-Receipt**: Enter customer phone number for WhatsApp paperless bill."
            )
            upsell = "Ask customer if they need extended 1-year screen replacement."
            pos_step = "Navigate to POS Sandbox -> Tender Screen -> Select Split."
        elif "battery" in q or "optim" in q:
            ans = (
                "⚡ **Battery Optimization Pitch Formula**:\n\n"
                "• 'Sir, isme **Adaptive AI Battery Management** hai jo background apps ko automatically sleep mode me daalta hai, jisse 5000mAh battery aaram se **1.5 din** chalti hai.'\n"
                "• 'Sath me 45W SuperVOOC charger sirf 30 minutes me 70% charge kar deta hai.'"
            )
            upsell = "Car charger or braided 65W fast-charging cable."
            pos_step = "Add accessory barcode to bill before closing tender."
        else:
            ans = (
                f"🤖 **QuestBot Floor Assistant Response**:\n\n"
                f"Regarding *'{query}'*:\n"
                "1. **Core Customer Value**: Emphasize durability, official local warranty, and 7-day hassle-free replacement.\n"
                "2. **Hinglish Conversational Hook**: 'Sir/Ma'am, yeh model Tier-3 network bands ke sath fully optimized hai.'\n"
                "3. **POS Shortcut**: F2 = Quick Scan, F4 = Coupon Lookup, F8 = UPI Tender."
            )
            upsell = "Bundle tempered glass + silicone shockproof case."
            pos_step = "Press 'Print Bill' on POS terminal."

        return {
            "answer": ans,
            "suggested_upsell": upsell,
            "pos_action_step": pos_step,
            "confidence_score": 0.96
        }

    def polish_kudos(self, raw_notes: str, receiver_name: str, sender_name: str, help_context: Optional[str] = None) -> Dict[str, Any]:
        """
        Transforms rough peer appreciation notes into warm, professional recognition shoutouts.
        """
        raw = raw_notes.strip()
        
        if "pos" in raw.lower() or "bill" in raw.lower() or "speed" in raw.lower():
            polished = f"Huge shoutout to {receiver_name}! ⭐ {raw} Your calm patience and deep POS expertise during peak rush hours helped our store keep billing smooth and customer satisfaction high. Truly a POS Pro and an inspiring teammate!"
            badge = "pos-pro"
        elif "customer" in raw.lower() or "csat" in raw.lower() or "happy" in raw.lower():
            polished = f"Kudos to {receiver_name}! 🌟 {raw} The way you handled difficult customer queries with genuine empathy set the gold standard for our floor today. Thank you for championing customer delight!"
            badge = "customer-champion"
        else:
            polished = f"Big appreciation for {receiver_name}! 🤝 {raw} Thank you for stepping up, sharing knowledge, and making our shift so much more productive. You embody true team spirit!"
            badge = "team-player"

        return {
            "polished_message": polished,
            "recommended_badge": badge,
            "tone": "Warm & Inspiring"
        }

    def generate_micro_lesson(self, topic: str, store_tier: str = "Tier-3 Retail Hub") -> Dict[str, Any]:
        """
        Generates a 2-3 min micro-learning module + quiz on the fly.
        """
        module_title = f"2-Min Micro-Mastery: {topic}"
        category = "Product Knowledge" if any(w in topic.lower() for w in ["phone", "5g", "battery", "camera", "spec"]) else "POS Operations"
        
        summary = f"A rapid 3-minute bite-sized training module designed for {store_tier} store associates to master {topic} and boost floor conversion."
        
        key_points = [
            f"Core USP of {topic} explained in simple customer-facing terms",
            "Top 3 objections customers raise in Tier-3 stores & how to resolve them",
            "POS shortcut & combo upsell formula (+50 XP per conversion)"
        ]

        content_slides = [
            {
                "slideNumber": 1,
                "title": f"The Big Picture: Why {topic} Matters",
                "content": f"Customers visiting our stores often hesitate because of unfamiliarity. In 60 seconds, explain how {topic} brings everyday convenience, superior durability, and maximum value for money."
            },
            {
                "slideNumber": 2,
                "title": "Floor Conversation Hook & Vernacular Pitch",
                "content": "Use simple local analogies: 'Jaise ghar ka inverter light jaane par continuous backup deta hai, waise hi Adaptive AI Battery power optimize karta hai.' Avoid overly complex jargon."
            },
            {
                "slideNumber": 3,
                "title": "Consultative Upsell & POS Attachment",
                "content": "Always attach complementary items before billing. A customer buying a smartphone is 65% more likely to purchase earbuds or extended warranty when offered as a discounted bundle."
            }
        ]

        quiz_questions = [
            {
                "id": "q1",
                "question": f"When a customer asks about {topic}, what is the best consultative response?",
                "options": [
                    "Just tell them to read the back of the box",
                    "Explain the top 2 benefits using relatable everyday benefits and offer a live demo",
                    "Tell them it is expensive and move to another product",
                    "Ask them to check online reviews on their own phone"
                ],
                "correct_index": 1,
                "explanation": "Explaining concrete everyday benefits with a live demo builds immediate customer trust and boosts store conversion."
            },
            {
                "id": "q2",
                "question": "Which POS practice maximizes upsell conversion and customer satisfaction?",
                "options": [
                    "Directly billing without mentioning eligible combo discounts",
                    "Recommending the matching accessory bundle (e.g. Earbuds + Screen Guard) with the active festive promo",
                    "Skipping the customer mobile number entry",
                    "Only accepting cash payments"
                ],
                "correct_index": 1,
                "explanation": "In-flight bundle recommendations at the POS terminal increase upsell conversion while giving the customer genuine value."
            }
        ]

        return {
            "module_title": module_title,
            "category": category,
            "summary": summary,
            "key_points": key_points,
            "content_slides": content_slides,
            "quiz_questions": quiz_questions,
            "xp_value": 30
        }

    def generate_manager_insights(self, store_id: str, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        AI Diagnostic & Action Center for Store Managers.
        """
        training_pct = metrics.get("training_completion_rate", 92.0)
        pos_pct = metrics.get("pos_adoption_rate", 87.0)
        csat = metrics.get("customer_satisfaction", 4.6)
        upsell = metrics.get("upsell_conversion_rate", 18.0)

        exec_summary = (
            f"Store {store_id} is operating at high health ({training_pct}% training completion, {csat}/5.0 CSAT). "
            f"Key growth lever is Upsell Conversion ({upsell}%), where targeted Smartphone+Earbuds micro-challenges can unlock ₹1.8L incremental weekly revenue."
        )

        interventions = [
            {
                "priority": "High",
                "target": "3 Store Associates with <60% POS Split-Tender Usage",
                "action": "Assign '2-Minute POS Split-Billing Challenge' with +50 XP bounty",
                "expected_impact": "+12% faster checkout during 6 PM - 9 PM evening peak"
            },
            {
                "priority": "Medium",
                "target": "Associate Rahul Verma (Training 40% vs Store Avg 92%)",
                "action": "Trigger automated peer-buddy pairing with POS Pro Vikram Singh",
                "expected_impact": "Brings knowledge gap to parity within 48 hours"
            },
            {
                "priority": "Growth",
                "target": "Tier-3 Festive Footfall Upsell",
                "action": "Activate 'Smartphone + Earbuds Attachment Sprint' (+100 XP per 3 combos)",
                "expected_impact": "Boosts upsell conversion from 18% to 24%"
            }
        ]

        talking_points = [
            "Morning Huddle: Celebrate Sneha Patil for receiving 4 Peer Kudos this week.",
            "Floor Coaching: Demonstrate how to pitch 5000mAh battery + Fast Charging to price-sensitive shoppers.",
            "POS Review: Ensure every associate knows how to apply 'GOLD5' and 'FESTIVE100' vouchers seamlessly."
        ]

        recommended_challenges = [
            {
                "id": "c-mgr-upsell",
                "title": "Weekend Earbuds Attachment Blitz",
                "reward_xp": 100,
                "type": "upsell_sprint",
                "description": "Attach audio accessories to 3 smartphone purchases in one shift."
            },
            {
                "id": "c-mgr-pos",
                "title": "Zero-Error POS Billing Sprint",
                "reward_xp": 75,
                "type": "pos_speed",
                "description": "Process 5 consecutive customer orders under 90 seconds each."
            }
        ]

        return {
            "store_id": store_id,
            "executive_summary": exec_summary,
            "high_priority_interventions": interventions,
            "coaching_talking_points": talking_points,
            "recommended_challenges": recommended_challenges,
            "upsell_opportunity_zones": ["Audio Accessories", "2-Year Screen Shield", "Fast Chargers"]
        }

llm_engine = LLMEngine()
