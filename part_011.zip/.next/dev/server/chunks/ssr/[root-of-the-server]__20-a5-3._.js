module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/dynamic-access-async-storage.external.js [external] (next/dist/server/app-render/dynamic-access-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/dynamic-access-async-storage.external.js", () => require("next/dist/server/app-render/dynamic-access-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/runtime-reacts.external.js [external] (next/dist/server/runtime-reacts.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/runtime-reacts.external.js", () => require("next/dist/server/runtime-reacts.external.js"));

module.exports = mod;
}),
"[project]/src/lib/audioEffect.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sounds",
    ()=>sounds
]);
/**
 * Synthesizes celebratory audio tones using the standard Web Audio API
 */ class SoundEffects {
    ctx = null;
    initCtx() {
        if ("TURBOPACK compile-time truthy", 1) return null;
        //TURBOPACK unreachable
        ;
    }
    playSuccess() {
        try {
            const ctx = this.initCtx();
            if (!ctx) return;
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(523.25, now); // C5
            osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.1); // E5
            osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.2); // G5
            osc.frequency.exponentialRampToValueAtTime(1046.50, now + 0.35); // C6
            gain.gain.setValueAtTime(0.15, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.55);
        } catch  {
        // Ignore audio failure
        }
    }
    playLevelUp() {
        try {
            const ctx = this.initCtx();
            if (!ctx) return;
            const now = ctx.currentTime;
            const notes = [
                440,
                554.37,
                659.25,
                880,
                1108.73
            ]; // A4, C#5, E5, A5, C#6
            notes.forEach((freq, i)=>{
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(freq, now + i * 0.08);
                gain.gain.setValueAtTime(0.12, now + i * 0.08);
                gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.4);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now + i * 0.08);
                osc.stop(now + i * 0.08 + 0.45);
            });
        } catch  {
        // Ignore audio failure
        }
    }
    playClick() {
        try {
            const ctx = this.initCtx();
            if (!ctx) return;
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, now);
            osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);
            gain.gain.setValueAtTime(0.05, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.06);
        } catch  {
        // Ignore audio failure
        }
    }
}
const sounds = new SoundEffects();
}),
"[project]/src/lib/constants.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BADGES",
    ()=>BADGES,
    "CATEGORY_ICONS",
    ()=>CATEGORY_ICONS,
    "COLORS",
    ()=>COLORS,
    "LEVELS",
    ()=>LEVELS,
    "RECOGNITION_CATEGORIES",
    ()=>RECOGNITION_CATEGORIES,
    "ROLE_LABEL",
    ()=>ROLE_LABEL,
    "WEEKLY_TREND",
    ()=>WEEKLY_TREND
]);
const COLORS = {
    navy: '#12183A',
    navy2: '#1B2354',
    navy3: '#232C63',
    paper: '#F5F5FB',
    card: '#FFFFFF',
    amber: '#F3A712',
    amberDeep: '#C9840C',
    teal: '#0E8C82',
    coral: '#EF5A4C',
    plum: '#6C3FA0',
    ink: '#1B1C29',
    muted: '#6E7191',
    line: '#E7E7F2',
    emerald: '#10B981',
    sky: '#0EA5E9'
};
const LEVELS = [
    {
        level: 1,
        name: 'Beginner',
        min: 0
    },
    {
        level: 2,
        name: 'Learner',
        min: 400
    },
    {
        level: 3,
        name: 'Skilled',
        min: 800
    },
    {
        level: 4,
        name: 'Expert',
        min: 1200
    },
    {
        level: 5,
        name: 'Champion',
        min: 1600
    }
];
const BADGES = [
    {
        id: 'product-expert',
        name: 'Product Expert',
        icon: '🏅',
        desc: 'Completed all Product Knowledge modules',
        category: 'Product Knowledge'
    },
    {
        id: 'pos-pro',
        name: 'POS Pro',
        icon: '🎯',
        desc: 'Mastered digital POS training & zero billing errors',
        category: 'POS Training'
    },
    {
        id: 'customer-champion',
        name: 'Customer Champion',
        icon: '⭐',
        desc: 'Received 5+ positive customer feedbacks',
        category: 'Customer Service'
    },
    {
        id: 'learning-streak',
        name: 'Learning Streak',
        icon: '🔥',
        desc: 'Completed daily lessons 7 days in a row',
        category: 'General'
    },
    {
        id: 'team-player',
        name: 'Team Player',
        icon: '🤝',
        desc: 'Helped 3+ teammates and received peer recognition',
        category: 'Culture'
    },
    {
        id: 'top-performer',
        name: 'Top Performer',
        icon: '🏆',
        desc: 'Ranked Top 3 on the monthly leaderboard',
        category: 'Sales Skills'
    },
    {
        id: 'knowledge-seeker',
        name: 'Knowledge Seeker',
        icon: '📚',
        desc: 'Completed 5+ training modules and quizzes',
        category: 'General'
    },
    {
        id: 'problem-solver',
        name: 'Problem Solver',
        icon: '💡',
        desc: 'Resolved an escalated customer issue smoothly',
        category: 'Customer Service'
    }
];
const ROLE_LABEL = {
    employee: 'Store Associate',
    manager: 'Store Manager',
    admin: 'HR / Admin'
};
const CATEGORY_ICONS = {
    'Product Knowledge': '🪔',
    'Customer Service': '🗣️',
    'POS Training': '🧾',
    'Sales Skills': '📈',
    'Company Policies': '🛡️'
};
const RECOGNITION_CATEGORIES = [
    {
        name: 'Customer Service',
        icon: '🌟',
        color: COLORS.teal
    },
    {
        name: 'Teamwork',
        icon: '🤝',
        color: COLORS.plum
    },
    {
        name: 'Problem Solving',
        icon: '💡',
        color: COLORS.amberDeep
    },
    {
        name: 'Knowledge Sharing',
        icon: '📚',
        color: COLORS.navy3
    },
    {
        name: 'Sales Excellence',
        icon: '🎯',
        color: COLORS.coral
    }
];
const WEEKLY_TREND = [
    {
        week: 'Wk 1',
        engagement: 68,
        training: 55,
        pos: 60,
        cx: 62
    },
    {
        week: 'Wk 2',
        engagement: 72,
        training: 61,
        pos: 64,
        cx: 67
    },
    {
        week: 'Wk 3',
        engagement: 76,
        training: 68,
        pos: 70,
        cx: 73
    },
    {
        week: 'Wk 4',
        engagement: 84,
        training: 77,
        pos: 79,
        cx: 81
    }
];
}),
"[project]/src/lib/cxCalculator.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "avg",
    ()=>avg,
    "calculateCX",
    ()=>calculateCX,
    "getEmployeeName",
    ()=>getEmployeeName,
    "getInitials",
    ()=>getInitials,
    "getLevelInfo",
    ()=>getLevelInfo,
    "getStoreCity",
    ()=>getStoreCity,
    "getStoreName",
    ()=>getStoreName,
    "trainingPct",
    ()=>trainingPct
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/data/initialData.ts [app-ssr] (ecmascript)");
;
;
const avg = (arr)=>arr.length ? Math.round(arr.reduce((a, b)=>a + b, 0) / arr.length) : 0;
const trainingPct = (emp, modules = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRAINING_MODULES_INIT"])=>modules.length ? Math.round(emp.completedModules.length / modules.length * 100) : 0;
function getLevelInfo(points) {
    let current = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LEVELS"][0];
    for (const l of __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LEVELS"]){
        if (points >= l.min) {
            current = l;
        }
    }
    const idx = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LEVELS"].findIndex((l)=>l.level === current.level);
    const next = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LEVELS"][idx + 1];
    const progressPct = next ? Math.min(100, Math.max(0, Math.round((points - current.min) / (next.min - current.min) * 100))) : 100;
    const pointsToNext = next ? Math.max(0, next.min - points) : 0;
    return {
        ...current,
        next,
        pointsToNext,
        progressPct
    };
}
function calculateCX(employees, modules = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRAINING_MODULES_INIT"]) {
    if (!employees.length) {
        return {
            score: 0,
            label: 'Needs Attention',
            color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].coral,
            trainingAvg: 0,
            posAvg: 0,
            feedbackAvg: 0,
            salesAvg: 0,
            engagementAvg: 0
        };
    }
    const trainingAvg = avg(employees.map((e)=>trainingPct(e, modules)));
    const posAvg = avg(employees.map((e)=>e.posAdoption));
    const feedbackAvg = avg(employees.map((e)=>e.customerFeedbackScore));
    const salesAvg = avg(employees.map((e)=>e.salesConversion));
    const engagementAvg = avg(employees.map((e)=>e.engagementScore));
    const weightedScore = Math.round(trainingAvg * 0.20 + posAvg * 0.25 + feedbackAvg * 0.25 + salesAvg * 0.15 + engagementAvg * 0.15);
    let label = 'Needs Attention';
    let color = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].coral;
    if (weightedScore >= 85) {
        label = 'Excellent';
        color = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].teal;
    } else if (weightedScore >= 70) {
        label = 'Good';
        color = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].amberDeep;
    }
    return {
        score: weightedScore,
        label,
        color,
        trainingAvg,
        posAvg,
        feedbackAvg,
        salesAvg,
        engagementAvg
    };
}
const getStoreCity = (stores, id)=>stores.find((s)=>s.id === id)?.city || '—';
const getStoreName = (stores, id)=>stores.find((s)=>s.id === id)?.name || '—';
const getEmployeeName = (employees, id)=>{
    const found = employees.find((e)=>e.id === id);
    if (found) return found.name;
    if (id === 'mgr1') return 'Anil Deshmukh';
    if (id === 'mgr2') return 'Rekha Menon';
    if (id === 'mgr3') return 'Sanjay Gupta';
    if (id === 'admin1') return 'Neha Kapoor';
    return 'Associate';
};
const getInitials = (name)=>name.split(' ').map((n)=>n[0]).slice(0, 2).join('').toUpperCase();
}),
"[project]/src/lib/data/initialData.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ADMIN_INIT",
    ()=>ADMIN_INIT,
    "CHALLENGES_INIT",
    ()=>CHALLENGES_INIT,
    "CURRENT_EMPLOYEE_ID",
    ()=>CURRENT_EMPLOYEE_ID,
    "CURRENT_MANAGER_ID",
    ()=>CURRENT_MANAGER_ID,
    "EMPLOYEES_INIT",
    ()=>EMPLOYEES_INIT,
    "MANAGERS_INIT",
    ()=>MANAGERS_INIT,
    "NOTIFICATIONS_INIT",
    ()=>NOTIFICATIONS_INIT,
    "RECOGNITIONS_INIT",
    ()=>RECOGNITIONS_INIT,
    "STORES_INIT",
    ()=>STORES_INIT,
    "TRAINING_MODULES_INIT",
    ()=>TRAINING_MODULES_INIT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
;
const STORES_INIT = [
    {
        id: 's1',
        code: 'QF-STORE-104',
        name: 'QuestFloor Store #104 (Nagpur Hub)',
        city: 'Nagpur',
        state: 'Maharashtra',
        tier: 'Tier-3',
        activeAssociates: 24
    },
    {
        id: 's2',
        code: 'QF-IND-02',
        name: 'QuestFloor Indore Palasia Hub',
        city: 'Indore',
        state: 'Madhya Pradesh',
        tier: 'Tier-3',
        activeAssociates: 26
    },
    {
        id: 's3',
        code: 'QF-JPR-03',
        name: 'QuestFloor Jaipur Malviya Nagar',
        city: 'Jaipur',
        state: 'Rajasthan',
        tier: 'Tier-3',
        activeAssociates: 22
    },
    {
        id: 's4',
        code: 'QF-CBE-04',
        name: 'QuestFloor Coimbatore RS Puram',
        city: 'Coimbatore',
        state: 'Tamil Nadu',
        tier: 'Tier-3',
        activeAssociates: 20
    },
    {
        id: 's5',
        code: 'QF-PAT-05',
        name: 'QuestFloor Patna Boring Road',
        city: 'Patna',
        state: 'Bihar',
        tier: 'Tier-3',
        activeAssociates: 18
    }
];
const MANAGERS_INIT = [
    {
        id: 'mgr1',
        name: 'Priya Patel',
        title: 'Senior Store Manager (Store #104)',
        email: 'priya.patel@questfloor.in',
        stores: [
            's1',
            's2'
        ]
    },
    {
        id: 'mgr2',
        name: 'Rekha Menon',
        title: 'Cluster Manager',
        email: 'rekha.menon@questfloor.in',
        stores: [
            's3',
            's4'
        ]
    },
    {
        id: 'mgr3',
        name: 'Sanjay Gupta',
        title: 'Regional Operations Manager',
        email: 'sanjay.gupta@questfloor.in',
        stores: [
            's5'
        ]
    }
];
const ADMIN_INIT = {
    id: 'admin1',
    name: 'Neha Kapoor',
    title: 'Head of People & Workforce CX (1,200 Stores)',
    email: 'neha.kapoor@questfloor.in'
};
const CURRENT_EMPLOYEE_ID = 'e0';
const CURRENT_MANAGER_ID = 'mgr1';
const EMPLOYEES_INIT = [
    {
        id: 'e0',
        name: 'Amit Kumar',
        email: 'amit.kumar@questfloor.in',
        storeId: 's1',
        points: 1500,
        weeklyPoints: 350,
        monthlyPoints: 1100,
        posAdoption: 92,
        customerFeedbackScore: 94,
        salesConversion: 78,
        engagementScore: 92,
        badges: [
            'product-expert',
            'pos-pro',
            'team-player',
            'customer-champion',
            'learning-streak'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm4',
            'm5'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].navy2,
        joinDate: '2025-01-10'
    },
    {
        id: 'e1',
        name: 'Sneha Patil',
        email: 'sneha.patil@questfloor.in',
        storeId: 's1',
        points: 1480,
        weeklyPoints: 320,
        monthlyPoints: 890,
        posAdoption: 82,
        customerFeedbackScore: 91,
        salesConversion: 74,
        engagementScore: 88,
        badges: [
            'product-expert',
            'customer-champion',
            'team-player',
            'learning-streak',
            'knowledge-seeker'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm5',
            'm6',
            'm7',
            'm9'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].amber,
        joinDate: '2025-01-15'
    },
    {
        id: 'e2',
        name: 'Rahul Verma',
        email: 'rahul.verma@questfloor.in',
        storeId: 's1',
        points: 980,
        weeklyPoints: 180,
        monthlyPoints: 560,
        posAdoption: 58,
        customerFeedbackScore: 70,
        salesConversion: 60,
        engagementScore: 65,
        badges: [
            'team-player',
            'knowledge-seeker'
        ],
        completedModules: [
            'm2',
            'm5',
            'm7'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].teal,
        joinDate: '2025-03-10'
    },
    {
        id: 'e3',
        name: 'Ayesha Khan',
        email: 'ayesha.khan@questfloor.in',
        storeId: 's2',
        points: 640,
        weeklyPoints: 140,
        monthlyPoints: 400,
        posAdoption: 45,
        customerFeedbackScore: 66,
        salesConversion: 50,
        engagementScore: 55,
        badges: [
            'learning-streak'
        ],
        completedModules: [
            'm3',
            'm5'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].coral,
        joinDate: '2025-05-20'
    },
    {
        id: 'e4',
        name: 'Vikram Singh',
        email: 'vikram.singh@questfloor.in',
        storeId: 's2',
        points: 2150,
        weeklyPoints: 410,
        monthlyPoints: 1200,
        posAdoption: 93,
        customerFeedbackScore: 95,
        salesConversion: 88,
        engagementScore: 92,
        badges: [
            'product-expert',
            'pos-pro',
            'customer-champion',
            'top-performer',
            'knowledge-seeker',
            'team-player'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm4',
            'm5',
            'm6',
            'm7',
            'm8',
            'm9',
            'm10'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].plum,
        joinDate: '2024-11-01'
    },
    {
        id: 'e5',
        name: 'Priya Nair',
        email: 'priya.nair@questfloor.in',
        storeId: 's3',
        points: 1340,
        weeklyPoints: 260,
        monthlyPoints: 780,
        posAdoption: 71,
        customerFeedbackScore: 84,
        salesConversion: 69,
        engagementScore: 80,
        badges: [
            'customer-champion',
            'knowledge-seeker'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm4',
            'm6',
            'm7'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].navy3,
        joinDate: '2025-02-14'
    },
    {
        id: 'e6',
        name: 'Arjun Reddy',
        email: 'arjun.reddy@questfloor.in',
        storeId: 's3',
        points: 1620,
        weeklyPoints: 300,
        monthlyPoints: 900,
        posAdoption: 85,
        customerFeedbackScore: 88,
        salesConversion: 79,
        engagementScore: 84,
        badges: [
            'pos-pro',
            'product-expert',
            'knowledge-seeker'
        ],
        completedModules: [
            'm1',
            'm3',
            'm5',
            'm6',
            'm8',
            'm9'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].amberDeep,
        joinDate: '2024-12-05'
    },
    {
        id: 'e7',
        name: 'Meera Iyer',
        email: 'meera.iyer@questfloor.in',
        storeId: 's4',
        points: 1890,
        weeklyPoints: 350,
        monthlyPoints: 1020,
        posAdoption: 90,
        customerFeedbackScore: 93,
        salesConversion: 82,
        engagementScore: 89,
        badges: [
            'product-expert',
            'customer-champion',
            'pos-pro',
            'top-performer'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm4',
            'm5',
            'm6',
            'm8'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].teal,
        joinDate: '2024-09-18'
    },
    {
        id: 'e8',
        name: 'Karan Malhotra',
        email: 'karan.malhotra@questfloor.in',
        storeId: 's4',
        points: 860,
        weeklyPoints: 150,
        monthlyPoints: 480,
        posAdoption: 52,
        customerFeedbackScore: 62,
        salesConversion: 55,
        engagementScore: 58,
        badges: [
            'team-player'
        ],
        completedModules: [
            'm2',
            'm5'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].coral,
        joinDate: '2025-04-01'
    },
    {
        id: 'e9',
        name: 'Divya Sharma',
        email: 'divya.sharma@questfloor.in',
        storeId: 's5',
        points: 1210,
        weeklyPoints: 230,
        monthlyPoints: 700,
        posAdoption: 68,
        customerFeedbackScore: 80,
        salesConversion: 65,
        engagementScore: 76,
        badges: [
            'learning-streak',
            'team-player',
            'knowledge-seeker'
        ],
        completedModules: [
            'm1',
            'm2',
            'm5',
            'm6',
            'm7'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].plum,
        joinDate: '2025-02-28'
    },
    {
        id: 'e10',
        name: 'Suresh Kumar',
        email: 'suresh.kumar@questfloor.in',
        storeId: 's5',
        points: 420,
        weeklyPoints: 90,
        monthlyPoints: 250,
        posAdoption: 38,
        customerFeedbackScore: 58,
        salesConversion: 42,
        engagementScore: 48,
        badges: [],
        completedModules: [
            'm5'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].navy3,
        joinDate: '2025-06-12'
    }
];
const TRAINING_MODULES_INIT = [
    {
        id: 'm1',
        title: 'Festive Season Product Line-up',
        category: 'Product Knowledge',
        duration: '5 min',
        points: 100,
        emoji: '🪔',
        description: 'Get up to speed on this season’s ethnic wear, curated gifting hampers, and home lighting collections.',
        keyPoints: [
            'This festive range highlights premium cotton-silk ethnic wear, brass diya combos, and gourmet hampers.',
            'Diya and lantern combos are strategically priced under ₹499 for effortless impulse upselling.',
            'All gifting hampers can be custom-packed in-store — always highlight this customization option.',
            'Ethnic wear runs true-to-size; guide first-time buyers to the in-store digital size selector.'
        ],
        quiz: [
            {
                id: 'q1-1',
                q: 'What is the key selling proposition of the festive diya and lantern combos?',
                options: [
                    'They are imported from overseas',
                    'They are attractively priced under ₹499 for impulse checkout',
                    'They are strictly online-only',
                    'They require professional assembly'
                ],
                correct: 1,
                explanation: 'At ₹499, it fits the ideal impulse purchase price ceiling for festive shoppers.'
            },
            {
                id: 'q1-2',
                q: 'What complimentary service should you always mention regarding gifting hampers?',
                options: [
                    'They cannot be returned',
                    'Free in-store custom packing and personalization',
                    'They only come in a single fixed variant',
                    'They take 10 business days to dispatch'
                ],
                correct: 1,
                explanation: 'Customization adds perceived luxury value and increases repeat customer trust.'
            },
            {
                id: 'q1-3',
                q: 'How should you assist first-time ethnic wear shoppers with sizing?',
                options: [
                    'Advise them to buy 2 sizes larger',
                    'Show them the size chart & digital fit guide',
                    'Recommend online-only trials',
                    'Skip fitting room trials entirely'
                ],
                correct: 1,
                explanation: 'The digital fit guide eliminates return frictions and ensures customer satisfaction.'
            }
        ]
    },
    {
        id: 'm2',
        title: 'De-escalation & Handling Difficult Customers',
        category: 'Customer Service',
        duration: '4 min',
        points: 100,
        emoji: '🗣️',
        description: 'Actionable techniques to calmly de-escalate tension and transform frustrated shoppers into brand advocates.',
        keyPoints: [
            'Practice active silence: Listen completely without interrupting or jumping to defense.',
            'Empathize authentically: Paraphrase the customer concern in your own respectful words.',
            'Provide concrete solutions: Propose immediate resolution options rather than hollow apologies.',
            'Know your authority limit: Escalate smoothly to the Store Manager only when policy limits are reached.'
        ],
        quiz: [
            {
                id: 'q2-1',
                q: 'What is the critical first step when an agitated customer approaches the counter?',
                options: [
                    'Immediately offer a flat 20% discount',
                    'Listen attentively without interruption',
                    'Ring the manager bell immediately',
                    'Quote company policy clauses'
                ],
                correct: 1,
                explanation: 'Allowing the customer to feel heard immediately reduces emotional escalation.'
            },
            {
                id: 'q2-2',
                q: 'What must always follow empathetic acknowledgement of a customer’s issue?',
                options: [
                    'Politely ending the conversation',
                    'Offering a clear, actionable next step or solution',
                    'Assigning blame to the inventory logistics team',
                    'Asking them to email customer care'
                ],
                correct: 1,
                explanation: 'Actionable solutions rebuild trust and show genuine retail ownership.'
            },
            {
                id: 'q2-3',
                q: 'When is it appropriate to escalate an issue to your Store Manager?',
                options: [
                    'For every standard customer inquiry',
                    'When the required resolution exceeds your associate authorization level',
                    'Never under any circumstances',
                    'Only when explicitly asked by the customer'
                ],
                correct: 1,
                explanation: 'Store managers step in for policy overrides or financial refund approvals beyond store floor limits.'
            }
        ]
    },
    {
        id: 'm3',
        title: 'POS Basics: Fast Billing & QR Payments',
        category: 'POS Training',
        duration: '5 min',
        points: 120,
        emoji: '🧾',
        description: 'Master fast barcode scanning, promotional coupon application, and instant UPI/QR payments on the digital terminal.',
        keyPoints: [
            'Always scan barcodes directly — avoid manual SKU typing to prevent billing inaccuracies.',
            'Apply promotional offer vouchers prior to selecting the final payment tender.',
            'For returns without a physical receipt, retrieve transaction history via customer registered phone number.',
            'Perform end-of-shift digital cash drawer reconciliation without exception.'
        ],
        quiz: [
            {
                id: 'q3-1',
                q: 'Why does store policy mandate barcode scanning over manual SKU entry?',
                options: [
                    'To generate longer receipts',
                    'To eliminate pricing and inventory mismatch errors',
                    'It is an optional speed preference',
                    'To bypass manager audit logs'
                ],
                correct: 1,
                explanation: 'Manual entry has a 4.2% error rate, whereas optical barcode scans guarantee zero pricing discrepancy.'
            },
            {
                id: 'q3-2',
                q: 'At what point in the POS flow should promotional coupons and loyalty points be redeemed?',
                options: [
                    'After final card/UPI payment is authorized',
                    'Before choosing payment tender and calculating net total',
                    'Only on weekend shifts',
                    'Only for store managers'
                ],
                correct: 1,
                explanation: 'Applying discounts before checkout updates tax calculation and avoids payment reversal headaches.'
            },
            {
                id: 'q3-3',
                q: 'How can an associate verify purchase history if the customer misplaced their physical bill?',
                options: [
                    'Refuse the return flatly',
                    'Look up transaction history using their registered phone number',
                    'Ask them to re-purchase the item',
                    'Estimate the price manually'
                ],
                correct: 1,
                explanation: 'The omnichannel POS centralizes purchase logs by phone number across all 1,200 stores.'
            }
        ]
    },
    {
        id: 'm4',
        title: 'Upselling & Cross-merchandising Essentials',
        category: 'Sales Skills',
        duration: '4 min',
        points: 100,
        emoji: '📈',
        description: 'Learn consultative selling techniques that boost average basket size while delivering genuine value.',
        keyPoints: [
            'Recommend relevant accessories that complement what the customer already selected (e.g. matching dupatta or cufflinks).',
            'Frame every recommendation as value enhancement rather than added cost.',
            'Limit recommendations to 1–2 items to prevent decision paralysis.',
            'Always gracefully accept a customer decline without repeating the pitch.'
        ],
        quiz: [
            {
                id: 'q4-1',
                q: 'What should form the basis of a consultative upsell recommendation?',
                options: [
                    'Whatever item has the highest profit margin',
                    'Complementary utility to what the customer has already selected',
                    'Slow-moving dead stock regardless of category',
                    'Random trending items'
                ],
                correct: 1,
                explanation: 'Relevance ensures the customer sees the recommendation as thoughtful styling assistance.'
            },
            {
                id: 'q4-2',
                q: 'How many add-on items should an associate typically suggest during a single consultation?',
                options: [
                    '1 or 2 targeted items',
                    '5 or more to maximize conversion',
                    'As many as possible until they buy',
                    'Zero suggestions'
                ],
                correct: 0,
                explanation: '1 or 2 items keeps the experience delightful and avoids feeling pushy.'
            },
            {
                id: 'q4-3',
                q: 'What is the professional protocol when a customer says "No thank you" to an upsell suggestion?',
                options: [
                    'Repeat the offer with a bigger pitch',
                    'Respect the choice warmly and proceed with checkout',
                    'Call another associate to try again',
                    'Frown and walk away'
                ],
                correct: 1,
                explanation: 'Respectful acknowledgment preserves customer rapport and long-term loyalty.'
            }
        ]
    },
    {
        id: 'm5',
        title: 'Code of Conduct, Safety & Store Standards',
        category: 'Company Policies',
        duration: '5 min',
        points: 100,
        emoji: '🛡️',
        description: 'Core retail standards that ensure customer safety, associate dignity, and zero-compromise store security.',
        keyPoints: [
            'Standard neat uniform and visible QuestFloor associate badge are mandatory on the sales floor.',
            'Report safety hazards (spills, loose cables, blocked fire exits) to the shift lead within the same hour.',
            'Never export or share customer personal information outside authorized POS and CRM consoles.',
            'Zero tolerance policy applies to discrimination, harassment, or disrespectful conduct.'
        ],
        quiz: [
            {
                id: 'q5-1',
                q: 'Within what timeframe must a store floor safety hazard (e.g. liquid spill) be addressed and reported?',
                options: [
                    'At the end of the monthly audit',
                    'Immediately within the same shift/hour',
                    'Only if someone slips or falls',
                    'During weekly maintenance'
                ],
                correct: 1,
                explanation: 'Immediate containment prevents accidents and guarantees floor safety.'
            },
            {
                id: 'q5-2',
                q: 'Where can customer contact numbers collected at checkout be stored or shared?',
                options: [
                    'In personal WhatsApp groups',
                    'Exclusively inside the encrypted QuestFloor POS system',
                    'In a personal floor notebook',
                    'With third-party vendor associates'
                ],
                correct: 1,
                explanation: 'Data privacy compliance strictly forbids storing customer numbers on personal devices.'
            },
            {
                id: 'q5-3',
                q: 'What is QuestFloor’s policy regarding workplace harassment and discrimination?',
                options: [
                    'Evaluated case by case without penalty',
                    'Strict Zero Tolerance across all stores and roles',
                    'Only applicable to corporate HQ staff',
                    'Warning only for first 3 offenses'
                ],
                correct: 1,
                explanation: 'Zero tolerance protects all associates and maintains a dignified, safe workplace.'
            }
        ]
    },
    {
        id: 'm6',
        title: 'Seasonal Discounts, Combos & Clearance Tags',
        category: 'Product Knowledge',
        duration: '3 min',
        points: 80,
        emoji: '🏷️',
        description: 'Ensure 100% price quote accuracy on festive promotional combos, tiered savings, and clearance items.',
        keyPoints: [
            'Promotional combo discounts trigger automatically only when all combo SKUs are included in the same bill.',
            'Clearance red-tagged items are final sale — clearly inform customers prior to billing.',
            'Gold Club loyalty members receive an extra 5% instant discount during the festive campaign window.',
            'Shelf price tags indicate standard MRP; promotional prices reflect dynamically on the POS screen.'
        ],
        quiz: [
            {
                id: 'q6-1',
                q: 'When do promotional bundle/combo discounts apply?',
                options: [
                    'Across multiple days',
                    'When all qualifying items are billed together in a single transaction',
                    'Only for online orders',
                    'Only when approved by regional manager'
                ],
                correct: 1,
                explanation: 'Bundle rules require simultaneous scanning in the active checkout session.'
            },
            {
                id: 'q6-2',
                q: 'What policy applies to items marked with red Clearance Tags?',
                options: [
                    'Eligible for full refund within 30 days',
                    'Final sale — non-returnable unless defective',
                    'Can be exchanged at competitor stores',
                    'Free with purchase'
                ],
                correct: 1,
                explanation: 'Clearance inventory is final sale, and associates must kindly remind customers before payment.'
            },
            {
                id: 'q6-3',
                q: 'What extra benefit do Gold Club members enjoy during seasonal campaigns?',
                options: [
                    'Free store ownership',
                    'An extra 5% instant discount applied at billing',
                    'No payment required',
                    'Free delivery anywhere in India'
                ],
                correct: 1,
                explanation: 'Loyalty perks drive member engagement and incentivize higher annual spend.'
            }
        ]
    },
    {
        id: 'm7',
        title: 'Active Listening & Customer Engagement',
        category: 'Customer Service',
        duration: '3 min',
        points: 80,
        emoji: '👂',
        description: 'Subtle conversational habits that make shoppers feel respected, understood, and eager to return.',
        keyPoints: [
            'Confirm requirements by summarizing what the customer asked before walking to the aisle.',
            'Maintain polite eye contact and pause floor stocking tasks while a customer is speaking.',
            'Ask clarifying open-ended questions (e.g. "What occasion is this outfit for?") to narrow preferences.',
            'Express genuine gratitude for their time and specific choices.'
        ],
        quiz: [
            {
                id: 'q7-1',
                q: 'What is the most effective way to verify you understood a customer’s specific request?',
                options: [
                    'Guess based on what other customers bought',
                    'Summarize and repeat back the key preference to confirm',
                    'Assume you know best without confirmation',
                    'Wait for them to repeat it 3 times'
                ],
                correct: 1,
                explanation: 'Confirming key preferences prevents wasted aisle search time and builds instant rapport.'
            },
            {
                id: 'q7-2',
                q: 'What type of question best unlocks customer needs when they seem unsure?',
                options: [
                    'Yes/No closed questions',
                    'Open-ended questions about occasion, style, or budget preferences',
                    'Asking how much money they have in their wallet',
                    'Directing them to the exit'
                ],
                correct: 1,
                explanation: 'Open-ended questions encourage the customer to share details that guide perfect recommendations.'
            },
            {
                id: 'q7-3',
                q: 'How should you manage floor restocking tasks when a shopper approaches you?',
                options: [
                    'Continue stocking and talk over your shoulder',
                    'Pause the task, make eye contact, and give full attention',
                    'Ask the shopper to wait 15 minutes',
                    'Direct them to another aisle'
                ],
                correct: 1,
                explanation: 'Customer interaction on the sales floor always takes precedence over administrative stocking.'
            }
        ]
    },
    {
        id: 'm8',
        title: 'POS Advanced: Loyalty Redemption & Gift Cards',
        category: 'POS Training',
        duration: '5 min',
        points: 120,
        emoji: '💳',
        description: 'Flawlessly redeem digital gift cards, split tenders across UPI and cash, and manage loyalty points balance.',
        keyPoints: [
            'Loyalty points are credited based on the net payable amount after discount deductions.',
            'Gift card balances can be partially redeemed across multiple shopping trips until depleted.',
            'Always confirm the live remaining gift card balance on the customer-facing screen before completing transaction.',
            'Unused loyalty points carry a 12-month validity from the transaction date.'
        ],
        quiz: [
            {
                id: 'q8-1',
                q: 'On which amount are customer loyalty points calculated and credited?',
                options: [
                    'The original MRP before discounts',
                    'The net payable bill amount post discounts',
                    'The tax amount only',
                    'A fixed 10 points per bill'
                ],
                correct: 1,
                explanation: 'Points are awarded proportionally to the real revenue earned on the transaction.'
            },
            {
                id: 'q8-2',
                q: 'Can a QuestFloor gift card balance be split across multiple separate store visits?',
                options: [
                    'No, single-use only',
                    'Yes, until the available balance reaches zero',
                    'Only within the first 2 hours',
                    'Only if the manager enters a master key'
                ],
                correct: 1,
                explanation: 'Partial balances stay saved securely on the central gift card ledger.'
            },
            {
                id: 'q8-3',
                q: 'What is the standard validity period for QuestFloor customer loyalty reward points?',
                options: [
                    '30 days',
                    '12 months from the date of earning',
                    'They expire at the end of each week',
                    'They never expire'
                ],
                correct: 1,
                explanation: '12-month validity allows ample time for repeat purchases while encouraging annual shopping cycles.'
            }
        ]
    },
    {
        id: 'm9',
        title: 'Visual Merchandising & Impulse Displays',
        category: 'Sales Skills',
        duration: '4 min',
        points: 100,
        emoji: '✨',
        description: 'Keep entrance tables pristine, feature "Hero" products, and organize checkout impulse counters.',
        keyPoints: [
            'Follow the "Rule of Three": Group products in odd numbers (e.g. 3 candle holders) for higher visual attraction.',
            'Ensure high-margin impulse items near the billing queue are restocked at the start of each rush hour.',
            'Price tags must always face forward and be clearly visible without turning the product.',
            'Tidy folded apparel stacks every 45 minutes during high-traffic shifts.'
        ],
        quiz: [
            {
                id: 'q9-1',
                q: 'What is the "Rule of Three" in visual merchandising display design?',
                options: [
                    'Discounts must always be 33%',
                    'Grouping products in odd sets of three creates appealing focal visual balance',
                    'Only 3 customers allowed per aisle',
                    'Associates must work in groups of 3'
                ],
                correct: 1,
                explanation: 'Odd-number groupings capture human eye attention faster than even symmetric grids.'
            },
            {
                id: 'q9-2',
                q: 'When should checkout impulse counters be replenished?',
                options: [
                    'Only once a month',
                    'Before peak rush hour windows so shelves are never empty',
                    'Only after all items sell out completely',
                    'During store closing only'
                ],
                correct: 1,
                explanation: 'Full shelves at checkout create abundant impulse opportunities during queue wait times.'
            },
            {
                id: 'q9-3',
                q: 'How frequently should high-traffic apparel display tables be reorganized during festive rushes?',
                options: [
                    'Every 45 minutes to maintain crisp luxury presentation',
                    'Once a week',
                    'Never during store hours',
                    'Only if the manager requests it'
                ],
                correct: 0,
                explanation: 'Regular tidying preserves high customer perception and reduces checkout friction.'
            }
        ]
    },
    {
        id: 'm10',
        title: 'Data Privacy & Customer Information Security',
        category: 'Company Policies',
        duration: '4 min',
        points: 100,
        emoji: '🔒',
        description: 'Maintain ironclad customer trust by securing personal phone numbers, OTP authorizations, and receipts.',
        keyPoints: [
            'Only request information strictly required for billing, warranty registration, and e-receipts.',
            'Never write customer phone numbers on loose paper, scratchpads, or personal messaging apps.',
            'Always lock your POS terminal screen (press Ctrl+L) whenever leaving the billing counter unattended.',
            'Honor customer requests to opt-out of marketing SMS by updating their profile flag in the POS console.'
        ],
        quiz: [
            {
                id: 'q10-1',
                q: 'What should an associate do whenever stepping away from their active POS terminal?',
                options: [
                    'Leave the screen open for the next colleague',
                    'Lock the terminal screen immediately to protect customer data',
                    'Turn off the store power mains',
                    'Delete the daily transaction log'
                ],
                correct: 1,
                explanation: 'Terminal locking prevents unauthorized data viewing and maintains audit integrity.'
            },
            {
                id: 'q10-2',
                q: 'What is the correct protocol if a customer requests to opt-out of promotional marketing SMS?',
                options: [
                    'Tell them it is mandatory and cannot be disabled',
                    'Toggle the marketing opt-out preference in the POS customer profile',
                    'Ignore the request',
                    'Ask them to change their phone number'
                ],
                correct: 1,
                explanation: 'Respecting communication preferences adheres to data privacy laws and builds long-term brand goodwill.'
            },
            {
                id: 'q10-3',
                q: 'Can customer phone numbers be shared with external store vendors for promotional gifts?',
                options: [
                    'Yes, without restriction',
                    'Strictly prohibited under company data security policy',
                    'Only on festival holidays',
                    'Only if the gift value exceeds ₹500'
                ],
                correct: 1,
                explanation: 'Customer data must remain strictly confidential inside the protected enterprise perimeter.'
            }
        ]
    }
];
const CHALLENGES_INIT = [
    {
        id: 'c1',
        title: 'Complete Festive Season Product Line-up Training',
        type: 'daily',
        reward: 100,
        icon: 'BookOpen',
        desc: 'Finish the 5-minute module and score at least 60% on the quiz.',
        completedBy: [
            'e4',
            'e7'
        ]
    },
    {
        id: 'c2',
        title: 'Zero Billing & Scanning Errors this Week',
        type: 'weekly',
        reward: 150,
        icon: 'ClipboardList',
        desc: 'Keep all digital POS barcode scans 100% error-free.',
        completedBy: [
            'e4'
        ]
    },
    {
        id: 'c3',
        title: 'Recognize 2 Teammates with Positive Shoutouts',
        type: 'daily',
        reward: 50,
        icon: 'Heart',
        desc: 'Give appreciation to peers who assisted you on the store floor.',
        completedBy: []
    },
    {
        id: 'c4',
        title: 'Achieve 90%+ Digital POS Adoption Today',
        type: 'daily',
        reward: 80,
        icon: 'Zap',
        desc: 'Process nearly every floor checkout on the digital POS system.',
        completedBy: [
            'e4',
            'e7'
        ]
    },
    {
        id: 'c5',
        title: 'Collect 3 Verified 5-Star Customer Feedbacks',
        type: 'weekly',
        reward: 120,
        icon: 'Star',
        desc: 'Guide satisfied shoppers to submit quick digital feedback at checkout.',
        completedBy: []
    },
    {
        id: 'c6',
        title: 'Complete Any 2 Micro-Learning Modules',
        type: 'weekly',
        reward: 150,
        icon: 'GraduationCap',
        desc: 'Select any 2 lessons from the Learning Center to expand your skill set.',
        completedBy: [
            'e6'
        ]
    },
    {
        id: 'c7',
        title: 'Support a New Associate Onboarding Step',
        type: 'daily',
        reward: 60,
        icon: 'Users',
        desc: 'Demonstrate the fast UPI POS return flow to a junior peer.',
        completedBy: []
    },
    {
        id: 'c8',
        title: 'Suggest Consultative Upsells on 5 Bills',
        type: 'daily',
        reward: 90,
        icon: 'TrendingUp',
        desc: 'Apply the Upselling Essentials module recommendations on the floor.',
        completedBy: [
            'e4'
        ]
    },
    {
        id: 'c9',
        title: 'Zero Return Processing Delay this Week',
        type: 'weekly',
        reward: 100,
        icon: 'ShieldCheck',
        desc: 'Process all verified customer returns in under 2 minutes.',
        completedBy: []
    },
    {
        id: 'c10',
        title: 'Maintain a 7-Day Micro-Learning Streak',
        type: 'weekly',
        reward: 200,
        icon: 'Flame',
        desc: 'Complete at least one micro-lesson every single day this week.',
        completedBy: [
            'e1'
        ]
    }
];
const RECOGNITIONS_INIT = [
    {
        id: 'r1',
        fromId: 'e4',
        toId: 'e1',
        category: 'Customer Service',
        message: 'Sneha went above and beyond to help a family find matching festive outfits within their exact budget limit during the weekend rush!',
        likes: 14,
        time: '2h ago'
    },
    {
        id: 'r2',
        fromId: 'mgr1',
        toId: 'e6',
        category: 'Sales Excellence',
        message: 'Arjun closed 4 consultative combo upsells in a single evening shift — exceptional product knowledge application!',
        likes: 9,
        time: '4h ago'
    },
    {
        id: 'r3',
        fromId: 'e9',
        toId: 'e10',
        category: 'Teamwork',
        message: 'Suresh stepped in proactively to cover the gift wrapping counter during the 7 PM rush without being asked. Big lifesaver!',
        likes: 7,
        time: '1d ago'
    },
    {
        id: 'r4',
        fromId: 'e1',
        toId: 'e2',
        category: 'Knowledge Sharing',
        message: 'Rahul patiently walked me through the new split-tender POS payment flow step by step. Really appreciate the mentorship!',
        likes: 8,
        time: '1d ago'
    },
    {
        id: 'r5',
        fromId: 'e7',
        toId: 'e4',
        category: 'Problem Solving',
        message: 'Vikram calmly assisted an upset customer with an exchange and turned the interaction into a glowing 5-star Google review.',
        likes: 18,
        time: '2d ago'
    },
    {
        id: 'r6',
        fromId: 'mgr2',
        toId: 'e5',
        category: 'Customer Service',
        message: 'Priya’s detailed styling guidance for traditional festive wear resulted in repeat visits from three customer families!',
        likes: 11,
        time: '2d ago'
    }
];
const NOTIFICATIONS_INIT = [
    {
        id: 'n1',
        recipientId: 'e1',
        icon: 'Trophy',
        text: 'You climbed to #4 on the store leaderboard with 1,480 points!',
        time: '1h ago',
        read: false
    },
    {
        id: 'n2',
        recipientId: 'e1',
        icon: 'Award',
        text: 'You unlocked the "Learning Streak" badge for 7 consecutive days of micro-lessons.',
        time: '1d ago',
        read: false
    },
    {
        id: 'n3',
        recipientId: 'e1',
        icon: 'Heart',
        text: 'Vikram Singh gave you a shoutout for Customer Service.',
        time: '1d ago',
        read: false
    },
    {
        id: 'n4',
        recipientId: 'e1',
        icon: 'BookOpen',
        text: 'New training module available: "Visual Merchandising & Impulse Displays" (+100 XP).',
        time: '2d ago',
        read: true
    },
    {
        id: 'n5',
        recipientId: 'e1',
        icon: 'Target',
        text: 'New weekly challenge: Maintain zero return delays.',
        time: '3d ago',
        read: true
    },
    {
        id: 'n6',
        recipientId: 'mgr1',
        icon: 'AlertTriangle',
        text: 'Ayesha Khan (Indore Palasia) POS adoption dropped to 45% (below 55% threshold).',
        time: '3h ago',
        read: false
    },
    {
        id: 'n7',
        recipientId: 'mgr1',
        icon: 'Heart',
        text: 'Anil Deshmukh recognized Arjun Reddy for Sales Excellence.',
        time: '5h ago',
        read: true
    },
    {
        id: 'n8',
        recipientId: 'admin1',
        icon: 'Building2',
        text: 'QuestFloor Patna Boring Road is currently below target average training completion (38%).',
        time: '6h ago',
        read: false
    },
    {
        id: 'n9',
        recipientId: 'all',
        icon: 'Megaphone',
        text: 'Diwali Festival Mega-Campaign begins Monday! Complete your Festive Range training modules by Sunday.',
        time: '1d ago',
        read: true
    }
];
}),
"[project]/src/lib/store/useAppStore.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppProvider",
    ()=>AppProvider,
    "useAppStore",
    ()=>useAppStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$canvas$2d$confetti$2f$dist$2f$confetti$2e$module$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/canvas-confetti/dist/confetti.module.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/data/initialData.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/cxCalculator.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/audioEffect.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/translations.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const INITIAL_MISSIONS = [
    {
        id: 'sm-1',
        title: '⚡ Floor Speed Sprint: Reduce Billing Time below 90s',
        category: 'Speed',
        currentValue: 82,
        targetValue: 90,
        unit: 'sec avg',
        rewardXP: 300,
        icon: 'Zap',
        expiresIn: '4h 20m',
        isClaimed: false,
        description: 'Keep average digital POS scan & tender authorization under 90 seconds during peak shift.'
    },
    {
        id: 'sm-2',
        title: '🎯 Festive Pairing: Recommend 5 Diya & Kurta Combos',
        category: 'Sales',
        currentValue: 4,
        targetValue: 5,
        unit: 'upsells',
        rewardXP: 200,
        icon: 'TrendingUp',
        expiresIn: '6h 15m',
        isClaimed: false,
        description: 'Help shoppers pair traditional ethnic wear with ₹499 diya and lantern impulse combos.'
    },
    {
        id: 'sm-3',
        title: '⭐ Customer Delight: Maintain 90%+ 5-Star CSAT Rating',
        category: 'CSAT',
        currentValue: 94,
        targetValue: 90,
        unit: '% CSAT',
        rewardXP: 500,
        icon: 'Star',
        expiresIn: 'End of Shift',
        isClaimed: false,
        description: 'Ensure friendly hospitality greetings and zero pricing friction across all floor counters.'
    }
];
const INITIAL_FEEDBACK = [
    {
        id: 'fb-1',
        rating: 5,
        associateId: 'e1',
        storeId: 's1',
        helpful: true,
        selectedTags: [
            'Helpful Staff',
            'Polite Hospitality',
            'Clean Store'
        ],
        comment: 'Sneha explained the cotton-silk fabric quality and helped customize my Diwali gift hamper beautifully!',
        createdAt: '15 mins ago'
    },
    {
        id: 'fb-2',
        rating: 5,
        associateId: 'e4',
        storeId: 's2',
        helpful: true,
        selectedTags: [
            'Fast Billing',
            'Product Knowledge'
        ],
        comment: 'Super fast UPI QR checkout! Billed in under 45 seconds.',
        createdAt: '1h ago'
    },
    {
        id: 'fb-3',
        rating: 4,
        associateId: 'e6',
        storeId: 's3',
        helpful: true,
        selectedTags: [
            'Helpful Staff',
            'Product Knowledge'
        ],
        comment: 'Arjun recommended the perfect matching dupatta for my kurta set.',
        createdAt: '3h ago'
    },
    {
        id: 'fb-4',
        rating: 2,
        associateId: 'e2',
        storeId: 's1',
        helpful: false,
        selectedTags: [
            'Billing Queue Delay'
        ],
        comment: 'Had to wait 7 minutes at billing counter 2 because split payment took time.',
        createdAt: '5h ago'
    }
];
const INITIAL_VOUCHERS = [
    {
        id: 'rv-0',
        rewardId: 'rw-ccd',
        rewardTitle: '☕ Café Coffee Day Free Beverage Voucher',
        costXP: 500,
        code: 'QF-CCD-8492',
        redeemedAt: 'Yesterday',
        expiresAt: 'In 29 Days',
        status: 'Active'
    }
];
const AppContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const LOCAL_STORAGE_KEY = 'questfloor_store_v1';
function AppProvider({ children }) {
    const [role, setRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [screen, setScreen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('dashboard');
    const [mobileOpen, setMobileOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [celebration, setCelebration] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isStoryModalOpen, setIsStoryModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeEmployeeId, setActiveEmployeeId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"]);
    const [language, setLanguage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('en');
    const [theme, setTheme] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('light');
    const toggleTheme = ()=>{
        setTheme((prev)=>prev === 'light' ? 'dark' : 'light');
    };
    const t = (key)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTranslation"])(language, key);
    const [employees, setEmployees] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EMPLOYEES_INIT"]);
    const [stores] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["STORES_INIT"]);
    const [managers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MANAGERS_INIT"]);
    const [admin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ADMIN_INIT"]);
    const [trainingModules, setTrainingModules] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRAINING_MODULES_INIT"]);
    const [challenges, setChallenges] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CHALLENGES_INIT"]);
    const [recognitions, setRecognitions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RECOGNITIONS_INIT"]);
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NOTIFICATIONS_INIT"]);
    const [publishedQuizzes, setPublishedQuizzes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [redeemedVouchers, setRedeemedVouchers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(INITIAL_VOUCHERS);
    const [feedbackSubmissions, setFeedbackSubmissions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(INITIAL_FEEDBACK);
    const [storeMissions, setStoreMissions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(INITIAL_MISSIONS);
    const [pendingRegistrations, setPendingRegistrations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 'e-pending-1',
            name: 'Rohan Sharma',
            email: 'rohan.sharma@retailrise.com',
            role: 'employee',
            storeId: 's1',
            joinDate: 'Today (10 mins ago)',
            avatarColor: '#f59e0b'
        }
    ]);
    const [managerProfile, setManagerProfile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        name: 'Priya Patel',
        shiftHours: '09:00 AM - 06:00 PM (Morning & Peak Rush)',
        coachingFocus: 'POS Split-Tender Speed & Upsell Attachment',
        phone: '+91 98765 43210',
        storeName: 'QuestFloor Store #104 (Nagpur Hub)',
        targetPosRate: 90.0,
        targetTrainingRate: 95.0
    });
    // Load from local storage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        try {
            const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (saved) {
                const parsed = JSON.parse(saved);
                if (parsed.employees) setEmployees(parsed.employees);
                if (parsed.trainingModules) setTrainingModules(parsed.trainingModules);
                if (parsed.challenges) setChallenges(parsed.challenges);
                if (parsed.recognitions) setRecognitions(parsed.recognitions);
                if (parsed.notifications) setNotifications(parsed.notifications);
                if (parsed.publishedQuizzes) setPublishedQuizzes(parsed.publishedQuizzes);
                if (parsed.redeemedVouchers) setRedeemedVouchers(parsed.redeemedVouchers);
                if (parsed.feedbackSubmissions) setFeedbackSubmissions(parsed.feedbackSubmissions);
                if (parsed.storeMissions) setStoreMissions(parsed.storeMissions);
                if (parsed.language) setLanguage(parsed.language);
                if (parsed.theme) setTheme(parsed.theme);
            }
        } catch  {
        // LocalStorage access failed or not supported
        }
    }, []);
    // Save to local storage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        try {
            const stateToSave = {
                employees,
                trainingModules,
                challenges,
                recognitions,
                notifications,
                publishedQuizzes,
                redeemedVouchers,
                feedbackSubmissions,
                storeMissions,
                language,
                theme
            };
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(stateToSave));
        } catch  {
        // LocalStorage save failed
        }
    }, [
        employees,
        trainingModules,
        challenges,
        recognitions,
        notifications,
        publishedQuizzes,
        redeemedVouchers,
        feedbackSubmissions,
        storeMissions,
        language,
        theme
    ]);
    const showToast = (message, icon = '✨')=>{
        const id = `toast-${Date.now()}`;
        setToast({
            id,
            message,
            icon
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playClick();
        setTimeout(()=>{
            setToast((prev)=>prev?.id === id ? null : prev);
        }, 3500);
    };
    const fireCelebration = (data)=>{
        setCelebration(data);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playLevelUp();
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        setTimeout(()=>{
            setCelebration(null);
        }, 2600);
    };
    const addNotification = (recipientId, icon, text)=>{
        const newNotif = {
            id: `n-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            recipientId,
            icon,
            text,
            time: 'Just now',
            read: false
        };
        setNotifications((prev)=>[
                newNotif,
                ...prev
            ]);
    };
    const currentEmployee = employees.find((e)=>e.id === activeEmployeeId) || employees[0];
    const currentManager = managers.find((m)=>m.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_MANAGER_ID"]) || managers[0];
    const handleLogin = (selectedRole)=>{
        setRole(selectedRole);
        setScreen('dashboard');
        const name = selectedRole === 'employee' ? currentEmployee?.name?.split(' ')[0] || 'Amit' : selectedRole === 'manager' ? 'Priya' : 'Neha';
        showToast(`Welcome back, ${name}!`, '👋');
    };
    const handleLogout = ()=>{
        setRole(null);
        setScreen('dashboard');
    };
    const finishModule = (moduleId, scorePct)=>{
        const emp = employees.find((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"]) || employees[0];
        const moduleDef = trainingModules.find((m)=>m.id === moduleId);
        if (!moduleDef) return {
            pointsEarned: 0,
            unlockedBadge: null
        };
        const alreadyDone = emp.completedModules.includes(moduleId);
        const pointsEarned = alreadyDone || scorePct < 60 ? 0 : moduleDef.points;
        const newCompleted = alreadyDone ? emp.completedModules : [
            ...emp.completedModules,
            moduleId
        ];
        let newBadges = [
            ...emp.badges
        ];
        let unlockedBadge = null;
        if (!alreadyDone && scorePct >= 60) {
            const nextBadge = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BADGES"].find((b)=>!emp.badges.includes(b.id));
            if (nextBadge) {
                newBadges.push(nextBadge.id);
                unlockedBadge = nextBadge;
            }
        }
        const beforeLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLevelInfo"])(emp.points);
        const afterLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLevelInfo"])(emp.points + pointsEarned);
        setEmployees((prev)=>prev.map((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"] ? {
                    ...e,
                    points: e.points + pointsEarned,
                    weeklyPoints: e.weeklyPoints + pointsEarned,
                    monthlyPoints: e.monthlyPoints + pointsEarned,
                    completedModules: newCompleted,
                    badges: newBadges
                } : e));
        if (!alreadyDone && scorePct >= 60) {
            addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'BookOpen', `Completed "${moduleDef.title}" — +${moduleDef.points} XP earned!`);
            if (unlockedBadge) {
                addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'Award', `New Badge Unlocked: ${unlockedBadge.name}!`);
                fireCelebration({
                    emoji: unlockedBadge.icon,
                    eyebrow: 'Badge Unlocked!',
                    title: unlockedBadge.name,
                    sub: unlockedBadge.desc
                });
            } else if (afterLevel.level > beforeLevel.level) {
                fireCelebration({
                    emoji: '🚀',
                    eyebrow: 'Level Up!',
                    title: `Level ${afterLevel.level} · ${afterLevel.name}`,
                    sub: 'Outstanding work! Keep building momentum.'
                });
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
                showToast(`Quiz Passed! +${pointsEarned} XP`, '🎉');
            }
        }
        return {
            pointsEarned,
            unlockedBadge
        };
    };
    const completeChallenge = (challengeId)=>{
        const ch = challenges.find((c)=>c.id === challengeId);
        if (!ch || ch.completedBy.includes(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"])) return;
        const emp = employees.find((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"]) || employees[0];
        const beforeLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLevelInfo"])(emp.points);
        const afterLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLevelInfo"])(emp.points + ch.reward);
        setChallenges((prev)=>prev.map((c)=>c.id === challengeId ? {
                    ...c,
                    completedBy: [
                        ...c.completedBy,
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"]
                    ]
                } : c));
        setEmployees((prev)=>prev.map((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"] ? {
                    ...e,
                    points: e.points + ch.reward,
                    weeklyPoints: e.weeklyPoints + ch.reward
                } : e));
        addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'Target', `Challenge Completed: "${ch.title}" (+${ch.reward} XP)`);
        if (afterLevel.level > beforeLevel.level) {
            fireCelebration({
                emoji: '🚀',
                eyebrow: 'Level Up!',
                title: `Level ${afterLevel.level} · ${afterLevel.name}`,
                sub: 'You crushed today\'s challenge!'
            });
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
            showToast(`Challenge Completed! +${ch.reward} XP`, '🎯');
        }
    };
    const giveRecognition = (fromId, toId, category, message)=>{
        const newRec = {
            id: `r-${Date.now()}`,
            fromId,
            toId,
            category,
            message,
            likes: 0,
            time: 'Just now'
        };
        setRecognitions((prev)=>[
                newRec,
                ...prev
            ]);
        const recipientName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getEmployeeName"])(employees, toId);
        const senderName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getEmployeeName"])(employees, fromId);
        addNotification(toId, 'Heart', `${senderName} recognized you for ${category}: "${message.slice(0, 45)}…"`);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
        showToast(`Recognition shared with ${recipientName}!`, '👏');
    };
    const likeRecognition = (id)=>{
        setRecognitions((prev)=>prev.map((r)=>r.id === id ? {
                    ...r,
                    likes: r.likes + 1
                } : r));
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playClick();
    };
    const markNotificationsRead = (recipientId)=>{
        setNotifications((prev)=>{
            const hasUnread = prev.some((n)=>(n.recipientId === recipientId || n.recipientId === 'all') && !n.read);
            if (!hasUnread) return prev;
            return prev.map((n)=>n.recipientId === recipientId || n.recipientId === 'all' ? {
                    ...n,
                    read: true
                } : n);
        });
    };
    const nudgeEmployee = (emp)=>{
        addNotification(emp.id, 'AlertTriangle', `Manager Anil Deshmukh sent a reminder to complete your POS Training module.`);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playClick();
        showToast(`Training reminder sent to ${emp.name}.`, '📩');
    };
    const createChallenge = (ch)=>{
        const newCh = {
            id: `c-${Date.now()}`,
            title: ch.title,
            type: ch.type,
            reward: ch.reward,
            icon: 'Target',
            desc: 'Published organization-wide by HR & Admin.',
            completedBy: []
        };
        setChallenges((prev)=>[
                newCh,
                ...prev
            ]);
        addNotification('all', 'Target', `New Challenge Published: "${ch.title}" (+${ch.reward} XP)`);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
        showToast('New challenge published to all stores!', '🎯');
    };
    const publishAIQuiz = (draft)=>{
        const newModule = {
            id: `m-ai-${Date.now()}`,
            title: `${draft.product} Masterclass`,
            category: draft.skill,
            duration: `${draft.timeLimit} min`,
            points: draft.rewardPoints,
            emoji: '✨',
            description: `AI-generated micro-learning module focusing on ${draft.skill.toLowerCase()} for ${draft.product}.`,
            keyPoints: [
                `Master key consultation techniques for ${draft.product}.`,
                `Apply store guidelines to resolve customer doubts with empathy.`,
                `Accurately register product sales and warranties in the POS terminal.`
            ],
            quiz: draft.questions.map((q, idx)=>({
                    id: `q-mod-${idx}`,
                    q: q.prompt,
                    options: q.options,
                    correct: q.correct
                }))
        };
        setTrainingModules((prev)=>[
                newModule,
                ...prev
            ]);
        setPublishedQuizzes((prev)=>[
                draft,
                ...prev
            ]);
        createChallenge({
            title: draft.challengeTitle,
            type: 'weekly',
            reward: draft.rewardPoints
        });
        addNotification('all', 'Sparkles', `New AI Training live: "${newModule.title}" (+${draft.rewardPoints} XP)`);
        showToast(`AI Quiz & Challenge for "${draft.product}" published live!`, '🚀');
    };
    const sendAnnouncement = (text)=>{
        addNotification('all', 'Megaphone', text);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
        showToast('Announcement broadcasted to all 3,000 associates!', '📣');
    };
    const toggleEmployeeActive = (id)=>{
        setEmployees((prev)=>prev.map((e)=>e.id === id ? {
                    ...e,
                    active: !e.active
                } : e));
        showToast('Employee status updated.', '⚙️');
    };
    // 360-DEGREE ACTIONS
    const redeemReward = (reward)=>{
        if (currentEmployee.points < reward.costXP) {
            showToast(`Need ${reward.costXP - currentEmployee.points} more XP to redeem this reward.`, '⚠️');
            return false;
        }
        const code = `QF-${reward.category.slice(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
        const newVoucher = {
            id: `v-${Date.now()}`,
            rewardId: reward.id,
            rewardTitle: reward.title,
            costXP: reward.costXP,
            code,
            redeemedAt: 'Just now',
            expiresAt: 'In 30 Days',
            status: 'Active'
        };
        setEmployees((prev)=>prev.map((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"] ? {
                    ...e,
                    points: e.points - reward.costXP
                } : e));
        setRedeemedVouchers((prev)=>[
                newVoucher,
                ...prev
            ]);
        addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'Award', `Redeemed "${reward.title}" (Code: ${code})`);
        fireCelebration({
            emoji: '🎁',
            eyebrow: 'Reward Unlocked & Claimed!',
            title: reward.title,
            sub: `Voucher Code: ${code}`
        });
        return true;
    };
    const submitCustomerFeedback = (feedback)=>{
        const newFb = {
            ...feedback,
            id: `fb-${Date.now()}`,
            createdAt: 'Just now'
        };
        setFeedbackSubmissions((prev)=>[
                newFb,
                ...prev
            ]);
        // Boost associate CSAT slightly if 5-star
        if (feedback.rating === 5) {
            setEmployees((prev)=>prev.map((e)=>e.id === feedback.associateId ? {
                        ...e,
                        customerFeedbackScore: Math.min(99, e.customerFeedbackScore + 1)
                    } : e));
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
        showToast('Customer Voice & CSAT Feedback Recorded!', '⭐');
    };
    const claimMissionReward = (missionId)=>{
        const mission = storeMissions.find((m)=>m.id === missionId);
        if (!mission || mission.isClaimed) return;
        setStoreMissions((prev)=>prev.map((m)=>m.id === missionId ? {
                    ...m,
                    isClaimed: true
                } : m));
        setEmployees((prev)=>prev.map((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"] ? {
                    ...e,
                    points: e.points + mission.rewardXP,
                    weeklyPoints: e.weeklyPoints + mission.rewardXP
                } : e));
        addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'Zap', `Store Mission Claimed: "${mission.title}" (+${mission.rewardXP} XP)`);
        fireCelebration({
            emoji: '🔥',
            eyebrow: 'Store Operational Mission Completed!',
            title: `+${mission.rewardXP} XP Claimed`,
            sub: mission.title
        });
    };
    const sendManagerAction = (empId, actionTitle, rewardXP)=>{
        const emp = employees.find((e)=>e.id === empId);
        if (!emp) return;
        if (rewardXP > 0) {
            setEmployees((prev)=>prev.map((e)=>e.id === empId ? {
                        ...e,
                        points: e.points + rewardXP,
                        weeklyPoints: e.weeklyPoints + rewardXP
                    } : e));
        }
        addNotification(empId, 'Award', `Manager Action: ${actionTitle} (+${rewardXP} XP)`);
        showToast(`Manager Action "${actionTitle}" dispatched to ${emp.name}!`, '🚀');
    };
    const registerPendingEmployee = async (data)=>{
        const newPending = {
            id: `e-${Date.now()}`,
            name: data.name,
            email: data.email,
            role: data.role || 'employee',
            storeId: data.storeId || 's1',
            joinDate: 'Today',
            avatarColor: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].amber
        };
        setPendingRegistrations((prev)=>[
                newPending,
                ...prev
            ]);
        return {
            status: 'pending_approval',
            message: `Registration request for ${data.name} has been sent to Store Manager (Store #${data.storeId || '104'}) for verification.`
        };
    };
    const approveRegistration = async (id)=>{
        const target = pendingRegistrations.find((p)=>p.id === id);
        if (!target) return;
        setPendingRegistrations((prev)=>prev.filter((p)=>p.id !== id));
        const newActiveEmployee = {
            id: target.id,
            name: target.name,
            email: target.email,
            storeId: target.storeId,
            points: 100,
            weeklyPoints: 100,
            monthlyPoints: 100,
            posAdoption: 75,
            customerFeedbackScore: 80,
            salesConversion: 70,
            engagementScore: 85,
            badges: [
                'knowledge-seeker'
            ],
            completedModules: [],
            active: true,
            approvalStatus: 'approved',
            color: target.avatarColor || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COLORS"].teal,
            joinDate: target.joinDate
        };
        setEmployees((prev)=>[
                newActiveEmployee,
                ...prev
            ]);
        const approvalNotif = {
            id: `notif-appr-${Date.now()}`,
            recipientId: target.id,
            icon: 'Award',
            text: `🎉 Welcome to QuestFloor! Store Manager Priya Patel approved your account. +100 XP Welcome Bonus Credited.`,
            time: 'Just Now',
            read: false
        };
        setNotifications((prev)=>[
                approvalNotif,
                ...prev
            ]);
        showToast(`Approved ${target.name}! Account activated with +100 XP.`, '✅');
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sounds"].playLevelUp();
    };
    const rejectRegistration = async (id)=>{
        const target = pendingRegistrations.find((p)=>p.id === id);
        setPendingRegistrations((prev)=>prev.filter((p)=>p.id !== id));
        showToast(`Rejected registration request for ${target?.name || 'staff'}.`, 'ℹ️');
    };
    const updateManagerProfileData = async (data)=>{
        setManagerProfile((prev)=>({
                ...prev,
                ...data
            }));
        showToast('Manager profile and shift targets updated!', '💾');
    };
    const resetDemoData = ()=>{
        setEmployees(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EMPLOYEES_INIT"]);
        setTrainingModules(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TRAINING_MODULES_INIT"]);
        setChallenges(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CHALLENGES_INIT"]);
        setRecognitions(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RECOGNITIONS_INIT"]);
        setNotifications(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NOTIFICATIONS_INIT"]);
        setPublishedQuizzes([]);
        setRedeemedVouchers(INITIAL_VOUCHERS);
        setFeedbackSubmissions(INITIAL_FEEDBACK);
        setStoreMissions(INITIAL_MISSIONS);
        setPendingRegistrations([
            {
                id: 'e-pending-1',
                name: 'Rohan Sharma',
                email: 'rohan.sharma@retailrise.com',
                role: 'employee',
                storeId: 's1',
                joinDate: 'Today (10 mins ago)',
                avatarColor: '#f59e0b'
            }
        ]);
        localStorage.removeItem(LOCAL_STORAGE_KEY);
        showToast('Demo data reset to default seed.', '🔄');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AppContext.Provider, {
        value: {
            role,
            screen,
            mobileOpen,
            setMobileOpen,
            currentEmployeeId: activeEmployeeId,
            setSelectedEmployeeId: setActiveEmployeeId,
            currentManagerId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CURRENT_MANAGER_ID"],
            currentEmployee,
            currentManager,
            admin,
            employees,
            stores,
            managers,
            trainingModules,
            challenges,
            recognitions,
            notifications,
            toast,
            celebration,
            publishedQuizzes,
            redeemedVouchers,
            feedbackSubmissions,
            storeMissions,
            pendingRegistrations,
            managerProfile,
            registerPendingEmployee,
            approveRegistration,
            rejectRegistration,
            updateManagerProfileData,
            isStoryModalOpen,
            setIsStoryModalOpen,
            language,
            setLanguage,
            theme,
            setTheme,
            toggleTheme,
            t,
            setRole,
            setScreen,
            showToast,
            fireCelebration,
            handleLogin,
            handleLogout,
            finishModule,
            completeChallenge,
            giveRecognition,
            likeRecognition,
            markNotificationsRead,
            nudgeEmployee,
            createChallenge,
            publishAIQuiz,
            sendAnnouncement,
            toggleEmployeeActive,
            resetDemoData,
            redeemReward,
            submitCustomerFeedback,
            claimMissionReward,
            sendManagerAction
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/store/useAppStore.tsx",
        lineNumber: 787,
        columnNumber: 5
    }, this);
}
function useAppStore() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(AppContext);
    if (!context) {
        throw new Error('useAppStore must be used within an AppProvider');
    }
    return context;
}
}),
"[project]/src/lib/translations.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LANGUAGES",
    ()=>LANGUAGES,
    "TRANSLATIONS",
    ()=>TRANSLATIONS,
    "getTranslation",
    ()=>getTranslation
]);
const LANGUAGES = [
    {
        code: 'en',
        label: 'English',
        nativeLabel: 'English',
        flag: '🇬🇧',
        region: 'Global / Pan-India'
    },
    {
        code: 'hi',
        label: 'Hindi',
        nativeLabel: 'हिन्दी',
        flag: '🇮🇳',
        region: 'North / Central India'
    },
    {
        code: 'mr',
        label: 'Marathi',
        nativeLabel: 'मराठी',
        flag: '🇮🇳',
        region: 'Maharashtra'
    },
    {
        code: 'ta',
        label: 'Tamil',
        nativeLabel: 'தமிழ்',
        flag: '🇮🇳',
        region: 'Tamil Nadu'
    },
    {
        code: 'te',
        label: 'Telugu',
        nativeLabel: 'తెలుగు',
        flag: '🇮🇳',
        region: 'Andhra / Telangana'
    },
    {
        code: 'kn',
        label: 'Kannada',
        nativeLabel: 'ಕನ್ನಡ',
        flag: '🇮🇳',
        region: 'Karnataka'
    },
    {
        code: 'bn',
        label: 'Bengali',
        nativeLabel: 'বাংলা',
        flag: '🇮🇳',
        region: 'West Bengal / East'
    },
    {
        code: 'gu',
        label: 'Gujarati',
        nativeLabel: 'ગુજરાતી',
        flag: '🇮🇳',
        region: 'Gujarat'
    },
    {
        code: 'ml',
        label: 'Malayalam',
        nativeLabel: 'മലയാളം',
        flag: '🇮🇳',
        region: 'Kerala'
    },
    {
        code: 'pa',
        label: 'Punjabi',
        nativeLabel: 'ਪੰਜਾਬੀ',
        flag: '🇮🇳',
        region: 'Punjab / North'
    },
    {
        code: 'or',
        label: 'Odia',
        nativeLabel: 'ଓଡ଼ିଆ',
        flag: '🇮🇳',
        region: 'Odisha'
    },
    {
        code: 'hng',
        label: 'Hinglish',
        nativeLabel: 'Hinglish',
        flag: '🇮🇳',
        region: 'Retail Floor Slang'
    }
];
const TRANSLATIONS = {
    en: {
        dashboard: 'Dashboard',
        learning: 'Learning Center & Quizzes',
        posSandbox: 'POS Speed Terminal',
        roleplayArena: 'AI Customer Roleplay',
        recognition: 'Peer Recognition Wall',
        leaderboard: 'Leaderboard & Badges',
        rewards: 'Rewards Marketplace',
        actionCenter: 'Manager Action Center',
        employees: 'Team Directory',
        storeAnalytics: 'Store Analytics',
        aiStudio: 'Generative AI Studio',
        stores: 'Store Network',
        analytics: 'Chain Analytics',
        brandTitle: 'QuestFloor Autonomous HCM',
        storeTag: 'Store #104 Nagpur Hub • Tier-3 Cluster',
        storeCX: 'Store CX: 96.4/100 (#1 District 🏆)',
        pitchBtn: '1-Min Pitch & Story',
        streakActive: '7-DAY LEARNING STREAK ACTIVE (+10% BONUS XP)',
        heroHeadingPrefix: 'Empowering Retail Excellence Through ',
        heroHeadingHighlight: 'Learning & Recognition.',
        heroSub: 'A closed-loop operational journey: Learn micro-skills in 2-3 minutes, practice on digital POS, earn peer kudos, and deliver 5-star customer experiences across 1,200 stores.',
        startLesson: 'Start 3-Min Lesson (+100 XP)',
        posTerminal: 'POS Fast-Lane Terminal',
        bhashaCoach: 'Bhasha Coach',
        peerKudos: 'Peer Kudos',
        shiftAssociate: 'Shift Associate',
        levelRank: 'Level & Rank',
        xpProgress: 'XP Progression',
        consistencyStreak: '7-Day Micro-Learning Streak',
        shiftMissionsComplete: 'Shift Missions Completion:',
        totalXP: 'Total Experience Points',
        badgesUnlocked: 'Badges Unlocked',
        curriculumCompleted: 'Curriculum Completed',
        chainRank: 'Chain Leaderboard Rank',
        thisWeek: '+320 this week',
        expertTier: '5 Behavior Badges',
        topPerformer: 'Top 5% Performer',
        dailyMissionsTitle: 'Daily Shift Missions & Sprints',
        dailyMissionsSub: 'Complete bite-sized challenges to earn XP, maintain learning streaks, and unlock badges',
        completeMission: 'Complete Mission',
        completedClaimed: 'Completed & XP Claimed',
        recentBadgesTitle: 'Recent Behavior Badges',
        recentBadgesSub: 'Recognizing product expertise, POS speed, customer delight, and peer teamwork',
        viewAllBadges: 'View All Badges',
        trainingCurriculum: 'Training Curriculum Progress',
        smartAiRec: 'Smart AI Recommendation',
        whyThis: 'Why this?',
        peerRecSummary: 'Peer Recognition Summary',
        received: 'Appreciations Received',
        given: 'Appreciations Given',
        associateRole: 'Store Associate',
        managerRole: 'Store Manager',
        adminRole: 'Regional Admin',
        lightMode: 'Light Mode',
        darkMode: 'Dark Mode'
    },
    hi: {
        dashboard: 'डैशबोर्ड',
        learning: 'लर्निंग सेंटर और क्विज़',
        posSandbox: 'पीओएस स्पीड टर्मिनल',
        roleplayArena: 'एआई ग्राहक रोलप्ले',
        recognition: 'साथी पहचान और प्रशंसा',
        leaderboard: 'लीडरबोर्ड और बैज',
        rewards: 'रिवॉर्ड्स मार्केटप्लेस',
        actionCenter: 'मैनेजर एक्शन सेंटर',
        employees: 'टीम डायरेक्टरी',
        storeAnalytics: 'स्टोर एनालिटिक्स',
        aiStudio: 'जेनरेटिव एआई स्टूडियो',
        stores: 'स्टोर नेटवर्क',
        analytics: 'चेन एनालिटिक्स',
        brandTitle: 'क्वेस्टफ्लोर एचसीएम',
        storeTag: 'स्टोर #104 नागपुर हब • टियर-3 क्लस्टर',
        storeCX: 'स्टोर ग्राहक संतुष्टि: 96.4/100 (#1 जिला 🏆)',
        pitchBtn: '1-मिनट पिच और कहानी',
        streakActive: '7-दिवसीय लर्निंग स्ट्रीक सक्रिय (+10% बोनस एक्सपी)',
        heroHeadingPrefix: 'प्रशिक्षण और पहचान के माध्यम से ',
        heroHeadingHighlight: 'खुदरा उत्कृष्टता को सशक्त बनाना।',
        heroSub: 'क्लोज्ड-लूप संचालन: 2-3 मिनट में नए कौशल सीखें, डिजिटल पीओएस पर अभ्यास करें, सहकर्मियों से प्रशंसा पाएं, और 1,200 स्टोर्स में 5-स्टार ग्राहक अनुभव प्रदान करें।',
        startLesson: '3-मिनट पाठ शुरू करें (+100 XP)',
        posTerminal: 'पीओएस फास्ट-लेन टर्मिनल',
        bhashaCoach: 'भाषा कोच',
        peerKudos: 'साथी को कुडोस दें',
        shiftAssociate: 'शिफ्ट सहयोगी',
        levelRank: 'स्तर और रैंक',
        xpProgress: 'एक्सपी प्रगति',
        consistencyStreak: '7-दिवसीय निरंतरता स्ट्रीक',
        shiftMissionsComplete: 'शिफ्ट मिशन पूर्णता:',
        totalXP: 'कुल अनुभव अंक (XP)',
        badgesUnlocked: 'अनलॉक किए गए बैज',
        curriculumCompleted: 'पाठ्यक्रम पूर्णता',
        chainRank: 'चेन लीडरबोर्ड रैंक',
        thisWeek: '+320 इस सप्ताह',
        expertTier: '5 व्यवहार बैज',
        topPerformer: 'शीर्ष 5% सर्वश्रेष्ठ',
        dailyMissionsTitle: 'दैनिक शिफ्ट मिशन और चुनौतियाँ',
        dailyMissionsSub: 'एक्सपी अर्जित करने, स्ट्रीक बनाए रखने और बैज अनलॉक करने के लिए मिशन पूरे करें',
        completeMission: 'मिशन पूरा करें',
        completedClaimed: 'पूर्ण और एक्सपी दावा किया गया',
        recentBadgesTitle: 'हाल के व्यवहार बैज',
        recentBadgesSub: 'उत्पाद ज्ञान, पीओएस गति और टीमवर्क के लिए सम्मान',
        viewAllBadges: 'सभी बैज देखें',
        trainingCurriculum: 'प्रशिक्षण पाठ्यक्रम प्रगति',
        smartAiRec: 'स्मार्ट एआई सिफारिश',
        whyThis: 'यह क्यों?',
        peerRecSummary: 'साथी मान्यता सारांश',
        received: 'प्राप्त प्रशंसा',
        given: 'दी गई प्रशंसा',
        associateRole: 'स्टोर एसोसिएट',
        managerRole: 'स्टोर मैनेजर',
        adminRole: 'रीजनल एडमिन',
        lightMode: 'लाइट मोड',
        darkMode: 'डार्क मोड'
    },
    mr: {
        dashboard: 'डॅशबोर्ड',
        learning: 'शिक्षण केंद्र आणि चाचण्या',
        posSandbox: 'पीओएस स्पीड टर्मिनल',
        roleplayArena: 'एआय ग्राहक संवाद',
        recognition: 'सहकारी प्रशंसा वॉल',
        leaderboard: 'गुणवत्ता क्रमवारी आणि बॅजेस',
        rewards: 'बक्षिसे मार्केटप्लेस',
        actionCenter: 'व्यवस्थापक कृती केंद्र',
        employees: 'कर्मचारी यादी',
        storeAnalytics: 'स्टोअर विश्लेषण',
        aiStudio: 'एआय स्टुडिओ',
        stores: 'स्टोअर नेटवर्क',
        analytics: 'साखळी विश्लेषण',
        brandTitle: 'क्वेस्टफ्लोर स्वायत्त एचसीएम',
        storeTag: 'स्टोअर #104 नागपूर • टियर-3 क्लस्टर',
        storeCX: 'स्टोअर ग्राहक अनुभव: 96.4/100 (जिल्हा #1 🏆)',
        pitchBtn: '1-मिनिट सादरीकरण',
        streakActive: '7-दिवसीय शिक्षण सातत्य सक्रिय (+10% बोनस)',
        heroHeadingPrefix: 'शिक्षण आणि कौतुकाच्या माध्यमातून ',
        heroHeadingHighlight: 'रिटेल उत्कृष्टतेला सक्षम करणे.',
        heroSub: 'बंद लूप प्रवास: 2-3 मिनिटांत कौशल्ये शिका, पीओएसवर सराव करा, सहकाऱ्यांकडून कौतुक मिळवा आणि 1,200 स्टोअर्समध्ये उत्कृष्ट ग्राहक सेवा द्या.',
        startLesson: '3-मिनिट धडा सुरू करा (+100 XP)',
        posTerminal: 'पीओएस बिलिंग टर्मिनल',
        bhashaCoach: 'भाषा प्रशिक्षक',
        peerKudos: 'सहकाऱ्यांचे कौतुक करा',
        shiftAssociate: 'शिफ्ट कर्मचारी',
        levelRank: 'पातळी आणि क्रमवारी',
        xpProgress: 'अनुभव प्रगती',
        consistencyStreak: '7-दिवसीय शिक्षण सातत्य',
        shiftMissionsComplete: 'शिफ्ट उद्दिष्टे पूर्ण:',
        totalXP: 'एकूण अनुभव गुण (XP)',
        badgesUnlocked: 'मिळालेले बॅजेस',
        curriculumCompleted: 'अभ्यासक्रम पूर्णता',
        chainRank: 'साखळी क्रमवारी',
        thisWeek: '+320 या आठवड्यात',
        expertTier: '5 वर्तन बॅजेस',
        topPerformer: 'शीर्ष 5% सर्वोत्तम',
        dailyMissionsTitle: 'दैनंदिन शिफ्ट उद्दिष्टे',
        dailyMissionsSub: 'गुण मिळवण्यासाठी आणि बॅज मिळवण्यासाठी छोटी आव्हाने पूर्ण करा',
        completeMission: 'उद्दिष्ट पूर्ण करा',
        completedClaimed: 'पूर्ण आणि गुण जमा',
        recentBadgesTitle: 'नुकतेच मिळालेले बॅजेस',
        recentBadgesSub: 'उत्पादन ज्ञान, जलद बिलिंग आणि ग्राहक सेवेची पावती',
        viewAllBadges: 'सर्व बॅजेस पहा',
        trainingCurriculum: 'प्रशिक्षण प्रगती',
        smartAiRec: 'स्मार्ट एआय शिफारस',
        whyThis: 'हेच का?',
        peerRecSummary: 'कौतुक सारांश',
        received: 'मिळालेली प्रशंसा',
        given: 'केलेली प्रशंसा',
        associateRole: 'स्टोअर सहयोगी',
        managerRole: 'स्टोअर व्यवस्थापक',
        adminRole: 'प्रादेशिक प्रशासक',
        lightMode: 'लाइट मोड',
        darkMode: 'डार्क मोड'
    },
    ta: {
        dashboard: 'டாஷ்போர்டு',
        learning: 'கற்றல் மையம் & வினாடிவினா',
        posSandbox: 'பிஓஎஸ் டெர்மினல்',
        roleplayArena: 'ஏஐ வாடிக்கையாளர் பயிற்சி',
        recognition: 'சக ஊழியர் அங்கீகாரம்',
        leaderboard: 'மதிப்பெண் பட்டியல் & பேட்ஜ்கள்',
        rewards: 'பரிசுகள் சந்தை',
        actionCenter: 'மேலாளர் நடவடிக்கை மையம்',
        employees: 'குழு விவரங்கள்',
        storeAnalytics: 'கடை பகுப்பாய்வு',
        aiStudio: 'ஏஐ ஸ்டுடியோ',
        stores: 'கடை நெட்வொர்க்',
        analytics: 'செயல்திறன் பகுப்பாய்வு',
        brandTitle: 'குவெஸ்ட்ஃப்ளோர் எச்சிஎம்',
        storeTag: 'கடை #104 சேலம் / நாக்பூர் • அடுக்கு-3',
        storeCX: 'வாடிக்கையாளர் திருப்தி: 96.4/100 (மாவட்டம் #1 🏆)',
        pitchBtn: '1-நிமிட கதை',
        streakActive: '7-நாள் தொடர் கற்றல் (+10% போனஸ் XP)',
        heroHeadingPrefix: 'கற்றல் மற்றும் அங்கீகாரம் மூலம் ',
        heroHeadingHighlight: 'சில்லறை வர்த்தக சிறப்பு.',
        heroSub: '2-3 நிமிடங்களில் புதிய நுணுக்கங்களை கற்றுக்கொள்ளுங்கள், பிஓஎஸ்-இல் பயிற்சி செய்யுங்கள், சக ஊழியர்களின் பாராட்டைப் பெறுங்கள், 1,200 கடைகளில் 5-நட்சத்திர வாடிக்கையாளர் அனுபவத்தை வழங்குங்கள்.',
        startLesson: '3-நிமிட பாடம் (+100 XP)',
        posTerminal: 'பிஓஎஸ் பில்லிங்',
        bhashaCoach: 'மொழி பயிற்றுவிப்பாளர்',
        peerKudos: 'பாராட்டு அனுப்பு',
        shiftAssociate: 'பணி ஊழியர்',
        levelRank: 'நிலை & தரம்',
        xpProgress: 'XP முன்னேற்றம்',
        consistencyStreak: '7-நாள் தொடர் கற்றல்',
        shiftMissionsComplete: 'பணி இலக்குகள்:',
        totalXP: 'மொத்த அனுபவ புள்ளிகள்',
        badgesUnlocked: 'திறக்கப்பட்ட பேட்ஜ்கள்',
        curriculumCompleted: 'பாடத்திட்டம் முடிவு',
        chainRank: 'முன்னணி தரவரிசை',
        thisWeek: '+320 இந்த வாரம்',
        expertTier: '5 நடத்தை பேட்ஜ்கள்',
        topPerformer: 'சிறந்த 5% ஊழியர்',
        dailyMissionsTitle: 'தினசரி பணி இலக்குகள்',
        dailyMissionsSub: 'புள்ளிகளைப் பெற மற்றும் பேட்ஜ்களைத் திறக்க தினசரி சவால்களை முடிக்கவும்',
        completeMission: 'இலக்கை முடிக்கவும்',
        completedClaimed: 'முடிக்கப்பட்டது & XP பெறப்பட்டது',
        recentBadgesTitle: 'சமீபத்திய பேட்ஜ்கள்',
        recentBadgesSub: 'தயாரிப்பு அறிவு மற்றும் வாடிக்கையாளர் சேவைக்கான விருதுகள்',
        viewAllBadges: 'அனைத்து பேட்ஜ்களையும் காண்க',
        trainingCurriculum: 'பயிற்சி முன்னேற்றம்',
        smartAiRec: 'ஏஐ பரிந்துரை',
        whyThis: 'ஏன் இது?',
        peerRecSummary: 'பாராட்டு சுருக்கம்',
        received: 'பெற்ற பாராட்டுகள்',
        given: 'வழங்கிய பாராட்டுகள்',
        associateRole: 'கடை ஊழியர்',
        managerRole: 'கடை மேலாளர்',
        adminRole: 'நிர்வாகி',
        lightMode: 'லைட் மோட்',
        darkMode: 'டார்க் மோட்'
    },
    te: {
        dashboard: 'డ్యాష్‌బోర్డ్',
        learning: 'లెర్నింగ్ సెంటర్ & క్విజ్',
        posSandbox: 'పీవోఎస్ టెర్మినల్',
        roleplayArena: 'ఏఐ కస్టమర్ రోల్‌ప్లే',
        recognition: 'సహోద్యోగుల ప్రశంసలు',
        leaderboard: 'లీడర్‌బోర్డ్ & బ్యాడ్జ్‌లు',
        rewards: 'రివార్డ్స్ మార్కెట్‌ప్లేస్',
        actionCenter: 'మేనేజర్ యాక్షన్ సెంటర్',
        employees: 'బృందం డైరెక్టరీ',
        storeAnalytics: 'స్టోర్ విశ్లేషణ',
        aiStudio: 'ఏఐ స్టూడియో',
        stores: 'స్టోర్ నెట్‌వర్క్',
        analytics: 'నెట్‌వర్క్ విశ్లేషణ',
        brandTitle: 'క్వెస్ట్‌ఫ్లోర్ హెచ్‌సీఎం',
        storeTag: 'స్టోర్ #104 నాగపూర్ • టైర్-3 క్లస్టర్',
        storeCX: 'కస్టమర్ అనుభవం: 96.4/100 (డిస్ట్రిక్ట్ #1 🏆)',
        pitchBtn: '1-నిమిషం పిచ్',
        streakActive: '7-రోజుల నిరంతర శిక్షణ (+10% బోనస్ XP)',
        heroHeadingPrefix: 'శిక్షణ మరియు గుర్తింపు ద్వారా ',
        heroHeadingHighlight: 'రిటైల్ నైపుణ్యాన్ని సాధించండి.',
        heroSub: '2-3 నిమిషాల్లో కొత్త నైపుణ్యాలను నేర్చుకోండి, పీవోఎస్‌లో ప్రాక్టీస్ చేయండి, సహోద్యోగుల నుండి గుర్తింపు పొందండి మరియు 1,200 స్టోర్‌లలో 5-స్టార్ కస్టమర్ అనుభవాన్ని అందించండి.',
        startLesson: '3-నిమిషాల పాఠం (+100 XP)',
        posTerminal: 'పీవోఎస్ ఫాస్ట్-లేన్',
        bhashaCoach: 'భాషా కోచ్',
        peerKudos: 'ప్రశంస పంపండి',
        shiftAssociate: 'షిఫ్ట్ ఉద్యోగి',
        levelRank: 'స్థాయి & ర్యాంక్',
        xpProgress: 'XP పురోగతి',
        consistencyStreak: '7-రోజుల లెర్నింగ్ స్ట్రీక్',
        shiftMissionsComplete: 'షిఫ్ట్ లక్ష్యాలు:',
        totalXP: 'మొత్తం అనుభవ పాయింట్లు',
        badgesUnlocked: 'అన్‌లాక్ చేసిన బ్యాడ్జ్‌లు',
        curriculumCompleted: 'సిలబస్ పూర్తి',
        chainRank: 'లీడర్‌బోర్డ్ ర్యాంక్',
        thisWeek: '+320 ఈ వారం',
        expertTier: '5 బిహేవియర్ బ్యాడ్జ్‌లు',
        topPerformer: 'టాప్ 5% పెర్ఫార్మర్',
        dailyMissionsTitle: 'రోజువారీ షిఫ్ట్ మిషన్లు',
        dailyMissionsSub: 'పాయింట్లు పొందడానికి మరియు బ్యాడ్జ్‌లను అన్‌లాక్ చేయడానికి మిషన్లను పూర్తి చేయండి',
        completeMission: 'మిషన్ పూర్తి చేయండి',
        completedClaimed: 'పూర్తయింది & XP క్లెయిమ్ చేయబడింది',
        recentBadgesTitle: 'ఇటీవలి బ్యాడ్జ్‌లు',
        recentBadgesSub: 'ఉత్పత్తి పరిజ్ఞానం మరియు కస్టమర్ సేవకు గుర్తింపు',
        viewAllBadges: 'అన్ని బ్యాడ్జ్‌లను చూడండి',
        trainingCurriculum: 'శిక్షణ పురోగతి',
        smartAiRec: 'స్మార్ట్ ఏఐ సిఫార్సు',
        whyThis: 'ఎందుకు ఇది?',
        peerRecSummary: 'ప్రశంసల సారాంశం',
        received: 'పొందిన ప్రశంసలు',
        given: 'ఇచ్చిన ప్రశంసలు',
        associateRole: 'స్టోర్ అసోసియేట్',
        managerRole: 'స్టోర్ మేనేజర్',
        adminRole: 'రీజినల్ అడ్మిన్',
        lightMode: 'లైట్ మోడ్',
        darkMode: 'డార్క్ మోడ్'
    },
    kn: {
        dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
        learning: 'ಕಲಿಕಾ ಕೇಂದ್ರ ಮತ್ತು ರಸಪ್ರಶ್ನೆ',
        posSandbox: 'ಪಿಒಎಸ್ ಸ್ಪೀಡ್ ಟರ್ಮಿನಲ್',
        roleplayArena: 'ಎಐ ಗ್ರಾಹಕ ಸಂವಾದ',
        recognition: 'ಸಹೋದ್ಯೋಗಿಗಳ ಪ್ರಶಂಸೆ',
        leaderboard: 'ಶ್ರೇಯಾಂಕ ಮತ್ತು ಬ್ಯಾಡ್ಜ್‌ಗಳು',
        rewards: 'ರಿವಾರ್ಡ್ಸ್ ಮಾರ್ಕೆಟ್‌ಪ್ಲೇಸ್',
        actionCenter: 'ಮ್ಯಾನೇಜರ್ ಆಕ್ಷನ್ ಸೆಂಟರ್',
        employees: 'ತಂಡದ ವಿವರ',
        storeAnalytics: 'ಅಂಗಡಿ ವಿಶ್ಲೇಷಣೆ',
        aiStudio: 'ಎಐ ಸ್ಟುಡಿಯೋ',
        stores: 'ಅಂಗಡಿಗಳ ನೆಟ್‌ವರ್ಕ್',
        analytics: 'ಸರಪಳಿ ವಿಶ್ಲೇಷಣೆ',
        brandTitle: 'ಕ್ವೆಸ್ಟ್‌ಫ್ಲೋರ್ ಎಚ್‌ಸಿಎಂ',
        storeTag: 'ಅಂಗಡಿ #104 ನಾಗ್ಪುರ / ಹುಬ್ಬಳ್ಳಿ • ಶ್ರೇಣಿ-3',
        storeCX: 'ಗ್ರಾಹಕ ಅನುಭವ: 96.4/100 (ಜಿಲ್ಲೆ #1 🏆)',
        pitchBtn: '1-ನಿಮಿಷದ ಪಿಚ್',
        streakActive: '7-ದಿನಗಳ ನಿರಂತರ ಕಲಿಕೆ (+10% ಬೋನಸ್ XP)',
        heroHeadingPrefix: 'ಕಲಿಕೆ ಮತ್ತು ಪ್ರಶಂಸೆಯ ಮೂಲಕ ',
        heroHeadingHighlight: 'ರಿಟೇಲ್ ಉತ್ಕೃಷ್ಟತೆ ಸಾಧಿಸಿ.',
        heroSub: '2-3 ನಿಮಿಷಗಳಲ್ಲಿ ಕೌಶಲ್ಯಗಳನ್ನು ಕಲಿಯಿರಿ, ಡಿಜಿಟಲ್ ಪಿಒಎಸ್‌ನಲ್ಲಿ ಅಭ್ಯಾಸ ಮಾಡಿ, ಸಹೋದ್ಯೋಗಿಗಳಿಂದ ಪ್ರಶಂಸೆ ಪಡೆಯಿರಿ ಮತ್ತು 1,200 ಅಂಗಡಿಗಳಲ್ಲಿ ಅತ್ಯುತ್ತಮ ಗ್ರಾಹಕ ಸೇವೆ ನೀಡಿ.',
        startLesson: '3-ನಿಮಿಷದ ಪಾಠ ಆರಂಭಿಸಿ (+100 XP)',
        posTerminal: 'ಪಿಒಎಸ್ ಬಿಲ್ಲಿಂಗ್ ಟರ್ಮಿನಲ್',
        bhashaCoach: 'ಭಾಷಾ ಕೋಚ್',
        peerKudos: 'ಸಹೋದ್ಯೋಗಿಗಳಿಗೆ ಕುಡೋಸ್ ನೀಡಿ',
        shiftAssociate: 'ಶಿಫ್ಟ್ ಉದ್ಯೋಗಿ',
        levelRank: 'ಮಟ್ಟ ಮತ್ತು ಶ್ರೇಣಿ',
        xpProgress: 'XP ಪ್ರಗತಿ',
        consistencyStreak: '7-ದಿನಗಳ ಕಲಿಕಾ ಸ್ಟ್ರೀಕ್',
        shiftMissionsComplete: 'ಶಿಫ್ಟ್ ಗುರಿಗಳು:',
        totalXP: 'ಒಟ್ಟು ಅನುಭವ ಅಂಕಗಳು (XP)',
        badgesUnlocked: 'ಗಳಿಸಿದ ಬ್ಯಾಡ್ಜ್‌ಗಳು',
        curriculumCompleted: 'ಪಠ್ಯಕ್ರಮ ಪೂರ್ಣ',
        chainRank: 'ನೆಟ್‌ವರ್ಕ್ ಶ್ರೇಯಾಂಕ',
        thisWeek: '+320 ಈ ವಾರ',
        expertTier: '5 ವರ್ತನೆಯ ಬ್ಯಾಡ್ಜ್‌ಗಳು',
        topPerformer: 'ಟಾಪ್ 5% ಸಾಧಕ',
        dailyMissionsTitle: 'ದೈನಂದಿನ ಶಿಫ್ಟ್ ಗುರಿಗಳು',
        dailyMissionsSub: 'ಅಂಕಗಳನ್ನು ಗಳಿಸಲು ಮತ್ತು ಬ್ಯಾಡ್ಜ್‌ಗಳನ್ನು ಪಡೆಯಲು ಸವಾಲುಗಳನ್ನು ಪೂರ್ಣಗೊಳಿಸಿ',
        completeMission: 'ಗುರಿ ಪೂರ್ಣಗೊಳಿಸಿ',
        completedClaimed: 'ಪೂರ್ಣಗೊಂಡಿದೆ & XP ಜಮೆಯಾಗಿದೆ',
        recentBadgesTitle: 'ಇತ್ತೀಚಿನ ಬ್ಯಾಡ್ಜ್‌ಗಳು',
        recentBadgesSub: 'ಉತ್ಪನ್ನ ಜ್ಞಾನ ಮತ್ತು ಗ್ರಾಹಕ ಸೇವೆಗಾಗಿ ಮನ್ನಣೆ',
        viewAllBadges: 'ಎಲ್ಲಾ ಬ್ಯಾಡ್ಜ್‌ಗಳನ್ನು ವೀಕ್ಷಿಸಿ',
        trainingCurriculum: 'ತರಬೇತಿ ಪ್ರಗತಿ',
        smartAiRec: 'ಸ್ಮಾರ್ಟ್ ಎಐ ಶಿಫಾರಸು',
        whyThis: 'ಏಕೆ ಇದು?',
        peerRecSummary: 'ಪ್ರಶಂಸೆಯ ಸಾರಾಂಶ',
        received: 'ಸ್ವೀಕರಿಸಿದ ಪ್ರಶಂಸೆ',
        given: 'ನೀಡಿದ ಪ್ರಶಂಸೆ',
        associateRole: 'ಸ್ಟೋರ್ ಅಸೋಸಿಯೇಟ್',
        managerRole: 'ಸ್ಟೋರ್ ಮ್ಯಾನೇಜರ್',
        adminRole: 'ಪ್ರಾದೇಶಿಕ ನಿರ್ವಾಹಕ',
        lightMode: 'ಲೈಟ್ ಮೋಡ್',
        darkMode: 'ಡಾರ್ಕ್ ಮೋಡ್'
    },
    bn: {
        dashboard: 'ড্যাশবোর্ড',
        learning: 'লার্নিং সেন্টার ও কুইজ',
        posSandbox: 'পিওএস স্পিড টার্মিনাল',
        roleplayArena: 'এআই কাস্টমার রোলপ্লে',
        recognition: 'সহকর্মীদের প্রশংসা প্রাচীর',
        leaderboard: 'লিডারবোর্ড ও ব্যাজ',
        rewards: 'রিওয়ার্ডস মার্কেটপ্লেস',
        actionCenter: 'ম্যানেজার অ্যাকশন সেন্টার',
        employees: 'টিম ডিরেক্টরি',
        storeAnalytics: 'স্টোর অ্যানালিটিক্স',
        aiStudio: 'জেনারেটিভ এআই স্টুডিও',
        stores: 'স্টোর নেটওয়ার্ক',
        analytics: 'চেন অ্যানালিটিক্স',
        brandTitle: 'কোয়েস্টফ্লোর এইচসিএম',
        storeTag: 'স্টোর #104 নাগপুর / শিলিগুড়ি • টায়ার-৩',
        storeCX: 'গ্রাহক সন্তুষ্টি: ৯৬.৪/১০০ (জেলা #১ 🏆)',
        pitchBtn: '১-মিনিট পিচ ও গল্প',
        streakActive: '৭-দিনের লার্নিং স্ট্রিক সক্রিয় (+১০% বোনাস XP)',
        heroHeadingPrefix: 'প্রশিক্ষণ ও স্বীকৃতির মাধ্যমে ',
        heroHeadingHighlight: 'খুচরা ব্যবসায়িক শ্রেষ্ঠত্ব অর্জন।',
        heroSub: '২-৩ মিনিটে নতুন দক্ষতা শিখুন, ডিজিটাল পিওএসে অনুশীলন করুন, সহকর্মীদের প্রশংসা অর্জন করুন এবং ১,২০০ দোকানে ৫-তারকা গ্রাহক সেবা প্রদান করুন।',
        startLesson: '৩-মিনিটের পাঠ শুরু করুন (+100 XP)',
        posTerminal: 'পিওএস ফাস্ট-লেন',
        bhashaCoach: 'ভাষা প্রশিক্ষক',
        peerKudos: 'সহকর্মীকে কুডোস দিন',
        shiftAssociate: 'শিফট কর্মী',
        levelRank: 'লেভেল ও র‍্যাঙ্ক',
        xpProgress: 'XP অগ্রগতি',
        consistencyStreak: '৭-দিনের লার্নিং স্ট্রিক',
        shiftMissionsComplete: 'শিফট মিশন সম্পন্ন:',
        totalXP: 'মোট অভিজ্ঞতা পয়েন্ট (XP)',
        badgesUnlocked: 'আনলক করা ব্যাজ',
        curriculumCompleted: 'কোর্স সম্পন্ন',
        chainRank: 'চেন লিডারবোর্ড র‍্যাঙ্ক',
        thisWeek: '+৩২০ এই সপ্তাহে',
        expertTier: '৫টি আচরণগত ব্যাজ',
        topPerformer: 'শীর্ষ ৫% সেরা কর্মী',
        dailyMissionsTitle: 'দৈনিক শিফট মিশন',
        dailyMissionsSub: 'পয়েন্ট অর্জন করতে এবং ব্যাজ আনলক করতে মিশন সম্পূর্ণ করুন',
        completeMission: 'মিশন সম্পন্ন করুন',
        completedClaimed: 'সম্পন্ন ও XP অর্জিত',
        recentBadgesTitle: 'সাম্প্রতিক ব্যাজসমূহ',
        recentBadgesSub: 'পণ্য জ্ঞান এবং গ্রাহক সেবার জন্য সম্মাননা',
        viewAllBadges: 'সমস্ত ব্যাজ দেখুন',
        trainingCurriculum: 'প্রশিক্ষণ অগ্রগতি',
        smartAiRec: 'স্মার্ট এআই সুপারিশ',
        whyThis: 'কেন এটি?',
        peerRecSummary: 'প্রশংসার সংক্ষিপ্তসার',
        received: 'প্রাপ্ত প্রশংসা',
        given: 'প্রদত্ত প্রশংসা',
        associateRole: 'স্টোর সহযোগী',
        managerRole: 'স্টোর ম্যানেজার',
        adminRole: 'আঞ্চলিক অ্যাডমিন',
        lightMode: 'লাইট মোড',
        darkMode: 'ডার্ক মোড'
    },
    gu: {
        dashboard: 'ડેશબોર્ડ',
        learning: 'લર્નિંગ સેન્ટર અને ક્વિઝ',
        posSandbox: 'પીઓએસ સ્પીડ ટર્મિનલ',
        roleplayArena: 'એઆઈ ગ્રાહક રોલપ્લે',
        recognition: 'સહકર્મી પ્રશંસા વોલ',
        leaderboard: 'લીડરબોર્ડ અને બેજ',
        rewards: 'રિવોર્ડ્સ માર્કેટપ્લેસ',
        actionCenter: 'મેનેજર એક્શન સેન્ટર',
        employees: 'ટીમ ડિરેક્ટરી',
        storeAnalytics: 'સ્ટોર એનાલિટિક્સ',
        aiStudio: 'એઆઈ સ્ટુડિયો',
        stores: 'સ્ટોર નેટવર્ક',
        analytics: 'ચેઈન એનાલિટિક્સ',
        brandTitle: 'ક્વેસ્ટફ્લોર એચસીએમ',
        storeTag: 'સ્ટોર #104 નાગપુર / સુરત • ટિયર-3',
        storeCX: 'ગ્રાહક સંતોષ: 96.4/100 (જિલ્લા #1 🏆)',
        pitchBtn: '1-મિનિટ પિચ',
        streakActive: '7-દિવસીય લર્નિંગ સ્ટ્રીક સક્રિય (+10% બોનસ XP)',
        heroHeadingPrefix: 'તાલીમ અને માન્યતા દ્વારા ',
        heroHeadingHighlight: 'રિટેલ શ્રેષ્ઠતાને સક્ષમ બનાવો.',
        heroSub: '2-3 મિનિટમાં કુશળતા શીખો, ડિજિટલ પીઓએસ પર પ્રેક્ટિસ કરો, સહકર્મીઓ તરફથી પ્રશંસા મેળવો અને 1,200 સ્ટોર્સમાં 5-સ્ટાર ગ્રાહક અનુભવ પ્રદાન કરો.',
        startLesson: '3-મિનિટનો પાઠ શરૂ કરો (+100 XP)',
        posTerminal: 'પીઓએસ બિલિંગ ટર્મિનલ',
        bhashaCoach: 'ભાષા કોચ',
        peerKudos: 'સાથીને પ્રશંસા મોકલો',
        shiftAssociate: 'શિફ્ટ સહયોગી',
        levelRank: 'સ્તર અને રેન્ક',
        xpProgress: 'XP પ્રગતિ',
        consistencyStreak: '7-દિવસીય સાતત્ય સ્ટ્રીક',
        shiftMissionsComplete: 'શિફ્ટ મિશન પૂર્ણ:',
        totalXP: 'કુલ અનુભવ પોઈન્ટ્સ (XP)',
        badgesUnlocked: 'અનલૉક કરેલ બેજ',
        curriculumCompleted: 'અભ્યાસક્રમ પૂર્ણ',
        chainRank: 'ચેઈન રેન્કિંગ',
        thisWeek: '+320 આ અઠવાડિયે',
        expertTier: '5 વર્તણૂક બેજ',
        topPerformer: 'ટોચના 5% શ્રેષ્ઠ',
        dailyMissionsTitle: 'દૈનિક શિફ્ટ મિશન',
        dailyMissionsSub: 'પોઈન્ટ મેળવવા અને બેજ અનલૉક કરવા માટે પડકારો પૂર્ણ કરો',
        completeMission: 'મિશન પૂર્ણ કરો',
        completedClaimed: 'પૂર્ણ અને પોઈન્ટ જમા',
        recentBadgesTitle: 'તાજેતરના બેજ',
        recentBadgesSub: 'પ્રોડક્ટ જ્ઞાન અને ગ્રાહક સેવા માટે સન્માન',
        viewAllBadges: 'બધા બેજ જુઓ',
        trainingCurriculum: 'તાલીમ પ્રગતિ',
        smartAiRec: 'સ્માર્ટ એઆઈ ભલામણ',
        whyThis: 'આ કેમ?',
        peerRecSummary: 'પ્રશંસા સારાંશ',
        received: 'મળેલી પ્રશંસા',
        given: 'આપેલી પ્રશંસા',
        associateRole: 'સ્ટોર એસોસિયેટ',
        managerRole: 'સ્ટોર મેનેજર',
        adminRole: 'પ્રાદેશિક એડમિન',
        lightMode: 'લાઈટ મોડ',
        darkMode: 'ડાર્ક મોડ'
    },
    ml: {
        dashboard: 'ഡാഷ്‌ബോർഡ്',
        learning: 'പഠന കേന്ദ്രവും ക്വിസുകളും',
        posSandbox: 'പിഒഎസ് സ്പീഡ് ടെർമിനൽ',
        roleplayArena: 'എഐ കസ്റ്റമർ റോൾപ്ലേ',
        recognition: 'സഹപ്രവർത്തക പ്രശംസ വാൾ',
        leaderboard: 'ലീഡർബോർഡും ബാഡ്ജുകളും',
        rewards: 'റിവാർഡ്സ് മാർക്കറ്റ്പ്ലെയ്സ്',
        actionCenter: 'മാനേജർ ആക്ഷൻ സെന്റർ',
        employees: 'ടീം ഡയറക്ടറി',
        storeAnalytics: 'സ്റ്റോർ അനലിറ്റിക്സ്',
        aiStudio: 'എഐ സ്റ്റുഡിയോ',
        stores: 'സ്റ്റോർ ശൃംഖല',
        analytics: 'ശൃംഖലാ അനലിറ്റിക്സ്',
        brandTitle: 'ക്വസ്റ്റ്ഫ്ലോർ എച്ച്സിഎം',
        storeTag: 'സ്റ്റോർ #104 നാഗ്പൂർ / കൊച്ചി • ടയർ-3',
        storeCX: 'ഉപഭോക്തൃ സംതൃപ്തി: 96.4/100 (ജില്ല #1 🏆)',
        pitchBtn: '1-മിനിറ്റ് കഥ',
        streakActive: '7-ദിവസത്തെ ലേണിംഗ് സ്ട്രീക്ക് (+10% ബോണസ് XP)',
        heroHeadingPrefix: 'പഠനത്തിലൂടെയും അംഗീകാരത്തിലൂടെയും ',
        heroHeadingHighlight: 'റീട്ടെയിൽ മികവ് കൈവരിക്കുക.',
        heroSub: '2-3 മിനിറ്റിൽ പുതിയ കഴിവുകൾ പഠിക്കുക, ഡിജിറ്റൽ പിഒഎസിൽ പരിശീലിക്കുക, സഹപ്രവർത്തകരിൽ നിന്ന് പ്രശംസ നേടുക, 1,200 സ്റ്റോറുകളിൽ 5-സ്റ്റാർ സേവനം നൽകുക.',
        startLesson: '3-മിനിറ്റ് പാഠം തുടങ്ങുക (+100 XP)',
        posTerminal: 'പിഒഎസ് ഫാസ്റ്റ്-ലൈൻ',
        bhashaCoach: 'ഭാഷാ പരിശീലകൻ',
        peerKudos: 'കുഡോസ് നൽകുക',
        shiftAssociate: 'ഷിഫ്റ്റ് ജീവനക്കാരൻ',
        levelRank: 'ലെവലും റാങ്കും',
        xpProgress: 'XP പുരോഗതി',
        consistencyStreak: '7-ദിവസത്തെ ലേണിംഗ് സ്ട്രീക്ക്',
        shiftMissionsComplete: 'ഷിഫ്റ്റ് ദൗത്യങ്ങൾ:',
        totalXP: 'ആകെ അനുഭവ പോയിന്റുകൾ',
        badgesUnlocked: 'നേടിയ ബാഡ്ജുകൾ',
        curriculumCompleted: 'കോഴ്സ് പൂർത്തിയായി',
        chainRank: 'ലീഡർബോർഡ് റാങ്ക്',
        thisWeek: '+320 ഈ ആഴ്ച',
        expertTier: '5 ബിഹേവിയർ ബാഡ്ജുകൾ',
        topPerformer: 'മികച്ച 5% ജീവനക്കാരൻ',
        dailyMissionsTitle: 'ദൈനംദിന ഷിഫ്റ്റ് ദൗത്യങ്ങൾ',
        dailyMissionsSub: 'പോയിന്റുകൾ നേടാനും ബാഡ്ജുകൾ അൺലോക്ക് ചെയ്യാനും വെല്ലുവിളികൾ പൂർത്തിയാക്കുക',
        completeMission: 'ദൗത്യം പൂർത്തിയാക്കുക',
        completedClaimed: 'പൂർത്തിയായി & XP ക്ലെയിം ചെയ്തു',
        recentBadgesTitle: 'സമീപകാല ബാഡ്ജുകൾ',
        recentBadgesSub: 'ഉൽപ്പന്ന പരിജ്ഞാനത്തിനും മികച്ച സേവനത്തിനുമുള്ള അംഗീകാരം',
        viewAllBadges: 'എല്ലാ ബാഡ്ജുകളും കാണുക',
        trainingCurriculum: 'പരിശീലന പുരോഗതി',
        smartAiRec: 'സ്മാർട്ട് എഐ നിർദ്ദേശം',
        whyThis: 'എന്തുകൊണ്ട് ഇത്?',
        peerRecSummary: 'പ്രശംസാ സംഗ്രഹം',
        received: 'ലഭിച്ച പ്രശംസകൾ',
        given: 'നൽകിയ പ്രശംസകൾ',
        associateRole: 'സ്റ്റോർ അസോസിയേറ്റ്',
        managerRole: 'സ്റ്റോർ മാനേജർ',
        adminRole: 'റീജിയണൽ അഡ്മിൻ',
        lightMode: 'ലൈറ്റ് മോഡ്',
        darkMode: 'ഡാർക്ക് മോഡ്'
    },
    pa: {
        dashboard: 'ਡੈਸ਼ਬੋਰਡ',
        learning: 'ਲਰਨਿੰਗ ਸੈਂਟਰ ਅਤੇ ਕੁਇਜ਼',
        posSandbox: 'ਪੀਓਐਸ ਸਪੀਡ ਟਰਮੀਨਲ',
        roleplayArena: 'ਏਆਈ ਗਾਹਕ ਰੋਲਪਲੇ',
        recognition: 'ਸਾਥੀ ਪ੍ਰਸ਼ੰਸਾ ਵਾਲ',
        leaderboard: 'ਲੀਡਰਬੋਰਡ ਅਤੇ ਬੈਜ',
        rewards: 'ਇਨਾਮ ਮਾਰਕੀਟਪਲੇਸ',
        actionCenter: 'ਮੈਨੇਜਰ ਐਕਸ਼ਨ ਸੈਂਟਰ',
        employees: 'ਟੀਮ ਡਾਇਰੈਕਟਰੀ',
        storeAnalytics: 'ਸਟੋਰ ਐਨਾਲਿਟਿਕਸ',
        aiStudio: 'ਏਆਈ ਸਟੂਡੀਓ',
        stores: 'ਸਟੋਰ ਨੈੱਟਵਰਕ',
        analytics: 'ਚੇਨ ਐਨਾਲਿਟਿਕਸ',
        brandTitle: 'ਕਵੈਸਟਫਲੋਰ ਐਚਸੀਐਮ',
        storeTag: 'ਸਟੋਰ #104 ਨਾਗਪੁਰ / ਅੰਮ੍ਰਿਤਸਰ • ਟੀਅਰ-3',
        storeCX: 'ਗਾਹਕ ਸੰਤੁਸ਼ਟੀ: 96.4/100 (ਜ਼ਿਲ੍ਹਾ #1 🏆)',
        pitchBtn: '1-ਮਿੰਟ ਪਿੱਚ',
        streakActive: '7-ਦਿਨਾ ਲਰਨਿੰਗ ਸਟ੍ਰੀਕ ਸਰਗਰਮ (+10% ਬੋਨਸ XP)',
        heroHeadingPrefix: 'ਸਿਖਲਾਈ ਅਤੇ ਮਾਨਤਾ ਰਾਹੀਂ ',
        heroHeadingHighlight: 'ਰਿਟੇਲ ਉੱਤਮਤਾ ਨੂੰ ਸਮਰੱਥ ਬਣਾਓ।',
        heroSub: '2-3 ਮਿੰਟਾਂ ਵਿੱਚ ਹੁਨਰ ਸਿੱਖੋ, ਡਿਜੀਟਲ ਪੀਓਐਸ ਤੇ ਅਭਿਆਸ ਕਰੋ, ਸਾਥੀਆਂ ਤੋਂ ਪ੍ਰਸ਼ੰਸਾ ਪ੍ਰਾਪਤ ਕਰੋ ਅਤੇ 1,200 ਸਟੋਰਾਂ ਵਿੱਚ 5-ਸਿਤਾਰਾ ਗਾਹਕ ਅਨੁਭਵ ਪ੍ਰਦਾਨ ਕਰੋ।',
        startLesson: '3-ਮਿੰਟ ਦਾ ਪਾਠ ਸ਼ੁਰੂ ਕਰੋ (+100 XP)',
        posTerminal: 'ਪੀਓਐਸ ਬਿਲਿੰਗ ਟਰਮੀਨਲ',
        bhashaCoach: 'ਭਾਸ਼ਾ ਕੋਚ',
        peerKudos: 'ਸਾਥੀ ਨੂੰ ਕੁਡੋਸ ਭੇਜੋ',
        shiftAssociate: 'ਸ਼ਿਫਟ ਸਹਿਯੋਗੀ',
        levelRank: 'ਪੱਧਰ ਅਤੇ ਰੈਂਕ',
        xpProgress: 'XP ਪ੍ਰਗਤੀ',
        consistencyStreak: '7-ਦਿਨਾ ਲਰਨਿੰਗ ਸਟ੍ਰੀਕ',
        shiftMissionsComplete: 'ਸ਼ਿਫਟ ਮਿਸ਼ਨ ਪੂਰੇ:',
        totalXP: 'ਕੁੱਲ ਅਨੁਭਵ ਅੰਕ (XP)',
        badgesUnlocked: 'ਅਨਲੌਕ ਕੀਤੇ ਬੈਜ',
        curriculumCompleted: 'ਸਿਲੇਬਸ ਪੂਰਾ',
        chainRank: 'ਚੇਨ ਰੈਂਕਿੰਗ',
        thisWeek: '+320 ਇਸ ਹਫ਼ਤੇ',
        expertTier: '5 ਵਿਵਹਾਰ ਬੈਜ',
        topPerformer: 'ਚੋਟੀ ਦੇ 5% ਪ੍ਰਦਰਸ਼ਨਕਾਰੀ',
        dailyMissionsTitle: 'ਰੋਜ਼ਾਨਾ ਸ਼ਿਫਟ ਮਿਸ਼ਨ',
        dailyMissionsSub: 'ਅੰਕ ਪ੍ਰਾਪਤ ਕਰਨ ਅਤੇ ਬੈਜ ਅਨਲੌਕ ਕਰਨ ਲਈ ਚੁਣੌਤੀਆਂ ਪੂਰੀਆਂ ਕਰੋ',
        completeMission: 'ਮਿਸ਼ਨ ਪੂਰਾ ਕਰੋ',
        completedClaimed: 'ਪੂਰਾ ਹੋਇਆ ਅਤੇ XP ਕਲੇਮ ਕੀਤਾ',
        recentBadgesTitle: 'ਤਾਜ਼ਾ ਬੈਜ',
        recentBadgesSub: 'ਉਤਪਾਦ ਗਿਆਨ ਅਤੇ ਗਾਹਕ ਸੇਵਾ ਲਈ ਮਾਨਤਾ',
        viewAllBadges: 'ਸਾਰੇ ਬੈਜ ਦੇਖੋ',
        trainingCurriculum: 'ਸਿਖਲਾਈ ਪ੍ਰਗਤੀ',
        smartAiRec: 'ਸਮਾਰਟ ਏਆਈ ਸਿਫਾਰਸ਼',
        whyThis: 'ਇਹ ਕਿਉਂ?',
        peerRecSummary: 'ਪ੍ਰਸ਼ੰਸਾ ਸਾਰ',
        received: 'ਮਿਲੀ ਪ੍ਰਸ਼ੰਸਾ',
        given: 'ਦਿੱਤੀ ਪ੍ਰਸ਼ੰਸਾ',
        associateRole: 'ਸਟੋਰ ਐਸੋਸੀਏਟ',
        managerRole: 'ਸਟੋਰ ਮੈਨੇਜਰ',
        adminRole: 'ਖੇਤਰੀ ਐਡਮਿਨ',
        lightMode: 'ਲਾਈਟ ਮੋਡ',
        darkMode: 'ਡਾਰਕ ਮੋਡ'
    },
    or: {
        dashboard: 'ଡ୍ୟାସବୋର୍ଡ',
        learning: 'ଶିକ୍ଷଣ କେନ୍ଦ୍ର ଓ କୁଇଜ୍',
        posSandbox: 'ପିଓଏସ୍ ସ୍ପିଡ୍ ଟର୍ମିନାଲ୍',
        roleplayArena: 'ଏଆଇ ଗ୍ରାହକ ରୋଲପ୍ଲେ',
        recognition: 'ସହକର୍ମୀ ପ୍ରଶଂସା କାନ୍ଥ',
        leaderboard: 'ଲିଡରବୋର୍ଡ ଓ ବ୍ୟାଜ୍',
        rewards: 'ପୁରସ୍କାର ବଜାର',
        actionCenter: 'ମ୍ୟାନେଜର ଆକ୍ସନ ସେଣ୍ଟର',
        employees: 'ଟିମ୍ ଡିରେକ୍ଟୋରୀ',
        storeAnalytics: 'ଷ୍ଟୋର ବିଶ୍ଳେଷଣ',
        aiStudio: 'ଏଆଇ ଷ୍ଟୁଡିଓ',
        stores: 'ଷ୍ଟୋର ନେଟୱାର୍କ',
        analytics: 'ଚେନ୍ ବିଶ୍ଳେଷଣ',
        brandTitle: 'କ୍ୱେଷ୍ଟଫ୍ଲୋର୍ ଏଚସିଏମ୍',
        storeTag: 'ଷ୍ଟୋର #104 ନାଗପୁର / ଭୁବନେଶ୍ୱର • ଟିୟର-3',
        storeCX: 'ଗ୍ରାହକ ସନ୍ତୋଷ: 96.4/100 (ଜିଲ୍ଲା #1 🏆)',
        pitchBtn: '1-ମିନିଟ୍ ପିଚ୍',
        streakActive: '7-ଦିନିଆ ଶିକ୍ଷଣ ଷ୍ଟ୍ରିକ୍ ସକ୍ରିୟ (+10% ବୋନସ୍ XP)',
        heroHeadingPrefix: 'ତାଲିମ ଏବଂ ସ୍ୱୀକୃତି ମାଧ୍ୟମରେ ',
        heroHeadingHighlight: 'ଖୁଚୁରା ଉତ୍କର୍ଷତା ହାସଲ କରନ୍ତୁ।',
        heroSub: '2-3 ମିନିଟରେ ଦକ୍ଷତା ଶିଖନ୍ତୁ, ଡିଜିଟାଲ୍ ପିଓଏସରେ ଅଭ୍ୟାସ କରନ୍ତୁ, ସହକର୍ମୀଙ୍କଠାରୁ ପ୍ରଶଂସା ପାଆନ୍ତୁ ଏବଂ 1,200 ଷ୍ଟୋରରେ 5-ତାରକା ଗ୍ରାହକ ସେବା ପ୍ରଦାନ କରନ୍ତୁ।',
        startLesson: '3-ମିନିଟ୍ ପାଠ ଆରମ୍ଭ କରନ୍ତୁ (+100 XP)',
        posTerminal: 'ପିଓଏସ୍ ବିଲିଂ ଟର୍ମିନାଲ୍',
        bhashaCoach: 'ଭାଷା କୋଚ୍',
        peerKudos: 'ସହକର୍ମୀଙ୍କୁ ପ୍ରଶଂସା କରନ୍ତୁ',
        shiftAssociate: 'ସିଫ୍ଟ କର୍ମଚାରୀ',
        levelRank: 'ସ୍ତର ଓ ର଼୍ୟାଙ୍କ',
        xpProgress: 'XP ଅଗ୍ରଗତି',
        consistencyStreak: '7-ଦିନିଆ ଶିକ୍ଷଣ ଷ୍ଟ୍ରିକ୍',
        shiftMissionsComplete: 'ସିଫ୍ଟ ଲକ୍ଷ୍ୟ ପୂରଣ:',
        totalXP: 'ମୋଟ ଅଭିଜ୍ଞତା ପଏଣ୍ଟ (XP)',
        badgesUnlocked: 'ଅନଲକ୍ ହୋଇଥିବା ବ୍ୟାଜ୍',
        curriculumCompleted: 'ପାଠ୍ୟକ୍ରମ ସମ୍ପୂର୍ଣ୍ଣ',
        chainRank: 'ନେଟୱାର୍କ ର଼୍ୟାଙ୍କିଙ୍ଗ୍',
        thisWeek: '+320 ଏହି ସପ୍ତାହରେ',
        expertTier: '5 ବ୍ୟବହାରିକ ବ୍ୟାଜ୍',
        topPerformer: 'ଶ୍ରେଷ୍ଠ 5% ପ୍ରଦର୍ଶନକାରୀ',
        dailyMissionsTitle: 'ଦୈନିକ ସିଫ୍ଟ ମିଶନ',
        dailyMissionsSub: 'ପଏଣ୍ଟ ପାଇବା ଏବଂ ବ୍ୟାଜ୍ ଅନଲକ୍ କରିବା ପାଇଁ ଆହ୍ୱାନ ପୂରଣ କରନ୍ତୁ',
        completeMission: 'ମିଶନ ପୂରଣ କରନ୍ତୁ',
        completedClaimed: 'ସମ୍ପୂର୍ଣ୍ଣ ଏବଂ XP ଜମା ହୋଇଛି',
        recentBadgesTitle: 'ସାମ୍ପ୍ରତିକ ବ୍ୟାଜ୍',
        recentBadgesSub: 'ଉତ୍ପାଦ ଜ୍ଞାନ ଏବଂ ଗ୍ରାହକ ସେବା ପାଇଁ ସମ୍ମାନ',
        viewAllBadges: 'ସମସ୍ତ ବ୍ୟାଜ୍ ଦେଖନ୍ତୁ',
        trainingCurriculum: 'ତାଲିମ ଅଗ୍ରଗତି',
        smartAiRec: 'ସ୍ମାର୍ଟ ଏଆଇ ସୁପାରିଶ',
        whyThis: 'ଏହା କାହିଁକି?',
        peerRecSummary: 'ପ୍ରଶଂସା ସାରାଂଶ',
        received: 'ପ୍ରାପ୍ତ ପ୍ରଶଂସା',
        given: 'ପ୍ରଦତ୍ତ ପ୍ରଶଂସା',
        associateRole: 'ଷ୍ଟୋର ସହଯୋଗୀ',
        managerRole: 'ଷ୍ଟୋର ମ୍ୟାନେଜର',
        adminRole: 'ଆଞ୍ଚଳିକ ପ୍ରଶାସକ',
        lightMode: 'ଲାଇଟ୍ ମୋଡ୍',
        darkMode: 'ଡାର୍କ ମୋଡ୍'
    },
    hng: {
        dashboard: 'Floor Dashboard',
        learning: 'Micro-Learning & Quizzes',
        posSandbox: 'Speed Billing POS',
        roleplayArena: 'AI Customer Deal Roleplay',
        recognition: 'Team Kudos Wall',
        leaderboard: 'Store & Chain Ranks',
        rewards: 'Rewards & Vouchers',
        actionCenter: 'Manager Shift Center',
        employees: 'Team Directory',
        storeAnalytics: 'Store Numbers',
        aiStudio: 'GenAI Lesson Studio',
        stores: 'Store Network',
        analytics: 'Chain Analytics',
        brandTitle: 'QuestFloor Smart HCM',
        storeTag: 'Store #104 Nagpur Hub • Bharat Retail',
        storeCX: 'Store CX Rating: 96.4/100 (#1 in District 🏆)',
        pitchBtn: '1-Min Pitch Audio/Script',
        streakActive: '7-DAY STREAK ON FIRE (+10% EXTRA BONUS XP)',
        heroHeadingPrefix: 'Daily Learning & Real Kudos se ',
        heroHeadingHighlight: 'Retail Floor pe Excellence.',
        heroSub: 'Daily 2-3 minute micro-lessons, speed billing POS practice, teammates ko peer appreciation, aur 1,200 stores me top-class customer delight deliver karo.',
        startLesson: 'Start 3-Min Lesson (+100 XP)',
        posTerminal: 'Open POS Terminal',
        bhashaCoach: 'Dialect Coach',
        peerKudos: 'Give Teammate Kudos',
        shiftAssociate: 'On-Duty Associate',
        levelRank: 'Level & Leaderboard Rank',
        xpProgress: 'XP Level Progress',
        consistencyStreak: '7-Day Learning Streak',
        shiftMissionsComplete: 'Today Shift Missions Done:',
        totalXP: 'Total Experience XP',
        badgesUnlocked: 'Unlocked Badges',
        curriculumCompleted: 'Syllabus Completed',
        chainRank: 'Chain Rank',
        thisWeek: '+320 XP this week',
        expertTier: '5 Skills Badges',
        topPerformer: 'Top 5% Performer',
        dailyMissionsTitle: 'Today Shift Sprints & Targets',
        dailyMissionsSub: 'Complete quick floor targets, earn bonus XP, and level up your retail rank',
        completeMission: 'Finish Mission',
        completedClaimed: 'Done & XP Claimed',
        recentBadgesTitle: 'Recent Floor Badges',
        recentBadgesSub: 'Mastery in phone features, billing speed, customer rapport, and team support',
        viewAllBadges: 'View All Badges',
        trainingCurriculum: 'Curriculum Progress',
        smartAiRec: 'Smart AI Recommendation',
        whyThis: 'Why this module?',
        peerRecSummary: 'Team Kudos Summary',
        received: 'Kudos Received',
        given: 'Kudos Sent',
        associateRole: 'Store Associate',
        managerRole: 'Store Manager',
        adminRole: 'Regional Admin',
        lightMode: 'Light Mode',
        darkMode: 'Dark Mode'
    }
};
function getTranslation(lang, key) {
    return TRANSLATIONS[lang]?.[key] || TRANSLATIONS.en[key] || key;
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__20-a5-3._.js.map