(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MainPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2f$useAppStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/store/useAppStore.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$LoginScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/LoginScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$Sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/Sidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$Topbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/Topbar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/Toast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$CelebrationModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/CelebrationModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$NotificationsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/NotificationsScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$SettingsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/SettingsScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$OfflineEdgeSyncConsole$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/OfflineEdgeSyncConsole.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$CustomerFeedbackLoop$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/CustomerFeedbackLoop.tsx [app-client] (ecmascript)");
// Employee Screens
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$EmployeeDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/EmployeeDashboard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$RewardsMarketplace$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/RewardsMarketplace.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$StoreMissions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/StoreMissions.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$MyImpactScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/MyImpactScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$CXChampionHub$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/CXChampionHub.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$AICoachScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/AICoachScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$VernacularDialectCoach$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/VernacularDialectCoach.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$SpacedRepetitionDrill$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/SpacedRepetitionDrill.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$VoiceToneAnalyzer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/VoiceToneAnalyzer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$AIRoleplayArena$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/AIRoleplayArena.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$XAICounterfactualScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/XAICounterfactualScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$VisualMerchandisingAuditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/VisualMerchandisingAuditor.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$POSSandboxArena$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/POSSandboxArena.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$TeamBattleArena$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/TeamBattleArena.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$LearningCenter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/LearningCenter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$ChallengesScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/ChallengesScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$LeaderboardScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/LeaderboardScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$RecognitionScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/RecognitionScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$AchievementsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/AchievementsScreen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$ProfileScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/employee/ProfileScreen.tsx [app-client] (ecmascript)");
// Manager Screens
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/ManagerDashboard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerActionCenter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/ManagerActionCenter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$FloorTwinHeatmap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/FloorTwinHeatmap.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerEmployees$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/ManagerEmployees.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerPerformance$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/ManagerPerformance.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerAIInsights$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/ManagerAIInsights.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$PredictiveCXForecast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/PredictiveCXForecast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$StoreAnalytics$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/StoreAnalytics.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$TrainingOverview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/manager/TrainingOverview.tsx [app-client] (ecmascript)");
// Admin Screens
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/admin/AdminDashboard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$TrainingCorrelationMatrix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/admin/TrainingCorrelationMatrix.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminEmployees$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/admin/AdminEmployees.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminStores$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/admin/AdminStores.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminChallenges$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/admin/AdminChallenges.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminAIStudio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/admin/AdminAIStudio.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminAnalytics$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/admin/AdminAnalytics.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AnnouncementComposer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/admin/AnnouncementComposer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$LearnathonStoryModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/LearnathonStoryModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function MainPage() {
    _s();
    const { role, screen, toast, celebration, isStoryModalOpen, setIsStoryModalOpen, theme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2f$useAppStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])();
    if (!role) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$LoginScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoginScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$LearnathonStoryModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LearnathonStoryModal"], {
                    isOpen: isStoryModalOpen,
                    onClose: ()=>setIsStoryModalOpen(false)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 67,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 65,
            columnNumber: 7
        }, this);
    }
    let content = null;
    /* ==================== ROLE 1: STORE ASSOCIATE ==================== */ if (role === 'employee') {
        switch(screen){
            case 'dashboard':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$EmployeeDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmployeeDashboard"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 78,
                    columnNumber: 19
                }, this);
                break;
            case 'rewards':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$RewardsMarketplace$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RewardsMarketplace"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 81,
                    columnNumber: 19
                }, this);
                break;
            case 'storeMissions':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$StoreMissions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreMissions"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 84,
                    columnNumber: 19
                }, this);
                break;
            case 'myImpact':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$MyImpactScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MyImpactScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 87,
                    columnNumber: 19
                }, this);
                break;
            case 'cxChampion':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$CXChampionHub$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CXChampionHub"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 90,
                    columnNumber: 19
                }, this);
                break;
            case 'csatLoop':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$CustomerFeedbackLoop$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomerFeedbackLoop"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 93,
                    columnNumber: 19
                }, this);
                break;
            case 'vernacularCoach':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$VernacularDialectCoach$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VernacularDialectCoach"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 96,
                    columnNumber: 19
                }, this);
                break;
            case 'spacedRepetition':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$SpacedRepetitionDrill$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpacedRepetitionDrill"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 99,
                    columnNumber: 19
                }, this);
                break;
            case 'voiceAnalyzer':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$VoiceToneAnalyzer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VoiceToneAnalyzer"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 102,
                    columnNumber: 19
                }, this);
                break;
            case 'offlineSync':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$OfflineEdgeSyncConsole$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OfflineEdgeSyncConsole"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 105,
                    columnNumber: 19
                }, this);
                break;
            case 'roleplayArena':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$AIRoleplayArena$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AIRoleplayArena"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 108,
                    columnNumber: 19
                }, this);
                break;
            case 'xaiCounterfactual':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$XAICounterfactualScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XAICounterfactualScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 111,
                    columnNumber: 19
                }, this);
                break;
            case 'vmAuditor':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$VisualMerchandisingAuditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisualMerchandisingAuditor"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 114,
                    columnNumber: 19
                }, this);
                break;
            case 'posSandbox':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$POSSandboxArena$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["POSSandboxArena"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 117,
                    columnNumber: 19
                }, this);
                break;
            case 'teamBattles':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$TeamBattleArena$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TeamBattleArena"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 120,
                    columnNumber: 19
                }, this);
                break;
            case 'aiCoach':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$AICoachScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AICoachScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 123,
                    columnNumber: 19
                }, this);
                break;
            case 'learning':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$LearningCenter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LearningCenter"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 126,
                    columnNumber: 19
                }, this);
                break;
            case 'challenges':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$ChallengesScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChallengesScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 129,
                    columnNumber: 19
                }, this);
                break;
            case 'leaderboard':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$LeaderboardScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeaderboardScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 132,
                    columnNumber: 19
                }, this);
                break;
            case 'recognition':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$RecognitionScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RecognitionScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 135,
                    columnNumber: 19
                }, this);
                break;
            case 'achievements':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$AchievementsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AchievementsScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 138,
                    columnNumber: 19
                }, this);
                break;
            case 'notifications':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$NotificationsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NotificationsScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 141,
                    columnNumber: 19
                }, this);
                break;
            case 'profile':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$ProfileScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 144,
                    columnNumber: 19
                }, this);
                break;
            default:
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$EmployeeDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmployeeDashboard"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 147,
                    columnNumber: 19
                }, this);
        }
    } else if (role === 'manager') {
        switch(screen){
            case 'dashboard':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ManagerDashboard"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 155,
                    columnNumber: 19
                }, this);
                break;
            case 'actionCenter':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerActionCenter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ManagerActionCenter"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 158,
                    columnNumber: 19
                }, this);
                break;
            case 'storeMissions':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$StoreMissions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreMissions"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 161,
                    columnNumber: 19
                }, this);
                break;
            case 'csatLoop':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$CustomerFeedbackLoop$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomerFeedbackLoop"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 164,
                    columnNumber: 19
                }, this);
                break;
            case 'floorTwin':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$FloorTwinHeatmap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloorTwinHeatmap"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 167,
                    columnNumber: 19
                }, this);
                break;
            case 'predictiveCX':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$PredictiveCXForecast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PredictiveCXForecast"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 170,
                    columnNumber: 19
                }, this);
                break;
            case 'aiInsights':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerAIInsights$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ManagerAIInsights"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 173,
                    columnNumber: 19
                }, this);
                break;
            case 'employees':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerEmployees$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ManagerEmployees"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 176,
                    columnNumber: 19
                }, this);
                break;
            case 'performance':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerPerformance$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ManagerPerformance"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 179,
                    columnNumber: 19
                }, this);
                break;
            case 'storeAnalytics':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$StoreAnalytics$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreAnalytics"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 182,
                    columnNumber: 19
                }, this);
                break;
            case 'offlineSync':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$OfflineEdgeSyncConsole$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OfflineEdgeSyncConsole"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 185,
                    columnNumber: 19
                }, this);
                break;
            case 'recognition':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$RecognitionScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RecognitionScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 188,
                    columnNumber: 19
                }, this);
                break;
            case 'training':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$TrainingOverview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TrainingOverview"], {
                    scopeFilter: "manager"
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 191,
                    columnNumber: 19
                }, this);
                break;
            case 'notifications':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$NotificationsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NotificationsScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 194,
                    columnNumber: 19
                }, this);
                break;
            case 'settings':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$SettingsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SettingsScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 197,
                    columnNumber: 19
                }, this);
                break;
            default:
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$ManagerDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ManagerDashboard"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 200,
                    columnNumber: 19
                }, this);
        }
    } else if (role === 'admin') {
        switch(screen){
            case 'dashboard':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminDashboard"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 208,
                    columnNumber: 19
                }, this);
                break;
            case 'correlationMatrix':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$TrainingCorrelationMatrix$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TrainingCorrelationMatrix"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 211,
                    columnNumber: 19
                }, this);
                break;
            case 'rewards':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$RewardsMarketplace$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RewardsMarketplace"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 214,
                    columnNumber: 19
                }, this);
                break;
            case 'csatLoop':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$CustomerFeedbackLoop$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomerFeedbackLoop"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 217,
                    columnNumber: 19
                }, this);
                break;
            case 'floorTwin':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$FloorTwinHeatmap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloorTwinHeatmap"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 220,
                    columnNumber: 19
                }, this);
                break;
            case 'aiStudio':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminAIStudio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminAIStudio"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 223,
                    columnNumber: 19
                }, this);
                break;
            case 'vernacularCoach':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$VernacularDialectCoach$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VernacularDialectCoach"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 226,
                    columnNumber: 19
                }, this);
                break;
            case 'roleplayArena':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$AIRoleplayArena$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AIRoleplayArena"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 229,
                    columnNumber: 19
                }, this);
                break;
            case 'vmAuditor':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$VisualMerchandisingAuditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisualMerchandisingAuditor"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 232,
                    columnNumber: 19
                }, this);
                break;
            case 'employees':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminEmployees$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminEmployees"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 235,
                    columnNumber: 19
                }, this);
                break;
            case 'stores':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminStores$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminStores"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 238,
                    columnNumber: 19
                }, this);
                break;
            case 'training':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$manager$2f$TrainingOverview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TrainingOverview"], {
                    title: "Curriculum & Module Completion",
                    subtitle: "Organization-wide completion rates across all 3,000 associates",
                    scopeFilter: "all"
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 242,
                    columnNumber: 11
                }, this);
                break;
            case 'challenges':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminChallenges$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminChallenges"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 250,
                    columnNumber: 19
                }, this);
                break;
            case 'analytics':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminAnalytics$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminAnalytics"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 253,
                    columnNumber: 19
                }, this);
                break;
            case 'offlineSync':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$OfflineEdgeSyncConsole$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OfflineEdgeSyncConsole"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 256,
                    columnNumber: 19
                }, this);
                break;
            case 'recognition':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$employee$2f$RecognitionScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RecognitionScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 259,
                    columnNumber: 19
                }, this);
                break;
            case 'notifications':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AnnouncementComposer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnnouncementComposer"], {}, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 264,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$NotificationsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NotificationsScreen"], {}, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 265,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 263,
                    columnNumber: 11
                }, this);
                break;
            case 'settings':
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$SettingsScreen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SettingsScreen"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 270,
                    columnNumber: 19
                }, this);
                break;
            default:
                content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$admin$2f$AdminDashboard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminDashboard"], {}, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 273,
                    columnNumber: 19
                }, this);
        }
    }
    const isDark = theme === 'dark';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `min-h-screen flex transition-colors duration-200 ${isDark ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$Sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sidebar"], {}, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 285,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 min-w-0 flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$Topbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Topbar"], {}, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 287,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                        className: "flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto",
                        children: content
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 288,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 286,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toast"], {
                toast: toast
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 291,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$CelebrationModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CelebrationModal"], {
                celebration: celebration
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 292,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$LearnathonStoryModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LearnathonStoryModal"], {
                isOpen: isStoryModalOpen,
                onClose: ()=>setIsStoryModalOpen(false)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 293,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 280,
        columnNumber: 5
    }, this);
}
_s(MainPage, "q0f2alL1lY3ROOKQXAMrJpUbEjM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2f$useAppStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"]
    ];
});
_c = MainPage;
var _c;
__turbopack_context__.k.register(_c, "MainPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/aiEngine.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SKILL_CATEGORY_MAP",
    ()=>SKILL_CATEGORY_MAP,
    "aiConfidence",
    ()=>aiConfidence,
    "computeSkillScores",
    ()=>computeSkillScores,
    "evaluateScenarioRubric",
    ()=>evaluateScenarioRubric,
    "generateAIQuiz",
    ()=>generateAIQuiz,
    "getExplainabilityFactors",
    ()=>getExplainabilityFactors,
    "getImpactLevel",
    ()=>getImpactLevel,
    "primarySkillGap",
    ()=>primarySkillGap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/cxCalculator.ts [app-client] (ecmascript)");
;
;
const SKILL_CATEGORY_MAP = {
    'Product Knowledge': 'Product Knowledge',
    'Customer Service': 'Customer Service',
    'Sales': 'Sales Skills',
    'POS': 'POS Training'
};
function computeSkillScores(emp, modules) {
    const productModules = modules.filter((m)=>m.category === 'Product Knowledge');
    const productDone = productModules.filter((m)=>emp.completedModules.includes(m.id)).length;
    const productPct = productModules.length ? Math.round(productDone / productModules.length * 100) : 0;
    return [
        {
            skill: 'Product Knowledge',
            score: Math.round(productPct * 0.55 + emp.engagementScore * 0.45)
        },
        {
            skill: 'Customer Service',
            score: emp.customerFeedbackScore
        },
        {
            skill: 'Sales',
            score: emp.salesConversion
        },
        {
            skill: 'POS',
            score: emp.posAdoption
        }
    ];
}
function primarySkillGap(emp, modules) {
    const scores = computeSkillScores(emp, modules);
    return scores.reduce((worst, current)=>current.score < worst.score ? current : worst, scores[0]);
}
function aiConfidence(emp, gapScore) {
    const seed = emp.id.split('').reduce((a, c)=>a + c.charCodeAt(0), 0);
    return Math.min(97, Math.max(72, 96 - Math.round(gapScore / 6) + seed % 5));
}
function getImpactLevel(value, { high = 60, medium = 75 } = {}) {
    if (value < high) return {
        label: 'High',
        dot: '🔴',
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].coral
    };
    if (value < medium) return {
        label: 'Medium',
        dot: '🟡',
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].amberDeep
    };
    return {
        label: 'Low',
        dot: '🟢',
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].teal
    };
}
function getExplainabilityFactors(emp, storeAvgPos, modules) {
    const gap = primarySkillGap(emp, modules);
    const posGapPct = Math.max(0, storeAvgPos - emp.posAdoption);
    return [
        {
            label: 'Digital POS usage',
            value: `${emp.posAdoption}%`,
            impact: getImpactLevel(gap.skill === 'POS' ? emp.posAdoption : 80)
        },
        {
            label: 'Micro-training completion',
            value: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trainingPct"])(emp, modules)}%`,
            impact: getImpactLevel((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trainingPct"])(emp, modules), {
                high: 55,
                medium: 75
            })
        },
        {
            label: 'Customer CSAT feedback',
            value: `${emp.customerFeedbackScore}%`,
            impact: getImpactLevel(emp.customerFeedbackScore, {
                high: 65,
                medium: 82
            })
        },
        {
            label: 'Store peer average comparison',
            value: `${storeAvgPos}%`,
            impact: getImpactLevel(100 - posGapPct, {
                high: 80,
                medium: 92
            })
        }
    ];
}
function generateAIQuiz(params) {
    const { product, skill, difficulty, numQuestions, scenarioBased, language, timeLimit } = params;
    const questions = [];
    const reward = difficulty === 'Hard' ? 200 : difficulty === 'Medium' ? 150 : 100;
    const baseCount = scenarioBased ? Math.max(1, numQuestions - 1) : numQuestions;
    for(let i = 1; i <= baseCount; i++){
        questions.push({
            id: `q-gen-${Date.now()}-${i}`,
            type: 'MCQ',
            difficulty,
            prompt: `Which approach best reflects optimal ${skill.toLowerCase()} standards when handling "${product}"?`,
            options: [
                `Follow standard ${skill.toLowerCase()} retail guidelines tailored for ${product}`,
                `Skip customer consultation if the floor rush is heavy`,
                `Improvise pricing without verifying on the POS scanner`,
                `Direct the shopper to check the competitor website`
            ],
            correct: 0
        });
    }
    if (scenarioBased) {
        questions.push({
            id: `q-gen-${Date.now()}-scenario`,
            type: 'Scenario-based',
            difficulty,
            prompt: `Roleplay Scenario: A customer walks into the store looking for "${product}" for an upcoming family celebration. They express budget doubts. What is the recommended consultative response?`,
            options: [
                `Ask clarifying questions regarding their preference, highlight product value & mention available store combo offers`,
                `Insist on selling the highest-priced alternative immediately`,
                `Tell them you cannot assist until they decide their budget`,
                `Walk away to restock adjacent shelves`
            ],
            correct: 0
        });
    }
    return {
        id: `quiz-draft-${Date.now()}`,
        product,
        skill,
        difficulty,
        language,
        timeLimit,
        questions: questions.slice(0, numQuestions),
        challengeTitle: `Recommend the right ${product} to 3 simulated customers with 0 errors`,
        rewardPoints: reward,
        createdAt: new Date().toISOString()
    };
}
function evaluateScenarioRubric(difficulty) {
    const base = difficulty === 'Hard' ? 82 : difficulty === 'Medium' ? 88 : 94;
    const rubric = [
        {
            label: 'Empathy & Rapport',
            score: Math.min(100, base + 4)
        },
        {
            label: 'Policy Adherence',
            score: Math.min(100, base - 5)
        },
        {
            label: 'Clear Communication',
            score: Math.min(100, base + 2)
        },
        {
            label: 'Problem Resolution',
            score: Math.min(100, base - 1)
        }
    ];
    const overall = Math.round(rubric.reduce((a, r)=>a + r.score, 0) / rubric.length);
    return {
        rubric,
        overall,
        feedback: 'High empathy and clear tone observed. Ensure store return policy terms are mentioned before initiating warranty replacement.'
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/aiRoleplayEngine.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CUSTOMER_PERSONAS",
    ()=>CUSTOMER_PERSONAS,
    "evaluateRoleplaySession",
    ()=>evaluateRoleplaySession,
    "simulateCustomerTurn",
    ()=>simulateCustomerTurn
]);
const CUSTOMER_PERSONAS = [
    {
        id: 'p1',
        name: 'Ramesh Gupta',
        role: 'Festive Shopper (Aggressive Haggler)',
        temperament: 'Aggressive',
        avatar: '👨‍💼',
        scenario: 'Comparing Store Prices with Online E-Commerce Discounts',
        initialPrompt: 'Look, Amazon is offering this same Kurta Set for ₹1,299 with free delivery. Your shelf price tag says ₹1,799! Give me a flat 25% store manager discount or I am ordering it online right now.',
        idealKeywords: [
            'fabric quality',
            'instant trial',
            'festive combo',
            'loyalty points',
            'store warranty',
            'in-store customization'
        ],
        objectionType: 'Price Comparison'
    },
    {
        id: 'p2',
        name: 'Sunita Sharma',
        role: 'Disgruntled Customer (Lost Receipt)',
        temperament: 'Frustrated',
        avatar: '👩‍🦳',
        scenario: 'Demanding Return Without Physical Paper Receipt',
        initialPrompt: 'I bought this festive lamp yesterday and it doesn’t fit my living room table! I lost the paper bill in the cab, and your cashier said no returns without a receipt! This is unacceptable customer service!',
        idealKeywords: [
            'registered phone number',
            'omnichannel lookup',
            'instant exchange',
            'store credit',
            'apologize',
            'digital invoice'
        ],
        objectionType: 'Return Without Bill'
    },
    {
        id: 'p3',
        name: 'Vikram Mehta',
        role: 'Corporate Commuter (Time Crunch)',
        temperament: 'Rushed',
        avatar: '👨‍💻',
        scenario: 'Rush Hour Checkout with Split Tender UPI + Gift Card',
        initialPrompt: 'I have a train departing in 10 minutes! I want to pay ₹400 using my QuestFloor Gift Card and the remaining ₹850 via UPI QR code. Make sure you don’t double charge me!',
        idealKeywords: [
            'split payment',
            'gift card balance verify',
            'instant qr',
            'fast scan',
            'express checkout'
        ],
        objectionType: 'Time Crunch'
    },
    {
        id: 'p4',
        name: 'Anjali Verma',
        role: 'First-time Festive Buyer (Indecisive)',
        temperament: 'Hesitant',
        avatar: '🥻',
        scenario: 'Unsure about Gifting Budget & Hamper Combinations',
        initialPrompt: 'I need to gift 4 family hampers under ₹2,000 total. I am completely confused between brass diyas, sweet boxes, and lighting. Everything looks overwhelming.',
        idealKeywords: [
            'customization',
            'under ₹499 combo',
            'complimentary gift packaging',
            'rule of three',
            'personalized recommendation'
        ],
        objectionType: 'Product Confusion'
    }
];
function simulateCustomerTurn(persona, conversationHistory, associateResponse) {
    const text = associateResponse.toLowerCase();
    // Check matching keywords
    const matchedKeywords = persona.idealKeywords.filter((kw)=>text.includes(kw.toLowerCase()));
    if (persona.id === 'p1') {
        if (matchedKeywords.length >= 2 || text.includes('trial') || text.includes('combo') || text.includes('loyalty')) {
            return {
                customerReply: 'Hmm, that is a fair point. If you can customize the packaging and apply the Gold Club 5% discount at the POS right now, I’ll take it.',
                sentiment: 'positive'
            };
        } else if (text.includes('policy') || text.includes('cannot') || text.includes('fixed price')) {
            return {
                customerReply: 'Just quoting store policy is unhelpful. Why should I pay more here if you won’t explain the value?',
                sentiment: 'negative'
            };
        } else {
            return {
                customerReply: 'I see. Can you show me the size chart and confirm if I can exchange it if my family doesn’t like the fit?',
                sentiment: 'neutral'
            };
        }
    }
    if (persona.id === 'p2') {
        if (matchedKeywords.length >= 1 || text.includes('phone') || text.includes('mobile') || text.includes('look up') || text.includes('help')) {
            return {
                customerReply: 'Oh, you can look it up with my phone number? Thank you, my registered mobile number is 98230-44912. Please see if we can exchange it for the brass diya set.',
                sentiment: 'positive'
            };
        } else {
            return {
                customerReply: 'Stop telling me about company rules! I want a manager right now!',
                sentiment: 'negative'
            };
        }
    }
    if (persona.id === 'p3') {
        if (text.includes('gift card') || text.includes('qr') || text.includes('split') || text.includes('done') || text.includes('seconds')) {
            return {
                customerReply: 'Awesome, scanned the QR! Received the e-receipt on SMS. That was super fast, thank you!',
                sentiment: 'positive'
            };
        } else {
            return {
                customerReply: 'Please hurry up, my cab is waiting outside!',
                sentiment: 'neutral'
            };
        }
    }
    // Persona 4
    if (matchedKeywords.length >= 1 || text.includes('499') || text.includes('pack') || text.includes('diya') || text.includes('recommend')) {
        return {
            customerReply: 'The ₹499 diya and lantern combo sounds wonderful and perfectly within my ₹2,000 budget for 4 gifts! Could you please pack them in festive gift boxes?',
            sentiment: 'positive'
        };
    }
    return {
        customerReply: 'Could you give me one concrete suggestion that fits my price range?',
        sentiment: 'neutral'
    };
}
function evaluateRoleplaySession(persona, conversationHistory) {
    const associateMessages = conversationHistory.filter((m)=>m.sender === 'associate').map((m)=>m.text.toLowerCase());
    const combined = associateMessages.join(' ');
    let empathyScore = 75;
    let policyScore = 70;
    let upsellScore = 65;
    persona.idealKeywords.forEach((kw)=>{
        if (combined.includes(kw.toLowerCase())) {
            empathyScore += 7;
            policyScore += 8;
            upsellScore += 6;
        }
    });
    if (combined.includes('sorry') || combined.includes('understand') || combined.includes('glad to help') || combined.includes('happy to assist')) {
        empathyScore += 10;
    }
    if (combined.includes('pos') || combined.includes('phone number') || combined.includes('bill') || combined.includes('discount')) {
        policyScore += 8;
    }
    if (combined.includes('combo') || combined.includes('recommend') || combined.includes('pairing') || combined.includes('gift')) {
        upsellScore += 12;
    }
    empathyScore = Math.min(98, Math.max(60, empathyScore));
    policyScore = Math.min(98, Math.max(60, policyScore));
    upsellScore = Math.min(98, Math.max(55, upsellScore));
    const overall = Math.round(empathyScore * 0.35 + policyScore * 0.35 + upsellScore * 0.30);
    const xpEarned = overall >= 85 ? 150 : overall >= 70 ? 100 : 60;
    let feedback = 'Good consultative listening and prompt responses.';
    let suggested = 'Remember to proactively offer phone number lookup or explain value-add customization.';
    if (persona.id === 'p1') {
        suggested = '“I completely understand! While online shipping takes 3-4 days, here you get instant fabric trial, free custom gift packing, and our 100% verified in-store exchange guarantee.”';
        feedback = 'Strong value framing against online discount pressure.';
    } else if (persona.id === 'p2') {
        suggested = '“I sincerely apologize for the inconvenience! Don’t worry at all — I can instantly retrieve your digital bill using your registered mobile number.”';
        feedback = 'De-escalated customer anger by removing friction.';
    }
    return {
        empathyScore,
        policyScore,
        upsellScore,
        overallScore: overall,
        feedback,
        suggestedResponse: suggested,
        xpEarned
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "api",
    ()=>api
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * QuestFloor / RetailRise API Client
 * Seamlessly interfaces React frontend with Python FastAPI Backend (http://localhost:8000/api)
 * with robust local fallback for ultra-smooth presentation.
 */ const API_BASE = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';
async function fetchJSON(endpoint, options) {
    try {
        const res = await fetch(`${API_BASE}${endpoint}`, {
            headers: {
                'Content-Type': 'application/json',
                ...options?.headers
            },
            ...options
        });
        if (!res.ok) {
            console.warn(`API call to ${endpoint} failed with status:`, res.status);
            return null;
        }
        return await res.json();
    } catch (err) {
        console.warn(`Backend connection to ${endpoint} unavailable, using intelligent local engine:`, err);
        return null;
    }
}
const api = {
    // Health & Personas
    async getHealth () {
        return fetchJSON('/health');
    },
    async getPersonas () {
        return fetchJSON('/auth/personas');
    },
    // Employees & Gamification
    async getEmployee (id) {
        return fetchJSON(`/employees/${id}`);
    },
    async addXP (employeeId, xpAmount, reason, badgeToUnlock) {
        return fetchJSON(`/employees/${employeeId}/add-xp`, {
            method: 'POST',
            body: JSON.stringify({
                xp_amount: xpAmount,
                reason,
                badge_to_unlock: badgeToUnlock
            })
        });
    },
    async getLeaderboard (scope = 'store', storeId = 's104') {
        return fetchJSON(`/employees/leaderboard/top?scope=${scope}&store_id=${storeId}`);
    },
    async getNotifications (employeeId) {
        return fetchJSON(`/employees/${employeeId}/notifications`);
    },
    // Learning & Quizzes
    async getModules () {
        return fetchJSON('/learning/modules');
    },
    async submitQuiz (employeeId, moduleId, selectedAnswers) {
        return fetchJSON('/learning/quiz/submit', {
            method: 'POST',
            body: JSON.stringify({
                employee_id: employeeId,
                module_id: moduleId,
                selected_answers: selectedAnswers
            })
        });
    },
    async getChallenges () {
        return fetchJSON('/learning/challenges/active');
    },
    // POS Sandbox & Speed Billing
    async getPOSCatalog () {
        return fetchJSON('/pos/catalog');
    },
    async processPOSCheckout (payload) {
        return fetchJSON('/pos/checkout', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    },
    // Peer Recognition
    async getRecognitionFeed () {
        return fetchJSON('/recognition/feed');
    },
    async sendRecognition (payload) {
        return fetchJSON('/recognition/send', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    },
    async likeRecognition (recognitionId) {
        return fetchJSON(`/recognition/${recognitionId}/like`, {
            method: 'POST'
        });
    },
    // Manager & Analytics
    async getStoreDashboard (storeId = 's104') {
        return fetchJSON(`/manager/store/${storeId}`);
    },
    async getMultiStoreOverview () {
        return fetchJSON('/manager/multi-store-overview');
    },
    async assignNudge (storeId, employeeId, challengeTitle) {
        return fetchJSON(`/manager/store/${storeId}/assign-nudge`, {
            method: 'POST',
            body: JSON.stringify({
                employee_id: employeeId,
                challenge_title: challengeTitle
            })
        });
    },
    // LLM Features
    async roleplayTurn (payload) {
        return fetchJSON('/llm/roleplay/turn', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    },
    async evaluateRoleplay (payload) {
        return fetchJSON('/llm/roleplay/evaluate', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    },
    async askCopilot (query, employeeId = 'e-amit', contextType = 'general') {
        return fetchJSON('/llm/copilot', {
            method: 'POST',
            body: JSON.stringify({
                query,
                employee_id: employeeId,
                context_type: contextType
            })
        });
    },
    async polishKudos (rawNotes, receiverName, senderName, helpContext) {
        return fetchJSON('/llm/polish-kudos', {
            method: 'POST',
            body: JSON.stringify({
                raw_notes: rawNotes,
                receiver_name: receiverName,
                sender_name: senderName,
                help_context: helpContext
            })
        });
    },
    async generateLesson (topic, targetRole = 'Store Associate', storeTier = 'Tier-3 Retail Hub') {
        return fetchJSON('/llm/generate-lesson', {
            method: 'POST',
            body: JSON.stringify({
                topic,
                target_role: targetRole,
                store_tier: storeTier
            })
        });
    },
    async generateManagerInsights (storeId = 's104', metrics) {
        return fetchJSON('/llm/manager-insights', {
            method: 'POST',
            body: JSON.stringify({
                store_id: storeId,
                metrics
            })
        });
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/bhashaEngine.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BHASHA_SCENARIOS",
    ()=>BHASHA_SCENARIOS,
    "evaluateVernacularResponse",
    ()=>evaluateVernacularResponse
]);
const BHASHA_SCENARIOS = [
    {
        id: 'bh-hinglish',
        language: 'Hinglish',
        nativeTitle: 'Hinglish Festive Rush & Sizing',
        customerQuery: '“Bhaiya, ye Kurta set bahut sundar hai but thoda loose lag raha hai. Kya iska Medium size trial room me mil sakta hai? Also online 10% sasta mil raha hai.”',
        phoneticAudioText: 'Bhaiya, ye Kurta set bahut sundar hai but thoda loose lag raha hai...',
        englishMeaning: '“Brother, this Kurta set looks beautiful but feels a bit loose. Can I get a Medium size in the trial room? Also it is 10% cheaper online.”',
        keyPolitenessTokens: [
            'ji',
            'bilkul',
            'aaiye sir',
            'trial room',
            'instant exchange',
            'quality warranty'
        ],
        idealPitch: '“Ji bilkul sir! Main abhi aapke liye Medium size trial room me arrange kar deta hoon. Store me aapko instant fit trial aur 100% genuine warranty milti hai jo online me possible nahi.”',
        context: 'Fast-paced metro / Tier-2 mixed language interaction with price comparison.'
    },
    {
        id: 'bh-hindi',
        language: 'Hindi',
        nativeTitle: 'शुद्ध हिंदी: पूजा दीया व उपहार कॉम्बो',
        customerQuery: '“नमस्ते जी! क्या यह पीतल का दीया और लालटेन सेट दिवाली पूजा के लिए उपयुक्त है? क्या आप इसमें विशेष उपहार पैकिंग कर देंगे?”',
        phoneticAudioText: 'Namaste ji! Kya yeh peetal ka diya set Diwali puja ke liye...',
        englishMeaning: '“Namaste! Is this brass diya and lantern set suitable for Diwali puja? Will you provide special gift packaging for it?”',
        keyPolitenessTokens: [
            'नमस्ते',
            'जी',
            'अवश्य',
            'उपहार',
            'पूजा',
            'निःशुल्क'
        ],
        idealPitch: '“नमस्ते जी! यह विशुद्ध पीतल का बना है और पूजा के लिए अत्यंत शुभ है। हमारे पास इसके साथ निःशुल्क उपहार पैकिंग की सुविधा भी उपलब्ध है।”',
        context: 'Traditional festive shopper looking for respectful cultural tone and free gift packing.'
    },
    {
        id: 'bh-marathi',
        language: 'Marathi',
        nativeTitle: 'मराठी: सणासुदीचे कॉम्बो व बजेट',
        customerQuery: '“नमस्कार, मला कुटुंबासाठी 4 भेटवस्तूंचे बॉक्सेस हवे आहेत. 2000 रुपयांच्या बजेटमध्ये तुमच्याकडे कोणता उत्तम कॉम्बो उपलब्ध आहे?”',
        phoneticAudioText: 'Namaskar, mala kutumbasathi 4 bhetvastunche boxes have aahet...',
        englishMeaning: '“Hello, I need 4 gift boxes for my family. What is the best combo available within a ₹2,000 budget?”',
        keyPolitenessTokens: [
            'नमस्कार',
            'नक्कीच',
            'उत्तम',
            'कॉम्बो',
            'पॅकिंग',
            'धन्यवाद'
        ],
        idealPitch: '“नमस्कार सर! आमच्याकडे 499 रुपयांचा खास पितळी दिवा आणि कंदील कॉम्बो आहे. 2000 रुपयांत चारही बॉक्सेस मोफत गिफ्ट पॅकिंगसह तयार होतील!”',
        context: 'Nagpur / Pune regional customer looking for polite Marathi greeting and exact budget fit.'
    },
    {
        id: 'bh-tamil',
        language: 'Tamil',
        nativeTitle: 'தமிழ்: பண்டிகை காம்போ & விரைவு பில்லிங்',
        customerQuery: '“வணக்கம் (Vanakkam)! Indha festive saree-kku matching stole irukka? Innum 10 mins-la train irukku, UPI QR-la fast-ah bill panna mudiyuma?”',
        phoneticAudioText: 'Vanakkam! Indha festive saree-kku matching stole irukka?...',
        englishMeaning: '“Greetings! Do you have a matching stole for this saree? I have a train in 10 mins, can you bill fast via UPI QR?”',
        keyPolitenessTokens: [
            'vanakkam',
            'kandippa',
            'matching',
            'instant upi',
            'nandri'
        ],
        idealPitch: '“Vanakkam madam! Kandippa irukku, idho matching silk stole. Namma POS terminal-la 30 seconds-la UPI QR scan panni express checkout mudichidalaam!”',
        context: 'Coimbatore / Chennai express customer needing warm Vanakkam and fast digital checkout.'
    },
    {
        id: 'bh-telugu',
        language: 'Telugu',
        nativeTitle: 'తెలుగు: పండుగ బహుమతి & కాంబో ఆఫర్లు',
        customerQuery: '“నమస్కారం (Namaskaram)! Ee festive hamper lo customized sweet box add cheyyocha? Gift card payment accept chesthara?”',
        phoneticAudioText: 'Namaskaram! Ee festive hamper lo customized sweet box...',
        englishMeaning: '“Greetings! Can I add a customized sweet box to this festive hamper? Do you accept gift card payment?”',
        keyPolitenessTokens: [
            'namaskaram',
            'tappakunda',
            'customization',
            'gift card',
            'dhanyavadalu'
        ],
        idealPitch: '“Namaskaram sir! Tappakunda, meeku istamaina sweets add chesi customized packing chestham. Mana POS lo Gift Card + UPI split payment easy ga avuthundi!”',
        context: 'Hyderabad / Tier-3 AP/Telangana festive shopper requiring polite Telugu consultation.'
    }
];
function evaluateVernacularResponse(scenario, associatePitch) {
    const text = associatePitch.toLowerCase();
    let politenessScore = 70;
    let clarityScore = 75;
    let translationAccuracy = 80;
    // Check politeness tokens
    let matchedTokens = 0;
    scenario.keyPolitenessTokens.forEach((token)=>{
        if (text.includes(token.toLowerCase())) {
            matchedTokens++;
            politenessScore += 7;
            clarityScore += 5;
        }
    });
    if (text.includes('ji') || text.includes('sir') || text.includes('madam') || text.includes('namaste') || text.includes('namaskar') || text.includes('vanakkam')) {
        politenessScore += 8;
    }
    if (text.includes('499') || text.includes('packing') || text.includes('upi') || text.includes('trial') || text.includes('warranty') || text.includes('pos')) {
        translationAccuracy += 10;
    }
    politenessScore = Math.min(99, Math.max(65, politenessScore));
    clarityScore = Math.min(98, Math.max(70, clarityScore));
    translationAccuracy = Math.min(100, Math.max(72, translationAccuracy));
    const bonusXP = politenessScore >= 85 ? 120 : 80;
    let etiquetteFeedback = 'Great conversational flow and respectful greeting.';
    if (matchedTokens < 2) {
        etiquetteFeedback = `Add traditional local greetings (e.g. "${scenario.keyPolitenessTokens[0]}") to establish immediate cultural warmth with the shopper.`;
    }
    return {
        politenessScore,
        clarityScore,
        translationAccuracy,
        culturalEtiquetteFeedback: etiquetteFeedback,
        suggestedVernacularPitch: scenario.idealPitch,
        bonusXP
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/spacedRepetitionEngine.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "INITIAL_MEMORY_NODES",
    ()=>INITIAL_MEMORY_NODES,
    "NEURO_DRILL_QUESTIONS",
    ()=>NEURO_DRILL_QUESTIONS
]);
const INITIAL_MEMORY_NODES = [
    {
        id: 'mem-1',
        topic: 'Diya & Lantern Combo Price Point',
        category: 'Product Knowledge',
        retentionPct: 48,
        daysSinceReview: 5,
        decayStatus: 'Decaying Critical',
        decayRiskReason: 'Unreviewed for 5 days. Risk of misquoting impulse checkout price to shoppers.'
    },
    {
        id: 'mem-2',
        topic: 'Phone Number Bill Retrieval Policy',
        category: 'POS & Returns',
        retentionPct: 56,
        daysSinceReview: 4,
        decayStatus: 'At Risk',
        decayRiskReason: 'Associates tend to ask for paper bills when digital lookup is available.'
    },
    {
        id: 'mem-3',
        topic: 'Rule of Three Visual Display Grouping',
        category: 'Visual Merchandising',
        retentionPct: 82,
        daysSinceReview: 1,
        decayStatus: 'Optimal',
        decayRiskReason: 'Recent training completed. Retaining core display principles.'
    },
    {
        id: 'mem-4',
        topic: 'Gold Club 5% Instant Festive Discount',
        category: 'Promotions',
        retentionPct: 52,
        daysSinceReview: 6,
        decayStatus: 'At Risk',
        decayRiskReason: 'Risk of forgetting to trigger extra 5% voucher at checkout.'
    },
    {
        id: 'mem-5',
        topic: 'Terminal Lockout (Ctrl+L) Safety Protocol',
        category: 'Data Security',
        retentionPct: 91,
        daysSinceReview: 1,
        decayStatus: 'Optimal',
        decayRiskReason: 'Strong adherence to POS terminal screen locking standards.'
    }
];
const NEURO_DRILL_QUESTIONS = [
    {
        id: 'nd-1',
        topicId: 'mem-1',
        prompt: '⚡ Quick 15s Recall: What is the exact price ceiling for the festive diya & lantern impulse combo?',
        options: [
            '₹299',
            '₹499',
            '₹799',
            '₹1,299'
        ],
        correct: 1,
        quickFact: '₹499 is the optimal impulse threshold for festive shopper conversion.'
    },
    {
        id: 'nd-2',
        topicId: 'mem-2',
        prompt: '⚡ Quick 15s Recall: If a customer lost their paper receipt, what is the fastest way to look up their purchase history on POS?',
        options: [
            'Ask for bank statement',
            'Search by registered mobile phone number',
            'Call regional manager',
            'Refuse return'
        ],
        correct: 1,
        quickFact: 'All purchases across 1,200 stores are indexed by registered mobile number.'
    },
    {
        id: 'nd-3',
        topicId: 'mem-4',
        prompt: '⚡ Quick 15s Recall: What extra discount percentage do Gold Club loyalty members receive on festive items?',
        options: [
            '2%',
            '5% instant discount',
            '15%',
            '25%'
        ],
        correct: 1,
        quickFact: 'Gold Club members receive 5% extra discount automatically applied at billing.'
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/xaiEngine.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGlassboxAttributions",
    ()=>getGlassboxAttributions,
    "simulateCounterfactual",
    ()=>simulateCounterfactual
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/cxCalculator.ts [app-client] (ecmascript)");
;
function getGlassboxAttributions(emp, modules) {
    const trnPct = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trainingPct"])(emp, modules);
    return [
        {
            feature: 'Digital POS Floor Adoption',
            weightPct: 25,
            currentValue: `${emp.posAdoption}%`,
            impactDirection: emp.posAdoption >= 75 ? 'positive' : emp.posAdoption >= 60 ? 'neutral' : 'negative',
            explanation: emp.posAdoption >= 75 ? 'Fast barcode scan rate eliminates pricing mismatches and billing queues.' : 'Low digital terminal usage creates inventory sync delays and checkout friction.'
        },
        {
            feature: 'Micro-Curriculum Mastery',
            weightPct: 20,
            currentValue: `${trnPct}% (${emp.completedModules.length}/${modules.length})`,
            impactDirection: trnPct >= 70 ? 'positive' : 'negative',
            explanation: 'Quiz scores demonstrate consistent festive catalog and return policy knowledge.'
        },
        {
            feature: 'Shopper CSAT & Sentiment',
            weightPct: 25,
            currentValue: `${emp.customerFeedbackScore}% 5-Star`,
            impactDirection: emp.customerFeedbackScore >= 80 ? 'positive' : 'neutral',
            explanation: 'Direct post-checkout customer survey ratings logged on digital receipts.'
        },
        {
            feature: 'Consultative Sales Conversion',
            weightPct: 15,
            currentValue: `${emp.salesConversion}% Basket Lift`,
            impactDirection: emp.salesConversion >= 70 ? 'positive' : 'neutral',
            explanation: 'Frequency of recommending relevant add-ons (cufflinks, dupatta, diya combos).'
        },
        {
            feature: 'Associate Morale & Recognition',
            weightPct: 15,
            currentValue: `${emp.engagementScore}% Morale`,
            impactDirection: emp.engagementScore >= 80 ? 'positive' : 'neutral',
            explanation: 'Peer recognition volume, attendance consistency, and daily challenge streaks.'
        }
    ];
}
function simulateCounterfactual(currentEmp, allEmployees, totalModules, params) {
    const simulatedTrainingPct = Math.round(params.completedModulesCount / totalModules * 100);
    // Compute simulated CX for this employee
    const currentEmpCX = Math.round((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trainingPct"])(currentEmp) * 0.20 + currentEmp.posAdoption * 0.25 + currentEmp.customerFeedbackScore * 0.25 + currentEmp.salesConversion * 0.15 + currentEmp.engagementScore * 0.15);
    const simulatedEmpCX = Math.round(simulatedTrainingPct * 0.20 + params.posAdoption * 0.25 + params.csatScore * 0.25 + params.upsellConversion * 0.15 + currentEmp.engagementScore * 0.15);
    const cxDelta = simulatedEmpCX - currentEmpCX;
    // Projected Points from new modules and POS milestones
    const extraPoints = (params.completedModulesCount - currentEmp.completedModules.length) * 100 + (params.posAdoption > currentEmp.posAdoption ? Math.round((params.posAdoption - currentEmp.posAdoption) * 4) : 0);
    const simulatedPoints = currentEmp.points + Math.max(0, extraPoints);
    // Re-calculate Leaderboard Rank
    const simulatedList = allEmployees.map((e)=>e.id === currentEmp.id ? {
            ...e,
            points: simulatedPoints
        } : e);
    simulatedList.sort((a, b)=>b.points - a.points);
    const projectedRank = simulatedList.findIndex((e)=>e.id === currentEmp.id) + 1;
    // ETA to next level
    const pointsNeeded = Math.max(0, 1600 - simulatedPoints);
    const daysToNextLevel = pointsNeeded === 0 ? 0 : Math.max(1, Math.ceil(pointsNeeded / 45));
    // Store Revenue Lift
    const storeRevenueLiftPct = +((params.posAdoption - currentEmp.posAdoption) * 0.08 + (params.upsellConversion - currentEmp.salesConversion) * 0.14).toFixed(1);
    const unlockedBadgesCount = Math.min(8, currentEmp.badges.length + (params.posAdoption >= 90 ? 1 : 0) + (params.completedModulesCount >= 8 ? 1 : 0));
    return {
        simulatedCX: simulatedEmpCX,
        cxDelta,
        projectedRank,
        daysToNextLevel,
        unlockedBadgesCount,
        storeRevenueLiftPct: Math.max(0, storeRevenueLiftPct)
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_03s1s2l._.js.map