(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/canvas-confetti/dist/confetti.module.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "create",
    ()=>create,
    "default",
    ()=>__TURBOPACK__default__export__
]);
// canvas-confetti v1.9.4 built on 2025-10-25T05:14:56.640Z
var module = {};
// source content
/* globals Map */ (function main(global, module, isWorker, workerSize) {
    var canUseWorker = !!(global.Worker && global.Blob && global.Promise && global.OffscreenCanvas && global.OffscreenCanvasRenderingContext2D && global.HTMLCanvasElement && global.HTMLCanvasElement.prototype.transferControlToOffscreen && global.URL && global.URL.createObjectURL);
    var canUsePaths = typeof Path2D === 'function' && typeof DOMMatrix === 'function';
    var canDrawBitmap = function() {
        // this mostly supports ssr
        if (!global.OffscreenCanvas) {
            return false;
        }
        try {
            var canvas = new OffscreenCanvas(1, 1);
            var ctx = canvas.getContext('2d');
            ctx.fillRect(0, 0, 1, 1);
            var bitmap = canvas.transferToImageBitmap();
            ctx.createPattern(bitmap, 'no-repeat');
        } catch (e) {
            return false;
        }
        return true;
    }();
    function noop() {}
    // create a promise if it exists, otherwise, just
    // call the function directly
    function promise(func) {
        var ModulePromise = module.exports.Promise;
        var Prom = ModulePromise !== void 0 ? ModulePromise : global.Promise;
        if (typeof Prom === 'function') {
            return new Prom(func);
        }
        func(noop, noop);
        return null;
    }
    var bitmapMapper = function(skipTransform, map) {
        // see https://github.com/catdad/canvas-confetti/issues/209
        // creating canvases is actually pretty expensive, so we should create a
        // 1:1 map for bitmap:canvas, so that we can animate the confetti in
        // a performant manner, but also not store them forever so that we don't
        // have a memory leak
        return {
            transform: function(bitmap) {
                if (skipTransform) {
                    return bitmap;
                }
                if (map.has(bitmap)) {
                    return map.get(bitmap);
                }
                var canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
                var ctx = canvas.getContext('2d');
                ctx.drawImage(bitmap, 0, 0);
                map.set(bitmap, canvas);
                return canvas;
            },
            clear: function() {
                map.clear();
            }
        };
    }(canDrawBitmap, new Map());
    var raf = function() {
        var TIME = Math.floor(1000 / 60);
        var frame, cancel;
        var frames = {};
        var lastFrameTime = 0;
        if (typeof requestAnimationFrame === 'function' && typeof cancelAnimationFrame === 'function') {
            frame = function(cb) {
                var id = Math.random();
                frames[id] = requestAnimationFrame(function onFrame(time) {
                    if (lastFrameTime === time || lastFrameTime + TIME - 1 < time) {
                        lastFrameTime = time;
                        delete frames[id];
                        cb();
                    } else {
                        frames[id] = requestAnimationFrame(onFrame);
                    }
                });
                return id;
            };
            cancel = function(id) {
                if (frames[id]) {
                    cancelAnimationFrame(frames[id]);
                }
            };
        } else {
            frame = function(cb) {
                return setTimeout(cb, TIME);
            };
            cancel = function(timer) {
                return clearTimeout(timer);
            };
        }
        return {
            frame: frame,
            cancel: cancel
        };
    }();
    var getWorker = function() {
        var worker;
        var prom;
        var resolves = {};
        function decorate(worker) {
            function execute(options, callback) {
                worker.postMessage({
                    options: options || {},
                    callback: callback
                });
            }
            worker.init = function initWorker(canvas) {
                var offscreen = canvas.transferControlToOffscreen();
                worker.postMessage({
                    canvas: offscreen
                }, [
                    offscreen
                ]);
            };
            worker.fire = function fireWorker(options, size, done) {
                if (prom) {
                    execute(options, null);
                    return prom;
                }
                var id = Math.random().toString(36).slice(2);
                prom = promise(function(resolve) {
                    function workerDone(msg) {
                        if (msg.data.callback !== id) {
                            return;
                        }
                        delete resolves[id];
                        worker.removeEventListener('message', workerDone);
                        prom = null;
                        bitmapMapper.clear();
                        done();
                        resolve();
                    }
                    worker.addEventListener('message', workerDone);
                    execute(options, id);
                    resolves[id] = workerDone.bind(null, {
                        data: {
                            callback: id
                        }
                    });
                });
                return prom;
            };
            worker.reset = function resetWorker() {
                worker.postMessage({
                    reset: true
                });
                for(var id in resolves){
                    resolves[id]();
                    delete resolves[id];
                }
            };
        }
        return function() {
            if (worker) {
                return worker;
            }
            if (!isWorker && canUseWorker) {
                var code = [
                    'var CONFETTI, SIZE = {}, module = {};',
                    '(' + main.toString() + ')(this, module, true, SIZE);',
                    'onmessage = function(msg) {',
                    '  if (msg.data.options) {',
                    '    CONFETTI(msg.data.options).then(function () {',
                    '      if (msg.data.callback) {',
                    '        postMessage({ callback: msg.data.callback });',
                    '      }',
                    '    });',
                    '  } else if (msg.data.reset) {',
                    '    CONFETTI && CONFETTI.reset();',
                    '  } else if (msg.data.resize) {',
                    '    SIZE.width = msg.data.resize.width;',
                    '    SIZE.height = msg.data.resize.height;',
                    '  } else if (msg.data.canvas) {',
                    '    SIZE.width = msg.data.canvas.width;',
                    '    SIZE.height = msg.data.canvas.height;',
                    '    CONFETTI = module.exports.create(msg.data.canvas);',
                    '  }',
                    '}'
                ].join('\n');
                try {
                    worker = new Worker(URL.createObjectURL(new Blob([
                        code
                    ])));
                } catch (e) {
                    // eslint-disable-next-line no-console
                    typeof console !== 'undefined' && typeof console.warn === 'function' ? console.warn('🎊 Could not load worker', e) : null;
                    return null;
                }
                decorate(worker);
            }
            return worker;
        };
    }();
    var defaults = {
        particleCount: 50,
        angle: 90,
        spread: 45,
        startVelocity: 45,
        decay: 0.9,
        gravity: 1,
        drift: 0,
        ticks: 200,
        x: 0.5,
        y: 0.5,
        shapes: [
            'square',
            'circle'
        ],
        zIndex: 100,
        colors: [
            '#26ccff',
            '#a25afd',
            '#ff5e7e',
            '#88ff5a',
            '#fcff42',
            '#ffa62d',
            '#ff36ff'
        ],
        // probably should be true, but back-compat
        disableForReducedMotion: false,
        scalar: 1
    };
    function convert(val, transform) {
        return transform ? transform(val) : val;
    }
    function isOk(val) {
        return !(val === null || val === undefined);
    }
    function prop(options, name, transform) {
        return convert(options && isOk(options[name]) ? options[name] : defaults[name], transform);
    }
    function onlyPositiveInt(number) {
        return number < 0 ? 0 : Math.floor(number);
    }
    function randomInt(min, max) {
        // [min, max)
        return Math.floor(Math.random() * (max - min)) + min;
    }
    function toDecimal(str) {
        return parseInt(str, 16);
    }
    function colorsToRgb(colors) {
        return colors.map(hexToRgb);
    }
    function hexToRgb(str) {
        var val = String(str).replace(/[^0-9a-f]/gi, '');
        if (val.length < 6) {
            val = val[0] + val[0] + val[1] + val[1] + val[2] + val[2];
        }
        return {
            r: toDecimal(val.substring(0, 2)),
            g: toDecimal(val.substring(2, 4)),
            b: toDecimal(val.substring(4, 6))
        };
    }
    function getOrigin(options) {
        var origin = prop(options, 'origin', Object);
        origin.x = prop(origin, 'x', Number);
        origin.y = prop(origin, 'y', Number);
        return origin;
    }
    function setCanvasWindowSize(canvas) {
        canvas.width = document.documentElement.clientWidth;
        canvas.height = document.documentElement.clientHeight;
    }
    function setCanvasRectSize(canvas) {
        var rect = canvas.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
    }
    function getCanvas(zIndex) {
        var canvas = document.createElement('canvas');
        canvas.style.position = 'fixed';
        canvas.style.top = '0px';
        canvas.style.left = '0px';
        canvas.style.pointerEvents = 'none';
        canvas.style.zIndex = zIndex;
        return canvas;
    }
    function ellipse(context, x, y, radiusX, radiusY, rotation, startAngle, endAngle, antiClockwise) {
        context.save();
        context.translate(x, y);
        context.rotate(rotation);
        context.scale(radiusX, radiusY);
        context.arc(0, 0, 1, startAngle, endAngle, antiClockwise);
        context.restore();
    }
    function randomPhysics(opts) {
        var radAngle = opts.angle * (Math.PI / 180);
        var radSpread = opts.spread * (Math.PI / 180);
        return {
            x: opts.x,
            y: opts.y,
            wobble: Math.random() * 10,
            wobbleSpeed: Math.min(0.11, Math.random() * 0.1 + 0.05),
            velocity: opts.startVelocity * 0.5 + Math.random() * opts.startVelocity,
            angle2D: -radAngle + (0.5 * radSpread - Math.random() * radSpread),
            tiltAngle: (Math.random() * (0.75 - 0.25) + 0.25) * Math.PI,
            color: opts.color,
            shape: opts.shape,
            tick: 0,
            totalTicks: opts.ticks,
            decay: opts.decay,
            drift: opts.drift,
            random: Math.random() + 2,
            tiltSin: 0,
            tiltCos: 0,
            wobbleX: 0,
            wobbleY: 0,
            gravity: opts.gravity * 3,
            ovalScalar: 0.6,
            scalar: opts.scalar,
            flat: opts.flat
        };
    }
    function updateFetti(context, fetti) {
        fetti.x += Math.cos(fetti.angle2D) * fetti.velocity + fetti.drift;
        fetti.y += Math.sin(fetti.angle2D) * fetti.velocity + fetti.gravity;
        fetti.velocity *= fetti.decay;
        if (fetti.flat) {
            fetti.wobble = 0;
            fetti.wobbleX = fetti.x + 10 * fetti.scalar;
            fetti.wobbleY = fetti.y + 10 * fetti.scalar;
            fetti.tiltSin = 0;
            fetti.tiltCos = 0;
            fetti.random = 1;
        } else {
            fetti.wobble += fetti.wobbleSpeed;
            fetti.wobbleX = fetti.x + 10 * fetti.scalar * Math.cos(fetti.wobble);
            fetti.wobbleY = fetti.y + 10 * fetti.scalar * Math.sin(fetti.wobble);
            fetti.tiltAngle += 0.1;
            fetti.tiltSin = Math.sin(fetti.tiltAngle);
            fetti.tiltCos = Math.cos(fetti.tiltAngle);
            fetti.random = Math.random() + 2;
        }
        var progress = fetti.tick++ / fetti.totalTicks;
        var x1 = fetti.x + fetti.random * fetti.tiltCos;
        var y1 = fetti.y + fetti.random * fetti.tiltSin;
        var x2 = fetti.wobbleX + fetti.random * fetti.tiltCos;
        var y2 = fetti.wobbleY + fetti.random * fetti.tiltSin;
        context.fillStyle = 'rgba(' + fetti.color.r + ', ' + fetti.color.g + ', ' + fetti.color.b + ', ' + (1 - progress) + ')';
        context.beginPath();
        if (canUsePaths && fetti.shape.type === 'path' && typeof fetti.shape.path === 'string' && Array.isArray(fetti.shape.matrix)) {
            context.fill(transformPath2D(fetti.shape.path, fetti.shape.matrix, fetti.x, fetti.y, Math.abs(x2 - x1) * 0.1, Math.abs(y2 - y1) * 0.1, Math.PI / 10 * fetti.wobble));
        } else if (fetti.shape.type === 'bitmap') {
            var rotation = Math.PI / 10 * fetti.wobble;
            var scaleX = Math.abs(x2 - x1) * 0.1;
            var scaleY = Math.abs(y2 - y1) * 0.1;
            var width = fetti.shape.bitmap.width * fetti.scalar;
            var height = fetti.shape.bitmap.height * fetti.scalar;
            var matrix = new DOMMatrix([
                Math.cos(rotation) * scaleX,
                Math.sin(rotation) * scaleX,
                -Math.sin(rotation) * scaleY,
                Math.cos(rotation) * scaleY,
                fetti.x,
                fetti.y
            ]);
            // apply the transform matrix from the confetti shape
            matrix.multiplySelf(new DOMMatrix(fetti.shape.matrix));
            var pattern = context.createPattern(bitmapMapper.transform(fetti.shape.bitmap), 'no-repeat');
            pattern.setTransform(matrix);
            context.globalAlpha = 1 - progress;
            context.fillStyle = pattern;
            context.fillRect(fetti.x - width / 2, fetti.y - height / 2, width, height);
            context.globalAlpha = 1;
        } else if (fetti.shape === 'circle') {
            context.ellipse ? context.ellipse(fetti.x, fetti.y, Math.abs(x2 - x1) * fetti.ovalScalar, Math.abs(y2 - y1) * fetti.ovalScalar, Math.PI / 10 * fetti.wobble, 0, 2 * Math.PI) : ellipse(context, fetti.x, fetti.y, Math.abs(x2 - x1) * fetti.ovalScalar, Math.abs(y2 - y1) * fetti.ovalScalar, Math.PI / 10 * fetti.wobble, 0, 2 * Math.PI);
        } else if (fetti.shape === 'star') {
            var rot = Math.PI / 2 * 3;
            var innerRadius = 4 * fetti.scalar;
            var outerRadius = 8 * fetti.scalar;
            var x = fetti.x;
            var y = fetti.y;
            var spikes = 5;
            var step = Math.PI / spikes;
            while(spikes--){
                x = fetti.x + Math.cos(rot) * outerRadius;
                y = fetti.y + Math.sin(rot) * outerRadius;
                context.lineTo(x, y);
                rot += step;
                x = fetti.x + Math.cos(rot) * innerRadius;
                y = fetti.y + Math.sin(rot) * innerRadius;
                context.lineTo(x, y);
                rot += step;
            }
        } else {
            context.moveTo(Math.floor(fetti.x), Math.floor(fetti.y));
            context.lineTo(Math.floor(fetti.wobbleX), Math.floor(y1));
            context.lineTo(Math.floor(x2), Math.floor(y2));
            context.lineTo(Math.floor(x1), Math.floor(fetti.wobbleY));
        }
        context.closePath();
        context.fill();
        return fetti.tick < fetti.totalTicks;
    }
    function animate(canvas, fettis, resizer, size, done) {
        var animatingFettis = fettis.slice();
        var context = canvas.getContext('2d');
        var animationFrame;
        var destroy;
        var prom = promise(function(resolve) {
            function onDone() {
                animationFrame = destroy = null;
                context.clearRect(0, 0, size.width, size.height);
                bitmapMapper.clear();
                done();
                resolve();
            }
            function update() {
                if (isWorker && !(size.width === workerSize.width && size.height === workerSize.height)) {
                    size.width = canvas.width = workerSize.width;
                    size.height = canvas.height = workerSize.height;
                }
                if (!size.width && !size.height) {
                    resizer(canvas);
                    size.width = canvas.width;
                    size.height = canvas.height;
                }
                context.clearRect(0, 0, size.width, size.height);
                animatingFettis = animatingFettis.filter(function(fetti) {
                    return updateFetti(context, fetti);
                });
                if (animatingFettis.length) {
                    animationFrame = raf.frame(update);
                } else {
                    onDone();
                }
            }
            animationFrame = raf.frame(update);
            destroy = onDone;
        });
        return {
            addFettis: function(fettis) {
                animatingFettis = animatingFettis.concat(fettis);
                return prom;
            },
            canvas: canvas,
            promise: prom,
            reset: function() {
                if (animationFrame) {
                    raf.cancel(animationFrame);
                }
                if (destroy) {
                    destroy();
                }
            }
        };
    }
    function confettiCannon(canvas, globalOpts) {
        var isLibCanvas = !canvas;
        var allowResize = !!prop(globalOpts || {}, 'resize');
        var hasResizeEventRegistered = false;
        var globalDisableForReducedMotion = prop(globalOpts, 'disableForReducedMotion', Boolean);
        var shouldUseWorker = canUseWorker && !!prop(globalOpts || {}, 'useWorker');
        var worker = shouldUseWorker ? getWorker() : null;
        var resizer = isLibCanvas ? setCanvasWindowSize : setCanvasRectSize;
        var initialized = canvas && worker ? !!canvas.__confetti_initialized : false;
        var preferLessMotion = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion)').matches;
        var animationObj;
        function fireLocal(options, size, done) {
            var particleCount = prop(options, 'particleCount', onlyPositiveInt);
            var angle = prop(options, 'angle', Number);
            var spread = prop(options, 'spread', Number);
            var startVelocity = prop(options, 'startVelocity', Number);
            var decay = prop(options, 'decay', Number);
            var gravity = prop(options, 'gravity', Number);
            var drift = prop(options, 'drift', Number);
            var colors = prop(options, 'colors', colorsToRgb);
            var ticks = prop(options, 'ticks', Number);
            var shapes = prop(options, 'shapes');
            var scalar = prop(options, 'scalar');
            var flat = !!prop(options, 'flat');
            var origin = getOrigin(options);
            var temp = particleCount;
            var fettis = [];
            var startX = canvas.width * origin.x;
            var startY = canvas.height * origin.y;
            while(temp--){
                fettis.push(randomPhysics({
                    x: startX,
                    y: startY,
                    angle: angle,
                    spread: spread,
                    startVelocity: startVelocity,
                    color: colors[temp % colors.length],
                    shape: shapes[randomInt(0, shapes.length)],
                    ticks: ticks,
                    decay: decay,
                    gravity: gravity,
                    drift: drift,
                    scalar: scalar,
                    flat: flat
                }));
            }
            // if we have a previous canvas already animating,
            // add to it
            if (animationObj) {
                return animationObj.addFettis(fettis);
            }
            animationObj = animate(canvas, fettis, resizer, size, done);
            return animationObj.promise;
        }
        function fire(options) {
            var disableForReducedMotion = globalDisableForReducedMotion || prop(options, 'disableForReducedMotion', Boolean);
            var zIndex = prop(options, 'zIndex', Number);
            if (disableForReducedMotion && preferLessMotion) {
                return promise(function(resolve) {
                    resolve();
                });
            }
            if (isLibCanvas && animationObj) {
                // use existing canvas from in-progress animation
                canvas = animationObj.canvas;
            } else if (isLibCanvas && !canvas) {
                // create and initialize a new canvas
                canvas = getCanvas(zIndex);
                document.body.appendChild(canvas);
            }
            if (allowResize && !initialized) {
                // initialize the size of a user-supplied canvas
                resizer(canvas);
            }
            var size = {
                width: canvas.width,
                height: canvas.height
            };
            if (worker && !initialized) {
                worker.init(canvas);
            }
            initialized = true;
            if (worker) {
                canvas.__confetti_initialized = true;
            }
            function onResize() {
                if (worker) {
                    // TODO this really shouldn't be immediate, because it is expensive
                    var obj = {
                        getBoundingClientRect: function() {
                            if (!isLibCanvas) {
                                return canvas.getBoundingClientRect();
                            }
                        }
                    };
                    resizer(obj);
                    worker.postMessage({
                        resize: {
                            width: obj.width,
                            height: obj.height
                        }
                    });
                    return;
                }
                // don't actually query the size here, since this
                // can execute frequently and rapidly
                size.width = size.height = null;
            }
            function done() {
                animationObj = null;
                if (allowResize) {
                    hasResizeEventRegistered = false;
                    global.removeEventListener('resize', onResize);
                }
                if (isLibCanvas && canvas) {
                    if (document.body.contains(canvas)) {
                        document.body.removeChild(canvas);
                    }
                    canvas = null;
                    initialized = false;
                }
            }
            if (allowResize && !hasResizeEventRegistered) {
                hasResizeEventRegistered = true;
                global.addEventListener('resize', onResize, false);
            }
            if (worker) {
                return worker.fire(options, size, done);
            }
            return fireLocal(options, size, done);
        }
        fire.reset = function() {
            if (worker) {
                worker.reset();
            }
            if (animationObj) {
                animationObj.reset();
            }
        };
        return fire;
    }
    // Make default export lazy to defer worker creation until called.
    var defaultFire;
    function getDefaultFire() {
        if (!defaultFire) {
            defaultFire = confettiCannon(null, {
                useWorker: true,
                resize: true
            });
        }
        return defaultFire;
    }
    function transformPath2D(pathString, pathMatrix, x, y, scaleX, scaleY, rotation) {
        var path2d = new Path2D(pathString);
        var t1 = new Path2D();
        t1.addPath(path2d, new DOMMatrix(pathMatrix));
        var t2 = new Path2D();
        // see https://developer.mozilla.org/en-US/docs/Web/API/DOMMatrix/DOMMatrix
        t2.addPath(t1, new DOMMatrix([
            Math.cos(rotation) * scaleX,
            Math.sin(rotation) * scaleX,
            -Math.sin(rotation) * scaleY,
            Math.cos(rotation) * scaleY,
            x,
            y
        ]));
        return t2;
    }
    function shapeFromPath(pathData) {
        if (!canUsePaths) {
            throw new Error('path confetti are not supported in this browser');
        }
        var path, matrix;
        if (typeof pathData === 'string') {
            path = pathData;
        } else {
            path = pathData.path;
            matrix = pathData.matrix;
        }
        var path2d = new Path2D(path);
        var tempCanvas = document.createElement('canvas');
        var tempCtx = tempCanvas.getContext('2d');
        if (!matrix) {
            // attempt to figure out the width of the path, up to 1000x1000
            var maxSize = 1000;
            var minX = maxSize;
            var minY = maxSize;
            var maxX = 0;
            var maxY = 0;
            var width, height;
            // do some line skipping... this is faster than checking
            // every pixel and will be mostly still correct
            for(var x = 0; x < maxSize; x += 2){
                for(var y = 0; y < maxSize; y += 2){
                    if (tempCtx.isPointInPath(path2d, x, y, 'nonzero')) {
                        minX = Math.min(minX, x);
                        minY = Math.min(minY, y);
                        maxX = Math.max(maxX, x);
                        maxY = Math.max(maxY, y);
                    }
                }
            }
            width = maxX - minX;
            height = maxY - minY;
            var maxDesiredSize = 10;
            var scale = Math.min(maxDesiredSize / width, maxDesiredSize / height);
            matrix = [
                scale,
                0,
                0,
                scale,
                -Math.round(width / 2 + minX) * scale,
                -Math.round(height / 2 + minY) * scale
            ];
        }
        return {
            type: 'path',
            path: path,
            matrix: matrix
        };
    }
    function shapeFromText(textData) {
        var text, scalar = 1, color = '#000000', // see https://nolanlawson.com/2022/04/08/the-struggle-of-using-native-emoji-on-the-web/
        fontFamily = '"Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "Twemoji Mozilla", "system emoji", sans-serif';
        if (typeof textData === 'string') {
            text = textData;
        } else {
            text = textData.text;
            scalar = 'scalar' in textData ? textData.scalar : scalar;
            fontFamily = 'fontFamily' in textData ? textData.fontFamily : fontFamily;
            color = 'color' in textData ? textData.color : color;
        }
        // all other confetti are 10 pixels,
        // so this pixel size is the de-facto 100% scale confetti
        var fontSize = 10 * scalar;
        var font = '' + fontSize + 'px ' + fontFamily;
        var canvas = new OffscreenCanvas(fontSize, fontSize);
        var ctx = canvas.getContext('2d');
        ctx.font = font;
        var size = ctx.measureText(text);
        var width = Math.ceil(size.actualBoundingBoxRight + size.actualBoundingBoxLeft);
        var height = Math.ceil(size.actualBoundingBoxAscent + size.actualBoundingBoxDescent);
        var padding = 2;
        var x = size.actualBoundingBoxLeft + padding;
        var y = size.actualBoundingBoxAscent + padding;
        width += padding + padding;
        height += padding + padding;
        canvas = new OffscreenCanvas(width, height);
        ctx = canvas.getContext('2d');
        ctx.font = font;
        ctx.fillStyle = color;
        ctx.fillText(text, x, y);
        var scale = 1 / scalar;
        return {
            type: 'bitmap',
            // TODO these probably need to be transfered for workers
            bitmap: canvas.transferToImageBitmap(),
            matrix: [
                scale,
                0,
                0,
                scale,
                -width * scale / 2,
                -height * scale / 2
            ]
        };
    }
    module.exports = function() {
        return getDefaultFire().apply(this, arguments);
    };
    module.exports.reset = function() {
        getDefaultFire().reset();
    };
    module.exports.create = confettiCannon;
    module.exports.shapeFromPath = shapeFromPath;
    module.exports.shapeFromText = shapeFromText;
})(function() {
    if (typeof window !== 'undefined') {
        return window;
    }
    if (typeof self !== 'undefined') {
        return self;
    }
    return this || {};
}(), module, false);
const __TURBOPACK__default__export__ = module.exports;
var create = module.exports.create;
}),
"[project]/node_modules/next/dist/client/components/bfcache-state-manager.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useRouterBFCache", {
    enumerable: true,
    get: function() {
        return useRouterBFCache;
    }
});
const _react = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
// When the flag is disabled, only track the currently active tree
const MAX_BF_CACHE_ENTRIES = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 1;
function useRouterBFCache(activeTree, activeCacheNode, activeStateKey) {
    // The currently active entry. The entries form a linked list, sorted in
    // order of most recently active. This allows us to reuse parts of the list
    // without cloning, unless there's a reordering or removal.
    // TODO: Once we start tracking back/forward history at each route level,
    // we should use the history order instead. In other words, when traversing
    // to an existing entry as a result of a popstate event, we should maintain
    // the existing order instead of moving it to the front of the list. I think
    // an initial implementation of this could be to pass an incrementing id
    // to history.pushState/replaceState, then use that here for ordering.
    const [prevActiveEntry, setPrevActiveEntry] = (0, _react.useState)(()=>{
        const initialEntry = {
            tree: activeTree,
            cacheNode: activeCacheNode,
            stateKey: activeStateKey,
            next: null
        };
        return initialEntry;
    });
    if (prevActiveEntry.tree === activeTree) {
        // Fast path. The active tree hasn't changed, so we can reuse the
        // existing state.
        return prevActiveEntry;
    }
    // The route tree changed. Note that this doesn't mean that the tree changed
    // *at this level* — the change may be due to a child route. Either way, we
    // need to either add or update the router tree in the bfcache.
    //
    // The rest of the code looks more complicated than it actually is because we
    // can't mutate the state in place; we have to copy-on-write.
    // Create a new entry for the active cache key. This is the head of the new
    // linked list.
    const newActiveEntry = {
        tree: activeTree,
        cacheNode: activeCacheNode,
        stateKey: activeStateKey,
        next: null
    };
    // We need to append the old list onto the new list. If the head of the new
    // list was already present in the cache, then we'll need to clone everything
    // that came before it. Then we can reuse the rest.
    let n = 1;
    let oldEntry = prevActiveEntry;
    let clonedEntry = newActiveEntry;
    while(oldEntry !== null && n < MAX_BF_CACHE_ENTRIES){
        if (oldEntry.stateKey === activeStateKey) {
            // Fast path. This entry in the old list that corresponds to the key that
            // is now active. We've already placed a clone of this entry at the front
            // of the new list. We can reuse the rest of the old list without cloning.
            // NOTE: We don't need to worry about eviction in this case because we
            // haven't increased the size of the cache, and we assume the max size
            // is constant across renders. If we were to change it to a dynamic limit,
            // then the implementation would need to account for that.
            clonedEntry.next = oldEntry.next;
            break;
        } else {
            // Clone the entry and append it to the list.
            n++;
            const entry = {
                tree: oldEntry.tree,
                cacheNode: oldEntry.cacheNode,
                stateKey: oldEntry.stateKey,
                next: null
            };
            clonedEntry.next = entry;
            clonedEntry = entry;
        }
        oldEntry = oldEntry.next;
    }
    setPrevActiveEntry(newActiveEntry);
    return newActiveEntry;
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/components/client-boundary-params.browser.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Browser variant of `./client-boundary-params`. In the browser the params and
// searchParams are created at render time rather than dynamically tracked.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    createClientParams: null,
    createClientSearchParams: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    createClientParams: function() {
        return _paramsbrowser.createRenderParamsFromClient;
    },
    createClientSearchParams: function() {
        return _searchparamsbrowser.createRenderSearchParamsFromClient;
    }
});
const _paramsbrowser = __turbopack_context__.r("[project]/node_modules/next/dist/client/request/params.browser.js [app-client] (ecmascript)");
const _searchparamsbrowser = __turbopack_context__.r("[project]/node_modules/next/dist/client/request/search-params.browser.js [app-client] (ecmascript)");
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/components/client-page.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ClientPageRoot", {
    enumerable: true,
    get: function() {
        return ClientPageRoot;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _approutercontextsharedruntime = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _routeparams = __turbopack_context__.r("[project]/node_modules/next/dist/client/route-params.js [app-client] (ecmascript)");
const _hooksclientcontextsharedruntime = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/hooks-client-context.shared-runtime.js [app-client] (ecmascript)");
const _clientboundaryparams = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/client-boundary-params.browser.js [app-client] (ecmascript)");
function ClientPageRoot({ Component, serverProvidedParams }) {
    let searchParams;
    let params;
    if (serverProvidedParams !== null) {
        searchParams = serverProvidedParams.searchParams;
        params = serverProvidedParams.params;
    } else {
        // When Cache Components is enabled, the server does not pass the params as
        // props; they are parsed on the client and passed via context.
        const layoutRouterContext = (0, _react.use)(_approutercontextsharedruntime.LayoutRouterContext);
        params = layoutRouterContext !== null ? layoutRouterContext.parentParams : {};
        // This is an intentional behavior change: when Cache Components is enabled,
        // client segments receive the "canonical" search params, not the
        // rewritten ones. Users should either call useSearchParams directly or pass
        // the rewritten ones in from a Server Component.
        // TODO: Log a deprecation error when this object is accessed
        searchParams = (0, _routeparams.urlSearchParamsToParsedUrlQuery)((0, _react.use)(_hooksclientcontextsharedruntime.SearchParamsContext));
    }
    const clientSearchParams = (0, _clientboundaryparams.createClientSearchParams)(searchParams);
    const clientParams = (0, _clientboundaryparams.createClientParams)(params);
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(Component, {
        params: clientParams,
        searchParams: clientSearchParams
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/components/client-segment.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ClientSegmentRoot", {
    enumerable: true,
    get: function() {
        return ClientSegmentRoot;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _approutercontextsharedruntime = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _clientboundaryparams = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/client-boundary-params.browser.js [app-client] (ecmascript)");
function ClientSegmentRoot({ Component, slots, serverProvidedParams }) {
    let params;
    if (serverProvidedParams !== null) {
        params = serverProvidedParams.params;
    } else {
        // When Cache Components is enabled, the server does not pass the params
        // as props; they are parsed on the client and passed via context.
        const layoutRouterContext = (0, _react.use)(_approutercontextsharedruntime.LayoutRouterContext);
        params = layoutRouterContext !== null ? layoutRouterContext.parentParams : {};
    }
    const clientParams = (0, _clientboundaryparams.createClientParams)(params);
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(Component, {
        ...slots,
        params: clientParams
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/components/instant-validation/boundary.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    InstantValidationBoundaryContext: null,
    PlaceValidationBoundaryBelowThisLevel: null,
    RenderValidationBoundaryAtThisLevel: null,
    SlotMarker: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    InstantValidationBoundaryContext: function() {
        return _impl.InstantValidationBoundaryContext;
    },
    PlaceValidationBoundaryBelowThisLevel: function() {
        return _impl.PlaceValidationBoundaryBelowThisLevel;
    },
    RenderValidationBoundaryAtThisLevel: function() {
        return _impl.RenderValidationBoundaryAtThisLevel;
    },
    SlotMarker: function() {
        return _impl.SlotMarker;
    }
});
const _impl = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/instant-validation/impl.browser.js [app-client] (ecmascript)");
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/components/instant-validation/impl.browser.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    InstantValidationBoundaryContext: null,
    PlaceValidationBoundaryBelowThisLevel: null,
    RenderValidationBoundaryAtThisLevel: null,
    SlotMarker: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    InstantValidationBoundaryContext: function() {
        return InstantValidationBoundaryContext;
    },
    PlaceValidationBoundaryBelowThisLevel: function() {
        return PlaceValidationBoundaryBelowThisLevel;
    },
    RenderValidationBoundaryAtThisLevel: function() {
        return RenderValidationBoundaryAtThisLevel;
    },
    SlotMarker: function() {
        return SlotMarker;
    }
});
const InstantValidationBoundaryContext = null;
const PlaceValidationBoundaryBelowThisLevel = null;
const RenderValidationBoundaryAtThisLevel = null;
const SlotMarker = null;
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/components/layout-router.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    LoadingBoundaryProvider: null,
    default: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    LoadingBoundaryProvider: function() {
        return LoadingBoundaryProvider;
    },
    /**
 * OuterLayoutRouter handles the current segment as well as <Offscreen> rendering of other segments.
 * It can be rendered next to each other with a different `parallelRouterKey`, allowing for Parallel routes.
 */ default: function() {
        return OuterLayoutRouter;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _interop_require_wildcard = __turbopack_context__.r("[project]/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _reactdom = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)"));
const _approutercontextsharedruntime = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)");
const _unresolvedthenable = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/unresolved-thenable.js [app-client] (ecmascript)");
const _errorboundary = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/error-boundary.js [app-client] (ecmascript)");
const _disablesmoothscroll = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/router/utils/disable-smooth-scroll.js [app-client] (ecmascript)");
const _redirectboundary = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/redirect-boundary.js [app-client] (ecmascript)");
const _errorboundary1 = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/http-access-fallback/error-boundary.js [app-client] (ecmascript)");
const _boundary = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/instant-validation/boundary.js [app-client] (ecmascript)");
const _createroutercachekey = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/router-reducer/create-router-cache-key.js [app-client] (ecmascript)");
const _bfcachestatemanager = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/bfcache-state-manager.js [app-client] (ecmascript)");
const _apppaths = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/router/utils/app-paths.js [app-client] (ecmascript)");
const _hooksclientcontextsharedruntime = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/hooks-client-context.shared-runtime.js [app-client] (ecmascript)");
const _routeparams = __turbopack_context__.r("[project]/node_modules/next/dist/client/route-params.js [app-client] (ecmascript)");
const _pprnavigations = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/router-reducer/ppr-navigations.js [app-client] (ecmascript)");
const enableNewScrollHandler = ("TURBOPACK compile-time value", true);
const __DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = _reactdom.default.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
// TODO-APP: Replace with new React API for finding dom nodes without a `ref` when available
/**
 * Wraps ReactDOM.findDOMNode with additional logic to hide React Strict Mode warning
 */ function findDOMNode(instance) {
    // Tree-shake for server bundle
    if (typeof window === 'undefined') return null;
    // __DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE.findDOMNode is null during module init.
    // We need to lazily reference it.
    const internal_reactDOMfindDOMNode = __DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE.findDOMNode;
    return internal_reactDOMfindDOMNode(instance);
}
const rectProperties = [
    'bottom',
    'height',
    'left',
    'right',
    'top',
    'width',
    'x',
    'y'
];
/**
 * Check if a HTMLElement is hidden or fixed/sticky position
 */ function shouldSkipElement(element) {
    // we ignore fixed or sticky positioned elements since they'll likely pass the "in-viewport" check
    // and will result in a situation we bail on scroll because of something like a fixed nav,
    // even though the actual page content is offscreen
    if ([
        'sticky',
        'fixed'
    ].includes(getComputedStyle(element).position)) {
        return true;
    }
    // Uses `getBoundingClientRect` to check if the element is hidden instead of `offsetParent`
    // because `offsetParent` doesn't consider document/body
    const rect = element.getBoundingClientRect();
    return rectProperties.every((item)=>rect[item] === 0);
}
/**
 * Resolve the root scroll padding used by the viewport check.
 *
 * Computed lengths serialize as pixels, but percentages remain relative to
 * the scrollport. Preserve the existing behavior for values that still
 * contain unresolved CSS math.
 */ function getScrollPaddingTopInPixels(htmlElement, viewportHeight) {
    const scrollPaddingTop = getComputedStyle(htmlElement).scrollPaddingTop;
    const value = Number.parseFloat(scrollPaddingTop);
    if (!Number.isFinite(value) || value < 0) {
        return 0;
    }
    if (scrollPaddingTop.endsWith('px')) {
        return value;
    }
    if (scrollPaddingTop.endsWith('%')) {
        return value / 100 * viewportHeight;
    }
    return 0;
}
/**
 * Check where the top corner of the HTMLElement is relative to the usable
 * viewport.
 *
 * Scroll padding is resolved lazily so an empty Fragment does not trigger a
 * computed style read. The caller caches the value for the second check.
 */ function getScrollTargetState(instance, viewportHeight, getScrollPaddingTop) {
    const rects = instance.getClientRects();
    if (rects.length === 0) {
        return 0;
    }
    let elementTop = Number.POSITIVE_INFINITY;
    for(let i = 0; i < rects.length; i++){
        const rect = rects[i];
        if (rect.top < elementTop) {
            elementTop = rect.top;
        }
    }
    return elementTop >= getScrollPaddingTop() && elementTop <= viewportHeight ? 1 : 2;
}
/**
 * Find the DOM node for a hash fragment.
 * If `top` the page has to scroll to the top of the page. This mirrors the browser's behavior.
 * If the hash fragment is an id, the page has to scroll to the element with that id.
 * If the hash fragment is a name, the page has to scroll to the first element with that name.
 */ function getHashFragmentDomNode(hashFragment) {
    // If the hash fragment is `top` the page has to scroll to the top of the page.
    if (hashFragment === 'top') {
        return document.body;
    }
    // If the hash fragment is an id, the page has to scroll to the element with that id.
    return document.getElementById(hashFragment) ?? // If the hash fragment is a name, the page has to scroll to the first element with that name.
    document.getElementsByName(hashFragment)[0] ?? null;
}
class InnerScrollAndFocusHandlerOld extends _react.default.Component {
    componentDidMount() {
        this.handlePotentialScroll();
    }
    componentDidUpdate() {
        this.handlePotentialScroll();
    }
    render() {
        return this.props.children;
    }
    constructor(...args){
        super(...args), this.handlePotentialScroll = ()=>{
            // Handle scroll and focus, it's only applied once.
            const { focusAndScrollRef, cacheNode } = this.props;
            const scrollRef = focusAndScrollRef.forceScroll ? focusAndScrollRef.scrollRef : cacheNode.scrollRef;
            if (scrollRef === null || !scrollRef.current) return;
            let domNode = null;
            const hashFragment = focusAndScrollRef.hashFragment;
            if (hashFragment) {
                domNode = getHashFragmentDomNode(hashFragment);
                if (domNode === null) {
                    // A missing hash target is still a handled scroll intent. Do not
                    // fall back to the route segment or leave the intent pending.
                    scrollRef.current = false;
                    focusAndScrollRef.onlyHashChange = false;
                    focusAndScrollRef.hashFragment = null;
                    return;
                }
            }
            // `findDOMNode` is tricky because it returns just the first child if the component is a fragment.
            // This already caused a bug where the first child was a <link/> in head.
            if (!domNode) {
                domNode = findDOMNode(this);
            }
            // If there is no DOM node this layout-router level is skipped. It'll be handled higher-up in the tree.
            if (!(domNode instanceof Element)) {
                return;
            }
            // Verify if the element is a HTMLElement and if we want to consider it for scroll behavior.
            // If the element is skipped, try to select the next sibling and try again.
            while(!(domNode instanceof HTMLElement) || shouldSkipElement(domNode)){
                if ("TURBOPACK compile-time truthy", 1) {
                    if (domNode.parentElement?.localName === 'head') {
                    // We enter this state when metadata was rendered as part of the page or via Next.js.
                    // This is always a bug in Next.js and caused by React hoisting metadata.
                    // Fixed with `experimental.appNewScrollHandler`
                    }
                }
                // No siblings found that match the criteria are found, so handle scroll higher up in the tree instead.
                if (domNode.nextElementSibling === null) {
                    return;
                }
                domNode = domNode.nextElementSibling;
            }
            // Mark as scrolled so no other segment scrolls for this navigation.
            scrollRef.current = false;
            (0, _disablesmoothscroll.disableSmoothScrollDuringRouteTransition)(()=>{
                // In case of hash scroll, we only need to scroll the element into view
                if (hashFragment) {
                    domNode.scrollIntoView();
                    return;
                }
                // Store the current viewport height because reading `clientHeight` causes a reflow,
                // and it won't change during this function.
                const htmlElement = document.documentElement;
                const viewportHeight = htmlElement.clientHeight;
                let scrollPaddingTop = null;
                const getScrollPaddingTop = ()=>{
                    if (scrollPaddingTop === null) {
                        // Reuse the style and layout update from the geometry read above.
                        scrollPaddingTop = getScrollPaddingTopInPixels(htmlElement, viewportHeight);
                    }
                    return scrollPaddingTop;
                };
                // If the element's top edge is already in the viewport, exit early.
                if (getScrollTargetState(domNode, viewportHeight, getScrollPaddingTop) === 1) {
                    return;
                }
                // Otherwise, try scrolling go the top of the document to be backward compatible with pages
                // scrollIntoView() called on `<html/>` element scrolls horizontally on chrome and firefox (that shouldn't happen)
                // We could use it to scroll horizontally following RTL but that also seems to be broken - it will always scroll left
                // scrollLeft = 0 also seems to ignore RTL and manually checking for RTL is too much hassle so we will scroll just vertically
                htmlElement.scrollTop = 0;
                // Scroll to domNode if domNode is not in viewport when scrolled to top of document
                if (getScrollTargetState(domNode, viewportHeight, getScrollPaddingTop) !== 1) {
                    // Scroll into view doesn't scroll horizontally by default when not needed
                    domNode.scrollIntoView();
                }
            }, {
                // We will force layout by querying domNode position
                dontForceLayout: true,
                onlyHashChange: focusAndScrollRef.onlyHashChange
            });
            // Mutate after scrolling so that it can be read by `disableSmoothScrollDuringRouteTransition`
            focusAndScrollRef.onlyHashChange = false;
            focusAndScrollRef.hashFragment = null;
            // Set focus on the element
            domNode.focus();
        };
    }
}
/**
 * Fork of InnerScrollAndFocusHandlerOld using Fragment refs for scrolling.
 * No longer focuses the first host descendant.
 */ function InnerScrollHandlerNew(props) {
    const childrenRef = _react.default.useRef(null);
    (0, _react.useLayoutEffect)(()=>{
        const { focusAndScrollRef, cacheNode } = props;
        const scrollRef = focusAndScrollRef.forceScroll ? focusAndScrollRef.scrollRef : cacheNode.scrollRef;
        if (scrollRef === null || !scrollRef.current) return;
        let instance = null;
        const hashFragment = focusAndScrollRef.hashFragment;
        if (hashFragment) {
            instance = getHashFragmentDomNode(hashFragment);
            if (instance === null) {
                // A missing hash target is still a handled scroll intent. Do not
                // fall back to the route Fragment or leave the intent pending.
                scrollRef.current = false;
                focusAndScrollRef.onlyHashChange = false;
                focusAndScrollRef.hashFragment = null;
                return;
            }
        } else {
            instance = childrenRef.current;
        }
        // If there is no DOM node this layout-router level is skipped. It'll be handled higher-up in the tree.
        if (instance === null) {
            return;
        }
        let didHandleScroll = false;
        (0, _disablesmoothscroll.disableSmoothScrollDuringRouteTransition)(()=>{
            const htmlElement = document.documentElement;
            let viewportHeight = null;
            let initialTargetState = null;
            let scrollPaddingTop = null;
            const getScrollPaddingTop = ()=>{
                if (scrollPaddingTop === null) {
                    // Reuse the style and layout update from the geometry read.
                    scrollPaddingTop = getScrollPaddingTopInPixels(htmlElement, viewportHeight);
                }
                return scrollPaddingTop;
            };
            if (!hashFragment) {
                // Store the current viewport height because reading `clientHeight` causes a reflow,
                // and it won't change during this function.
                viewportHeight = htmlElement.clientHeight;
                initialTargetState = getScrollTargetState(instance, viewportHeight, getScrollPaddingTop);
                // An empty Fragment is not a scroll target. In particular, avoid
                // React's sibling fallback and leave the scroll signal available
                // for another changed segment.
                if (initialTargetState === 0) {
                    return;
                }
            }
            didHandleScroll = true;
            // Mark as scrolled so no other segment scrolls for this navigation.
            scrollRef.current = false;
            // This handler intentionally leaves focus untouched; resetting focus on
            // navigation is deferred.
            // In case of hash scroll, we only need to scroll the element into view
            if (hashFragment) {
                instance.scrollIntoView();
                return;
            }
            // If the element's top edge is already in the viewport, exit early.
            if (initialTargetState === 1) {
                return;
            }
            // Otherwise, try scrolling go the top of the document to be backward compatible with pages
            // scrollIntoView() called on `<html/>` element scrolls horizontally on chrome and firefox (that shouldn't happen)
            // We could use it to scroll horizontally following RTL but that also seems to be broken - it will always scroll left
            // scrollLeft = 0 also seems to ignore RTL and manually checking for RTL is too much hassle so we will scroll just vertically
            htmlElement.scrollTop = 0;
            // Scroll to domNode if domNode is not in viewport when scrolled to top of document
            if (getScrollTargetState(instance, viewportHeight, getScrollPaddingTop) === 2) {
                // Scroll into view doesn't scroll horizontally by default when not needed
                instance.scrollIntoView();
            }
        }, {
            // We will force layout by querying domNode position
            dontForceLayout: true,
            onlyHashChange: focusAndScrollRef.onlyHashChange
        });
        if (!didHandleScroll) {
            return;
        }
        // Mutate after scrolling so that it can be read by `disableSmoothScrollDuringRouteTransition`
        focusAndScrollRef.onlyHashChange = false;
        focusAndScrollRef.hashFragment = null;
    }, // but be prepared for lots of manual testing.
    undefined);
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_react.Fragment, {
        ref: childrenRef,
        children: props.children
    });
}
const InnerScrollAndMaybeFocusHandler = ("TURBOPACK compile-time truthy", 1) ? InnerScrollHandlerNew : "TURBOPACK unreachable";
function ScrollAndMaybeFocusHandler({ children, cacheNode }) {
    const context = (0, _react.useContext)(_approutercontextsharedruntime.GlobalLayoutRouterContext);
    if (!context) {
        throw Object.defineProperty(new Error('invariant global layout router not mounted'), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: false,
            configurable: true
        });
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(InnerScrollAndMaybeFocusHandler, {
        focusAndScrollRef: context.focusAndScrollRef,
        cacheNode: cacheNode,
        children: children
    });
}
/**
 * InnerLayoutRouter handles rendering the provided segment based on the cache.
 */ function InnerLayoutRouter({ tree, segmentPath, debugNameContext, cacheNode: maybeCacheNode, params, url, isActive }) {
    const context = (0, _react.useContext)(_approutercontextsharedruntime.GlobalLayoutRouterContext);
    const parentNavPromises = (0, _react.useContext)(_hooksclientcontextsharedruntime.NavigationPromisesContext);
    if (!context) {
        throw Object.defineProperty(new Error('invariant global layout router not mounted'), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: false,
            configurable: true
        });
    }
    const cacheNode = maybeCacheNode !== null ? maybeCacheNode : // This should only be reachable for inactive/hidden segments, during
    // prerendering The active segment should always be consistent with the
    // CacheNode tree. Regardless, if we don't have a matching CacheNode, we
    // must suspend rather than render nothing, to prevent showing an
    // inconsistent route.
    (0, _react.use)(_unresolvedthenable.unresolvedThenable);
    // `rsc` represents the renderable node for this segment.
    // If this segment has a `prefetchRsc`, it's the statically prefetched data.
    // We should use that on initial render instead of `rsc`. Then we'll switch
    // to `rsc` when the dynamic response streams in.
    //
    // If no prefetch data is available, then we go straight to rendering `rsc`.
    const resolvedPrefetchRsc = cacheNode.prefetchRsc !== null ? cacheNode.prefetchRsc : cacheNode.rsc;
    // We use `useDeferredValue` to handle switching between the prefetched and
    // final values. The second argument is returned on initial render, then it
    // re-renders with the first argument.
    const rsc = (0, _react.useDeferredValue)(cacheNode.rsc, resolvedPrefetchRsc);
    // `rsc` is either a React node or a promise for a React node, except we
    // special case `null` to represent that this segment's data is missing. If
    // it's a promise, we need to unwrap it so we can determine whether or not the
    // data is missing.
    let resolvedRsc;
    if ((0, _pprnavigations.isDeferredRsc)(rsc)) {
        const unwrappedRsc = (0, _react.use)(rsc);
        if (unwrappedRsc === null) {
            // If the promise was resolved to `null`, it means the data for this
            // segment was not returned by the server. Suspend indefinitely. When this
            // happens, the router is responsible for triggering a new state update to
            // un-suspend this segment.
            (0, _react.use)(_unresolvedthenable.unresolvedThenable);
        }
        resolvedRsc = unwrappedRsc;
    } else {
        // This is not a deferred RSC promise. Don't need to unwrap it.
        if (rsc === null) {
            (0, _react.use)(_unresolvedthenable.unresolvedThenable);
        }
        resolvedRsc = rsc;
    }
    // In dev, we create a NavigationPromisesContext containing the instrumented promises that provide
    // `useSelectedLayoutSegment` and `useSelectedLayoutSegments`.
    // Promises are cached outside of render to survive suspense retries.
    let navigationPromises = null;
    if ("TURBOPACK compile-time truthy", 1) {
        const { createNestedLayoutNavigationPromises } = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/navigation-devtools.js [app-client] (ecmascript)");
        navigationPromises = createNestedLayoutNavigationPromises(tree, parentNavPromises);
    }
    let children = resolvedRsc;
    if (navigationPromises) {
        children = /*#__PURE__*/ (0, _jsxruntime.jsx)(_hooksclientcontextsharedruntime.NavigationPromisesContext.Provider, {
            value: navigationPromises,
            children: resolvedRsc
        });
    }
    children = /*#__PURE__*/ (0, _jsxruntime.jsx)(_approutercontextsharedruntime.LayoutRouterContext.Provider, {
        value: {
            parentTree: tree,
            parentCacheNode: cacheNode,
            parentSegmentPath: segmentPath,
            parentParams: params,
            // This is always set to null as we enter a child segment. It's
            // populated by LoadingBoundaryProvider the next time we reach a
            // loading boundary.
            parentLoadingData: null,
            debugNameContext: debugNameContext,
            // TODO-APP: overriding of url for parallel routes
            url: url,
            isActive: isActive
        },
        children: children
    });
    return children;
}
function LoadingBoundaryProvider({ loading, children }) {
    // Provides the data needed to render a loading.tsx boundary, via context.
    //
    // loading.tsx creates a Suspense boundary around each of a layout's child
    // slots. (Might be bit confusing to think about the data flow, but: if
    // loading.tsx and layout.tsx are in the same directory, they are assigned
    // to the same CacheNode.)
    //
    // This provider component does not render the Suspense boundary directly;
    // that's handled by LoadingBoundary.
    //
    // TODO: For simplicity, we should combine this provider with LoadingBoundary
    // and render the Suspense boundary directly. The only real benefit of doing
    // it separately is so that when there are multiple parallel routes, we only
    // send the boundary data once, rather than once per child. But that's a
    // negligible benefit and can be achieved via caching instead.
    const parentContext = (0, _react.use)(_approutercontextsharedruntime.LayoutRouterContext);
    if (parentContext === null) {
        return children;
    }
    // All values except for parentLoadingData are the same as the parent context.
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_approutercontextsharedruntime.LayoutRouterContext.Provider, {
        value: {
            parentTree: parentContext.parentTree,
            parentCacheNode: parentContext.parentCacheNode,
            parentSegmentPath: parentContext.parentSegmentPath,
            parentParams: parentContext.parentParams,
            parentLoadingData: loading,
            debugNameContext: parentContext.debugNameContext,
            url: parentContext.url,
            isActive: parentContext.isActive
        },
        children: children
    });
}
/**
 * Renders suspense boundary with the provided "loading" property as the fallback.
 * If no loading property is provided it renders the children without a suspense boundary.
 */ function LoadingBoundary({ name, loading, children }) {
    // TODO: For LoadingBoundary, and the other built-in boundary types, don't
    // wrap in an extra function component if no user-defined boundary is
    // provided. In other words, inline this conditional wrapping logic into
    // the parent component. More efficient and keeps unnecessary junk out of
    // the component stack.
    if (loading !== null) {
        const loadingRsc = loading[0];
        const loadingStyles = loading[1];
        const loadingScripts = loading[2];
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(_react.Suspense, {
            name: name,
            fallback: /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
                children: [
                    loadingStyles,
                    loadingScripts,
                    loadingRsc
                ]
            }),
            children: children
        });
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
        children: children
    });
}
function OuterLayoutRouter({ parallelRouterKey, error, errorStyles, errorScripts, templateStyles, templateScripts, template, notFound, forbidden, unauthorized, segmentViewBoundaries }) {
    const context = (0, _react.useContext)(_approutercontextsharedruntime.LayoutRouterContext);
    if (!context) {
        throw Object.defineProperty(new Error('invariant expected layout router to be mounted'), "__NEXT_ERROR_CODE", {
            value: "E56",
            enumerable: false,
            configurable: true
        });
    }
    const { parentTree, parentCacheNode, parentSegmentPath, parentParams, parentLoadingData, url, isActive, debugNameContext } = context;
    // Get the CacheNode for this segment by reading it from the parent segment's
    // child map.
    const parentTreeSegment = parentTree[0];
    const segmentPath = parentSegmentPath === null ? // the code. We should clean this up.
    [
        parallelRouterKey
    ] : parentSegmentPath.concat([
        parentTreeSegment,
        parallelRouterKey
    ]);
    // The "state" key of a segment is the one passed to React — it represents the
    // identity of the UI tree. Whenever the state key changes, the tree is
    // recreated and the state is reset. In the App Router model, search params do
    // not cause state to be lost, so two segments with the same segment path but
    // different search params should have the same state key.
    //
    // The "cache" key of a segment, however, *does* include the search params, if
    // it's possible that the segment accessed the search params on the server.
    // (This only applies to page segments; layout segments cannot access search
    // params on the server.)
    const activeTree = parentTree[1][parallelRouterKey];
    const maybeParentSlots = parentCacheNode.slots;
    if (activeTree === undefined || maybeParentSlots === null) {
        // Could not find a matching segment. The client tree is inconsistent with
        // the server tree. Suspend indefinitely; the router will have already
        // detected the inconsistency when handling the server response, and
        // triggered a refresh of the page to recover.
        (0, _react.use)(_unresolvedthenable.unresolvedThenable);
    }
    let maybeValidationBoundaryId = null;
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const activeSegment = activeTree[0];
    const activeCacheNode = maybeParentSlots[parallelRouterKey] ?? null;
    const activeStateKey = (0, _createroutercachekey.createRouterCacheKey)(activeSegment, true) // no search params
    ;
    // At each level of the route tree, not only do we render the currently
    // active segment — we also render the last N segments that were active at
    // this level inside a hidden <Activity> boundary, to preserve their state
    // if or when the user navigates to them again.
    //
    // bfcacheEntry is a linked list of FlightRouterStates.
    let bfcacheEntry = (0, _bfcachestatemanager.useRouterBFCache)(activeTree, activeCacheNode, activeStateKey);
    let children = [];
    do {
        const tree = bfcacheEntry.tree;
        const cacheNode = bfcacheEntry.cacheNode;
        const stateKey = bfcacheEntry.stateKey;
        const segment = tree[0];
        /*
    - Error boundary
      - Only renders error boundary if error component is provided.
      - Rendered for each segment to ensure they have their own error state.
      - When gracefully degrade for bots, skip rendering error boundary.
    - Loading boundary
      - Only renders suspense boundary if loading components is provided.
      - Rendered for each segment to ensure they have their own loading state.
      - Passed to the router during rendering to ensure it can be immediately rendered when suspending on a Flight fetch.
  */ let segmentBoundaryTriggerNode = null;
        let segmentViewStateNode = null;
        if ("TURBOPACK compile-time truthy", 1) {
            const { SegmentBoundaryTriggerNode, SegmentViewStateNode } = __turbopack_context__.r("[project]/node_modules/next/dist/next-devtools/userspace/app/segment-explorer-node.js [app-client] (ecmascript)");
            const pagePrefix = (0, _apppaths.normalizeAppPath)(url);
            segmentViewStateNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(SegmentViewStateNode, {
                page: pagePrefix
            }, pagePrefix);
            segmentBoundaryTriggerNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
                children: /*#__PURE__*/ (0, _jsxruntime.jsx)(SegmentBoundaryTriggerNode, {})
            });
        }
        let params = parentParams;
        if (Array.isArray(segment)) {
            // This segment contains a route param. Accumulate these as we traverse
            // down the router tree. The result represents the set of params that
            // the layout/page components are permitted to access below this point.
            const paramName = segment[0];
            const paramCacheKey = segment[1];
            const paramType = segment[2];
            const paramValue = (0, _routeparams.getParamValueFromCacheKey)(paramCacheKey, paramType);
            if (paramValue !== null) {
                params = {
                    ...parentParams,
                    [paramName]: paramValue
                };
            }
        }
        const debugName = getBoundaryDebugNameFromSegment(segment);
        // `debugNameContext` represents the nearest non-"virtual" parent segment.
        // `getBoundaryDebugNameFromSegment` returns undefined for virtual segments.
        // So if `debugName` is undefined, the context is passed through unchanged.
        const childDebugNameContext = debugName ?? debugNameContext;
        // In practical terms, clicking this name in the Suspense DevTools
        // should select the child slots of that layout.
        //
        // So the name we apply to the Activity boundary is actually based on
        // the nearest parent segments.
        //
        // We skip over "virtual" parents, i.e. ones inserted by Next.js that
        // don't correspond to application-defined code.
        const isVirtual = debugName === undefined;
        const debugNameToDisplay = isVirtual ? undefined : debugNameContext;
        let templateValue = /*#__PURE__*/ (0, _jsxruntime.jsxs)(ScrollAndMaybeFocusHandler, {
            cacheNode: cacheNode,
            children: [
                /*#__PURE__*/ (0, _jsxruntime.jsx)(_errorboundary.ErrorBoundary, {
                    errorComponent: error,
                    errorStyles: errorStyles,
                    errorScripts: errorScripts,
                    children: /*#__PURE__*/ (0, _jsxruntime.jsx)(LoadingBoundary, {
                        name: debugNameToDisplay,
                        // TODO: The loading module data for a segment is stored on the
                        // parent, then applied to each of that parent segment's
                        // parallel route slots. In the simple case where there's only
                        // one parallel route (the `children` slot), this is no
                        // different from if the loading module data were stored on the
                        // child directly. But I'm not sure this actually makes sense
                        // when there are multiple parallel routes. It's not a huge
                        // issue because you always have the option to define a narrower
                        // loading boundary for a particular slot. But this sort of
                        // smells like an implementation accident to me.
                        loading: parentLoadingData,
                        children: /*#__PURE__*/ (0, _jsxruntime.jsx)(_errorboundary1.HTTPAccessFallbackBoundary, {
                            notFound: notFound,
                            forbidden: forbidden,
                            unauthorized: unauthorized,
                            children: /*#__PURE__*/ (0, _jsxruntime.jsxs)(_redirectboundary.RedirectBoundary, {
                                children: [
                                    /*#__PURE__*/ (0, _jsxruntime.jsx)(InnerLayoutRouter, {
                                        url: url,
                                        tree: tree,
                                        params: params,
                                        cacheNode: cacheNode,
                                        segmentPath: segmentPath,
                                        debugNameContext: childDebugNameContext,
                                        isActive: isActive && stateKey === activeStateKey
                                    }),
                                    segmentBoundaryTriggerNode
                                ]
                            })
                        })
                    })
                }),
                segmentViewStateNode
            ]
        });
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        let child = /*#__PURE__*/ (0, _jsxruntime.jsxs)(_approutercontextsharedruntime.TemplateContext.Provider, {
            value: templateValue,
            children: [
                templateStyles,
                templateScripts,
                template
            ]
        }, stateKey);
        if ("TURBOPACK compile-time truthy", 1) {
            const { SegmentStateProvider } = __turbopack_context__.r("[project]/node_modules/next/dist/next-devtools/userspace/app/segment-explorer-node.js [app-client] (ecmascript)");
            child = /*#__PURE__*/ (0, _jsxruntime.jsxs)(SegmentStateProvider, {
                children: [
                    child,
                    segmentViewBoundaries
                ]
            }, stateKey);
        }
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        children.push(child);
        bfcacheEntry = bfcacheEntry.next;
    }while (bfcacheEntry !== null)
    return children;
}
function getBoundaryDebugNameFromSegment(segment) {
    if (segment === '/') {
        // Reached the root
        return '/';
    }
    if (typeof segment === 'string') {
        if (isVirtualLayout(segment)) {
            return undefined;
        } else {
            return segment + '/';
        }
    }
    const paramCacheKey = segment[1];
    return paramCacheKey + '/';
}
function isVirtualLayout(segment) {
    return(// (like __PAGE__ and __DEFAULT__) to avoid collisions with
    // user-defined route groups.
    segment === '(__SLOT__)');
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/components/render-from-template-context.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return RenderFromTemplateContext;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _approutercontextsharedruntime = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)");
function RenderFromTemplateContext() {
    const children = (0, _react.useContext)(_approutercontextsharedruntime.TemplateContext);
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
        children: children
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/request/params.browser.dev.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createRenderParamsFromClient", {
    enumerable: true,
    get: function() {
        return createRenderParamsFromClient;
    }
});
const _reflect = __turbopack_context__.r("[project]/node_modules/next/dist/server/web/spec-extension/adapters/reflect.js [app-client] (ecmascript)");
const _reflectutils = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/utils/reflect-utils.js [app-client] (ecmascript)");
const CachedParams = new WeakMap();
function makeDynamicallyTrackedParamsWithDevWarnings(underlyingParams) {
    const cachedParams = CachedParams.get(underlyingParams);
    if (cachedParams) {
        return cachedParams;
    }
    // We don't use makeResolvedReactPromise here because params
    // supports copying with spread and we don't want to unnecessarily
    // instrument the promise with spreadable properties of ReactPromise.
    const promise = Promise.resolve(underlyingParams);
    const proxiedProperties = new Set();
    Object.keys(underlyingParams).forEach((prop)=>{
        if (_reflectutils.wellKnownProperties.has(prop)) {
        // These properties cannot be shadowed because they need to be the
        // true underlying value for Promises to work correctly at runtime
        } else {
            proxiedProperties.add(prop);
        }
    });
    const proxiedPromise = new Proxy(promise, {
        get (target, prop, receiver) {
            if (typeof prop === 'string') {
                if (proxiedProperties.has(prop)) {
                    const expression = (0, _reflectutils.describeStringPropertyAccess)('params', prop);
                    warnForSyncAccess(expression);
                }
            }
            return _reflect.ReflectAdapter.get(target, prop, receiver);
        },
        set (target, prop, value, receiver) {
            if (typeof prop === 'string') {
                proxiedProperties.delete(prop);
            }
            return _reflect.ReflectAdapter.set(target, prop, value, receiver);
        },
        ownKeys (target) {
            warnForEnumeration();
            return Reflect.ownKeys(target);
        }
    });
    CachedParams.set(underlyingParams, proxiedPromise);
    return proxiedPromise;
}
function warnForSyncAccess(expression) {
    console.error(`A param property was accessed directly with ${expression}. ` + `\`params\` is a Promise and must be unwrapped with \`React.use()\` before accessing its properties. ` + `Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`);
}
function warnForEnumeration() {
    console.error(`params are being enumerated. ` + `\`params\` is a Promise and must be unwrapped with \`React.use()\` before accessing its properties. ` + `Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`);
}
function createRenderParamsFromClient(clientParams) {
    return makeDynamicallyTrackedParamsWithDevWarnings(clientParams);
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/request/params.browser.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createRenderParamsFromClient", {
    enumerable: true,
    get: function() {
        return createRenderParamsFromClient;
    }
});
const createRenderParamsFromClient = ("TURBOPACK compile-time truthy", 1) ? __turbopack_context__.r("[project]/node_modules/next/dist/client/request/params.browser.dev.js [app-client] (ecmascript)").createRenderParamsFromClient : "TURBOPACK unreachable";
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/request/search-params.browser.dev.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createRenderSearchParamsFromClient", {
    enumerable: true,
    get: function() {
        return createRenderSearchParamsFromClient;
    }
});
const _reflect = __turbopack_context__.r("[project]/node_modules/next/dist/server/web/spec-extension/adapters/reflect.js [app-client] (ecmascript)");
const _reflectutils = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/utils/reflect-utils.js [app-client] (ecmascript)");
const CachedSearchParams = new WeakMap();
function makeUntrackedSearchParamsWithDevWarnings(underlyingSearchParams) {
    const cachedSearchParams = CachedSearchParams.get(underlyingSearchParams);
    if (cachedSearchParams) {
        return cachedSearchParams;
    }
    const proxiedProperties = new Set();
    const promise = Promise.resolve(underlyingSearchParams);
    Object.keys(underlyingSearchParams).forEach((prop)=>{
        if (_reflectutils.wellKnownProperties.has(prop)) {
        // These properties cannot be shadowed because they need to be the
        // true underlying value for Promises to work correctly at runtime
        } else {
            proxiedProperties.add(prop);
        }
    });
    const proxiedPromise = new Proxy(promise, {
        get (target, prop, receiver) {
            if (typeof prop === 'string') {
                if (!_reflectutils.wellKnownProperties.has(prop) && (proxiedProperties.has(prop) || // We are accessing a property that doesn't exist on the promise nor
                // the underlying searchParams.
                Reflect.has(target, prop) === false)) {
                    const expression = (0, _reflectutils.describeStringPropertyAccess)('searchParams', prop);
                    warnForSyncAccess(expression);
                }
            }
            return _reflect.ReflectAdapter.get(target, prop, receiver);
        },
        set (target, prop, value, receiver) {
            if (typeof prop === 'string') {
                proxiedProperties.delete(prop);
            }
            return Reflect.set(target, prop, value, receiver);
        },
        has (target, prop) {
            if (typeof prop === 'string') {
                if (!_reflectutils.wellKnownProperties.has(prop) && (proxiedProperties.has(prop) || // We are accessing a property that doesn't exist on the promise nor
                // the underlying searchParams.
                Reflect.has(target, prop) === false)) {
                    const expression = (0, _reflectutils.describeHasCheckingStringProperty)('searchParams', prop);
                    warnForSyncAccess(expression);
                }
            }
            return Reflect.has(target, prop);
        },
        ownKeys (target) {
            warnForSyncSpread();
            return Reflect.ownKeys(target);
        }
    });
    CachedSearchParams.set(underlyingSearchParams, proxiedPromise);
    return proxiedPromise;
}
function warnForSyncAccess(expression) {
    console.error(`A searchParam property was accessed directly with ${expression}. ` + `\`searchParams\` is a Promise and must be unwrapped with \`React.use()\` before accessing its properties. ` + `Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`);
}
function warnForSyncSpread() {
    console.error(`The keys of \`searchParams\` were accessed directly. ` + `\`searchParams\` is a Promise and must be unwrapped with \`React.use()\` before accessing its properties. ` + `Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`);
}
function createRenderSearchParamsFromClient(underlyingSearchParams) {
    return makeUntrackedSearchParamsWithDevWarnings(underlyingSearchParams);
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/client/request/search-params.browser.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createRenderSearchParamsFromClient", {
    enumerable: true,
    get: function() {
        return createRenderSearchParamsFromClient;
    }
});
const createRenderSearchParamsFromClient = ("TURBOPACK compile-time truthy", 1) ? __turbopack_context__.r("[project]/node_modules/next/dist/client/request/search-params.browser.dev.js [app-client] (ecmascript)").createRenderSearchParamsFromClient : "TURBOPACK unreachable";
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ "use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
            case REACT_VIEW_TRANSITION_TYPE:
                return "ViewTransition";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    var React = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        if (trackActualOwner) {
            var previousStackTraceLimit = Error.stackTraceLimit;
            Error.stackTraceLimit = 10;
            var debugStackDEV = Error("react-stack-top-frame");
            Error.stackTraceLimit = previousStackTraceLimit;
        } else debugStackDEV = unknownOwnerDebugStack;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStackDEV, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/next/dist/lib/metadata/generate/icon-mark.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "IconMark", {
    enumerable: true,
    get: function() {
        return IconMark;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const IconMark = ()=>{
    if (typeof window !== 'undefined') {
        return null;
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsx)("meta", {
        name: "\xabnxt-icon\xbb"
    });
};
}),
"[project]/node_modules/next/dist/server/web/spec-extension/adapters/reflect.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ReflectAdapter", {
    enumerable: true,
    get: function() {
        return ReflectAdapter;
    }
});
class ReflectAdapter {
    static get(target, prop, receiver) {
        const value = Reflect.get(target, prop, receiver);
        if (typeof value === 'function') {
            return value.bind(target);
        }
        return value;
    }
    static set(target, prop, value, receiver) {
        return Reflect.set(target, prop, value, receiver);
    }
    static has(target, prop) {
        return Reflect.has(target, prop);
    }
    static deleteProperty(target, prop) {
        return Reflect.deleteProperty(target, prop);
    }
}
}),
"[project]/node_modules/next/dist/shared/lib/router/utils/disable-smooth-scroll.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * Run function with `scroll-behavior: auto` applied to `<html/>`.
 * This css change will be reverted after the function finishes.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "disableSmoothScrollDuringRouteTransition", {
    enumerable: true,
    get: function() {
        return disableSmoothScrollDuringRouteTransition;
    }
});
function disableSmoothScrollDuringRouteTransition(fn, options = {}) {
    // if only the hash is changed, we don't need to disable smooth scrolling
    // we only care to prevent smooth scrolling when navigating to a new page to avoid jarring UX
    if (options.onlyHashChange) {
        fn();
        return;
    }
    const htmlElement = document.documentElement;
    const hasDataAttribute = htmlElement.dataset.scrollBehavior === 'smooth';
    if (!hasDataAttribute) {
        // Warn if smooth scrolling is detected but no data attribute is present
        if (("TURBOPACK compile-time value", "development") === 'development' && getComputedStyle(htmlElement).scrollBehavior === 'smooth') {
            const { warnOnce } = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/utils/warn-once.js [app-client] (ecmascript)");
            warnOnce('Detected `scroll-behavior: smooth` on the `<html>` element. To disable smooth scrolling during route transitions, ' + 'add `data-scroll-behavior="smooth"` to your <html> element. ' + 'Learn more: https://nextjs.org/docs/messages/missing-data-scroll-behavior');
        }
        // No smooth scrolling configured, run directly without style manipulation
        fn();
        return;
    }
    // Proceed with temporarily disabling smooth scrolling
    const existing = htmlElement.style.scrollBehavior;
    htmlElement.style.scrollBehavior = 'auto';
    if (!options.dontForceLayout) {
        // In Chrome-based browsers we need to force reflow before calling `scrollTo`.
        // Otherwise it will not pickup the change in scrollBehavior
        // More info here: https://github.com/vercel/next.js/issues/40719#issuecomment-1336248042
        htmlElement.getClientRects();
    }
    fn();
    htmlElement.style.scrollBehavior = existing;
}
}),
"[project]/node_modules/next/dist/shared/lib/utils/reflect-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This regex will have fast negatives meaning valid identifiers may not pass
// this test. However this is only used during static generation to provide hints
// about why a page bailed out of some or all prerendering and we can use bracket notation
// for example while `ಠ_ಠ` is a valid identifier it's ok to print `searchParams['ಠ_ಠ']`
// even if this would have been fine too `searchParams.ಠ_ಠ`
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    describeHasCheckingStringProperty: null,
    describeStringPropertyAccess: null,
    wellKnownProperties: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    describeHasCheckingStringProperty: function() {
        return describeHasCheckingStringProperty;
    },
    describeStringPropertyAccess: function() {
        return describeStringPropertyAccess;
    },
    wellKnownProperties: function() {
        return wellKnownProperties;
    }
});
const isDefinitelyAValidIdentifier = /^[A-Za-z_$][A-Za-z0-9_$]*$/;
function describeStringPropertyAccess(target, prop) {
    if (isDefinitelyAValidIdentifier.test(prop)) {
        return `\`${target}.${prop}\``;
    }
    return `\`${target}[${JSON.stringify(prop)}]\``;
}
function describeHasCheckingStringProperty(target, prop) {
    const stringifiedProp = JSON.stringify(prop);
    return `\`Reflect.has(${target}, ${stringifiedProp})\`, \`${stringifiedProp} in ${target}\`, or similar`;
}
const wellKnownProperties = new Set([
    'hasOwnProperty',
    'isPrototypeOf',
    'propertyIsEnumerable',
    'toString',
    'valueOf',
    'toLocaleString',
    // Promise prototype
    'then',
    'catch',
    'finally',
    // React Promise extension
    'status',
    // 'value',
    // 'error',
    // React introspection
    'displayName',
    '_debugInfo',
    // Common tested properties
    'toJSON',
    '$$typeof',
    '__esModule',
    // Tested by flight when checking for iterables
    '@@iterator'
]);
}),
"[project]/src/lib/audioEffect.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sounds",
    ()=>sounds
]);
/**
 * Synthesizes celebratory audio tones using the standard Web Audio API
 */ class SoundEffects {
    ctx = null;
    initCtx() {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (AudioCtx) {
                this.ctx = new AudioCtx();
            }
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
        return this.ctx;
    }
    playSuccess() {
        try {
            const ctx = this.initCtx();
            if (!ctx) return;
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(523.25, now); // C5
            osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.1); // E5
            osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.2); // G5
            osc.frequency.exponentialRampToValueAtTime(1046.50, now + 0.35); // C6
            gain.gain.setValueAtTime(0.15, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.55);
        } catch  {
        // Ignore audio failure
        }
    }
    playLevelUp() {
        try {
            const ctx = this.initCtx();
            if (!ctx) return;
            const now = ctx.currentTime;
            const notes = [
                440,
                554.37,
                659.25,
                880,
                1108.73
            ]; // A4, C#5, E5, A5, C#6
            notes.forEach((freq, i)=>{
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(freq, now + i * 0.08);
                gain.gain.setValueAtTime(0.12, now + i * 0.08);
                gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.4);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now + i * 0.08);
                osc.stop(now + i * 0.08 + 0.45);
            });
        } catch  {
        // Ignore audio failure
        }
    }
    playClick() {
        try {
            const ctx = this.initCtx();
            if (!ctx) return;
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, now);
            osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);
            gain.gain.setValueAtTime(0.05, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.06);
        } catch  {
        // Ignore audio failure
        }
    }
}
const sounds = new SoundEffects();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BADGES",
    ()=>BADGES,
    "CATEGORY_ICONS",
    ()=>CATEGORY_ICONS,
    "COLORS",
    ()=>COLORS,
    "LEVELS",
    ()=>LEVELS,
    "RECOGNITION_CATEGORIES",
    ()=>RECOGNITION_CATEGORIES,
    "ROLE_LABEL",
    ()=>ROLE_LABEL,
    "WEEKLY_TREND",
    ()=>WEEKLY_TREND
]);
const COLORS = {
    navy: '#12183A',
    navy2: '#1B2354',
    navy3: '#232C63',
    paper: '#F5F5FB',
    card: '#FFFFFF',
    amber: '#F3A712',
    amberDeep: '#C9840C',
    teal: '#0E8C82',
    coral: '#EF5A4C',
    plum: '#6C3FA0',
    ink: '#1B1C29',
    muted: '#6E7191',
    line: '#E7E7F2',
    emerald: '#10B981',
    sky: '#0EA5E9'
};
const LEVELS = [
    {
        level: 1,
        name: 'Beginner',
        min: 0
    },
    {
        level: 2,
        name: 'Learner',
        min: 400
    },
    {
        level: 3,
        name: 'Skilled',
        min: 800
    },
    {
        level: 4,
        name: 'Expert',
        min: 1200
    },
    {
        level: 5,
        name: 'Champion',
        min: 1600
    }
];
const BADGES = [
    {
        id: 'product-expert',
        name: 'Product Expert',
        icon: '🏅',
        desc: 'Completed all Product Knowledge modules',
        category: 'Product Knowledge'
    },
    {
        id: 'pos-pro',
        name: 'POS Pro',
        icon: '🎯',
        desc: 'Mastered digital POS training & zero billing errors',
        category: 'POS Training'
    },
    {
        id: 'customer-champion',
        name: 'Customer Champion',
        icon: '⭐',
        desc: 'Received 5+ positive customer feedbacks',
        category: 'Customer Service'
    },
    {
        id: 'learning-streak',
        name: 'Learning Streak',
        icon: '🔥',
        desc: 'Completed daily lessons 7 days in a row',
        category: 'General'
    },
    {
        id: 'team-player',
        name: 'Team Player',
        icon: '🤝',
        desc: 'Helped 3+ teammates and received peer recognition',
        category: 'Culture'
    },
    {
        id: 'top-performer',
        name: 'Top Performer',
        icon: '🏆',
        desc: 'Ranked Top 3 on the monthly leaderboard',
        category: 'Sales Skills'
    },
    {
        id: 'knowledge-seeker',
        name: 'Knowledge Seeker',
        icon: '📚',
        desc: 'Completed 5+ training modules and quizzes',
        category: 'General'
    },
    {
        id: 'problem-solver',
        name: 'Problem Solver',
        icon: '💡',
        desc: 'Resolved an escalated customer issue smoothly',
        category: 'Customer Service'
    }
];
const ROLE_LABEL = {
    employee: 'Store Associate',
    manager: 'Store Manager',
    admin: 'HR / Admin'
};
const CATEGORY_ICONS = {
    'Product Knowledge': '🪔',
    'Customer Service': '🗣️',
    'POS Training': '🧾',
    'Sales Skills': '📈',
    'Company Policies': '🛡️'
};
const RECOGNITION_CATEGORIES = [
    {
        name: 'Customer Service',
        icon: '🌟',
        color: COLORS.teal
    },
    {
        name: 'Teamwork',
        icon: '🤝',
        color: COLORS.plum
    },
    {
        name: 'Problem Solving',
        icon: '💡',
        color: COLORS.amberDeep
    },
    {
        name: 'Knowledge Sharing',
        icon: '📚',
        color: COLORS.navy3
    },
    {
        name: 'Sales Excellence',
        icon: '🎯',
        color: COLORS.coral
    }
];
const WEEKLY_TREND = [
    {
        week: 'Wk 1',
        engagement: 68,
        training: 55,
        pos: 60,
        cx: 62
    },
    {
        week: 'Wk 2',
        engagement: 72,
        training: 61,
        pos: 64,
        cx: 67
    },
    {
        week: 'Wk 3',
        engagement: 76,
        training: 68,
        pos: 70,
        cx: 73
    },
    {
        week: 'Wk 4',
        engagement: 84,
        training: 77,
        pos: 79,
        cx: 81
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/cxCalculator.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "avg",
    ()=>avg,
    "calculateCX",
    ()=>calculateCX,
    "getEmployeeName",
    ()=>getEmployeeName,
    "getInitials",
    ()=>getInitials,
    "getLevelInfo",
    ()=>getLevelInfo,
    "getStoreCity",
    ()=>getStoreCity,
    "getStoreName",
    ()=>getStoreName,
    "trainingPct",
    ()=>trainingPct
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/data/initialData.ts [app-client] (ecmascript)");
;
;
const avg = (arr)=>arr.length ? Math.round(arr.reduce((a, b)=>a + b, 0) / arr.length) : 0;
const trainingPct = (emp, modules = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRAINING_MODULES_INIT"])=>modules.length ? Math.round(emp.completedModules.length / modules.length * 100) : 0;
function getLevelInfo(points) {
    let current = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEVELS"][0];
    for (const l of __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEVELS"]){
        if (points >= l.min) {
            current = l;
        }
    }
    const idx = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEVELS"].findIndex((l)=>l.level === current.level);
    const next = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LEVELS"][idx + 1];
    const progressPct = next ? Math.min(100, Math.max(0, Math.round((points - current.min) / (next.min - current.min) * 100))) : 100;
    const pointsToNext = next ? Math.max(0, next.min - points) : 0;
    return {
        ...current,
        next,
        pointsToNext,
        progressPct
    };
}
function calculateCX(employees, modules = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRAINING_MODULES_INIT"]) {
    if (!employees.length) {
        return {
            score: 0,
            label: 'Needs Attention',
            color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].coral,
            trainingAvg: 0,
            posAvg: 0,
            feedbackAvg: 0,
            salesAvg: 0,
            engagementAvg: 0
        };
    }
    const trainingAvg = avg(employees.map((e)=>trainingPct(e, modules)));
    const posAvg = avg(employees.map((e)=>e.posAdoption));
    const feedbackAvg = avg(employees.map((e)=>e.customerFeedbackScore));
    const salesAvg = avg(employees.map((e)=>e.salesConversion));
    const engagementAvg = avg(employees.map((e)=>e.engagementScore));
    const weightedScore = Math.round(trainingAvg * 0.20 + posAvg * 0.25 + feedbackAvg * 0.25 + salesAvg * 0.15 + engagementAvg * 0.15);
    let label = 'Needs Attention';
    let color = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].coral;
    if (weightedScore >= 85) {
        label = 'Excellent';
        color = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].teal;
    } else if (weightedScore >= 70) {
        label = 'Good';
        color = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].amberDeep;
    }
    return {
        score: weightedScore,
        label,
        color,
        trainingAvg,
        posAvg,
        feedbackAvg,
        salesAvg,
        engagementAvg
    };
}
const getStoreCity = (stores, id)=>stores.find((s)=>s.id === id)?.city || '—';
const getStoreName = (stores, id)=>stores.find((s)=>s.id === id)?.name || '—';
const getEmployeeName = (employees, id)=>{
    const found = employees.find((e)=>e.id === id);
    if (found) return found.name;
    if (id === 'mgr1') return 'Anil Deshmukh';
    if (id === 'mgr2') return 'Rekha Menon';
    if (id === 'mgr3') return 'Sanjay Gupta';
    if (id === 'admin1') return 'Neha Kapoor';
    return 'Associate';
};
const getInitials = (name)=>name.split(' ').map((n)=>n[0]).slice(0, 2).join('').toUpperCase();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/data/initialData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ADMIN_INIT",
    ()=>ADMIN_INIT,
    "CHALLENGES_INIT",
    ()=>CHALLENGES_INIT,
    "CURRENT_EMPLOYEE_ID",
    ()=>CURRENT_EMPLOYEE_ID,
    "CURRENT_MANAGER_ID",
    ()=>CURRENT_MANAGER_ID,
    "EMPLOYEES_INIT",
    ()=>EMPLOYEES_INIT,
    "MANAGERS_INIT",
    ()=>MANAGERS_INIT,
    "NOTIFICATIONS_INIT",
    ()=>NOTIFICATIONS_INIT,
    "RECOGNITIONS_INIT",
    ()=>RECOGNITIONS_INIT,
    "STORES_INIT",
    ()=>STORES_INIT,
    "TRAINING_MODULES_INIT",
    ()=>TRAINING_MODULES_INIT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
;
const STORES_INIT = [
    {
        id: 's1',
        code: 'QF-STORE-104',
        name: 'QuestFloor Store #104 (Nagpur Hub)',
        city: 'Nagpur',
        state: 'Maharashtra',
        tier: 'Tier-3',
        activeAssociates: 24
    },
    {
        id: 's2',
        code: 'QF-IND-02',
        name: 'QuestFloor Indore Palasia Hub',
        city: 'Indore',
        state: 'Madhya Pradesh',
        tier: 'Tier-3',
        activeAssociates: 26
    },
    {
        id: 's3',
        code: 'QF-JPR-03',
        name: 'QuestFloor Jaipur Malviya Nagar',
        city: 'Jaipur',
        state: 'Rajasthan',
        tier: 'Tier-3',
        activeAssociates: 22
    },
    {
        id: 's4',
        code: 'QF-CBE-04',
        name: 'QuestFloor Coimbatore RS Puram',
        city: 'Coimbatore',
        state: 'Tamil Nadu',
        tier: 'Tier-3',
        activeAssociates: 20
    },
    {
        id: 's5',
        code: 'QF-PAT-05',
        name: 'QuestFloor Patna Boring Road',
        city: 'Patna',
        state: 'Bihar',
        tier: 'Tier-3',
        activeAssociates: 18
    }
];
const MANAGERS_INIT = [
    {
        id: 'mgr1',
        name: 'Priya Patel',
        title: 'Senior Store Manager (Store #104)',
        email: 'priya.patel@questfloor.in',
        stores: [
            's1',
            's2'
        ]
    },
    {
        id: 'mgr2',
        name: 'Rekha Menon',
        title: 'Cluster Manager',
        email: 'rekha.menon@questfloor.in',
        stores: [
            's3',
            's4'
        ]
    },
    {
        id: 'mgr3',
        name: 'Sanjay Gupta',
        title: 'Regional Operations Manager',
        email: 'sanjay.gupta@questfloor.in',
        stores: [
            's5'
        ]
    }
];
const ADMIN_INIT = {
    id: 'admin1',
    name: 'Neha Kapoor',
    title: 'Head of People & Workforce CX (1,200 Stores)',
    email: 'neha.kapoor@questfloor.in'
};
const CURRENT_EMPLOYEE_ID = 'e0';
const CURRENT_MANAGER_ID = 'mgr1';
const EMPLOYEES_INIT = [
    {
        id: 'e0',
        name: 'Amit Kumar',
        email: 'amit.kumar@questfloor.in',
        storeId: 's1',
        points: 1500,
        weeklyPoints: 350,
        monthlyPoints: 1100,
        posAdoption: 92,
        customerFeedbackScore: 94,
        salesConversion: 78,
        engagementScore: 92,
        badges: [
            'product-expert',
            'pos-pro',
            'team-player',
            'customer-champion',
            'learning-streak'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm4',
            'm5'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].navy2,
        joinDate: '2025-01-10'
    },
    {
        id: 'e1',
        name: 'Sneha Patil',
        email: 'sneha.patil@questfloor.in',
        storeId: 's1',
        points: 1480,
        weeklyPoints: 320,
        monthlyPoints: 890,
        posAdoption: 82,
        customerFeedbackScore: 91,
        salesConversion: 74,
        engagementScore: 88,
        badges: [
            'product-expert',
            'customer-champion',
            'team-player',
            'learning-streak',
            'knowledge-seeker'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm5',
            'm6',
            'm7',
            'm9'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].amber,
        joinDate: '2025-01-15'
    },
    {
        id: 'e2',
        name: 'Rahul Verma',
        email: 'rahul.verma@questfloor.in',
        storeId: 's1',
        points: 980,
        weeklyPoints: 180,
        monthlyPoints: 560,
        posAdoption: 58,
        customerFeedbackScore: 70,
        salesConversion: 60,
        engagementScore: 65,
        badges: [
            'team-player',
            'knowledge-seeker'
        ],
        completedModules: [
            'm2',
            'm5',
            'm7'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].teal,
        joinDate: '2025-03-10'
    },
    {
        id: 'e3',
        name: 'Ayesha Khan',
        email: 'ayesha.khan@questfloor.in',
        storeId: 's2',
        points: 640,
        weeklyPoints: 140,
        monthlyPoints: 400,
        posAdoption: 45,
        customerFeedbackScore: 66,
        salesConversion: 50,
        engagementScore: 55,
        badges: [
            'learning-streak'
        ],
        completedModules: [
            'm3',
            'm5'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].coral,
        joinDate: '2025-05-20'
    },
    {
        id: 'e4',
        name: 'Vikram Singh',
        email: 'vikram.singh@questfloor.in',
        storeId: 's2',
        points: 2150,
        weeklyPoints: 410,
        monthlyPoints: 1200,
        posAdoption: 93,
        customerFeedbackScore: 95,
        salesConversion: 88,
        engagementScore: 92,
        badges: [
            'product-expert',
            'pos-pro',
            'customer-champion',
            'top-performer',
            'knowledge-seeker',
            'team-player'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm4',
            'm5',
            'm6',
            'm7',
            'm8',
            'm9',
            'm10'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].plum,
        joinDate: '2024-11-01'
    },
    {
        id: 'e5',
        name: 'Priya Nair',
        email: 'priya.nair@questfloor.in',
        storeId: 's3',
        points: 1340,
        weeklyPoints: 260,
        monthlyPoints: 780,
        posAdoption: 71,
        customerFeedbackScore: 84,
        salesConversion: 69,
        engagementScore: 80,
        badges: [
            'customer-champion',
            'knowledge-seeker'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm4',
            'm6',
            'm7'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].navy3,
        joinDate: '2025-02-14'
    },
    {
        id: 'e6',
        name: 'Arjun Reddy',
        email: 'arjun.reddy@questfloor.in',
        storeId: 's3',
        points: 1620,
        weeklyPoints: 300,
        monthlyPoints: 900,
        posAdoption: 85,
        customerFeedbackScore: 88,
        salesConversion: 79,
        engagementScore: 84,
        badges: [
            'pos-pro',
            'product-expert',
            'knowledge-seeker'
        ],
        completedModules: [
            'm1',
            'm3',
            'm5',
            'm6',
            'm8',
            'm9'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].amberDeep,
        joinDate: '2024-12-05'
    },
    {
        id: 'e7',
        name: 'Meera Iyer',
        email: 'meera.iyer@questfloor.in',
        storeId: 's4',
        points: 1890,
        weeklyPoints: 350,
        monthlyPoints: 1020,
        posAdoption: 90,
        customerFeedbackScore: 93,
        salesConversion: 82,
        engagementScore: 89,
        badges: [
            'product-expert',
            'customer-champion',
            'pos-pro',
            'top-performer'
        ],
        completedModules: [
            'm1',
            'm2',
            'm3',
            'm4',
            'm5',
            'm6',
            'm8'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].teal,
        joinDate: '2024-09-18'
    },
    {
        id: 'e8',
        name: 'Karan Malhotra',
        email: 'karan.malhotra@questfloor.in',
        storeId: 's4',
        points: 860,
        weeklyPoints: 150,
        monthlyPoints: 480,
        posAdoption: 52,
        customerFeedbackScore: 62,
        salesConversion: 55,
        engagementScore: 58,
        badges: [
            'team-player'
        ],
        completedModules: [
            'm2',
            'm5'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].coral,
        joinDate: '2025-04-01'
    },
    {
        id: 'e9',
        name: 'Divya Sharma',
        email: 'divya.sharma@questfloor.in',
        storeId: 's5',
        points: 1210,
        weeklyPoints: 230,
        monthlyPoints: 700,
        posAdoption: 68,
        customerFeedbackScore: 80,
        salesConversion: 65,
        engagementScore: 76,
        badges: [
            'learning-streak',
            'team-player',
            'knowledge-seeker'
        ],
        completedModules: [
            'm1',
            'm2',
            'm5',
            'm6',
            'm7'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].plum,
        joinDate: '2025-02-28'
    },
    {
        id: 'e10',
        name: 'Suresh Kumar',
        email: 'suresh.kumar@questfloor.in',
        storeId: 's5',
        points: 420,
        weeklyPoints: 90,
        monthlyPoints: 250,
        posAdoption: 38,
        customerFeedbackScore: 58,
        salesConversion: 42,
        engagementScore: 48,
        badges: [],
        completedModules: [
            'm5'
        ],
        active: true,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLORS"].navy3,
        joinDate: '2025-06-12'
    }
];
const TRAINING_MODULES_INIT = [
    {
        id: 'm1',
        title: 'Festive Season Product Line-up',
        category: 'Product Knowledge',
        duration: '5 min',
        points: 100,
        emoji: '🪔',
        description: 'Get up to speed on this season’s ethnic wear, curated gifting hampers, and home lighting collections.',
        keyPoints: [
            'This festive range highlights premium cotton-silk ethnic wear, brass diya combos, and gourmet hampers.',
            'Diya and lantern combos are strategically priced under ₹499 for effortless impulse upselling.',
            'All gifting hampers can be custom-packed in-store — always highlight this customization option.',
            'Ethnic wear runs true-to-size; guide first-time buyers to the in-store digital size selector.'
        ],
        quiz: [
            {
                id: 'q1-1',
                q: 'What is the key selling proposition of the festive diya and lantern combos?',
                options: [
                    'They are imported from overseas',
                    'They are attractively priced under ₹499 for impulse checkout',
                    'They are strictly online-only',
                    'They require professional assembly'
                ],
                correct: 1,
                explanation: 'At ₹499, it fits the ideal impulse purchase price ceiling for festive shoppers.'
            },
            {
                id: 'q1-2',
                q: 'What complimentary service should you always mention regarding gifting hampers?',
                options: [
                    'They cannot be returned',
                    'Free in-store custom packing and personalization',
                    'They only come in a single fixed variant',
                    'They take 10 business days to dispatch'
                ],
                correct: 1,
                explanation: 'Customization adds perceived luxury value and increases repeat customer trust.'
            },
            {
                id: 'q1-3',
                q: 'How should you assist first-time ethnic wear shoppers with sizing?',
                options: [
                    'Advise them to buy 2 sizes larger',
                    'Show them the size chart & digital fit guide',
                    'Recommend online-only trials',
                    'Skip fitting room trials entirely'
                ],
                correct: 1,
                explanation: 'The digital fit guide eliminates return frictions and ensures customer satisfaction.'
            }
        ]
    },
    {
        id: 'm2',
        title: 'De-escalation & Handling Difficult Customers',
        category: 'Customer Service',
        duration: '4 min',
        points: 100,
        emoji: '🗣️',
        description: 'Actionable techniques to calmly de-escalate tension and transform frustrated shoppers into brand advocates.',
        keyPoints: [
            'Practice active silence: Listen completely without interrupting or jumping to defense.',
            'Empathize authentically: Paraphrase the customer concern in your own respectful words.',
            'Provide concrete solutions: Propose immediate resolution options rather than hollow apologies.',
            'Know your authority limit: Escalate smoothly to the Store Manager only when policy limits are reached.'
        ],
        quiz: [
            {
                id: 'q2-1',
                q: 'What is the critical first step when an agitated customer approaches the counter?',
                options: [
                    'Immediately offer a flat 20% discount',
                    'Listen attentively without interruption',
                    'Ring the manager bell immediately',
                    'Quote company policy clauses'
                ],
                correct: 1,
                explanation: 'Allowing the customer to feel heard immediately reduces emotional escalation.'
            },
            {
                id: 'q2-2',
                q: 'What must always follow empathetic acknowledgement of a customer’s issue?',
                options: [
                    'Politely ending the conversation',
                    'Offering a clear, actionable next step or solution',
                    'Assigning blame to the inventory logistics team',
                    'Asking them to email customer care'
                ],
                correct: 1,
                explanation: 'Actionable solutions rebuild trust and show genuine retail ownership.'
            },
            {
                id: 'q2-3',
                q: 'When is it appropriate to escalate an issue to your Store Manager?',
                options: [
                    'For every standard customer inquiry',
                    'When the required resolution exceeds your associate authorization level',
                    'Never under any circumstances',
                    'Only when explicitly asked by the customer'
                ],
                correct: 1,
                explanation: 'Store managers step in for policy overrides or financial refund approvals beyond store floor limits.'
            }
        ]
    },
    {
        id: 'm3',
        title: 'POS Basics: Fast Billing & QR Payments',
        category: 'POS Training',
        duration: '5 min',
        points: 120,
        emoji: '🧾',
        description: 'Master fast barcode scanning, promotional coupon application, and instant UPI/QR payments on the digital terminal.',
        keyPoints: [
            'Always scan barcodes directly — avoid manual SKU typing to prevent billing inaccuracies.',
            'Apply promotional offer vouchers prior to selecting the final payment tender.',
            'For returns without a physical receipt, retrieve transaction history via customer registered phone number.',
            'Perform end-of-shift digital cash drawer reconciliation without exception.'
        ],
        quiz: [
            {
                id: 'q3-1',
                q: 'Why does store policy mandate barcode scanning over manual SKU entry?',
                options: [
                    'To generate longer receipts',
                    'To eliminate pricing and inventory mismatch errors',
                    'It is an optional speed preference',
                    'To bypass manager audit logs'
                ],
                correct: 1,
                explanation: 'Manual entry has a 4.2% error rate, whereas optical barcode scans guarantee zero pricing discrepancy.'
            },
            {
                id: 'q3-2',
                q: 'At what point in the POS flow should promotional coupons and loyalty points be redeemed?',
                options: [
                    'After final card/UPI payment is authorized',
                    'Before choosing payment tender and calculating net total',
                    'Only on weekend shifts',
                    'Only for store managers'
                ],
                correct: 1,
                explanation: 'Applying discounts before checkout updates tax calculation and avoids payment reversal headaches.'
            },
            {
                id: 'q3-3',
                q: 'How can an associate verify purchase history if the customer misplaced their physical bill?',
                options: [
                    'Refuse the return flatly',
                    'Look up transaction history using their registered phone number',
                    'Ask them to re-purchase the item',
                    'Estimate the price manually'
                ],
                correct: 1,
                explanation: 'The omnichannel POS centralizes purchase logs by phone number across all 1,200 stores.'
            }
        ]
    },
    {
        id: 'm4',
        title: 'Upselling & Cross-merchandising Essentials',
        category: 'Sales Skills',
        duration: '4 min',
        points: 100,
        emoji: '📈',
        description: 'Learn consultative selling techniques that boost average basket size while delivering genuine value.',
        keyPoints: [
            'Recommend relevant accessories that complement what the customer already selected (e.g. matching dupatta or cufflinks).',
            'Frame every recommendation as value enhancement rather than added cost.',
            'Limit recommendations to 1–2 items to prevent decision paralysis.',
            'Always gracefully accept a customer decline without repeating the pitch.'
        ],
        quiz: [
            {
                id: 'q4-1',
                q: 'What should form the basis of a consultative upsell recommendation?',
                options: [
                    'Whatever item has the highest profit margin',
                    'Complementary utility to what the customer has already selected',
                    'Slow-moving dead stock regardless of category',
                    'Random trending items'
                ],
                correct: 1,
                explanation: 'Relevance ensures the customer sees the recommendation as thoughtful styling assistance.'
            },
            {
                id: 'q4-2',
                q: 'How many add-on items should an associate typically suggest during a single consultation?',
                options: [
                    '1 or 2 targeted items',
                    '5 or more to maximize conversion',
                    'As many as possible until they buy',
                    'Zero suggestions'
                ],
                correct: 0,
                explanation: '1 or 2 items keeps the experience delightful and avoids feeling pushy.'
            },
            {
                id: 'q4-3',
                q: 'What is the professional protocol when a customer says "No thank you" to an upsell suggestion?',
                options: [
                    'Repeat the offer with a bigger pitch',
                    'Respect the choice warmly and proceed with checkout',
                    'Call another associate to try again',
                    'Frown and walk away'
                ],
                correct: 1,
                explanation: 'Respectful acknowledgment preserves customer rapport and long-term loyalty.'
            }
        ]
    },
    {
        id: 'm5',
        title: 'Code of Conduct, Safety & Store Standards',
        category: 'Company Policies',
        duration: '5 min',
        points: 100,
        emoji: '🛡️',
        description: 'Core retail standards that ensure customer safety, associate dignity, and zero-compromise store security.',
        keyPoints: [
            'Standard neat uniform and visible QuestFloor associate badge are mandatory on the sales floor.',
            'Report safety hazards (spills, loose cables, blocked fire exits) to the shift lead within the same hour.',
            'Never export or share customer personal information outside authorized POS and CRM consoles.',
            'Zero tolerance policy applies to discrimination, harassment, or disrespectful conduct.'
        ],
        quiz: [
            {
                id: 'q5-1',
                q: 'Within what timeframe must a store floor safety hazard (e.g. liquid spill) be addressed and reported?',
                options: [
                    'At the end of the monthly audit',
                    'Immediately within the same shift/hour',
                    'Only if someone slips or falls',
                    'During weekly maintenance'
                ],
                correct: 1,
                explanation: 'Immediate containment prevents accidents and guarantees floor safety.'
            },
            {
                id: 'q5-2',
                q: 'Where can customer contact numbers collected at checkout be stored or shared?',
                options: [
                    'In personal WhatsApp groups',
                    'Exclusively inside the encrypted QuestFloor POS system',
                    'In a personal floor notebook',
                    'With third-party vendor associates'
                ],
                correct: 1,
                explanation: 'Data privacy compliance strictly forbids storing customer numbers on personal devices.'
            },
            {
                id: 'q5-3',
                q: 'What is QuestFloor’s policy regarding workplace harassment and discrimination?',
                options: [
                    'Evaluated case by case without penalty',
                    'Strict Zero Tolerance across all stores and roles',
                    'Only applicable to corporate HQ staff',
                    'Warning only for first 3 offenses'
                ],
                correct: 1,
                explanation: 'Zero tolerance protects all associates and maintains a dignified, safe workplace.'
            }
        ]
    },
    {
        id: 'm6',
        title: 'Seasonal Discounts, Combos & Clearance Tags',
        category: 'Product Knowledge',
        duration: '3 min',
        points: 80,
        emoji: '🏷️',
        description: 'Ensure 100% price quote accuracy on festive promotional combos, tiered savings, and clearance items.',
        keyPoints: [
            'Promotional combo discounts trigger automatically only when all combo SKUs are included in the same bill.',
            'Clearance red-tagged items are final sale — clearly inform customers prior to billing.',
            'Gold Club loyalty members receive an extra 5% instant discount during the festive campaign window.',
            'Shelf price tags indicate standard MRP; promotional prices reflect dynamically on the POS screen.'
        ],
        quiz: [
            {
                id: 'q6-1',
                q: 'When do promotional bundle/combo discounts apply?',
                options: [
                    'Across multiple days',
                    'When all qualifying items are billed together in a single transaction',
                    'Only for online orders',
                    'Only when approved by regional manager'
                ],
                correct: 1,
                explanation: 'Bundle rules require simultaneous scanning in the active checkout session.'
            },
            {
                id: 'q6-2',
                q: 'What policy applies to items marked with red Clearance Tags?',
                options: [
                    'Eligible for full refund within 30 days',
                    'Final sale — non-returnable unless defective',
                    'Can be exchanged at competitor stores',
                    'Free with purchase'
                ],
                correct: 1,
                explanation: 'Clearance inventory is final sale, and associates must kindly remind customers before payment.'
            },
            {
                id: 'q6-3',
                q: 'What extra benefit do Gold Club members enjoy during seasonal campaigns?',
                options: [
                    'Free store ownership',
                    'An extra 5% instant discount applied at billing',
                    'No payment required',
                    'Free delivery anywhere in India'
                ],
                correct: 1,
                explanation: 'Loyalty perks drive member engagement and incentivize higher annual spend.'
            }
        ]
    },
    {
        id: 'm7',
        title: 'Active Listening & Customer Engagement',
        category: 'Customer Service',
        duration: '3 min',
        points: 80,
        emoji: '👂',
        description: 'Subtle conversational habits that make shoppers feel respected, understood, and eager to return.',
        keyPoints: [
            'Confirm requirements by summarizing what the customer asked before walking to the aisle.',
            'Maintain polite eye contact and pause floor stocking tasks while a customer is speaking.',
            'Ask clarifying open-ended questions (e.g. "What occasion is this outfit for?") to narrow preferences.',
            'Express genuine gratitude for their time and specific choices.'
        ],
        quiz: [
            {
                id: 'q7-1',
                q: 'What is the most effective way to verify you understood a customer’s specific request?',
                options: [
                    'Guess based on what other customers bought',
                    'Summarize and repeat back the key preference to confirm',
                    'Assume you know best without confirmation',
                    'Wait for them to repeat it 3 times'
                ],
                correct: 1,
                explanation: 'Confirming key preferences prevents wasted aisle search time and builds instant rapport.'
            },
            {
                id: 'q7-2',
                q: 'What type of question best unlocks customer needs when they seem unsure?',
                options: [
                    'Yes/No closed questions',
                    'Open-ended questions about occasion, style, or budget preferences',
                    'Asking how much money they have in their wallet',
                    'Directing them to the exit'
                ],
                correct: 1,
                explanation: 'Open-ended questions encourage the customer to share details that guide perfect recommendations.'
            },
            {
                id: 'q7-3',
                q: 'How should you manage floor restocking tasks when a shopper approaches you?',
                options: [
                    'Continue stocking and talk over your shoulder',
                    'Pause the task, make eye contact, and give full attention',
                    'Ask the shopper to wait 15 minutes',
                    'Direct them to another aisle'
                ],
                correct: 1,
                explanation: 'Customer interaction on the sales floor always takes precedence over administrative stocking.'
            }
        ]
    },
    {
        id: 'm8',
        title: 'POS Advanced: Loyalty Redemption & Gift Cards',
        category: 'POS Training',
        duration: '5 min',
        points: 120,
        emoji: '💳',
        description: 'Flawlessly redeem digital gift cards, split tenders across UPI and cash, and manage loyalty points balance.',
        keyPoints: [
            'Loyalty points are credited based on the net payable amount after discount deductions.',
            'Gift card balances can be partially redeemed across multiple shopping trips until depleted.',
            'Always confirm the live remaining gift card balance on the customer-facing screen before completing transaction.',
            'Unused loyalty points carry a 12-month validity from the transaction date.'
        ],
        quiz: [
            {
                id: 'q8-1',
                q: 'On which amount are customer loyalty points calculated and credited?',
                options: [
                    'The original MRP before discounts',
                    'The net payable bill amount post discounts',
                    'The tax amount only',
                    'A fixed 10 points per bill'
                ],
                correct: 1,
                explanation: 'Points are awarded proportionally to the real revenue earned on the transaction.'
            },
            {
                id: 'q8-2',
                q: 'Can a QuestFloor gift card balance be split across multiple separate store visits?',
                options: [
                    'No, single-use only',
                    'Yes, until the available balance reaches zero',
                    'Only within the first 2 hours',
                    'Only if the manager enters a master key'
                ],
                correct: 1,
                explanation: 'Partial balances stay saved securely on the central gift card ledger.'
            },
            {
                id: 'q8-3',
                q: 'What is the standard validity period for QuestFloor customer loyalty reward points?',
                options: [
                    '30 days',
                    '12 months from the date of earning',
                    'They expire at the end of each week',
                    'They never expire'
                ],
                correct: 1,
                explanation: '12-month validity allows ample time for repeat purchases while encouraging annual shopping cycles.'
            }
        ]
    },
    {
        id: 'm9',
        title: 'Visual Merchandising & Impulse Displays',
        category: 'Sales Skills',
        duration: '4 min',
        points: 100,
        emoji: '✨',
        description: 'Keep entrance tables pristine, feature "Hero" products, and organize checkout impulse counters.',
        keyPoints: [
            'Follow the "Rule of Three": Group products in odd numbers (e.g. 3 candle holders) for higher visual attraction.',
            'Ensure high-margin impulse items near the billing queue are restocked at the start of each rush hour.',
            'Price tags must always face forward and be clearly visible without turning the product.',
            'Tidy folded apparel stacks every 45 minutes during high-traffic shifts.'
        ],
        quiz: [
            {
                id: 'q9-1',
                q: 'What is the "Rule of Three" in visual merchandising display design?',
                options: [
                    'Discounts must always be 33%',
                    'Grouping products in odd sets of three creates appealing focal visual balance',
                    'Only 3 customers allowed per aisle',
                    'Associates must work in groups of 3'
                ],
                correct: 1,
                explanation: 'Odd-number groupings capture human eye attention faster than even symmetric grids.'
            },
            {
                id: 'q9-2',
                q: 'When should checkout impulse counters be replenished?',
                options: [
                    'Only once a month',
                    'Before peak rush hour windows so shelves are never empty',
                    'Only after all items sell out completely',
                    'During store closing only'
                ],
                correct: 1,
                explanation: 'Full shelves at checkout create abundant impulse opportunities during queue wait times.'
            },
            {
                id: 'q9-3',
                q: 'How frequently should high-traffic apparel display tables be reorganized during festive rushes?',
                options: [
                    'Every 45 minutes to maintain crisp luxury presentation',
                    'Once a week',
                    'Never during store hours',
                    'Only if the manager requests it'
                ],
                correct: 0,
                explanation: 'Regular tidying preserves high customer perception and reduces checkout friction.'
            }
        ]
    },
    {
        id: 'm10',
        title: 'Data Privacy & Customer Information Security',
        category: 'Company Policies',
        duration: '4 min',
        points: 100,
        emoji: '🔒',
        description: 'Maintain ironclad customer trust by securing personal phone numbers, OTP authorizations, and receipts.',
        keyPoints: [
            'Only request information strictly required for billing, warranty registration, and e-receipts.',
            'Never write customer phone numbers on loose paper, scratchpads, or personal messaging apps.',
            'Always lock your POS terminal screen (press Ctrl+L) whenever leaving the billing counter unattended.',
            'Honor customer requests to opt-out of marketing SMS by updating their profile flag in the POS console.'
        ],
        quiz: [
            {
                id: 'q10-1',
                q: 'What should an associate do whenever stepping away from their active POS terminal?',
                options: [
                    'Leave the screen open for the next colleague',
                    'Lock the terminal screen immediately to protect customer data',
                    'Turn off the store power mains',
                    'Delete the daily transaction log'
                ],
                correct: 1,
                explanation: 'Terminal locking prevents unauthorized data viewing and maintains audit integrity.'
            },
            {
                id: 'q10-2',
                q: 'What is the correct protocol if a customer requests to opt-out of promotional marketing SMS?',
                options: [
                    'Tell them it is mandatory and cannot be disabled',
                    'Toggle the marketing opt-out preference in the POS customer profile',
                    'Ignore the request',
                    'Ask them to change their phone number'
                ],
                correct: 1,
                explanation: 'Respecting communication preferences adheres to data privacy laws and builds long-term brand goodwill.'
            },
            {
                id: 'q10-3',
                q: 'Can customer phone numbers be shared with external store vendors for promotional gifts?',
                options: [
                    'Yes, without restriction',
                    'Strictly prohibited under company data security policy',
                    'Only on festival holidays',
                    'Only if the gift value exceeds ₹500'
                ],
                correct: 1,
                explanation: 'Customer data must remain strictly confidential inside the protected enterprise perimeter.'
            }
        ]
    }
];
const CHALLENGES_INIT = [
    {
        id: 'c1',
        title: 'Complete Festive Season Product Line-up Training',
        type: 'daily',
        reward: 100,
        icon: 'BookOpen',
        desc: 'Finish the 5-minute module and score at least 60% on the quiz.',
        completedBy: [
            'e4',
            'e7'
        ]
    },
    {
        id: 'c2',
        title: 'Zero Billing & Scanning Errors this Week',
        type: 'weekly',
        reward: 150,
        icon: 'ClipboardList',
        desc: 'Keep all digital POS barcode scans 100% error-free.',
        completedBy: [
            'e4'
        ]
    },
    {
        id: 'c3',
        title: 'Recognize 2 Teammates with Positive Shoutouts',
        type: 'daily',
        reward: 50,
        icon: 'Heart',
        desc: 'Give appreciation to peers who assisted you on the store floor.',
        completedBy: []
    },
    {
        id: 'c4',
        title: 'Achieve 90%+ Digital POS Adoption Today',
        type: 'daily',
        reward: 80,
        icon: 'Zap',
        desc: 'Process nearly every floor checkout on the digital POS system.',
        completedBy: [
            'e4',
            'e7'
        ]
    },
    {
        id: 'c5',
        title: 'Collect 3 Verified 5-Star Customer Feedbacks',
        type: 'weekly',
        reward: 120,
        icon: 'Star',
        desc: 'Guide satisfied shoppers to submit quick digital feedback at checkout.',
        completedBy: []
    },
    {
        id: 'c6',
        title: 'Complete Any 2 Micro-Learning Modules',
        type: 'weekly',
        reward: 150,
        icon: 'GraduationCap',
        desc: 'Select any 2 lessons from the Learning Center to expand your skill set.',
        completedBy: [
            'e6'
        ]
    },
    {
        id: 'c7',
        title: 'Support a New Associate Onboarding Step',
        type: 'daily',
        reward: 60,
        icon: 'Users',
        desc: 'Demonstrate the fast UPI POS return flow to a junior peer.',
        completedBy: []
    },
    {
        id: 'c8',
        title: 'Suggest Consultative Upsells on 5 Bills',
        type: 'daily',
        reward: 90,
        icon: 'TrendingUp',
        desc: 'Apply the Upselling Essentials module recommendations on the floor.',
        completedBy: [
            'e4'
        ]
    },
    {
        id: 'c9',
        title: 'Zero Return Processing Delay this Week',
        type: 'weekly',
        reward: 100,
        icon: 'ShieldCheck',
        desc: 'Process all verified customer returns in under 2 minutes.',
        completedBy: []
    },
    {
        id: 'c10',
        title: 'Maintain a 7-Day Micro-Learning Streak',
        type: 'weekly',
        reward: 200,
        icon: 'Flame',
        desc: 'Complete at least one micro-lesson every single day this week.',
        completedBy: [
            'e1'
        ]
    }
];
const RECOGNITIONS_INIT = [
    {
        id: 'r1',
        fromId: 'e4',
        toId: 'e1',
        category: 'Customer Service',
        message: 'Sneha went above and beyond to help a family find matching festive outfits within their exact budget limit during the weekend rush!',
        likes: 14,
        time: '2h ago'
    },
    {
        id: 'r2',
        fromId: 'mgr1',
        toId: 'e6',
        category: 'Sales Excellence',
        message: 'Arjun closed 4 consultative combo upsells in a single evening shift — exceptional product knowledge application!',
        likes: 9,
        time: '4h ago'
    },
    {
        id: 'r3',
        fromId: 'e9',
        toId: 'e10',
        category: 'Teamwork',
        message: 'Suresh stepped in proactively to cover the gift wrapping counter during the 7 PM rush without being asked. Big lifesaver!',
        likes: 7,
        time: '1d ago'
    },
    {
        id: 'r4',
        fromId: 'e1',
        toId: 'e2',
        category: 'Knowledge Sharing',
        message: 'Rahul patiently walked me through the new split-tender POS payment flow step by step. Really appreciate the mentorship!',
        likes: 8,
        time: '1d ago'
    },
    {
        id: 'r5',
        fromId: 'e7',
        toId: 'e4',
        category: 'Problem Solving',
        message: 'Vikram calmly assisted an upset customer with an exchange and turned the interaction into a glowing 5-star Google review.',
        likes: 18,
        time: '2d ago'
    },
    {
        id: 'r6',
        fromId: 'mgr2',
        toId: 'e5',
        category: 'Customer Service',
        message: 'Priya’s detailed styling guidance for traditional festive wear resulted in repeat visits from three customer families!',
        likes: 11,
        time: '2d ago'
    }
];
const NOTIFICATIONS_INIT = [
    {
        id: 'n1',
        recipientId: 'e1',
        icon: 'Trophy',
        text: 'You climbed to #4 on the store leaderboard with 1,480 points!',
        time: '1h ago',
        read: false
    },
    {
        id: 'n2',
        recipientId: 'e1',
        icon: 'Award',
        text: 'You unlocked the "Learning Streak" badge for 7 consecutive days of micro-lessons.',
        time: '1d ago',
        read: false
    },
    {
        id: 'n3',
        recipientId: 'e1',
        icon: 'Heart',
        text: 'Vikram Singh gave you a shoutout for Customer Service.',
        time: '1d ago',
        read: false
    },
    {
        id: 'n4',
        recipientId: 'e1',
        icon: 'BookOpen',
        text: 'New training module available: "Visual Merchandising & Impulse Displays" (+100 XP).',
        time: '2d ago',
        read: true
    },
    {
        id: 'n5',
        recipientId: 'e1',
        icon: 'Target',
        text: 'New weekly challenge: Maintain zero return delays.',
        time: '3d ago',
        read: true
    },
    {
        id: 'n6',
        recipientId: 'mgr1',
        icon: 'AlertTriangle',
        text: 'Ayesha Khan (Indore Palasia) POS adoption dropped to 45% (below 55% threshold).',
        time: '3h ago',
        read: false
    },
    {
        id: 'n7',
        recipientId: 'mgr1',
        icon: 'Heart',
        text: 'Anil Deshmukh recognized Arjun Reddy for Sales Excellence.',
        time: '5h ago',
        read: true
    },
    {
        id: 'n8',
        recipientId: 'admin1',
        icon: 'Building2',
        text: 'QuestFloor Patna Boring Road is currently below target average training completion (38%).',
        time: '6h ago',
        read: false
    },
    {
        id: 'n9',
        recipientId: 'all',
        icon: 'Megaphone',
        text: 'Diwali Festival Mega-Campaign begins Monday! Complete your Festive Range training modules by Sunday.',
        time: '1d ago',
        read: true
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/store/useAppStore.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppProvider",
    ()=>AppProvider,
    "useAppStore",
    ()=>useAppStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$canvas$2d$confetti$2f$dist$2f$confetti$2e$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/canvas-confetti/dist/confetti.module.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/data/initialData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/cxCalculator.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/audioEffect.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const INITIAL_MISSIONS = [
    {
        id: 'sm-1',
        title: '⚡ Floor Speed Sprint: Reduce Billing Time below 90s',
        category: 'Speed',
        currentValue: 82,
        targetValue: 90,
        unit: 'sec avg',
        rewardXP: 300,
        icon: 'Zap',
        expiresIn: '4h 20m',
        isClaimed: false,
        description: 'Keep average digital POS scan & tender authorization under 90 seconds during peak shift.'
    },
    {
        id: 'sm-2',
        title: '🎯 Festive Pairing: Recommend 5 Diya & Kurta Combos',
        category: 'Sales',
        currentValue: 4,
        targetValue: 5,
        unit: 'upsells',
        rewardXP: 200,
        icon: 'TrendingUp',
        expiresIn: '6h 15m',
        isClaimed: false,
        description: 'Help shoppers pair traditional ethnic wear with ₹499 diya and lantern impulse combos.'
    },
    {
        id: 'sm-3',
        title: '⭐ Customer Delight: Maintain 90%+ 5-Star CSAT Rating',
        category: 'CSAT',
        currentValue: 94,
        targetValue: 90,
        unit: '% CSAT',
        rewardXP: 500,
        icon: 'Star',
        expiresIn: 'End of Shift',
        isClaimed: false,
        description: 'Ensure friendly hospitality greetings and zero pricing friction across all floor counters.'
    }
];
const INITIAL_FEEDBACK = [
    {
        id: 'fb-1',
        rating: 5,
        associateId: 'e1',
        storeId: 's1',
        helpful: true,
        selectedTags: [
            'Helpful Staff',
            'Polite Hospitality',
            'Clean Store'
        ],
        comment: 'Sneha explained the cotton-silk fabric quality and helped customize my Diwali gift hamper beautifully!',
        createdAt: '15 mins ago'
    },
    {
        id: 'fb-2',
        rating: 5,
        associateId: 'e4',
        storeId: 's2',
        helpful: true,
        selectedTags: [
            'Fast Billing',
            'Product Knowledge'
        ],
        comment: 'Super fast UPI QR checkout! Billed in under 45 seconds.',
        createdAt: '1h ago'
    },
    {
        id: 'fb-3',
        rating: 4,
        associateId: 'e6',
        storeId: 's3',
        helpful: true,
        selectedTags: [
            'Helpful Staff',
            'Product Knowledge'
        ],
        comment: 'Arjun recommended the perfect matching dupatta for my kurta set.',
        createdAt: '3h ago'
    },
    {
        id: 'fb-4',
        rating: 2,
        associateId: 'e2',
        storeId: 's1',
        helpful: false,
        selectedTags: [
            'Billing Queue Delay'
        ],
        comment: 'Had to wait 7 minutes at billing counter 2 because split payment took time.',
        createdAt: '5h ago'
    }
];
const INITIAL_VOUCHERS = [
    {
        id: 'rv-0',
        rewardId: 'rw-ccd',
        rewardTitle: '☕ Café Coffee Day Free Beverage Voucher',
        costXP: 500,
        code: 'QF-CCD-8492',
        redeemedAt: 'Yesterday',
        expiresAt: 'In 29 Days',
        status: 'Active'
    }
];
const AppContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const LOCAL_STORAGE_KEY = 'questfloor_store_v1';
function AppProvider({ children }) {
    _s();
    const [role, setRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [screen, setScreen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('dashboard');
    const [mobileOpen, setMobileOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [celebration, setCelebration] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isStoryModalOpen, setIsStoryModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeEmployeeId, setActiveEmployeeId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"]);
    const [employees, setEmployees] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPLOYEES_INIT"]);
    const [stores] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORES_INIT"]);
    const [managers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MANAGERS_INIT"]);
    const [admin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADMIN_INIT"]);
    const [trainingModules, setTrainingModules] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRAINING_MODULES_INIT"]);
    const [challenges, setChallenges] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHALLENGES_INIT"]);
    const [recognitions, setRecognitions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOGNITIONS_INIT"]);
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOTIFICATIONS_INIT"]);
    const [publishedQuizzes, setPublishedQuizzes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [redeemedVouchers, setRedeemedVouchers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(INITIAL_VOUCHERS);
    const [feedbackSubmissions, setFeedbackSubmissions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(INITIAL_FEEDBACK);
    const [storeMissions, setStoreMissions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(INITIAL_MISSIONS);
    // Load from local storage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppProvider.useEffect": ()=>{
            try {
                const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
                if (saved) {
                    const parsed = JSON.parse(saved);
                    if (parsed.employees) setEmployees(parsed.employees);
                    if (parsed.trainingModules) setTrainingModules(parsed.trainingModules);
                    if (parsed.challenges) setChallenges(parsed.challenges);
                    if (parsed.recognitions) setRecognitions(parsed.recognitions);
                    if (parsed.notifications) setNotifications(parsed.notifications);
                    if (parsed.publishedQuizzes) setPublishedQuizzes(parsed.publishedQuizzes);
                    if (parsed.redeemedVouchers) setRedeemedVouchers(parsed.redeemedVouchers);
                    if (parsed.feedbackSubmissions) setFeedbackSubmissions(parsed.feedbackSubmissions);
                    if (parsed.storeMissions) setStoreMissions(parsed.storeMissions);
                }
            } catch  {
            // LocalStorage access failed or not supported
            }
        }
    }["AppProvider.useEffect"], []);
    // Save to local storage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppProvider.useEffect": ()=>{
            try {
                const stateToSave = {
                    employees,
                    trainingModules,
                    challenges,
                    recognitions,
                    notifications,
                    publishedQuizzes,
                    redeemedVouchers,
                    feedbackSubmissions,
                    storeMissions
                };
                localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(stateToSave));
            } catch  {
            // LocalStorage save failed
            }
        }
    }["AppProvider.useEffect"], [
        employees,
        trainingModules,
        challenges,
        recognitions,
        notifications,
        publishedQuizzes,
        redeemedVouchers,
        feedbackSubmissions,
        storeMissions
    ]);
    const showToast = (message, icon = '✨')=>{
        const id = `toast-${Date.now()}`;
        setToast({
            id,
            message,
            icon
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playClick();
        setTimeout(()=>{
            setToast((prev)=>prev?.id === id ? null : prev);
        }, 3500);
    };
    const fireCelebration = (data)=>{
        setCelebration(data);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playLevelUp();
        if ("TURBOPACK compile-time truthy", 1) {
            try {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$canvas$2d$confetti$2f$dist$2f$confetti$2e$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    particleCount: 80,
                    spread: 70,
                    origin: {
                        y: 0.6
                    },
                    colors: [
                        '#F3A712',
                        '#0E8C82',
                        '#6C3FA0',
                        '#EF5A4C'
                    ]
                });
            } catch  {
            // Confetti fallback
            }
        }
        setTimeout(()=>{
            setCelebration(null);
        }, 2600);
    };
    const addNotification = (recipientId, icon, text)=>{
        const newNotif = {
            id: `n-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            recipientId,
            icon,
            text,
            time: 'Just now',
            read: false
        };
        setNotifications((prev)=>[
                newNotif,
                ...prev
            ]);
    };
    const currentEmployee = employees.find((e)=>e.id === activeEmployeeId) || employees[0];
    const currentManager = managers.find((m)=>m.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_MANAGER_ID"]) || managers[0];
    const handleLogin = (selectedRole)=>{
        setRole(selectedRole);
        setScreen('dashboard');
        const name = selectedRole === 'employee' ? currentEmployee?.name?.split(' ')[0] || 'Amit' : selectedRole === 'manager' ? 'Priya' : 'Neha';
        showToast(`Welcome back, ${name}!`, '👋');
    };
    const handleLogout = ()=>{
        setRole(null);
        setScreen('dashboard');
    };
    const finishModule = (moduleId, scorePct)=>{
        const emp = employees.find((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"]) || employees[0];
        const moduleDef = trainingModules.find((m)=>m.id === moduleId);
        if (!moduleDef) return {
            pointsEarned: 0,
            unlockedBadge: null
        };
        const alreadyDone = emp.completedModules.includes(moduleId);
        const pointsEarned = alreadyDone || scorePct < 60 ? 0 : moduleDef.points;
        const newCompleted = alreadyDone ? emp.completedModules : [
            ...emp.completedModules,
            moduleId
        ];
        let newBadges = [
            ...emp.badges
        ];
        let unlockedBadge = null;
        if (!alreadyDone && scorePct >= 60) {
            const nextBadge = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BADGES"].find((b)=>!emp.badges.includes(b.id));
            if (nextBadge) {
                newBadges.push(nextBadge.id);
                unlockedBadge = nextBadge;
            }
        }
        const beforeLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLevelInfo"])(emp.points);
        const afterLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLevelInfo"])(emp.points + pointsEarned);
        setEmployees((prev)=>prev.map((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"] ? {
                    ...e,
                    points: e.points + pointsEarned,
                    weeklyPoints: e.weeklyPoints + pointsEarned,
                    monthlyPoints: e.monthlyPoints + pointsEarned,
                    completedModules: newCompleted,
                    badges: newBadges
                } : e));
        if (!alreadyDone && scorePct >= 60) {
            addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'BookOpen', `Completed "${moduleDef.title}" — +${moduleDef.points} XP earned!`);
            if (unlockedBadge) {
                addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'Award', `New Badge Unlocked: ${unlockedBadge.name}!`);
                fireCelebration({
                    emoji: unlockedBadge.icon,
                    eyebrow: 'Badge Unlocked!',
                    title: unlockedBadge.name,
                    sub: unlockedBadge.desc
                });
            } else if (afterLevel.level > beforeLevel.level) {
                fireCelebration({
                    emoji: '🚀',
                    eyebrow: 'Level Up!',
                    title: `Level ${afterLevel.level} · ${afterLevel.name}`,
                    sub: 'Outstanding work! Keep building momentum.'
                });
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
                showToast(`Quiz Passed! +${pointsEarned} XP`, '🎉');
            }
        }
        return {
            pointsEarned,
            unlockedBadge
        };
    };
    const completeChallenge = (challengeId)=>{
        const ch = challenges.find((c)=>c.id === challengeId);
        if (!ch || ch.completedBy.includes(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"])) return;
        const emp = employees.find((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"]) || employees[0];
        const beforeLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLevelInfo"])(emp.points);
        const afterLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLevelInfo"])(emp.points + ch.reward);
        setChallenges((prev)=>prev.map((c)=>c.id === challengeId ? {
                    ...c,
                    completedBy: [
                        ...c.completedBy,
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"]
                    ]
                } : c));
        setEmployees((prev)=>prev.map((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"] ? {
                    ...e,
                    points: e.points + ch.reward,
                    weeklyPoints: e.weeklyPoints + ch.reward
                } : e));
        addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'Target', `Challenge Completed: "${ch.title}" (+${ch.reward} XP)`);
        if (afterLevel.level > beforeLevel.level) {
            fireCelebration({
                emoji: '🚀',
                eyebrow: 'Level Up!',
                title: `Level ${afterLevel.level} · ${afterLevel.name}`,
                sub: 'You crushed today\'s challenge!'
            });
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
            showToast(`Challenge Completed! +${ch.reward} XP`, '🎯');
        }
    };
    const giveRecognition = (fromId, toId, category, message)=>{
        const newRec = {
            id: `r-${Date.now()}`,
            fromId,
            toId,
            category,
            message,
            likes: 0,
            time: 'Just now'
        };
        setRecognitions((prev)=>[
                newRec,
                ...prev
            ]);
        const recipientName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEmployeeName"])(employees, toId);
        const senderName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cxCalculator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEmployeeName"])(employees, fromId);
        addNotification(toId, 'Heart', `${senderName} recognized you for ${category}: "${message.slice(0, 45)}…"`);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
        showToast(`Recognition shared with ${recipientName}!`, '👏');
    };
    const likeRecognition = (id)=>{
        setRecognitions((prev)=>prev.map((r)=>r.id === id ? {
                    ...r,
                    likes: r.likes + 1
                } : r));
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playClick();
    };
    const markNotificationsRead = (recipientId)=>{
        setNotifications((prev)=>prev.map((n)=>n.recipientId === recipientId || n.recipientId === 'all' ? {
                    ...n,
                    read: true
                } : n));
    };
    const nudgeEmployee = (emp)=>{
        addNotification(emp.id, 'AlertTriangle', `Manager Anil Deshmukh sent a reminder to complete your POS Training module.`);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playClick();
        showToast(`Training reminder sent to ${emp.name}.`, '📩');
    };
    const createChallenge = (ch)=>{
        const newCh = {
            id: `c-${Date.now()}`,
            title: ch.title,
            type: ch.type,
            reward: ch.reward,
            icon: 'Target',
            desc: 'Published organization-wide by HR & Admin.',
            completedBy: []
        };
        setChallenges((prev)=>[
                newCh,
                ...prev
            ]);
        addNotification('all', 'Target', `New Challenge Published: "${ch.title}" (+${ch.reward} XP)`);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
        showToast('New challenge published to all stores!', '🎯');
    };
    const publishAIQuiz = (draft)=>{
        const newModule = {
            id: `m-ai-${Date.now()}`,
            title: `${draft.product} Masterclass`,
            category: draft.skill,
            duration: `${draft.timeLimit} min`,
            points: draft.rewardPoints,
            emoji: '✨',
            description: `AI-generated micro-learning module focusing on ${draft.skill.toLowerCase()} for ${draft.product}.`,
            keyPoints: [
                `Master key consultation techniques for ${draft.product}.`,
                `Apply store guidelines to resolve customer doubts with empathy.`,
                `Accurately register product sales and warranties in the POS terminal.`
            ],
            quiz: draft.questions.map((q, idx)=>({
                    id: `q-mod-${idx}`,
                    q: q.prompt,
                    options: q.options,
                    correct: q.correct
                }))
        };
        setTrainingModules((prev)=>[
                newModule,
                ...prev
            ]);
        setPublishedQuizzes((prev)=>[
                draft,
                ...prev
            ]);
        createChallenge({
            title: draft.challengeTitle,
            type: 'weekly',
            reward: draft.rewardPoints
        });
        addNotification('all', 'Sparkles', `New AI Training live: "${newModule.title}" (+${draft.rewardPoints} XP)`);
        showToast(`AI Quiz & Challenge for "${draft.product}" published live!`, '🚀');
    };
    const sendAnnouncement = (text)=>{
        addNotification('all', 'Megaphone', text);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
        showToast('Announcement broadcasted to all 3,000 associates!', '📣');
    };
    const toggleEmployeeActive = (id)=>{
        setEmployees((prev)=>prev.map((e)=>e.id === id ? {
                    ...e,
                    active: !e.active
                } : e));
        showToast('Employee status updated.', '⚙️');
    };
    // 360-DEGREE ACTIONS
    const redeemReward = (reward)=>{
        if (currentEmployee.points < reward.costXP) {
            showToast(`Need ${reward.costXP - currentEmployee.points} more XP to redeem this reward.`, '⚠️');
            return false;
        }
        const code = `QF-${reward.category.slice(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
        const newVoucher = {
            id: `v-${Date.now()}`,
            rewardId: reward.id,
            rewardTitle: reward.title,
            costXP: reward.costXP,
            code,
            redeemedAt: 'Just now',
            expiresAt: 'In 30 Days',
            status: 'Active'
        };
        setEmployees((prev)=>prev.map((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"] ? {
                    ...e,
                    points: e.points - reward.costXP
                } : e));
        setRedeemedVouchers((prev)=>[
                newVoucher,
                ...prev
            ]);
        addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'Award', `Redeemed "${reward.title}" (Code: ${code})`);
        fireCelebration({
            emoji: '🎁',
            eyebrow: 'Reward Unlocked & Claimed!',
            title: reward.title,
            sub: `Voucher Code: ${code}`
        });
        return true;
    };
    const submitCustomerFeedback = (feedback)=>{
        const newFb = {
            ...feedback,
            id: `fb-${Date.now()}`,
            createdAt: 'Just now'
        };
        setFeedbackSubmissions((prev)=>[
                newFb,
                ...prev
            ]);
        // Boost associate CSAT slightly if 5-star
        if (feedback.rating === 5) {
            setEmployees((prev)=>prev.map((e)=>e.id === feedback.associateId ? {
                        ...e,
                        customerFeedbackScore: Math.min(99, e.customerFeedbackScore + 1)
                    } : e));
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$audioEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sounds"].playSuccess();
        showToast('Customer Voice & CSAT Feedback Recorded!', '⭐');
    };
    const claimMissionReward = (missionId)=>{
        const mission = storeMissions.find((m)=>m.id === missionId);
        if (!mission || mission.isClaimed) return;
        setStoreMissions((prev)=>prev.map((m)=>m.id === missionId ? {
                    ...m,
                    isClaimed: true
                } : m));
        setEmployees((prev)=>prev.map((e)=>e.id === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"] ? {
                    ...e,
                    points: e.points + mission.rewardXP,
                    weeklyPoints: e.weeklyPoints + mission.rewardXP
                } : e));
        addNotification(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_EMPLOYEE_ID"], 'Zap', `Store Mission Claimed: "${mission.title}" (+${mission.rewardXP} XP)`);
        fireCelebration({
            emoji: '🔥',
            eyebrow: 'Store Operational Mission Completed!',
            title: `+${mission.rewardXP} XP Claimed`,
            sub: mission.title
        });
    };
    const sendManagerAction = (empId, actionTitle, rewardXP)=>{
        const emp = employees.find((e)=>e.id === empId);
        if (!emp) return;
        if (rewardXP > 0) {
            setEmployees((prev)=>prev.map((e)=>e.id === empId ? {
                        ...e,
                        points: e.points + rewardXP,
                        weeklyPoints: e.weeklyPoints + rewardXP
                    } : e));
        }
        addNotification(empId, 'Award', `Manager Action: ${actionTitle} (+${rewardXP} XP)`);
        showToast(`Manager Action "${actionTitle}" dispatched to ${emp.name}!`, '🚀');
    };
    const resetDemoData = ()=>{
        setEmployees(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPLOYEES_INIT"]);
        setTrainingModules(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRAINING_MODULES_INIT"]);
        setChallenges(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHALLENGES_INIT"]);
        setRecognitions(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOGNITIONS_INIT"]);
        setNotifications(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOTIFICATIONS_INIT"]);
        setPublishedQuizzes([]);
        setRedeemedVouchers(INITIAL_VOUCHERS);
        setFeedbackSubmissions(INITIAL_FEEDBACK);
        setStoreMissions(INITIAL_MISSIONS);
        localStorage.removeItem(LOCAL_STORAGE_KEY);
        showToast('Demo data reset to default seed.', '🔄');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AppContext.Provider, {
        value: {
            role,
            screen,
            mobileOpen,
            setMobileOpen,
            currentEmployeeId: activeEmployeeId,
            setSelectedEmployeeId: setActiveEmployeeId,
            currentManagerId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2f$initialData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_MANAGER_ID"],
            currentEmployee,
            currentManager,
            admin,
            employees,
            stores,
            managers,
            trainingModules,
            challenges,
            recognitions,
            notifications,
            toast,
            celebration,
            publishedQuizzes,
            redeemedVouchers,
            feedbackSubmissions,
            storeMissions,
            isStoryModalOpen,
            setIsStoryModalOpen,
            setRole,
            setScreen,
            showToast,
            fireCelebration,
            handleLogin,
            handleLogout,
            finishModule,
            completeChallenge,
            giveRecognition,
            likeRecognition,
            markNotificationsRead,
            nudgeEmployee,
            createChallenge,
            publishAIQuiz,
            sendAnnouncement,
            toggleEmployeeActive,
            resetDemoData,
            redeemReward,
            submitCustomerFeedback,
            claimMissionReward,
            sendManagerAction
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/store/useAppStore.tsx",
        lineNumber: 644,
        columnNumber: 5
    }, this);
}
_s(AppProvider, "tK6BynkfMx9Q6XvIjnQotp9UrMU=");
_c = AppProvider;
function useAppStore() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AppContext);
    if (!context) {
        throw new Error('useAppStore must be used within an AppProvider');
    }
    return context;
}
_s1(useAppStore, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AppProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_0tl7n61._.js.map